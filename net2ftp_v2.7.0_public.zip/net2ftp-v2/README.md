# net2ftp v2 — web-based FTP, SFTP/SSH and Amazon S3 client

A modern rewrite of the net2ftp idea for a classic **Linux · Apache · MySQL · PHP** stack:
log in to any FTP, FTPS, SFTP/SSH server or Amazon S3 (or S3-compatible) storage and manage files from the browser.

- **Front-end**: a dependency-free single-page app (vanilla ES modules + CSS, about 38 KB gzipped in total). It uses a virtualized datagrid, caches folder listings, and preloads a folder while your pointer rests on it, so moving between folders doesn't reload the page.
- **Back-end**: PHP 8.1+ JSON API with three protocol drivers behind one interface. phpseclib (SFTP) is bundled, so you don't need Composer or PECL.
- **Database**: every user action is written to MySQL (`n2f_action_log`), like net2ftp's access log, together with daily consumption per IP and per server, software errors, security events and a block list. All of it can be viewed in the built-in admin panel.

## Features

| Area | What you get |
|---|---|
| Login | A portal page with the information pages in the top menu, **your remembered servers on the left** (one click fills in the form; with a saved password, only *Connect* is left. Each server remembers its port, passive/active mode, FTP or FTP over TLS, and **the last folder you worked in**, where the next login starts; a folder that no longer exists falls back to the initial folder), the login form on the right, and features below. FTP (passive/active), FTPS (explicit TLS), SFTP with password **or private key**, Amazon S3 (any region, optional bucket, session token) and S3-compatible endpoints (Exoscale SOS, Infomaniak, Wasabi, MinIO, Cloudflare R2…). With "Preferences" cookies allowed, connections are remembered including the password, in an encrypted HttpOnly cookie. |
| Cookie banner | GDPR/cookie banner on the first visit with Necessary (fixed), Preferences, Statistics, Personalized ads and Non-personalized ads. It can be reopened via "Cookie settings". The text and defaults are set in `config.php`. |
| Languages | English, Deutsch, Español, Français, Nederlands, Русский, 简体中文, 繁體中文, 日本語, עברית, العربية. Chosen on the login screen (the browser language is the default) and remembered in the `n2f_lang` cookie. Hebrew and Arabic get a **mirrored right-to-left layout**, while code, paths and fingerprints stay left-to-right. Server messages are translated too. |
| Bookmarks | Every page has a complete address, e.g. `#sftp://alice@example.com:2222/var/www/index.php?edit&line=12`, so browser bookmarks (Ctrl+D) and the **Copy link** buttons reopen that exact folder or file in the editor. **Passwords are never put in links.** Opening a link reconnects automatically when that connection's password is remembered; otherwise the login form is pre-filled and only the password is asked for. The part after `#` is never sent to the server, so links don't appear in server logs. |
| Server fingerprint | **Check server fingerprint** on the login screen shows an SFTP server's SSH host key, or an FTPS server's TLS certificate (issuer, validity, trusted or self-signed, name match), *before* the password is sent. It says whether the server is known, new, or **changed**. After you confirm, the login is pinned to that fingerprint: if the server presents another one, the password is not sent. PHP's FTP extension never verifies FTPS certificates itself, so this check is the only certificate check FTPS gets. |
| Browse | Datagrid with sorting, instant filter, multi-select (click, Ctrl/⌘-click, Shift-click, checkboxes), keyboard navigation, type-ahead, breadcrumbs, typed paths (Ctrl+L), back/forward buttons and deep links (`#/path`). Listings are cached and refreshed in the background, and folders are prefetched on hover. Large folders (10,000+ entries) render only the visible rows. |
| Upload | Drag and drop files **or whole folders** anywhere, or use the picker. Files are sent in chunks (so `upload_max_filesize` doesn't cap file size), 2 at a time (the per-session limit), with per-file and total progress, cancel, and an overwrite/skip prompt. **Each chunk goes straight on to the server** (no copy of the whole file on the web server), and **uploads resume**: after a network error automatically, and after a closed browser or a new login by choosing the same file again. See *Large transfers*. |
| Download | **Streamed** from the FTP/SSH/S3 server straight to the browser: the first bytes arrive at once, whatever the size. Supports HTTP ranges, so browsers can **resume** an interrupted download. Images and PDFs can be opened inline. |
| Zip | Download any mix of files and folders, recursively, as one `.zip` (with size and file-count limits). The zip is **streamed**: written while each file streams from the server, so it starts at once and nothing is stored on the web server. Text is compressed; images, video and archives are stored as they are. |
| Rename · Copy · Move · Delete | Recursive for folders, with a folder picker for the target. Copying and deleting folders, and moving them on S3, run as **jobs** of any size: scanned first, then worked on in short steps by 2 workers in parallel, with progress, speed, time left, pause, resume and cancel. A job **survives interruptions** (network, PHP timeouts, a closed browser) and continues after the next login. Moves on FTP/SFTP are a rename on the server, instant at any size. S3 uses server-side copy, in parts for objects over 5 GB. Copying into the same folder creates "name copy". |
| Permissions | **chmod / chown** for any selection of files and folders, optionally **recursive**, with separate modes for folders and files (e.g. 755 / 644), a read/write/execute grid synced with an octal field, and owner/group by name or numeric id (SFTP). FTP supports chmod only, S3 neither. The order is chosen so you never lock yourself out halfway: see below. Errors are collected and shown at the end instead of stopping the run. |
| Extract | **Unzip on the server**: `.zip`, `.tar`, `.tar.gz`/`.tgz`, `.tar.bz2`, into a new folder named after the archive or into the current folder, skipping or overwriting existing files. Works for FTP, SFTP and S3. Protected against "zip slip" (entries with `..` or absolute paths), zip bombs (size, file count and compression ratio are limited, and bytes are counted while unpacking) and symbolic links. Windows zip file names (CP437) are converted to UTF-8. |
| Share links | **Expiring download links, like WeTransfer.** Select files or folders → *Share*: they are copied to the web server and you get a link that works from 1 hour up to `shares.max_days` (7 days by default), with an optional password, maximum number of downloads and message. Recipients get a clean, translated download page (single files or *Download all* as zip) and **never get access to your server**. *Shares* in the top bar lists your links for the current connection, with copy and delete. Expired links and their files are deleted automatically. Programs and scripts (`.exe`, `.bat`, `.ps1` …, also inside a zip or renamed) can't be shared, and each visitor address has a storage quota. |
| Edit | Full-screen **syntax-highlighting editor** (CodeMirror 6, self-hosted, loaded on first use) for PHP, HTML, CSS, JavaScript/TypeScript, JSON, XML/SVG, Python, SQL, Markdown, YAML, shell, ini/.env/.htaccess, Perl, Ruby, Lua, Dockerfile and nginx. It has search & replace (Ctrl+F), code folding, bracket matching, multiple cursors, auto-indent, Ctrl+S and an unsaved-changes guard. It keeps the file's encoding (UTF-8/Latin-1), BOM and line endings, and warns if someone else changed the file on the server since you opened it. |
| Search | Recursive search in file **contents** or **names**, with optional case sensitivity, regular expressions and file-name patterns (`*.php *.js`). Results are grouped by file; click a line to open the editor at that line. |
| SSH terminal | For SFTP connections: run shell commands in the current folder (`cd` changes the browsed folder). If the current folder can't be entered, the command is not run and the shell's error is shown. Works with Unix shells, with Bitvise SSH Server's BvShell on Windows, and with minimal built-in shells such as Rebex's. Can be disabled. |
| Logging | Each action is logged with IP, user agent, protocol, server, user, folder, entries, target, bytes, item count, duration, status and error message. Plus daily consumption per IP and per server (with **daily limits**), grouped software errors (PHP and JavaScript), security events, and blocks. Old rows are deleted automatically. See *Logs and statistics*. |
| Information pages | `page.php` (with `edition` `'full'`; your own installation, `'reduced'`, keeps only the legal pages): **Screenshots**, **Features**, **Download** (lists packages you put in `public/downloads/`, with SHA-256), **How to use**, **Install**, **Report abuse** (form), **Privacy policy**, **GDPR request** (form) and **Disclaimer**. Server-rendered, no JavaScript, linked from the login page and every share page. All pages are available in the eleven languages; the legal pages (privacy policy, disclaimer) say that the English text is the reference and link to it. |
| Admin | `admin.php`, protected by password, two-factor code, lockout and an optional IP allowlist: dashboard with charts, access log, **Investigate** (for abuse and GDPR requests, with CSV export), consumption, blocks, errors, security events, share links, the abuse/GDPR inbox, SSH host keys, system check, cleanup job and maintenance mode. See *Admin panel*. |

### Why the chmod order matters

Changing a whole tree recursively can lock you out halfway: once a folder loses its owner read (r) or execute (x) bit, its contents can no longer be listed, so the rest of the tree can't be changed. net2ftp picks the order per folder:

- **New folder mode keeps owner read + execute** (e.g. 755, 750, 700): the folder is changed **first**, then its contents. This also *restores* access to a locked folder (e.g. 000 → 755) before descending into it.
- **New folder mode takes it away** (e.g. 600, 000): the contents are changed **first** and the folder **last**. The dialog warns that you won't be able to open the folder afterwards.
- **Owner/group** changes are always done children-first, because after giving a folder away you may lose the right to change what's inside it.
- Symbolic links are never followed, so a link can't take the change outside the selected tree.

## Requirements

- Linux with **Apache 2.4** (with mod_php or PHP-FPM). nginx + PHP-FPM also works.
- **PHP 8.1 or newer**.
- **MySQL 5.7+ or MariaDB 10.3+** for the action log (optional, see below).

Full install on Debian/Ubuntu: `apt install php php-curl php-zip php-mbstring php-mysql php-xml`. The `ftp`, `sodium` and `openssl` extensions are built in there.

### What happens when something is missing

net2ftp checks its environment on every page load and **degrades gracefully**. It never shows a blank page or a raw PHP error. Users see a message such as *net2ftp requires the PHP extension "ftp" but it is not installed. Please contact the administrator.*

The message says which of four situations applies, because each needs a different fix:

| Message | Meaning | Fix |
|---|---|---|
| … *is not installed* | No extension file in `extension_dir` | Install it (`apt install php-curl`, or copy `php_curl.dll` into `ext\`) |
| … *is installed but not enabled in php.ini* | The file exists, but no `extension=` line loads it | Add `extension=curl` to the php.ini the web server uses, restart |
| … *is enabled in php.ini, but PHP could not load it* | PHP tried and failed. On **Windows** this almost always means a DLL the extension needs can't be found (for curl: `libssh2.dll`, `nghttp2.dll`, `libcrypto-*.dll`, `libssl-*.dll` from the PHP folder) | Add the PHP folder (e.g. `C:\PHP`) to the **system** PATH and restart Windows, or load the DLLs in `httpd.conf` with `LoadFile "C:/PHP/libssh2.dll"` etc. The Apache error log shows *PHP Startup: Unable to load dynamic library* with the exact file |
| … *the PHP function "x" … is disabled* | The extension is loaded, but `disable_functions` blocks a function | Remove it from `disable_functions` |

`admin.php` → System check shows the details (which php.ini, which file, which DLLs are next to PHP).

| Missing | Effect |
|---|---|
| PHP not installed/enabled, PHP-FPM down, `api.php` not found, Apache unreachable | The login screen says exactly that (detected by the browser) |
| PHP older than 8.1 | Clear message from `api.php` / `admin.php` (the entry files are parseable by old PHP versions) |
| PHP `session` or `filter`, both `sodium` **and** `openssl`, a writable `storage/tmp` folder, a writable session folder | **net2ftp cannot start.** The login form is replaced by the list of problems |
| PHP `ftp` | FTP tab disabled with the message. SFTP and S3 still work |
| `ftp` built without OpenSSL | The "FTP over TLS" switch is disabled |
| PHP `curl` or `simplexml` (or `curl_exec` disabled) | Amazon S3 tab disabled with the message |
| `fsockopen` disabled, or `lib/phpseclib` missing | SFTP/SSH tab disabled with the message |
| PHP `zip` | "Download as zip" shows the message, zip archives can't be extracted. Everything else works |
| PHP `phar` / `zlib` / `bz2` | `.tar` / `.tar.gz` / `.tar.bz2` archives can't be extracted (the message names the extension) |
| A writable `storage/shares` folder | Share links are hidden, with the reason on the admin page |
| MySQL down, wrong credentials, database or tables missing, `pdo`/`pdo_mysql` missing | Works without logging, with a notice on the login screen naming the reason. Set `'log_required' => true` to refuse service instead (strict audit) |
| `sodium` only | Credentials are encrypted with OpenSSL AES-256-GCM instead |
| `mbstring`, `fileinfo`, `iconv`, `gmp`/`bcmath` | Built-in fallbacks (slower or less precise). Shown as warnings to the admin only |
| Disabled functions (`set_time_limit`, `ini_set`, `tempnam`, `escapeshellarg`, `dns_get_record`, `fnmatch`…) | Built-in fallbacks |
| Apache `mod_headers`, `mod_deflate`, `mod_dir`, `mod_php`, or `AllowOverride None` | Every `.htaccess` directive is wrapped in `<IfModule>`, so nothing breaks. You only lose the extra headers and compression. PHP-FPM reads `public/.user.ini` instead |

**Checking a server:** open `admin.php` → **System check**, which shows every component as OK / Warning / Missing as seen by the web server. Or run `php bin/check.php` on the command line. Note that command-line PHP can use a different php.ini than Apache, so the admin page is the authoritative check.

## Installation

```bash
# 1. Put the files on the server (outside the existing web root)
sudo mkdir -p /var/www/net2ftp && sudo unzip net2ftp-v2.zip -d /var/www/   # → /var/www/net2ftp-v2
cd /var/www/net2ftp-v2

# 2. Database
sudo mysql -e "CREATE DATABASE net2ftp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
sudo mysql -e "CREATE USER 'net2ftp'@'localhost' IDENTIFIED BY 'a-strong-password';
               GRANT SELECT, INSERT, UPDATE, DELETE ON net2ftp.* TO 'net2ftp'@'localhost'"
sudo mysql net2ftp < sql/schema.sql

# 3. Configuration
cp config.sample.php config.php
php -r "echo base64_encode(random_bytes(32)), PHP_EOL;"           # paste into 'secret_key'
php -r "echo password_hash('admin-password', PASSWORD_DEFAULT), PHP_EOL;"  # paste into 'admin_password_hash' (optional)
php bin/admin-2fa.php                                              # two-factor code for admin.php: paste into 'admin_totp_secret'
nano config.php                                                    # set db password, limits, allowed servers…

# 4. Permissions: PHP must be able to write storage/
sudo chown -R www-data:www-data storage
sudo chmod 750 storage storage/tmp          # storage/shares is created automatically

# 5. Cleanup job (recommended; then set 'housekeeping' => ['mode' => 'cron'] in config.php)
sudo crontab -u www-data -e      # add the line:  17 * * * *  php /var/www/net2ftp-v2/bin/cleanup.php --quiet
```

### Upgrading from 2.6 to 2.7

No database changes and no new settings. Copy the new files over the old ones and keep your `config.php`.
- **Guides** (edition `'full'` only): a new menu item with 9 pages in all 11 languages: five pages on what net2ftp is used for (online FTP client, web SFTP client, Amazon S3 in the browser, editing files online, uploading large files), questions and answers, and three articles (active and passive FTP, FTP vs FTPS vs SFTP, moving a website). They are in the sitemap and carry structured data for search engines (`FAQPage`, `Article`, `SoftwareApplication`). The login page links to the questions and answers. Own installations (`'reduced'`) don't show them.
- **The login page has an address per language** (`/?hl=de`, `/?hl=ja` …), like the information pages: it opens in that language, sets the canonical address and the links to the other language versions, and the sitemap lists all of them. Search engines can now index the login page in every language. `/` without `hl` still follows the cookie or the browser's language.
- Guide pages are plain text in `src/pages/<lang>/<slug>.php` (a `$doc` array) with one shared layout, `src/pages/_shared/guide.php`; see the comment at the top of that file to add or change one.

### Upgrading from 2.5 to 2.6

No database changes. Copy the new files over the old ones and keep your `config.php`.
- **Running a test version next to production** is now supported, on its own host name or in a sub-folder of the same site: see *Production and test side by side*. New optional settings: `site.noindex`, `site.label`, `site.robots_disallow`.
- **Cookies in a sub-folder:** an installation that is *not* at the root of its site (e.g. `https://example.com/net2ftp/`) now names its cookies after the folder and limits them to it. After the upgrade its visitors are asked once more for their cookie choice and language, and remembered servers have to be saved again. Installations at the root of a site are not affected.
- The footer says **"Powered by net2ftp"** with a link to net2ftp.com instead of the version number (the version is in Admin → System).
- New texts on the login page (features, questions and answers), and new screenshots (copy jobs, resuming uploads, SSH terminal).

2.6.1 fixes one problem found on net2ftp.com: when an FTP server (or a firewall in front of it) never answered the request for passive mode, the visitor got an internal server error (HTTP 500) and the error was logged in Admin → Errors. net2ftp now shows *"&lt;server&gt; did not answer the request for passive mode. Log in again with passive mode turned off."* (HTTP 502), in all languages.

### Upgrading from 2.4 (or 2.5.x)

2.5.2 fixes three problems found on a public test installation (Ubuntu, PHP with `open_basedir`, against ftp.dlptest.com and test.rebex.net):
- **FTP:** after a transfer that failed or timed out, net2ftp kept using the same control connection. A late reply from the server was then read as the answer to the next command, e.g. *Could not rename … (Entering Passive Mode …)* at the end of an upload. Now the connection is dropped after any failed transfer and the next command uses a fresh one.
- **SSH commands on minimal shells:** on Unix shells net2ftp runs `cd <folder> && { command }`. Some SSH servers have a minimal built-in shell without `{ … }` (e.g. the Rebex demo server) and silently returned nothing. net2ftp now tries a tiny group once per session and server, and uses `cd <folder> && command` when the shell doesn't run it.
- **`open_basedir`:** the FTPS certificate check failed with an error when the system's CA bundle (`/usr/lib/ssl/cert.pem`) is outside `open_basedir`; it now reports the certificate as not verified. A session folder outside `open_basedir` is reported clearly instead of with an error.

2.5.1 fixes a Windows-only error in jobs: a step could fail with "Access is denied (code: 5)" when two workers touched the job's state at the same moment (the job carried on at the next step).

No database changes. Copy the new files over the old ones and keep your `config.php`. The new settings are optional: `disk_quota`, `shares.blocked_types`, `shares.block_programs`, `s3_copy_part_threshold` and `s3_copy_part_size` (see *Configuration*). Note:
- Share links refuse programs and scripts by default; set `'blocked_types' => []` and `'block_programs' => false` under `shares` to allow every file type.
- `index.html` now carries its own Content-Security-Policy. If you added scripts from other sites (statistics, ads), allow them there **and** in `public/.htaccess`.
- Zip downloads no longer need PHP's zip extension (extracting archives still does).

### Upgrading from 2.3

No database changes. Copy the new files over the old ones and keep your `config.php`. The new settings `connections_per_server` and `jobs` are optional (defaults: 4 connections, 2 workers, 15-second steps). If PHP's `upload_max_filesize` is below 6 MB, raise it to 16M (and `post_max_size` to 20M): uploads then need fewer requests, and S3 uploads can resume.

### Upgrading from 2.2

```bash
mysql net2ftp < sql/upgrade-2.3.sql   # adds file_hash + indexes to n2f_action_log
mysql net2ftp < sql/schema.sql        # creates the 4 new tables (existing tables are left alone)
```

Then add the new keys from `config.sample.php` (`daily_limits`, `mass_upload`, `admin_*`) to your `config.php`. Until the database is upgraded, net2ftp keeps working without the new logs, and `admin.php` shows these instructions.

### Apache virtual host

The **DocumentRoot must be `public/`**, so `src/`, `lib/`, `config.php` and `storage/` are never reachable over HTTP.

```apache
<VirtualHost *:443>
    ServerName files.example.com
    DocumentRoot /var/www/net2ftp-v2/public

    <Directory /var/www/net2ftp-v2/public>
        AllowOverride All
        Require all granted
    </Directory>

    SSLEngine on
    SSLCertificateFile    /etc/letsencrypt/live/files.example.com/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/files.example.com/privkey.pem
</VirtualHost>
```

`public/.htaccess` sets security headers (CSP, nosniff, frame-deny), caching and compression. If you use PHP-FPM instead of mod_php, put these into `php.ini` or the pool config:

```ini
upload_max_filesize = 16M   ; browser sends 8 MB chunks — this only needs to exceed one chunk
post_max_size       = 20M
max_execution_time  = 300   ; zip, recursive copy and search on big trees (= config max_execution_time)
memory_limit        = 256M
```

Always serve the app over **HTTPS**: users type server passwords into it.

### Production and test side by side

You can run two (or more) installations on one server, e.g. the **production** version on `www.example.com` and a **test** version on `test.example.com` or `www.example.com/test/`. Each installation is a complete, separate copy:

```
/var/www/example.com/
    production/          ← www.example.com          (its own config.php, storage/, database)
    test/                ← test.example.com  or  www.example.com/test/
```

**What keeps them apart:**
- **Files:** `config.php`, `storage/` (secret key, temporary files, share links, form submissions) and the cleanup job are per folder. Install the cron line once per installation.
- **Database:** give each installation its own database (e.g. `net2ftp` and `net2ftp_test`), so logs, limits and blocks don't mix:
  ```bash
  sudo mysql -e "CREATE DATABASE net2ftp_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
                 GRANT SELECT, INSERT, UPDATE, DELETE ON net2ftp_test.* TO 'net2ftp'@'localhost'"
  sudo mysql net2ftp_test < /var/www/example.com/test/sql/schema.sql
  ```
- **Browser:** on its own host name (`test.example.com`) the browser keeps everything apart by itself. In a sub-folder of the same site, net2ftp names its cookies after the folder and limits them to it: production keeps `N2FSESSID`, `n2f_saved`, `n2f_consent`, `n2f_lang`; the test version at `/test/` uses `N2FSESSID_test`, `n2f_saved_test` …, so the two never share a session, remembered servers, cookie choice or language. Nothing changes for an installation at the root of its site.
- **Search engines:** in the test version's `config.php`, set `'site' => ['noindex' => true, 'label' => 'TEST', …]`. Every page then says "noindex", `robots.txt` disallows everything, there is no sitemap, and an orange **TEST** badge next to the logo (and `[TEST]` in the window title) shows which version you are in. A test version in a sub-folder is also excluded by the production installation's `robots.txt`: set `'robots_disallow' => ['/test/']` in production (search engines only read `robots.txt` at the root of a domain). For a test host name, also add `Header always set X-Robots-Tag "noindex, nofollow"` to its virtual host, which covers the static `index.html` too.

**Apache, test on its own host name** (recommended: the cleanest separation):
```apache
<VirtualHost *:443>
    ServerName test.example.com
    DocumentRoot /var/www/example.com/test/public
    <Directory /var/www/example.com/test/public>
        AllowOverride All
        Require all granted
    </Directory>
    Header always set X-Robots-Tag "noindex, nofollow"
    # SSL… (sudo certbot --apache -d test.example.com)
</VirtualHost>
```

**Apache, test in a sub-folder** of the production site (inside the `www.example.com` virtual host):
```apache
Alias /test /var/www/example.com/test/public
<Directory /var/www/example.com/test/public>
    AllowOverride All
    Require all granted
</Directory>
```
With an `Alias`, the two rewrite rules in `public/.htaccess` (pretty `robots.txt` and `sitemap.xml` addresses) don't apply in the sub-folder; a test version doesn't need them.

**PHP `open_basedir`:** if you use it, allow the parent folder of both installations (e.g. `/var/www/example.com/`) and the session folder.

**Promoting the test version to production** (after testing a new release in `test/`):
```bash
cd /var/www/example.com
sudo mkdir production.new && sudo unzip -q net2ftp-v2.zip -d /tmp/n2f && sudo cp -a /tmp/n2f/net2ftp-v2/. production.new/
sudo cp -a production/config.php production.new/                       # production's own settings
sudo rm -rf production.new/storage && sudo cp -a production/storage production.new/   # its key, shares, temp files
sudo mv production production.old && sudo mv production.new production   # switch (undo: swap back)
sudo systemctl reload apache2      # or php-fpm, to clear the opcode cache
```
Database changes, if a release has any, are listed under *Upgrading* and must be applied to the production database too.

## Configuration (`config.php`)

| Key | Default | Meaning |
|---|---|---|
| `edition` | `'reduced'` | `'full'` = the net2ftp.com website: login page with the feature sections and links, plus the Screenshots, Features, Download, How to use and Install pages. `'reduced'` = **your own installation**: a lightweight login page (intro, remembered servers, login form) and only the legal pages (privacy policy, disclaimer, abuse and GDPR forms); links to the product pages go to the login page. Without the setting (older `config.php`): `'full'` |
| `protocols` | `['ftp','sftp','s3']` | Protocols offered on the login screen |
| `db` | — | PDO DSN, user and password for MySQL |
| `log_enabled` / `log_retention_days` | `true` / `90` | Action logging and automatic purge |
| `log_required` | `false` | `true` = refuse service while the database is unavailable, instead of continuing without logging |
| `secret_key` | auto | Key that encrypts credentials inside the PHP session (auto-generated in `storage/secret.key` if empty) |
| `session_timeout` | `1800` | Idle seconds before the user must log in again |
| `block_private_networks` | `true` | Refuse connections to 127.0.0.0/8, 10/8, 192.168/16, 169.254/16, … (SSRF protection: otherwise any visitor could reach machines in your internal network or the cloud metadata service) |
| `private_network_exceptions` | `['localhost']` | Private or local servers that are allowed anyway: IP addresses, ranges or host names. The default `['localhost']` allows FTP, FTPS, SFTP and SSH to the machine net2ftp runs on (`localhost`, 127.0.0.1 and ::1); remove it if that machine runs FTP or SSH services visitors must not reach. More examples: `['192.168.1.20', 'nas.lan']` for one LAN server, `['10.0.5.0/24']` for a subnet. Everything else stays blocked. For a quick local test you can also set `block_private_networks` to `false` |
| `cookie_banner` | see file | Banner on/off, title, text, initially ticked categories, privacy-policy link, how long a choice is valid |
| `remember_days` / `remember_max` | `30` / `5` | How long, and how many, connections are remembered when "Preferences" cookies are allowed |
| `connections_per_server` | `4` | Connections to one FTP/SFTP account (server + user) at the same time, all its net2ftp sessions together. When a server refuses one as "too many", net2ftp learns its real limit for a day; extra requests wait in line instead of failing |
| `jobs.workers` / `jobs.step_seconds` | `2` / `15` | Parallel steps per copy/move/delete job (fewer when a server allows few connections), and the length of one step. Keep `step_seconds` well below your PHP, web-server and proxy timeouts |
| `allowed_servers` / `banned_servers` | `[]` | Allow/deny lists with wildcards, e.g. `'*.example.com'` |
| `allowed_ports` | `[21, 22, 990, 2121, 2222, 443]` | Ports users may connect to; `[]` = any |
| `login_max_failures` / `login_failure_window` | `5` / `900` | Failed logins per IP (read from the action log) |
| `rate_limits` | see below | Rate and concurrency limits (file locks, no database needed) |
| `trusted_proxies` | `[]` | IP addresses of your reverse proxy / load balancer / CDN: the visitor's address is then read from `X-Forwarded-For`. **Required behind a proxy**, otherwise all visitors share one address and hit the per-IP limits together |
| `admin_password_hash` | `''` | Enables `admin.php` |
| `admin_totp_secret` | `''` | Two-factor code for `admin.php` (create with `php bin/admin-2fa.php`; works with any authenticator app). Strongly recommended |
| `admin_allowed_ips` | `[]` | Only these IP addresses / ranges (e.g. `'203.0.113.0/24'`) may open `admin.php`; everyone else gets "404 Not found". `[]` = any |
| `admin_session_minutes` / `admin_lockout` | `30` / `5` | Idle minutes before the admin must log in again (8 hours at most); failed admin logins per IP before a 15-minute lockout |
| `daily_limits` | see below | Data and server time per IP address and per FTP server per day |
| `mass_upload` | see below | Detects the same file being uploaded to many servers (defacement) |
| `max_upload_bytes`, `max_edit_bytes`, `max_zip_bytes`, `max_zip_files` | 512 MB, 2 MB, 500 MB, 20,000 | Limits. Zips are streamed, so `max_zip_bytes` limits time and traffic, not disk space |
| `disk_quota.ip_upload_bytes` / `disk_quota.ip_share_bytes` | 2 GB / 2 GB | Disk space on the web server per visitor IP address (IPv6: per /64): unfinished uploads collected here (small S3 files, servers that refuse appending) and active share links. `0` = no limit |
| `max_execution_time`, `ftp_timeout`, `sftp_timeout` | 300, 20, 20 s | Longest request; network timeouts |
| `search_max_files`, `search_max_file_bytes`, `search_time_limit`, `search_max_results` | 5,000, 2 MB, 60 s, 1,000 | Search limits |
| `ftp_use_pasv_address` | `false` | Ignore the IP in PASV replies (fixes servers behind NAT) |
| `ssh_exec_enabled` | `true` | Allow the SSH terminal |
| `ssh_strict_host_keys` | `true` | Trust-on-first-use host keys; refuse logins when a server's key changes |
| `s3_default_region` | `eu-central-2` | Region used when the user leaves it empty |
| `s3_copy_part_threshold` / `s3_copy_part_size` | 5 GiB / 512 MiB | S3 copies objects of up to 5 GiB in one request; larger ones are copied in parts on the S3 side (UploadPartCopy), a few parts per job step |
| `max_unzip_bytes`, `max_unzip_files`, `max_unzip_ratio` | 500 MB, 5,000, 200 | Extract limits (zip-bomb protection) |
| `tmp_dir` | `storage/tmp` | Scratch space for uploads, archives, the editor and the limiter's lock files. Keep it on a **local** disk (file locks are unreliable on NFS) |
| `housekeeping` | see below | Cleanup of leftover files, expired shares and old log rows |
| `shares.enabled` | `true` | Share links on/off |
| `shares.dir` | `storage/shares` | Where shared files are copied (writable, **outside** `public/`) |
| `shares.max_days` / `shares.default_days` | `7` / `3` | Longest and default link lifetime |
| `shares.max_bytes`, `shares.max_files`, `shares.total_bytes` | 500 MB, 1,000, 10 GB | Size of one share, files in one share, all shares together |
| `shares.blocked_types` / `shares.block_programs` | built-in list / `true` | Extensions that can't be shared, also inside a zip (`null` = exe, scr, com, pif, bat, cmd, cpl, msi, msp, msc, dll, jar, vbs, vbe, jse, wsf, wsh, ps1, psm1, hta, lnk, reg, scf, apk, appx, msix, appinstaller, iso, img, vhd, vhdx; `[]` = none); also refuse Windows programs under any name ("MZ" header) |
| `shares.public_url` | `''` | Full URL of `share.php` for the links, when the automatic one is wrong (e.g. behind a reverse proxy) |
| `site.base_url` | `''` | Public address of the installation, e.g. `'https://www.example.com/'`. Used for the absolute links search engines and link previews need (canonical, hreflang, sitemap, Open Graph). Empty = taken from the request. **Set it on a public site**, so these links always use your preferred address (https, with or without www) |
| `site.noindex` / `site.label` | `false` / `''` | For a **test installation**: no search-engine indexing (noindex on every page, `robots.txt` disallows all, no sitemap) / a label such as `'TEST'` next to the logo and in the window title. See *Production and test side by side* |
| `site.robots_disallow` | `[]` | Extra paths for `robots.txt`, e.g. `['/test/']` on production when a test installation runs in that sub-folder |
| `site.operator`, `address`, `email`, `abuse_email`, `privacy_email`, `jurisdiction`, `authority` | example values | Your details, used in the privacy policy, disclaimer and forms. **The privacy policy and disclaimer are templates**: they show a warning until `operator` is changed, and should be checked by a lawyer |
| `site.notify_email` | `''` | E-mail new abuse reports and GDPR requests to this address (needs PHP `mail()`) |
| `site.download_url`, `site.source_url` | `''` | Links on the Download page (e.g. your release page and repository) |
| `site.requests_dir`, `site.requests_per_hour` | `storage/requests`, `5` | Where submitted forms are saved; form submissions allowed per IP per hour |
| `site.pages` | `true` | `false` turns `page.php` off |

The defaults are those **for a public installation** (from the security review). For a private installation you can relax them.

### Rate and concurrency limits (`rate_limits`)

| Key | Default | Meaning |
|---|---|---|
| `session_parallel` / `ip_parallel` | 2 / 6 | Requests running at once per browser session / per IP address. Extra requests **wait in line** (the browser's own parallel requests are simply queued) |
| `queue_seconds` | 20 | How long a request waits for a free slot before it gets "429 Too many requests" |
| `heavy_parallel` / `heavy_per_session` | 4 / 1 | Zip, extract and share jobs at once on the whole server / per session |
| `logins_per_ip` | 30 per hour | Login attempts per IP, **successful or not** (slows down scripted mass logins with stolen passwords) |
| `logins_per_server` | 100 per hour | Login attempts to one target server, all visitors together |
| `failed_logins_per_account` | 10 per hour | Failed logins for one server + port + user name, from any IP (distributed password guessing) |

A slot is a file lock, held by the PHP process until the request ends — the operating system releases it even if PHP crashes, so a limit can never get "stuck". The lock files are in `storage/tmp/limits/`; their names are hashes, so no IP addresses are stored there. With the defaults, one visitor can occupy at most 6 PHP workers, even with a deliberately slow server.

### Daily limits (`daily_limits`) and mass-upload detection (`mass_upload`)

| Key | Default | Meaning |
|---|---|---|
| `ip_bytes` / `ip_seconds` | 2 GB / 1 hour | Data transferred and server time used **per visitor IP address per day** |
| `server_bytes` / `server_seconds` | 10 GB / 4 hours | The same **per FTP/SSH/S3 server per day**, all visitors together (protects a server from being used as a target) |
| `mass_upload.servers` / `window` / `block_hours` | 5 / 1 hour / 24 | When one IP uploads the **same file** (same SHA-256) to this many different servers within the window, it is a *critical* security event and the IP is blocked |

Set a value to `0` for no limit. Once a limit is reached, the visitor gets a clear message saying which limit and that it resets at midnight (server time). These defaults are a starting point: watch *Consumption* in the admin panel for a few weeks and adjust. Share-link downloads count towards the downloading visitor's IP limit.

## Large transfers

PHP requests have time limits (PHP's own, the web server's, a proxy's or CDN's — Cloudflare stops after 100 s), and many FTP and SSH servers allow only a few connections per user. net2ftp is built so that neither limits what you can transfer.

**Connections.** At most `connections_per_server` connections are open to one account at a time (4 by default). Many servers allow fewer (often 1–3 per user). When a server refuses a connection ("421 Too many connections"), net2ftp lowers its limit for that account for a day, and requests that find all connections busy wait in line instead of failing. Jobs never take the last connection, so browsing keeps working while a job runs. With a one-connection server, jobs work in shorter steps (6 s), so browsing never waits long.

**Downloads** are streamed from the server to the browser as the data arrives: no temporary file, and the first bytes reach the browser at once (so no proxy times out waiting). The response supports HTTP ranges (`Accept-Ranges`, `ETag`, `If-Range`), so a browser can continue an interrupted download. If streaming fails before anything was sent, net2ftp falls back to fetching the whole file first.

**Zip downloads** are streamed too. net2ftp first lists the selection (so `max_zip_files` and `max_zip_bytes` give a normal error message), then writes the zip while each file streams from the server: nothing is stored on the web server, and the download starts at once. The zip uses data descriptors and ZIP64 where needed (files or zips over 4 GB, more than 65,535 entries), and UTF-8 names. A file that can't be read is left out and listed in `net2ftp-errors.txt` inside the zip, because the HTTP status was sent long before. A streamed zip has no `Content-Length` and can't be resumed. The *Download all* button of share pages streams its zip the same way.

**Uploads.** The browser sends chunks of up to 8 MB (smaller when `upload_max_filesize` in php.ini is lower); each chunk is passed on to the server at once — appended to a hidden part file `.name.n2fpart` (FTP: `APPE`, or `REST`+`STOR`; SFTP: write at an offset), which is renamed to the real name after the last chunk. Amazon S3 gets one multipart-upload part per chunk (when the chunk size is at least 5 MB; otherwise, and for servers that refuse appending, the file is collected on the web server and sent at the end). An upload is identified by folder, name, size and the file's modification time, so:
- after a network error or a crashed request, the browser retries with growing pauses and continues at the right byte;
- after a closed browser or the next day, the unfinished upload is listed after login (*Choose the file again to continue*); dropping the same file into the same folder continues it too;
- *Cancel* deletes the part file.

**Copy, move and delete jobs.** Copying and deleting folders (and moving folders on S3) become jobs, saved on the web server under `tmp_dir/jobs/` (paths and progress, no passwords):
1. *Scan*: folders are listed one at a time; a copy creates the target folders as it goes. The panel shows how many files were found.
2. *Files*: workers take the files one by one (2 in parallel by default). A large file is copied in pieces and resumed at the byte where it stopped. When a second connection is free, the data **streams directly from one connection to the other** (the reader runs in a PHP Fiber, no temporary file). Otherwise each piece passes through memory (and a temporary file only if the piece is large). S3 copies on the server; objects over 5 GiB (S3's limit for one copy request) are copied in parts of 512 MiB (UploadPartCopy), a few per step, and resumed at the part. *Cancel* aborts the unfinished multipart upload, so S3 doesn't keep its parts.
3. *Folders*: a delete or move removes the emptied source folders, deepest first.

Each step works for at most `jobs.step_seconds` (15 s) and saves its progress, so no request comes near a timeout, and nothing is lost when a step is cut off: another step takes over the file after 90 seconds. *Pause* stops the workers; *Cancel* stops and removes a half-copied file; a job interrupted by a closed browser continues automatically after the next login. Files that fail three times are listed in the panel (*Show problems*) and the job carries on with the rest. One row is written to the action log when a job ends.

The browser has to stay open while a job runs — the server only works when asked. Running jobs with the browser closed would need the password stored on the server for the length of the job, which net2ftp deliberately does not do.

## Maintenance: cleanup job

One job cleans up everything net2ftp leaves behind:

| What | When |
|---|---|
| Temporary files of cancelled uploads, interrupted zips/extracts, crashed requests | after `housekeeping.tmp_days` (7 days); after **1 hour** while the disk has less than `min_free_mb` (2 GB) free |
| Expired share links and their files; share folders left half-created | at once / after 24 hours |
| Limiter files no longer in use | after 24 hours |
| Action log rows older than `log_retention_days` (90) | deleted in batches of 5,000 rows, so the table is never locked for long |
| Consumption per IP / per server | after `usage_ip_days` (30) / `usage_server_days` (400) |
| Error log entries | `errors_days` (90) after they last happened; the IP address is removed after 30 days |
| Security events | after `security_days` (180) |
| Expired blocks | `blocks_days` (90) after they ended |
| Abuse/GDPR requests marked *done* | after `housekeeping.requests_days` (3 years) |
| Jobs and unfinished uploads (their progress on the web server; no passwords) | 7 days after the last activity. Part files of uploads that were never finished stay on the FTP/SSH server (`.name.n2fpart`) until the user continues or discards them, or deletes them |

**Recommended — a cron job** (or systemd timer), and `'housekeeping' => ['mode' => 'cron']` in `config.php`:

```bash
sudo crontab -u www-data -e
17 * * * *  php /var/www/net2ftp-v2/bin/cleanup.php --quiet
```

Run it as the web server's user, so it can delete the files the web server created. `php bin/cleanup.php` without `--quiet` prints what was deleted.

**Without cron** (default mode `auto`, e.g. shared hosting): at most once an hour, the first request that finds the job due runs it **after** its response has been sent (with PHP-FPM; with mod_php the browser waits for the job, usually well under a second). A lock file guarantees that only one request runs it at a time.

`admin.php` → Maintenance shows when the job last ran and what it deleted, lets you run it now, and lists every retention period; System warns when it hasn't run for 2 days.

## Search engines (SEO)

What net2ftp does to be found, and what you can do on top.

**Built in**
- **Every language has its own address**: `page.php?p=features&hl=fr`. Search engines can only index what has its own URL; the language cookie alone would show them English only. Visitors who arrive on a French page keep French in the app. The language menu and all links between the pages carry the language. Old links with `?lang=` redirect (301) to the new ones.
- **Each information page** has a translated title ("Features – net2ftp: web-based FTP, SFTP/SSH and Amazon S3 file manager"), description and keywords, a canonical link to itself, `hreflang` links to its 10 translations plus `x-default`, Open Graph and Twitter tags for link previews (with `assets/img/og-image.png`, 1200×630), and schema.org data: a breadcrumb on every page, and a `SoftwareApplication` (free, GPL, version, screenshot) on the product pages.
- **The login page** (your home page) has a descriptive title and description, keywords, link-preview tags and, added when it loads, its canonical address and `WebSite` + `SoftwareApplication` data. Google indexes the page as rendered, so the title appears in the visitor's language.
- **Sitemap**: `sitemap.php` (also `sitemap.xml` with mod_rewrite) lists the home page and every page of the edition in every language, with the language versions linked to each other. Form pages and pages without a translation are not listed.
- **robots.txt**: generated by `robots.php` (through mod_rewrite) with the sitemap address and the right paths, also in a sub-folder. Without mod_rewrite, the static `robots.txt` is served: add your sitemap line to it.
- **Not indexed**: the API and downloads (`X-Robots-Tag: noindex`), share pages, the admin panel, the abuse and GDPR forms, and "page not found".
- The **keywords meta tag** is there because some search engines (e.g. Bing) still read it; Google ignores it completely. What counts for Google is the content, the title, the description (shown as the snippet), the language versions and links from other sites.

**What you should do**
1. Set `site.base_url` in `config.php` to your public address.
2. In `index.html`, replace `assets/img/og-image.png` in the `og:image` tag by its full address (e.g. `https://www.example.com/assets/img/og-image.png`): Facebook, LinkedIn and others need an absolute address, which a static file can't know.
3. Register the site in **Google Search Console** and **Bing Webmaster Tools**. A *domain property* verified by a DNS TXT record needs no change to net2ftp. Then submit `https://www.example.com/sitemap.php`.
4. Get links from other sites: your own website, the old net2ftp.com pages, GitHub/SourceForge project pages, directories of FTP clients and open-source software. Links are still the strongest signal.
5. Serve the site over HTTPS only, and redirect the other variant (www or not) to the one in `base_url`.
6. If net2ftp is in a sub-folder of a bigger site, add its sitemap to that site's `robots.txt` (search engines only read `robots.txt` at the root of a domain).

## Troubleshooting

**"Too many requests at the same time" / "Too many logins"** — a rate limit was reached (see `rate_limits`). If *every* user gets these behind a reverse proxy or CDN, set `trusted_proxies`.


**"net2ftp requires …"** — see the table under *What happens when something is missing*: the message tells you whether the extension is missing, not enabled, enabled but failing to load (on Windows: a DLL Apache can't find), or has disabled functions. Restart Apache or PHP-FPM after any change. `admin.php` → System check shows what the web server sees.

**"Could not change the permissions" over FTP** — the server refuses `SITE CHMOD` (common on Windows/IIS FTP servers and some locked-down hosting). Use SFTP if available.

**"The server accepted the change, but the permissions … are unchanged"** — the server answered OK but kept the old permissions. Windows FTP and SSH servers (for example Bitvise SSH Server) usually ignore Unix permissions; access is controlled by the server's own settings or by Windows file permissions instead. Servers that don't show permissions in the file list at all (the Permissions column is empty) can't be checked, so no warning appears there.

**"The server sent an unexpected answer (HTTP …)" on the login screen.** `api.php` returned something other than JSON. The message quotes the start of what came back. The full response is in the browser console (F12 → Console), and in F12 → Network → `api.php` → Response.
- *"Fatal error: …"* — a PHP error. Common ones: a missing extension (`Call to undefined function ftp_connect()` → `apt install php-ftp` or enable `extension=ftp`; same for `curl`, `zip`, `sodium`, `mbstring`), PHP older than 8.1, or the memory/time limit. The PHP error log has the details.
- *An HTML page from your host* (e.g. "Not Acceptable", "Access denied", a captcha) — a web application firewall such as ModSecurity or Imunify360 blocked the request because it contains a password field. Ask the host to whitelist `api.php` or disable that rule for the site.
- *An empty answer* — PHP crashed without output. Look in the PHP/Apache error log.

**"This server allows only one connection at a time, and it is busy"** — a transfer holds the server's only connection and the request waited 20 s (`rate_limits.queue_seconds`). It works once the transfer step ends. If the server could allow more, raise its per-user connection limit; net2ftp forgets a learned limit after a day.

**"Could not connect to …"** — many hosting providers block **outgoing** FTP (port 21), SSH (22) or passive-mode data ports from the web server. Test from the web server's shell with `curl -v ftp://your.server/ --user name:pass`. If that also hangs, ask the host to open outgoing ports.

**Listing hangs or fails after a successful login (FTP)** — the passive data connection is blocked. Try unticking *Passive mode*, or keep `ftp_use_pasv_address = false` (the default) for servers behind NAT.

## Logs and statistics

| Table | One row per | Used for | Kept |
|---|---|---|---|
| `n2f_action_log` | action (login, upload, delete …) with IP, server, user, file, bytes, duration, result, SHA-256 of uploaded files ≤ 100 MB | Answering abuse reports; investigating what happened | `log_retention_days` (90) |
| `n2f_usage_ip` | IP address per day: requests, logins, bytes, server time, errors, refused | Daily limits per visitor; top visitors | 30 days |
| `n2f_usage_server` | FTP server per day: the same + number of distinct IPs | Daily limits per server; statistics | 400 days |
| `n2f_error_log` | **distinct** software error (PHP exceptions and fatal errors, JavaScript errors from visitors' browsers), with a counter, first/last seen, version, stack trace | Finding bugs. User errors (wrong password …) are *not* here; they are in the action log | 90 days after last seen |
| `n2f_security_log` | security event: limit reached, blocked visitor, refused port or private network, changed SSH host key, mass upload, admin logins and actions | Spotting attacks; audit trail of admin actions | 180 days |
| `n2f_blocks` | blocked IP address / range or server (wildcards), with reason, expiry and hit counter | Blocking abusers by hand or automatically | 90 days after expiry |

The consumption tables are updated with one `INSERT … ON DUPLICATE KEY UPDATE` per request (written after the response), so they stay small and fast. No row per page load is needed: the SPA makes many small API requests, which would make such a table huge without adding information.

## Admin panel (`admin.php`)

| Section | What it shows / does |
|---|---|
| **Dashboard** | Today's requests, logins, visitors, servers, data, server time; refused requests, open errors and critical events; charts for the last 30 days; storage; top visitors and servers; recent warnings |
| **Access log** | The action log with filters (IP, server, user, action, status, session) |
| **Investigate** | For abuse reports and GDPR requests: everything one server, IP or user did in a time window, summary per IP, "Block 7 days", **CSV export** to attach to your reply |
| **Consumption** | Per IP and per server for any day, against the daily limits; "Block 24 h" |
| **Blocks** | Add / remove blocks of IP addresses, ranges (`198.51.100.0/24`, IPv6 too) and servers (`*.example.com`), with expiry |
| **Errors** | Grouped software errors with details and stack traces; mark resolved (reopens automatically if it happens again) |
| **Security** | Security events of the last 24 hours by type; filters; "Block 24 h" |
| **Share links**, **Requests**, **SSH hosts** | Shares (delete), abuse/GDPR inbox (done / reopen / delete), pinned host keys (forget) |
| **System** | Requirements check, versions, database tables |
| **Maintenance** | Cleanup job status and "Run now"; retention periods; **maintenance mode** (visitors see a friendly message; the admin keeps working) |
| **Settings** | The effective configuration, read-only, secrets masked |

### Protecting the admin panel

`admin.php` protects itself, so it is safe even on shared hosting without access to the Apache configuration:

- **Password + two-factor code** (TOTP, `admin_totp_secret`); the code is only checked after a correct password, and each code works only once.
- **Lockout** after 5 failed logins per IP for 15 minutes, logged as security events.
- **Own session cookie** (`N2FADMIN`, `HttpOnly`, `SameSite=Strict`), separate from the users' sessions; idle timeout and 8-hour maximum; destructive actions (delete, block, purge) need a login in the last 30 minutes.
- **`admin_allowed_ips`**: everyone else gets "404 Not found", so the page doesn't even reveal it exists.
- Every admin login and action is in the security log.

**`.htaccess` / `.htpasswd` as an extra layer** is a good idea (it stops attackers before PHP runs), but not as the only protection: HTTP Basic authentication has no lockout, no second factor and no logout. Combined with an IP restriction:

```apache
# public/.htaccess (or the <Directory> block of the virtual host)
<Files "admin.php">
    AuthType Basic
    AuthName "net2ftp admin"
    AuthUserFile /var/www/net2ftp-v2/.htpasswd      # outside public/!  create with: htpasswd -c -B .htpasswd admin
    <RequireAll>
        Require valid-user
        Require ip 203.0.113.0/24                    # your office / VPN; remove this line if you have no fixed IP
    </RequireAll>
</Files>
```

## The action log

`n2f_action_log` has one row per action: `login`, `logout`, `list`, `upload`, `download`, `zip`, `read`, `save`, `newfile`, `mkdir`, `rename`, `copy`, `move`, `delete`, `chmod` (modes and recursion in `target`), `extract`, `share`, `unshare`, `share-download` (each visitor download, with IP), `search` and `exec`. Upload chunks are not logged separately; one row is written per completed file. Example queries:

```sql
-- Activity today by action
SELECT action, COUNT(*) n, SUM(status='error') errors, ROUND(SUM(bytes)/1048576,1) MB
FROM n2f_action_log WHERE created_at >= CURDATE() GROUP BY action ORDER BY n DESC;

-- Everything one user did on one server
SELECT created_at, action, directory, entry, target, status, message
FROM n2f_action_log WHERE server = 'ftp.example.com' AND username = 'alice' ORDER BY id DESC LIMIT 200;

-- Failed logins by IP over the last day
SELECT remote_addr, COUNT(*) FROM n2f_action_log
WHERE action = 'login' AND status = 'error' AND created_at > NOW() - INTERVAL 1 DAY GROUP BY remote_addr ORDER BY 2 DESC;
```

The `n2f_daily_stats` view aggregates per day and action.

## Security notes

A full security and abuse review of version 2.1 produced a prioritized fix plan. Done since: the rate and concurrency limiter (steps 1 and parts of 3), `trusted_proxies`, the public-installation defaults, the cleanup job, daily limits per IP and per server, blocks, mass-upload detection, and the admin hardening (2FA, lockout, IP allowlist). Done in 2.5: per-IP disk quotas, pinning the checked IP per session (DNS rebinding), share-link file-type blocking and creator IPs, and the CSP in `index.html`. All points of the review are now done.

**Forms** (abuse, GDPR) are protected without a third-party CAPTCHA: CSRF token, a signed timestamp (submissions faster than 3 s or older than 2 h are refused), a hidden honeypot field, 5 submissions per IP per hour, and length limits. Submissions are stored as `0600` JSON files outside `public/`.

- Server credentials are never written to the database or to disk in plain text. During a session they live in the PHP session, encrypted with libsodium (XSalsa20-Poly1305, or AES-256-GCM via OpenSSL). Each request reconnects to the remote server using them.
- **Remembered connections** (only with "Preferences" consent) are kept in the `n2f_saved` cookie:
  - **Encrypted** with the installation's secret key.
  - **`HttpOnly`, `SameSite=Strict`, and `Secure` over HTTPS**, so JavaScript and other sites can't read it.
  - **The password never goes back to the browser.** The login form sends only the entry's id, and the server fills in the password, but only for exactly the same server, port and user.
  - **Deleted immediately** when "Preferences" is withdrawn or an entry is forgotten.
  - **SSH private keys are never remembered.**
  - **Shared computers:** anyone with access to the browser profile can reconnect for up to `remember_days`, so users on shared computers should untick "Remember".
- **Cookies used:**
  - `N2FSESSID` (session) and `n2f_consent` (the cookie choice): necessary.
  - `n2f_dl_*` (download progress, deleted after 2 minutes): necessary.
  - `n2f_saved` (remembered connections, with the last folder visited): preferences.
  - net2ftp sets **no statistics or advertising cookies**. Scripts added later can check `window.n2fConsent` or listen for the `n2f:consent` event before loading.
- Every state-changing request needs a CSRF token. Session cookies are `HttpOnly`, `SameSite=Strict`, and `Secure` over HTTPS. The session ID is regenerated at login and logout.
- Downloads are served as attachments with a restrictive CSP. Inline viewing is limited to images, PDF, plain text and audio/video, so uploaded HTML or SVG can't run scripts in the app's origin.
- SSH host keys are pinned on first use (`n2f_known_hosts`). If a key changes, login is refused until an admin clicks "Forget key".
- **Share links:**
  - The token has 192 random bits. Only its SHA-256 hash names the share folder, so someone who can read `storage/shares` still can't build the links; the creator's copy of the link is stored encrypted.
  - Shares are tied to the connection (server + user) that created them; other users of the same net2ftp can't list or delete them.
  - Passwords are stored with `password_hash()`. Wrong passwords are limited to 10 per 15 minutes per share.
  - The download page sends `noindex` and `Referrer-Policy: no-referrer`, so the link doesn't leak to search engines or other sites.
  - Recipients download copies; they never get access to the FTP/SSH/S3 server, and the link keeps working after the user logs out.
- **FTPS caveat**: PHP's `ext-ftp` encrypts the connection but doesn't verify the server certificate. Prefer SFTP where you can.
- The SSRF guard (`block_private_networks`, on by default) checks the resolved IP when the user logs in, and **pins it for the session**: every later request connects to that address (FTP, SFTP, and S3 endpoints through cURL's `CURLOPT_RESOLVE`, so TLS still checks the name). A server name whose DNS answer changes after login ("DNS rebinding") can't lead net2ftp to a private address. For a public installation, also consider restricting outbound traffic at the firewall.
- **Content-Security-Policy**: `index.html` carries its own policy in a `<meta>` tag (scripts only from this site, no `eval`, no plugins), so it also applies where `.htaccess` is ignored (nginx, `AllowOverride None`). `frame-ancestors` can't be set in a meta tag: `.htaccess` sends it, and the app also refuses to run inside another site's frame (clickjacking).
- **Share links against malware**: programs and scripts can't be shared (`shares.blocked_types`, checked by extension, inside zip archives, and by content for Windows programs). Each share records its creator's IP address, shown in *Admin → Share links* with a *Block IP* button; it is deleted with the share.
- **Disk space per visitor** (`disk_quota`): unfinished uploads collected on the web server and active share links are limited per IP address (IPv6 per /64), so one visitor can't fill the disk.

## Keyboard shortcuts

| Key | Action |
|---|---|
| ↑ ↓ PgUp PgDn Home End | Move (add Shift to extend the selection) |
| Enter / double-click | Open folder, edit text file, view image/PDF, download other files |
| Backspace / Alt+↑ | Up one folder (the folder you left stays selected) |
| Space · Ctrl/⌘+A · Esc | Toggle · select all · clear selection |
| F2 · Delete · Ctrl/⌘+C | Rename · delete · copy to… |
| `/` · Ctrl/⌘+L · Ctrl/⌘+Shift+F | Filter · type a path · search |
| Ctrl/⌘+S (editor) | Save |
| Letters | Type-ahead: jump to the first matching name |

## Project layout

```
config.sample.php        → copy to config.php
sql/schema.sql           MySQL tables (action log, consumption, errors, security events, blocks, SSH known hosts) and stats view
sql/upgrade-2.3.sql      upgrade of a 2.2 database (run before schema.sql)
public/                  ← Apache DocumentRoot
  index.html             SPA shell + SVG icon sprite
  api.php                JSON API entry point
  admin.php              admin panel entry point
  share.php              public download page of share links
  page.php               information pages (features, help, privacy, abuse and GDPR forms …), one address per language
  sitemap.php · robots.php · robots.txt  for search engines (see *Search engines*)
  downloads/             put release packages here to list them on the Download page
  assets/img/screenshots/  pictures for the Screenshots page
  .htaccess / .user.ini  Apache settings (all optional) / PHP settings for PHP-FPM
  assets/css/app.css     styles (light + dark, responsive) · admin.css (admin panel)
  assets/js/             app.js (main) · grid.js (virtual datagrid) · tools.js (permissions, extract, share links) · jobs.js (jobs panel) · api.js · i18n.js · links.js (bookmarks) · consent.js (cookie banner) · uploads.js · editor.js · ui.js · util.js
  assets/i18n/           translations (de, es, fr, nl, ru, zh-Hans, zh-Hant, ja, he, ar), used by the browser and by PHP
  assets/vendor/codemirror/  code editor, split per language (loaded on first use)
  assets/img/            logo, favicon, illustrations, og-image.png (link previews)
src/
  Api.php                action dispatcher, logging, streaming downloads, chunked uploads
  FileOps.php            recursive copy/move/delete, chmod/chown, zip (listing + streaming), search (protocol-independent)
  ZipStream.php          zip writer that streams (data descriptors, ZIP64, UTF-8 names); no temporary file
  Extractor.php          extract zip/tar archives on the server (zip-slip and zip-bomb safe)
  Jobs.php               copy/move/delete jobs: scan, steps, parallel workers, streaming or buffered copies, resume
  Uploads.php            state of resumable uploads (part files, S3 multipart, incremental SHA-256)
  ConnGate.php           connections per FTP/SFTP account: waiting in line, learning a server's limit
  Shares.php · share_page.php  expiring share links: storage, limits, blocked file types, public download page
  DiskQuota.php          disk space per visitor IP: unfinished uploads kept here, share links
  site_page.php          layout, navigation and language menu of page.php
  pages/<lang>/*.php     page texts per language (en, de, es, fr, nl, ru, zh-Hans, zh-Hant, ja, he, ar)
  pages/_shared/         what all languages share: download list, forms, install commands, privacy values from config.php
  SiteRequests.php       abuse and GDPR forms: validation, spam protection, storage, notification
  Limiter.php            rate and concurrency limits (file locks)
  Housekeeping.php       cleanup job (temp files, shares, log rows, requests)
  Usage.php              consumption per IP and per server, daily limits
  ErrorLog.php · SecurityLog.php · Blocks.php  error log, security events, block list
  Totp.php · Maintenance.php  admin two-factor codes · maintenance mode
  Driver/FtpDriver.php   FTP/FTPS (MLSD with LIST fallback, Unix + Windows listings)
  Driver/CallbackStream.php  stream wrapper that lets ext/ftp read from and write to callbacks (streaming without temp files)
  Driver/SftpDriver.php  SFTP/SSH (phpseclib 3), host-key pinning, exec
  Driver/S3Driver.php    S3 via Signature V4 + cURL (no AWS SDK), region auto-detection
  SavedConnections.php   remembered connections (encrypted HttpOnly cookie, consent-aware)
  Fingerprint.php        SSH host key / FTPS certificate check before login
  I18n.php               server-side translations (same catalogs as the browser)
  Session.php · Security.php · Logger.php · Db.php · Path.php · DriverFactory.php
  Requirements.php       environment check: required/optional extensions, folders, MySQL → user-facing messages
  preflight.php          PHP-version check that old PHP versions can parse (runs before everything else)
  polyfill.php           fallbacks for mbstring and commonly disabled functions
  admin_page.php         admin panel: login, 2FA, session, actions, layout
  admin/*.php            one file per admin section (dashboard, investigate, usage, errors …)
bin/check.php            command-line requirements check
bin/cleanup.php          cleanup job for cron
bin/admin-2fa.php        creates the admin two-factor secret and the authenticator-app link; checks a code
tools/                   translation tooling: extract_i18n.py, translations/part*.py, build_i18n.py
tests/                   end-to-end tests against local FTP/FTPS/SFTP/S3 test servers: setup.sh, run_all.sh, see tests/README.md
lib/                     bundled phpseclib 3 + paragonie/constant_time_encoding (MIT)
storage/                 secret key, temp files, shares/ (must be writable, never web-accessible)
```

### API (POST JSON to `api.php`, header `X-CSRF-Token`)

`session` (GET) · `login` · `logout` · `list {path}` · `mkdir {path,name}` · `newfile {path,name}` ·
`rename {path,from,to,isDir}` · `delete {path,items[]}` · `copy`/`move {path,items[],target}` ·
`read {path}` · `save {path,content,encoding,eol,bom,baseMtime}` · `search {path,needle,scope,caseSensitive,regex,filePattern}` ·
`chmod {path,items[],dirMode,fileMode,recursive,owner,group}` · `extract {path,name,into,folder,overwrite}` ·
`share {path,items[],days,password,maxDownloads,message}` · `shares` · `unshare {id}` ·
`exec {path,command}` · `uploadstart {path,name,relPath,size,lastModified}` → `{uploadId,offset}` · `upload {uploadId,offset}` (multipart chunk) ·
`uploads` · `uploaddiscard {uploadId}` · `download {path}` (GET, Range) · `zip {path,items}` (form POST, streamed) ·
`jobstart {kind:copy|move|delete,path,items[],target}` · `jobstep {id}` · `jobs` · `jobcontrol {id,op:pause|resume|cancel|dismiss}`.

Responses are `{"ok":true,"data":…}` or `{"ok":false,"error":"…","status":4xx}`.

## Tested with

Before release, the full feature set was run end-to-end in headless Chrome and directly against the API on PHP 8.3 + MariaDB 10.11, using real servers: pyftpdlib (FTP), asyncssh (SFTP/SSH) and moto (S3 API), and on Windows against a Windows FTP server and Bitvise SSH Server (SFTP and BvShell commands). That covered login, browse, chunked and folder uploads, download, zip, rename, recursive copy/move/delete, recursive chmod/chown (including the lock-out-safe order: 000 → 755 restores a whole locked tree), extracting zip and tar.gz (with zip-slip, symlink, CP437 and zip-bomb archives), share links (password, download limit, expiry, revoke), the rate limiter (9 parallel logins to a deliberately slow "tarpit" server: 6 ran, 3 were refused after waiting in line; per-account, per-IP and per-session limits), the cleanup job (cron and automatic mode, low-disk mode, batched log purge), editing with CRLF/UTF-8 round-trips, search, the SSH terminal, logging, consumption and daily limits, the error and security logs, mass-upload detection and auto-blocking, admin 2FA, lockout and IP allowlist, CSRF, throttling, host-key pinning and SSRF blocking. Transfers were tested on every protocol: uploads interrupted after a chunk and continued in a new session (byte-identical, including S3 multipart), downloads with ranges, copy/move/delete jobs with 2 parallel workers and pause/resume from another session, a server that allows only one connection (6 parallel requests and a 2-worker job: no errors, everything queued), and a job stopped in the middle of a file 488 times and resumed each time, with the copy byte-identical. In the browser: the jobs panel, a reload in the middle of a job, an upload retried after a connection reset, and an unfinished upload continued after a new login. With a 10,000-file folder, the first open took about 240 ms, scrolling ran at about 60 fps, and reopening from cache took about 90 ms.

Version 2.5 added `securitytest.py` (DNS rebinding with a changed hosts entry on FTP, SFTP and S3; blocked share types; per-IP quotas; CSP and frame refusal in Chrome) and `streamtest.py` (streamed zips on all three protocols, checked byte by byte, with nothing written to the web server's disk; an errors file for a missing file; S3 copies in parts as a job, a move, and a cancel that aborts the multipart upload). On the owner's Windows test machine (Apache, a Windows FTP server, Bitvise SSH Server), 2.5.0 passed over FTP and SSH: the 10-level folder copy (3.1–3.2 s), streamed zips of it and the share page's *Download all* (all 32 files byte-identical), refused `.exe` shares (also renamed), the errors file for a missing file, a resumed upload with 8 MB chunks, ranges, pause/resume, SSH commands, and no CSP errors. That run also found the Windows rename error fixed in 2.5.1. Version 2.5.2 added `ftpdesync.py` (an FTP server that answers APPE only after the client's timeout) `basedirtest.py` (PHP with `open_basedir`) and `minishelltest.py` (an SSH server with a minimal shell like Rebex's).

The tests are in `tests/` (`sh tests/setup.sh`, then `sh tests/run_all.sh`; see `tests/README.md`).

Degraded environments were tested too, with the messages checked both in the API and in the browser:
- bare PHP (`php -n`: no ftp/curl/zip/pdo/mbstring/fileinfo/iconv)
- no usable protocol
- MySQL stopped (logging optional and required)
- `pdo_mysql` missing and a wrong database password
- temp folder and session folder not writable
- sodium plus 8 functions disabled
- PHP too old
- PHP not installed, PHP-FPM down, and `api.php` missing

## Translations

All texts are written in English in the code: `t('…')` in JavaScript, `data-i18n` in `index.html`, and `new UserError('…')` / `I18n::t('…')` in PHP. The English text is the key.

1. `python3 tools/extract_i18n.py` collects every key into `tools/i18n_keys.json`.
2. Add the translations. The first 8 languages are the columns of `tools/translations/part*.py` (one row per key: fr, nl, ru, zh-Hans, zh-Hant, ja, he, ar). Languages added later each have one file, `tools/translations/lang_<code>.py` (German `lang_de.py`, Spanish `lang_es.py`), a dictionary from the English text to the translation. Count-dependent texts use plural forms (`one`, `few`, `many`, `two`, `zero`, `other`).
3. `python3 tools/build_i18n.py` writes `public/assets/i18n/<code>.json`. It fails if a key is missing in any language, a `{placeholder}` or HTML tag was dropped, or a language lacks a plural form it needs.

**Adding a language:** create `tools/translations/lang_<code>.py` (copy `lang_de.py` and translate the values), translate the pages into `src/pages/<code>/`, add the language to `LANGUAGES` in `assets/js/i18n.js` (with `rtl: true` if needed) and to `I18n::LANGUAGES` in `src/I18n.php`, and its name and Open Graph locale to `$names` and `$ogLocale` in `src/site_page.php`.

**Cookie banner text:** `cookie_banner.title` and `.text` in `config.php` can be a single English string (translated automatically when it matches the default text) or a per-language map: `['en' => '…', 'fr' => '…']`.

**Page texts** (`page.php`) are translated as whole files in `src/pages/<language>/<page>.php`, so they read naturally rather than sentence by sentence. Everything that isn't text lives once in `src/pages/_shared/`: the package list of the Download page, the abuse and GDPR forms (their labels come from the catalogs), the commands of the Install page, and the values the privacy policy reads from `config.php` (retention periods, operator, e-mail addresses). A language file therefore contains only text. When you change an English page, make the same change in the 10 other languages; a page missing in a language is shown in English with a short notice. Mark commands, paths and file names with `dir="ltr"` (and `translate="no"`), so they stay readable on Hebrew and Arabic pages.

## Licence

net2ftp v2 code: GPL-2.0-or-later (like the original net2ftp). phpseclib: MIT. constant_time_encoding: MIT. CodeMirror 6: MIT.

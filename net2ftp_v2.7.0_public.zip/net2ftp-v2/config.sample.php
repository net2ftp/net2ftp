<?php
/**
 * net2ftp v2 — configuration
 *
 * Copy this file to config.php (same folder) and adjust the values.
 * config.php lives OUTSIDE the web root (public/) so it is never served.
 */
return [

    // ---------------------------------------------------------------
    // General
    // ---------------------------------------------------------------
    'app_name'        => 'net2ftp',
    'base_url'        => '',            // e.g. 'https://files.example.com' (optional, used in admin links)
    'timezone'        => 'Europe/Zurich',
    'debug'           => false,         // true = show PHP error details in API responses

    // Enabled protocols: any of 'ftp', 'sftp', 's3'
    'protocols'       => ['ftp', 'sftp', 's3'],

    // ---------------------------------------------------------------
    // Database (MySQL / MariaDB) — used for the action log
    // ---------------------------------------------------------------
    'db' => [
        'dsn'      => 'mysql:host=127.0.0.1;port=3306;dbname=net2ftp;charset=utf8mb4',
        'user'     => 'net2ftp',
        'password' => 'change-me',
    ],
    'log_enabled'     => true,          // log every user action to the database
    'log_retention_days' => 90,         // older rows are purged automatically (0 = keep forever)
    // What happens when MySQL is down or pdo_mysql is missing:
    //   false = net2ftp keeps working without logging and shows a notice on the login screen
    //   true  = net2ftp refuses to work until the database is available (strict audit requirement)
    'log_required'    => false,

    // ---------------------------------------------------------------
    // Security
    // ---------------------------------------------------------------
    // 32-byte key (base64) used to encrypt remote-server credentials inside the PHP session.
    // Leave empty to auto-generate one into storage/secret.key on first run.
    // Generate manually with:  php -r "echo base64_encode(random_bytes(32)), PHP_EOL;"
    'secret_key'      => '',

    // Session idle timeout in seconds
    'session_timeout' => 1800,

    // Block connections to private / loopback / link-local addresses (127.0.0.1, 10.x, 192.168.x,
    // 169.254.169.254 …). ON for a public website: otherwise any visitor can use the web server as a
    // stepping stone into your internal network (SSRF), e.g. to reach services that only listen on
    // localhost or the cloud metadata service that hands out server credentials.
    // To test with an FTP server on your own computer or LAN, set this to false in YOUR config.php only.
    'block_private_networks' => true,
    // Exceptions to the rule above: private or local servers that users MAY connect to although
    // block_private_networks is on. IP addresses, ranges or host names, for example:
    //   ['localhost']                   an FTP, FTPS, SFTP or SSH server on the same machine as net2ftp
    //                                   (127.0.0.1, the whole 127.x range, and ::1)
    //   ['192.168.1.20', 'nas.lan']     one server in your LAN
    //   ['10.0.5.0/24']                 a whole internal subnet
    // Everything else stays blocked. Never add 169.254.169.254 (cloud metadata) or whole ranges such
    // as 10.0.0.0/8 on a public installation: every visitor could then reach those machines.
    // Remove 'localhost' if the web server runs FTP or SSH services that visitors must not reach.
    'private_network_exceptions' => ['localhost'],

    // Server allow / deny lists. Wildcards allowed: '*.example.com', 'ftp.*'
    // An empty allow list means "any server not on the deny list".
    'allowed_servers' => [],
    'banned_servers'  => [],
    // Ports users may connect to: FTP 21, SFTP 22, implicit FTPS 990, HTTPS 443 (S3) and two common
    // alternatives. [] = any port (also lets visitors probe other services on the internet).
    'allowed_ports'   => [21, 22, 990, 2121, 2222, 443],

    // Connections to one FTP/SFTP account (server + user) at the same time, for all its net2ftp sessions together.
    // Many servers allow only 1–3 per user; when a server refuses one ("421 Too many connections"), net2ftp learns
    // its real limit for a day, and extra requests wait in line instead of failing. Jobs always leave one free.
    'connections_per_server' => 4,

    // Copy, move and delete of folders run as jobs: in short steps, resumable after any interruption.
    'jobs' => [
        'workers'      => 2,    // steps the browser runs in parallel per job (fewer if the server allows few connections)
        'step_seconds' => 15,   // length of one step; keep it well under your PHP, web server and proxy timeouts
    ],

    // Brute-force protection: max failed logins per IP within the window
    'login_max_failures'   => 5,
    'login_failure_window' => 900,      // seconds

    // Rate and concurrency limits (file locks in tmp_dir/limits, no database needed). Requests over a
    // "parallel" limit wait in line for up to queue_seconds, then get "429 Too many requests".
    'rate_limits' => [
        'session_parallel'  => 2,     // requests at once per browser session
        'ip_parallel'       => 6,     // requests at once per IP address
        'queue_seconds'     => 20,    // how long an excess request waits for a free slot
        'heavy_parallel'    => 4,     // zip / extract / share jobs at once on the whole server
        'heavy_per_session' => 1,     // … and per browser session
        'login_window'      => 3600,  // seconds, for the three limits below
        'logins_per_ip'     => 30,    // login attempts (successful or not) per IP
        'logins_per_server' => 100,   // login attempts to one target server, from all visitors together
        'failed_logins_per_account' => 10, // failed logins for one server + user name (distributed password guessing)
    ],
    // Daily limits per IP address and per FTP/SSH/S3 server (consumption tables n2f_usage_ip / n2f_usage_server).
    // Bytes = data transferred through net2ftp; seconds = server time used. 0 = no limit. Reset at midnight.
    'daily_limits' => [
        'ip_bytes'       => 2 * 1024 * 1024 * 1024,   // 2 GB per IP address per day
        'ip_seconds'     => 3600,                      // 1 hour of server time per IP address per day
        'server_bytes'   => 10 * 1024 * 1024 * 1024,  // 10 GB per FTP server per day (all visitors together)
        'server_seconds' => 4 * 3600,                  // 4 hours per FTP server per day
    ],
    // The same file uploaded to this many different servers by one IP within the window looks like a mass
    // defacement with stolen passwords: recorded as a security event, and the IP is blocked for block_hours
    // (0 = record only).
    'mass_upload' => ['servers' => 5, 'window' => 3600, 'block_hours' => 24],

    // Behind a reverse proxy, load balancer or CDN, list its IP addresses here, so that the visitor's address
    // is taken from X-Forwarded-For. Otherwise every visitor seems to have the proxy's address, and the
    // per-IP limits would hit everyone at once. Never list addresses you don't control.
    'trusted_proxies' => [],

    // Admin panel (public/admin.php). Generate a hash with:
    //   php -r "echo password_hash('your-password', PASSWORD_DEFAULT), PHP_EOL;"
    // Leave empty to disable the admin page.
    'admin_password_hash' => '',
    // Two-factor login (an authenticator app: Google Authenticator, Microsoft Authenticator, 1Password, …).
    // Create the secret with:  php bin/admin-2fa.php   — then paste it here. Empty = password only.
    'admin_totp_secret'   => '',
    // Only these IP addresses / ranges may open admin.php (others get "404 Not Found"). [] = any address.
    // e.g. ['203.0.113.10', '198.51.100.0/24', '2001:db8::/32']
    'admin_allowed_ips'   => [],
    'admin_session_minutes' => 30,   // admin is logged out after this many minutes without activity
    'admin_lockout'         => 5,    // failed admin logins per IP before a 15-minute lockout

    // ---------------------------------------------------------------
    // Cookie / GDPR banner (shown on the first visit; users can reopen it via "Cookie settings")
    // ---------------------------------------------------------------
    'cookie_banner' => [
        'enabled' => true,
        'title'   => 'This website uses cookies',
        'text'    => 'We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. '
                   . 'We also share information about your use of our site with our social media, advertising and analytics partners '
                   . 'who may combine it with other information that you\'ve provided to them or that they\'ve collected from your use '
                   . 'of their services. You consent to our cookies if you continue to use this website.',
        // Initial state of the optional checkboxes ("Necessary" is always on and cannot be changed).
        // Note: under the GDPR, consent from pre-ticked boxes is not valid — set these to false for EU visitors.
        'defaults' => [
            'preferences'      => true,
            'statistics'       => true,
            'ads_personalized' => true,
            'ads_nonpersonalized' => true,
        ],
        'privacy_url' => 'page.php?p=privacy',   // link to your privacy policy
        'valid_days'  => 365,  // ask again after this many days
    ],
    // With "Preferences" cookies allowed, server, user name and password are remembered in an encrypted,
    // HttpOnly cookie for this many days (the password is never sent back to the browser).
    'remember_days' => 30,
    'remember_max'  => 5,      // number of connections remembered per browser

    // ---------------------------------------------------------------
    // Limits
    // ---------------------------------------------------------------
    'max_upload_bytes'   => 512 * 1024 * 1024,  // per file; also raise upload_max_filesize/post_max_size in php.ini
    'max_edit_bytes'     => 2 * 1024 * 1024,    // largest file that can be opened in the editor
    'max_zip_bytes'      => 500 * 1024 * 1024,  // total uncompressed size of a zip download
    'max_zip_files'      => 20000,
    'max_unzip_bytes'    => 500 * 1024 * 1024,  // extract on the server: total uncompressed size (zip-bomb protection)
    'max_unzip_files'    => 5000,               // extract on the server: number of entries
    'max_unzip_ratio'    => 200,                // extract on the server: refuse entries compressed more than 200:1
    'search_max_files'   => 5000,               // files scanned per search
    'search_max_file_bytes' => 2 * 1024 * 1024, // skip larger files when searching contents
    'search_time_limit'  => 60,                 // seconds
    'search_max_results' => 1000,
    'max_execution_time' => 300,                // for zip / copy / search requests

    // ---------------------------------------------------------------
    // Protocol defaults
    // ---------------------------------------------------------------
    'ftp_timeout'        => 20,
    'ftp_use_pasv_address' => false,   // false = ignore the IP sent in PASV replies (fixes NAT'ed servers)
    'sftp_timeout'       => 20,
    'ssh_exec_enabled'   => true,      // allow running shell commands over SSH (SFTP connections only)
    'ssh_strict_host_keys' => true,    // remember host-key fingerprints and refuse changed keys
    's3_default_region'  => 'eu-central-2', // Zurich
    's3_timeout'         => 60,
    // S3 copies objects of up to 5 GiB in one request; larger ones are copied in parts on the S3 side
    // (UploadPartCopy), a few parts per job step, so a copy of any size can be paused and resumed.
    's3_copy_part_threshold' => 5 * 1024 * 1024 * 1024,   // copy in parts from this size on (at most 5 GiB)
    's3_copy_part_size'      => 512 * 1024 * 1024,        // size of one part (5 MiB … 5 GiB)

    // Folder for temporary files (zip building, uploads, editor). Must be writable by PHP.
    'tmp_dir'            => __DIR__ . '/storage/tmp',

    // Disk space on this web server per visitor IP address (IPv6: per /64), so one visitor can't fill the disk.
    // 0 = no limit. Uploads to FTP/SFTP and big S3 uploads go straight to the server and don't count.
    'disk_quota' => [
        'ip_upload_bytes' => 2 * 1024 * 1024 * 1024,  // unfinished uploads collected here (small S3 files, servers that refuse appending)
        'ip_share_bytes'  => 2 * 1024 * 1024 * 1024,  // active share links created from one address
    ],

    // ---- cleanup of leftover files, expired shares and old log rows ----
    // mode 'auto': runs at most once per interval, after the response of whichever request finds it due
    //              (works everywhere, no setup);
    // mode 'cron': only `php bin/cleanup.php` runs it — recommended, see the README for the crontab line.
    'housekeeping' => [
        'mode'          => 'auto',
        'interval'      => 3600,   // seconds between runs in 'auto' mode
        'tmp_days'      => 7,      // delete leftover temporary files (cancelled uploads, interrupted jobs) after N days …
        'min_free_mb'   => 2048,   // … or after 1 hour while the disk has less than this free
        'requests_days' => 1095,   // delete handled abuse/GDPR requests after N days (0 = keep)
        // log tables (the access log uses log_retention_days above):
        'usage_ip_days'     => 30,   // consumption per IP address (personal data)
        'usage_server_days' => 400,  // consumption per server = long-term statistics
        'errors_days'       => 90,   // errors not seen for N days (the IP of an error is shortened after 30 days)
        'security_days'     => 180,  // security events
        'blocks_days'       => 90,   // blocks that ended more than N days ago
    ],

    // ---- public information pages (page.php): screenshots, features, help, privacy, abuse, GDPR … ----
    // The privacy policy and disclaimer are TEMPLATES: fill in these details and have them checked by a lawyer.
    // 'full'    = the net2ftp.com website: login page with the feature sections, and the Screenshots,
    //             Features, Download, How to use and Install pages.
    // 'reduced' = your own installation: a lightweight login page (servers + login form), and only the
    //             legal pages (privacy policy, disclaimer, abuse and GDPR forms).
    'edition' => 'reduced',

    'site' => [
        'pages'         => true,
        // Public address of this installation (the public/ folder), e.g. 'https://www.example.com/'.
        // Used for the absolute links search engines and link previews need (canonical, hreflang,
        // sitemap, Open Graph). Empty = taken from the request; set it on a public site.
        'base_url'      => '',
        // A second installation for testing (README: "Production and test side by side"):
        'noindex'       => false,   // true on the TEST installation: no search-engine indexing, no sitemap
        'label'         => '',      // e.g. 'TEST': shown next to the logo and in the window title
        'robots_disallow' => [],    // on PRODUCTION, when the test runs in a sub-folder of the same site: ['/test/']
        'operator'      => 'Example Ltd',                     // who runs this installation (data controller)
        'address'       => 'Example Street 1, 8000 Zurich, Switzerland',
        'email'         => 'info@example.com',                // general contact
        'abuse_email'   => 'abuse@example.com',               // shown on the abuse page (the form works without it)
        'privacy_email' => 'privacy@example.com',             // shown in the privacy policy and GDPR page
        'jurisdiction'  => 'Switzerland',                      // courts / applicable law named in the disclaimer
        'authority'     => 'the Federal Data Protection and Information Commissioner (FDPIC), www.edoeb.admin.ch',
        'notify_email'  => '',                                 // e-mail new abuse/GDPR requests here (needs PHP mail())
        'download_url'  => '',                                 // e.g. https://github.com/you/net2ftp-v2/releases
        'source_url'    => '',                                 // e.g. https://github.com/you/net2ftp-v2
        'requests_dir'  => __DIR__ . '/storage/requests',      // submitted forms (outside public/, writable)
        'requests_per_hour' => 5,                              // per IP, against form spam
    ],

    // ---- share links (like WeTransfer) ----
    // Shared files are COPIED to 'dir' when the link is created (a snapshot): the link keeps working even if
    // the original is changed or deleted, and visitors never get access to the FTP/SSH/S3 server itself.
    // 'dir' must be writable by the web server and must NOT be inside public/.
    'shares' => [
        'enabled'        => true,
        'dir'            => __DIR__ . '/storage/shares',
        'max_days'       => 7,                     // longest expiry a user can choose
        'default_days'   => 3,
        'max_bytes'      => 500 * 1024 * 1024,     // size of one share
        'max_files'      => 1000,                  // files in one share
        'total_bytes'    => 10 * 1024 * 1024 * 1024, // all active shares together
        'public_url'     => '',                    // e.g. https://ftp.example.com/share.php — empty = derived from the request
        // Against malware distribution: files with these extensions can't be shared, also not inside a zip.
        // null = the built-in list (exe scr com pif bat cmd cpl msi msp msc dll jar vbs vbe jse wsf wsh ps1 psm1 hta lnk
        // reg scf apk appx msix appinstaller iso img vhd vhdx); [] = allow every type.
        'blocked_types'  => null,
        'block_programs' => true,                  // also refuse Windows programs renamed to another extension ("MZ" header)
    ],
];

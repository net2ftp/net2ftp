<?php
// net2ftp v2 — admin page entry point (system check, action log, SSH known hosts).
// The preflight check runs first and is written so that even very old PHP versions can parse it.
require dirname(__DIR__) . '/src/preflight.php';
n2f_preflight('html');
require dirname(__DIR__) . '/src/bootstrap.php';
require dirname(__DIR__) . '/src/admin_page.php';

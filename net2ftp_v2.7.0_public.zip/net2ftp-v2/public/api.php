<?php
// net2ftp v2 — JSON API entry point.
// The preflight check runs first and is written so that even very old PHP versions can parse it.
require dirname(__DIR__) . '/src/preflight.php';
n2f_preflight('json');

require dirname(__DIR__) . '/src/bootstrap.php';

(new Net2ftp\Api())->run();

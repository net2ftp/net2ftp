// net2ftp v2 — API client
import { uid } from './util.js';
import { BASE_PATH } from './cookies.js';
import { t } from './i18n.js';

const ENDPOINT = 'api.php';
let csrf = '';
let onUnauthorized = () => {};

export class ApiError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

export const setUnauthorizedHandler = (fn) => { onUnauthorized = fn; };
export const setCsrf = (t) => { csrf = t; };
export const getCsrf = () => csrf;

export async function session() {
  let r;
  try {
    r = await fetch(`${ENDPOINT}?action=session`, { credentials: 'same-origin', cache: 'no-store' });
  } catch {
    throw new ApiError(t('Cannot reach the web server — check your internet connection, or the web server (Apache) may be down.'), 0);
  }
  const j = await parseJson(r);
  csrf = j.data.csrf;
  return j.data;
}

/** POST a JSON action. Rejects with ApiError. */
export async function call(action, params = {}, { signal } = {}) {
  let r;
  try {
    r = await fetch(ENDPOINT, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify({ action, ...params }),
      signal,
    });
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    throw new ApiError(t('Cannot reach the web server — check your internet connection, or the web server (Apache) may be down.'), 0);
  }
  const j = await parseJson(r);
  if (!j.ok) {
    if (j.status === 401 && action !== 'login') onUnauthorized(j.error);
    if (j.status === 419) { await session().catch(() => {}); }
    throw new ApiError(j.error || t('Unknown error'), j.status || r.status);
  }
  return j.data;
}

/**
 * Parse the API's JSON answer. If the server sent something else (a PHP error page, a firewall or
 * hosting block page…), show the beginning of it so the real cause is visible.
 */
async function parseJson(r) {
  const text = await r.text();
  try { return JSON.parse(text); } catch { /* fall through */ }
  throw unexpected(r.status, text);
}
const CONTACT = () => t('Please contact the administrator.');
// PHP functions/classes → the extension that provides them (for "Call to undefined function" errors)
const EXT_OF = [[/^ftp_/, 'ftp'], [/^curl_/, 'curl'], [/^mb_/, 'mbstring'], [/^sodium_/, 'sodium'], [/^simplexml_/, 'simplexml'],
  [/^session_/, 'session'], [/^openssl_/, 'openssl'], [/^filter_/, 'filter'], [/^(ZipArchive)$/, 'zip'], [/^(PDO)$/, 'pdo'], [/^json_/, 'json']];

function unexpected(status, text) {
  console.error(`net2ftp: api.php returned HTTP ${status} with a non-JSON body:\n`, text);
  const raw = String(text || '');
  const plain = raw.replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ').replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
  const fail = (msg) => new ApiError(msg, status || 500);

  // PHP is not installed / not enabled: Apache sends the PHP source code as plain text.
  if (/^\s*<\?php/.test(raw) || raw.includes('n2f_preflight(')) {
    return fail(`${t('net2ftp requires PHP but it is not installed or not enabled on this web server (api.php was sent as text instead of being run).')} ${CONTACT()}`);
  }
  // PHP crashed because a function/class from a missing extension was called.
  const undef = plain.match(/(?:undefined function|Class "?)\s*"?\\?([A-Za-z_][\w\\]*)\(?/);
  if (undef) {
    const name = undef[1].replace(/^.*\\/, '');
    const ext = EXT_OF.find(([re]) => re.test(name));
    if (ext) return fail(t('net2ftp requires the PHP extension "{ext}" but it is not installed. Please contact the administrator.', { ext: ext[1] }));
  }
  if (status === 404) {
    return fail(`${t('net2ftp could not find api.php on the web server: the installation is incomplete or the website does not point to the "public" folder.')} ${CONTACT()}`);
  }
  if (status === 502 || status === 503 || status === 504) {
    return fail(`${t('net2ftp requires PHP but the PHP service (e.g. PHP-FPM) is not running or not responding (HTTP {status}).', { status })} ${CONTACT()}`);
  }
  if (status === 403) {
    return fail(`${t('The web server refused access to api.php (HTTP 403) — check the Apache configuration or the hosting firewall.')} ${CONTACT()}`);
  }
  if (status === 500 && (!plain || /Internal Server Error/i.test(plain))) {
    return fail(`${t('The web server reported an internal error (HTTP 500). This is usually a .htaccess setting the server does not allow, or a crash logged in the Apache/PHP error log.')} ${CONTACT()}`);
  }
  return new ApiError(plain
    ? `${t('The server sent an unexpected answer (HTTP {status}):', { status })} “${plain.slice(0, 280)}${plain.length > 280 ? '…' : ''}”`
    : t('The server sent an empty answer (HTTP {status}). Check the PHP error log on the web server.', { status }), status || 500);
}

/** Upload one chunk with progress (XHR gives upload progress events, fetch does not). */
export function uploadChunk(fields, blob, onProgress, xhrRef) {
  return new Promise((resolve, reject) => {
    const fd = new FormData();
    fd.append('action', 'upload');
    for (const [k, v] of Object.entries(fields)) fd.append(k, v);
    fd.append('chunk', blob, 'chunk');
    const x = new XMLHttpRequest();
    if (xhrRef) xhrRef.current = x;
    x.open('POST', ENDPOINT);
    x.setRequestHeader('X-CSRF-Token', csrf);
    x.upload.onprogress = (e) => e.lengthComputable && onProgress(e.loaded);
    x.onload = () => {
      let j;
      try { j = JSON.parse(x.responseText); } catch { return reject(unexpected(x.status, x.responseText)); }
      if (!j.ok) { if (j.status === 401) onUnauthorized(j.error); return reject(new ApiError(j.error, j.status)); }
      resolve(j.data);
    };
    x.onerror = () => reject(new ApiError(t('Network error during upload.'), 0));
    x.onabort = () => reject(new DOMException('Aborted', 'AbortError'));
    x.send(fd);
  });
}

// ---------------------------------------------------------------- downloads
// Downloads go through a hidden iframe so the browser streams them to disk (no memory blobs, any size).
// The server sets a short-lived cookie when streaming starts, and error responses (JSON) land in the iframe.

let frame;
function getFrame() {
  if (!frame) {
    frame = document.createElement('iframe');
    frame.name = 'n2f-dl';
    frame.hidden = true;
    document.body.appendChild(frame);
  }
  return frame;
}

/**
 * Start a download. Resolves when the server begins sending, rejects with the server's error message.
 * @param {'download'|'zip'} action
 */
export function download(action, fields) {
  return new Promise((resolve, reject) => {
    const token = uid(12);
    const f = getFrame();
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = ENDPOINT;
    form.target = f.name;
    form.hidden = true;
    const all = { action, _csrf: csrf, dlToken: token, ...fields };
    for (const [k, v] of Object.entries(all)) {
      const i = document.createElement('input');
      i.type = 'hidden'; i.name = k; i.value = typeof v === 'string' ? v : JSON.stringify(v);
      form.appendChild(i);
    }
    let done = false;
    const cookie = `n2fdl_${token}=`;
    const finish = (err) => {
      if (done) return;
      done = true;
      clearInterval(poll);
      f.removeEventListener('load', onLoad);
      document.cookie = `${cookie}; Max-Age=0; Path=${BASE_PATH}`;
      form.remove();
      err ? reject(err) : resolve();
    };
    const poll = setInterval(() => { if (document.cookie.includes(cookie)) finish(); }, 150);
    const onLoad = () => {
      // A page loaded in the iframe means the server answered with an error instead of a file.
      let msg = t('Download failed.');
      try { if (f.contentWindow.location.href === 'about:blank') return; } catch { /* cross-origin: treat as error */ }
      try {
        const txt = f.contentDocument?.body?.textContent || '';
        const j = JSON.parse(txt);
        msg = j.error || msg;
        if (j.status === 401) onUnauthorized(j.error);
      } catch { /* not JSON */ }
      finish(new ApiError(msg, 400));
    };
    f.addEventListener('load', onLoad);
    document.body.appendChild(form);
    form.submit();
  });
}

export const previewUrl = (path) =>
  `${ENDPOINT}?action=download&inline=1&_csrf=${encodeURIComponent(csrf)}&path=${encodeURIComponent(path)}`;

/**
 * Report JavaScript errors of net2ftp's own scripts to the server's error log (admin.php → Errors).
 * At most 10 per page load; the server also limits them per IP. Messages are cut short and contain no form data.
 */
let reported = 0;
export function reportErrors(currentAction) {
  const send = (message, file, line, stack) => {
    if (reported++ >= 10 || !message) return;
    try {
      fetch(ENDPOINT, {
        method: 'POST', keepalive: true, credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'clientError', message: String(message).slice(0, 500), file: file || '', line: line || 0,
          stack: String(stack || '').slice(0, 3000), url: location.pathname, page: currentAction?.() || '' }),
      }).catch(() => {});
    } catch { /* never let error reporting cause errors */ }
  };
  window.addEventListener('error', (e) => {
    if (!e.filename || !e.filename.startsWith(location.origin)) return; // extensions, injected scripts
    send(e.message, e.filename, e.lineno, e.error?.stack);
  });
  window.addEventListener('unhandledrejection', (e) => {
    const r = e.reason;
    if (r?.name === 'AbortError' || r?.name === 'ApiError' || r instanceof ApiError) return; // expected: cancelled or server-reported errors
    const m = /(https?:\/\/[^\s)]+\/assets\/js\/[^\s:)]+):(\d+)/.exec(String(r?.stack || ''));
    if (!m || !m[1].startsWith(location.origin)) return;
    send(r?.message || String(r), m[1], +m[2], r?.stack);
  });
}

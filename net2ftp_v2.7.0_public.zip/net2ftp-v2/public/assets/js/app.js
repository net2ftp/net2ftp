// net2ftp v2 — main application
import * as api from './api.js';
import { DataGrid } from './grid.js';
import { Uploader, filesFromDrop, filesFromInput } from './uploads.js';
import { JobPanel } from './jobs.js';
import { openEditor } from './editor.js';
import { toast, dialog, confirmDialog, promptDialog, contextMenu, progress } from './ui.js';
import { $, $$, esc, icon, fmtSize, fmtDate, joinPath, parentPath, baseName, isEditable, isPreviewable, debounce, modKey, collator } from './util.js';
import { showCookieBanner, getConsent, allows } from './consent.js';
import { buildLink, parseLink, sameConnection, linkLabel } from './links.js';
import { cookieName } from './cookies.js';
import { initTools, doPermissions, doExtract, doShare, showShares, archiveKind } from './tools.js';
import { t, tn, setLanguage, detectLanguage, currentLanguage, LANGUAGES, persistLanguage } from './i18n.js';

/**
 * The language in the address (?hl=de): every language version of the login page has its own address.
 * Defined here rather than imported, so that this file also works with an older i18n.js still in a browser cache.
 */
const urlLanguage = () => {
  const q = new URLSearchParams(location.search).get('hl');
  return q && LANGUAGES.some((l) => l.code === q) ? q : '';
};

/** Standard ports per protocol: shown as the port field's hint, never kept as a typed value. */
const STANDARD_PORTS = { ftp: ['21'], sftp: ['22'], s3: ['443'] };

const state = {
  app: null,
  req: { fatal: [], protocols: {}, features: {}, notices: [] },
  conn: null,
  cwd: '/',
  cache: new Map(),      // path -> {entries, t}
  inflight: new Map(),   // path -> Promise
  navCtrl: null,
  grid: null,
  uploader: null,
  prefetching: 0,
  searchCtrl: null,
  saved: [],             // remembered connections (no secrets) — only with "Preferences" cookies
  pendingLink: null,     // bookmarked page to open once the user has logged in
  verifiedFp: null,      // {protocol, host, port, sha256} confirmed by the user on the login screen
};
const CACHE_FRESH_MS = 4000;
const PROTO_LABEL = { ftp: 'FTP', ftps: 'FTPS', sftp: 'SFTP', s3: 'S3' };

// ================================================================== boot
function refuseFrame() {
  const box = document.createElement('div');
  box.className = 'noscript';
  box.dir = 'auto';
  const a = document.createElement('a');
  a.href = location.href;
  a.target = '_blank';
  a.rel = 'noopener';
  a.textContent = t('Open net2ftp in its own window');
  box.append(t('For your security, net2ftp can’t be used inside another website.') + ' ', a);
  document.body.replaceChildren(box);
  document.documentElement.classList.remove('booting');
}

async function boot() {
  api.reportErrors(() => (state.conn ? 'browse' : 'login'));
  api.setUnauthorizedHandler((msg) => { if (state.conn) showLogin(msg); });
  // the language is chosen before anything is drawn (?hl= in the address, else cookie, else the browser's languages);
  // a visitor who arrives on a language address keeps that language, as on the information pages
  await setLanguage(urlLanguage() || detectLanguage(), { save: !!urlLanguage() });
  // never inside another site's frame (clickjacking): .htaccess forbids it, but that header is not sent everywhere
  if (window.top !== window.self) { refuseFrame(); return; }
  initLanguageSelector();
  initLogin();
  initBrowserChrome();
  try {
    const s = await api.session();
    state.app = s.app;
    document.documentElement.classList.toggle('edition-reduced', s.app?.edition === 'reduced');
    state.req = { fatal: [], protocols: {}, features: {}, notices: [], ...(s.requirements || {}) };
    state.saved = s.saved || [];
    applyProtocols(s.app.protocols);
    applyRequirements();
    applyConsent();
    renderRecent();
    const banner = s.app.cookieBanner;
    if (banner?.enabled && !getConsent()) showCookieBanner(banner, onConsentChange);
    const link = parseLink(location.hash);
    if (state.req.fatal.length) showLogin('');
    else if (s.connected && link && !sameConnection(s.conn.public, link)) {
      enterBrowser(s.conn, s.conn.home);
      openForeignLink(link);
    } else if (s.connected) enterBrowser(s.conn, link ? link.path : (legacyHashPath() || s.conn.home), link);
    else {
      showLogin(s.expired ? t('Your session timed out. Please log in again.') : '');
      if (link) loginFromLink(link);
    }
  } catch (e) {
    showLogin('');
    blockLogin([e instanceof api.ApiError ? e.message : t('net2ftp could not start. Please contact the administrator.')]);
  }
  document.documentElement.classList.remove('booting');
}

// ================================================================== language
function initLanguageSelector() {
  const sel = $('#lang-select');
  sel.innerHTML = LANGUAGES.map((l) => `<option value="${l.code}" lang="${l.code}">${esc(l.name)}</option>`).join('');
  sel.value = currentLanguage();
  sel.addEventListener('change', async () => {
    // remembered across visits when "Preferences" cookies are allowed, otherwise until the browser is closed
    await setLanguage(sel.value, { persist: allows('preferences') });
    // on a language address (?hl=), the address follows the choice, so it can be bookmarked and shared
    if (urlLanguage()) history.replaceState(history.state, '', `?hl=${encodeURIComponent(sel.value)}${location.hash}`);
    await refreshTranslatedState();
  });
}

/** Re-draw the parts of the page built by JavaScript, and fetch server messages in the new language. */
async function refreshTranslatedState() {
  try {
    const s = await api.session();
    state.req = { fatal: [], protocols: {}, features: {}, notices: [], ...(s.requirements || {}) };
  } catch { /* keep the previous messages */ }
  applyRequirements();
  applyConsent();
  renderRecent();
  updateFingerprintUi();
  if (state.pendingLink && !$('#login-info').hidden) {
    $('#login-info').textContent = t('Log in to open the bookmarked page {path} on {server}.', { path: state.pendingLink.path, server: linkLabel(state.pendingLink) });
  }
  portalHead();
  if ($('.cookie-banner') && state.app?.cookieBanner) showCookieBanner(state.app.cookieBanner, onConsentChange);
}

// ================================================================== test installations
/** "[TEST] " in the window title of an installation with site.label, so it is never mistaken for production. */
const envPrefix = () => (state.app?.label ? `[${state.app.label}] ` : '');

function showEnvLabel() {
  if (!state.app?.label) return;
  for (const brand of $$('.brand')) {
    if (brand.querySelector('.env-badge')) continue;
    const b = document.createElement('span');
    b.className = 'env-badge';
    b.textContent = state.app.label;
    brand.append(b);
  }
}

// ================================================================== search engines
/**
 * Title, canonical address and structured data of the login page (the home page for search engines).
 * The title says what the site is, in the visitor's language; Google indexes the page as rendered.
 * The canonical link and the schema.org data need the absolute address, known only here.
 */
function portalHead() {
  const name = state.app?.name || 'net2ftp';
  document.title = envPrefix() + `${name} – ${t('Web-based FTP, SFTP/SSH and Amazon S3 file manager')}`;
  showEnvLabel();
  if (state.app?.noindex) {
    // a test installation (site.noindex): no canonical address, no structured data, and "noindex"
    if (!document.querySelector('meta[name=robots]')) {
      const m = document.createElement('meta');
      m.name = 'robots';
      m.content = 'noindex, nofollow';
      document.head.append(m);
    }
    return;
  }
  const home = state.app?.baseUrl || location.origin + location.pathname.replace(/index\.html$/, '');
  const hl = urlLanguage();
  // links to the information pages carry the language, so a search engine on /?hl=de finds the German pages
  for (const a of $$('a[href^="page.php?"]')) {
    const q = new URLSearchParams(a.getAttribute('href').slice('page.php?'.length));
    q.set('hl', currentLanguage());
    a.setAttribute('href', `page.php?${q}`);
  }
  // canonical address: /?hl=<language> on a language address, else the home page itself ("x-default")
  let link = document.querySelector('link[rel=canonical]');
  if (!link) {
    link = document.createElement('link');
    link.rel = 'canonical';
    document.head.append(link);
  }
  link.href = hl ? `${home}?hl=${encodeURIComponent(currentLanguage())}` : home;
  if (document.querySelector('script[type="application/ld+json"]')) return;
  // the 11 language versions and the language-neutral home page (also listed in sitemap.php)
  for (const l of [...LANGUAGES.map((x) => x.code), 'x-default']) {
    const alt = document.createElement('link');
    alt.rel = 'alternate';
    alt.hreflang = l;
    alt.href = l === 'x-default' ? home : `${home}?hl=${encodeURIComponent(l)}`;
    document.head.append(alt);
  }
  const ld = document.createElement('script');
  ld.type = 'application/ld+json';
  ld.textContent = JSON.stringify([
    { '@context': 'https://schema.org', '@type': 'WebSite', name, url: home },
    { '@context': 'https://schema.org', '@type': 'SoftwareApplication', name, url: home,
      description: document.querySelector('meta[name=description]')?.content || '',
      applicationCategory: 'BusinessApplication', applicationSubCategory: 'FTP client',
      operatingSystem: 'Any (web browser)', isAccessibleForFree: true,
      offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
      license: 'https://www.gnu.org/licenses/gpl-2.0.html',
      image: home + 'assets/img/og-image.png', screenshot: home + 'assets/img/screenshots/browse.webp' },
  ]);
  document.head.append(ld);
}

// ================================================================== cookie consent
/** Reflect the cookie choice on the login screen. */
function applyConsent() {
  const prefs = allows('preferences');
  $('#remember-wrap').hidden = !prefs;
  $('#remember-off').hidden = prefs || !state.app?.cookieBanner?.enabled;
  if (!prefs) {
    // nothing may be remembered on this device without "Preferences"
    try { localStorage.removeItem(cookieName('n2f.proto')); localStorage.removeItem(cookieName('n2f.recent')); } catch { /* storage blocked */ }
  }
}

async function onConsentChange(now, before) {
  if (before?.preferences && !now.preferences) {
    // Preferences withdrawn: delete the remembered connections (an HttpOnly cookie only the server can remove)
    try { state.saved = (await api.call('forget', {})).saved; } catch { state.saved = []; }
  }
  applyConsent();
  renderRecent();
  persistLanguage(!!now.preferences);
  toast(t('Your cookie settings have been saved.'), { type: 'success', timeout: 2200 });
}

function openCookieSettings() {
  if (state.app?.cookieBanner) showCookieBanner(state.app.cookieBanner, onConsentChange);
}

// ================================================================== login

function initLogin() {
  const form = $('#login-form');
  $$('.seg-btn').forEach((b) => b.addEventListener('click', () => setProtocol(b.dataset.proto)));

  $('#auth-method').addEventListener('change', (e) => {
    $('#key-fields').hidden = e.target.value !== 'key';
    $('#pass-field').hidden = e.target.value === 'key';
  });
  $('#key-file').addEventListener('change', async (e) => {
    const f = e.target.files[0];
    if (f) form.privateKey.value = await f.text();
  });
  form.ssl.addEventListener('change', () => { if (!form.port.value || form.port.value === '21') form.port.placeholder = '21'; });
  // editing the server or account detaches the form from a remembered connection
  for (const n of ['host', 'port', 'username', 'accessKey', 'endpoint']) form.elements[n].addEventListener('input', clearSaved);
  for (const n of ['host', 'port']) form.elements[n].addEventListener('input', updateFingerprintUi);
  form.ssl.addEventListener('change', updateFingerprintUi);
  $('#fp-btn').addEventListener('click', checkFingerprint);
  // delegated: these links are re-created when the page is translated
  document.addEventListener('click', (e) => { if (e.target.closest('[data-cookie-settings]')) { e.preventDefault(); openCookieSettings(); } });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('#login-btn');
    const err = $('#login-error');
    err.hidden = true;
    const proto = form.protocol.value;
    const data = { protocol: proto };
    for (const el of form.elements) {
      if (!el.name || el.name === 'protocol' || el.closest('[hidden]')) continue;
      data[el.name] = el.type === 'checkbox' ? el.checked : el.value;
    }
    if (proto === 'ftp') { data.passive = form.passive.checked; data.ssl = form.ssl.checked; }
    data.remember = allows('preferences') && form.remember.checked;
    const fp = currentFingerprintTarget();
    if (state.verifiedFp && fp && state.verifiedFp.key === fp.key) data.expectFingerprint = state.verifiedFp.sha256;
    if (form.dataset.savedId) data.savedId = form.dataset.savedId;
    btn.classList.add('loading');
    btn.disabled = true;
    try {
      const r = await api.call('login', data);
      api.setCsrf(r.csrf);
      state.saved = r.saved || [];
      renderRecent();
      clearSaved();
      form.password.value = '';
      form.secretKey.value = '';
      form.passphrase.value = '';
      const link = state.pendingLink && sameConnection(r.conn.public, state.pendingLink) ? state.pendingLink : null;
      state.pendingLink = null;
      $('#login-info').hidden = true;
      enterBrowser(r.conn, link ? link.path : r.conn.home, link);
    } catch (ex) {
      err.textContent = ex.message;
      err.hidden = false;
    } finally {
      btn.classList.remove('loading');
      btn.disabled = false;
    }
  });
}

/** Fatal problems: replace the login form with the list of what is missing. */
function blockLogin(messages, env = '') {
  const box = $('#sys-error');
  box.innerHTML = `<div class="sys-head">${icon('alert')}<b>${esc(t('net2ftp cannot start'))}</b></div>`
    + `<ul>${messages.map((m) => `<li>${esc(m)}</li>`).join('')}</ul>`
    + (env ? `<p class="sys-env">${esc(env)}</p>` : '');
  box.hidden = false;
  $('#login-form').hidden = true;
  $('.seg').hidden = true;
  $('#recent').hidden = true;
  $('.login-sub').hidden = true;
}

function applyRequirements() {
  const { fatal, protocols, features, notices, env } = state.req;
  if (fatal.length) { blockLogin(fatal, env); return; }
  $$('.seg-btn').forEach((b) => {
    const msg = protocols[b.dataset.proto];
    b.classList.toggle('unavailable', typeof msg === 'string');
    b.title = typeof msg === 'string' ? msg : '';
  });
  const notice = $('#login-notice');
  notice.textContent = notices.join(' ');
  notice.hidden = !notices.length;
  // FTP over TLS needs PHP's FTP extension built with OpenSSL
  const ssl = $('#login-form').ssl;
  ssl.disabled = !!features.ftps;
  ssl.closest('label').title = features.ftps || '';
  if (features.ftps) ssl.checked = false;
  // prefer a protocol that works
  const cur = $('#login-form').protocol.value;
  if (typeof protocols[cur] === 'string') {
    const ok = Object.keys(protocols).find((p) => protocols[p] === null);
    if (ok) setProtocol(ok); else setProtocol(cur);
  } else setProtocol(cur);
}

function applyProtocols(list) {
  $$('.seg-btn').forEach((b) => { b.hidden = !list.includes(b.dataset.proto); });
  let last = null;
  try { last = allows('preferences') ? localStorage.getItem(cookieName('n2f.proto')) : null; } catch { /* storage blocked */ }
  setProtocol(list.includes(last) ? last : list[0]);
  if (state.app?.s3Region) $('#login-form').region.placeholder = state.app.s3Region;
}

function setProtocol(proto) {
  const form = $('#login-form');
  form.protocol.value = proto;
  try { if (allows('preferences')) localStorage.setItem(cookieName('n2f.proto'), proto); } catch { /* storage blocked */ }
  $$('.seg-btn').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.proto === proto)));
  $$('[data-show]', form).forEach((el) => { el.hidden = !el.dataset.show.split(' ').includes(proto); });
  if (proto === 'sftp') {
    $('#key-fields').hidden = $('#auth-method').value !== 'key';
    $('#pass-field').hidden = $('#auth-method').value === 'key';
  } else {
    $('#pass-field').hidden = proto === 's3';
  }
  // A port that is only the previous protocol's standard port (22 after SFTP, 21 after FTP …) is
  // cleared, so the new protocol's standard port applies; a custom port (e.g. 2222) is kept.
  const prev = $('.seg').dataset.active;
  if (prev && prev !== proto && STANDARD_PORTS[prev]?.includes(form.port.value.trim())) form.port.value = '';
  form.port.placeholder = proto === 'sftp' ? '22' : '21';
  $('.seg').dataset.active = proto;
  // protocol not usable on this server (missing PHP extension…)
  const msg = state.req?.protocols?.[proto];
  const pm = $('#proto-msg');
  pm.textContent = typeof msg === 'string' ? msg : '';
  pm.hidden = typeof msg !== 'string';
  $('#login-btn').disabled = typeof msg === 'string';
  form.classList.toggle('proto-off', typeof msg === 'string');
  updateFingerprintUi();
}

// ------------------------------------------------------------------ server fingerprint (before sending a password)
/** SFTP and FTPS servers have a fingerprint; returns what would be checked, or null. */
function currentFingerprintTarget() {
  const form = $('#login-form');
  const proto = form.protocol.value;
  if (proto !== 'sftp' && !(proto === 'ftp' && form.ssl.checked)) return null;
  const host = form.host.value.trim();
  if (!host) return { proto, host: '', port: 0, key: '' };
  const port = parseInt(form.port.value, 10) || (proto === 'sftp' ? 22 : 21);
  return { proto, host, port, key: `${proto}|${proto === 'ftp' ? 'tls' : ''}|${host.toLowerCase()}|${port}` };
}

function updateFingerprintUi() {
  const form = $('#login-form');
  const target = currentFingerprintTarget();
  $('#fp-btn').hidden = !target;
  $('#ftp-plain-warn').hidden = !(form.protocol.value === 'ftp' && !form.ssl.checked);
  const ok = state.verifiedFp && target && state.verifiedFp.key === target.key;
  const box = $('#fp-ok');
  box.hidden = !ok;
  if (ok) box.innerHTML = `${icon('check-circle')}<span>${esc(t('Fingerprint verified: {fp}', { fp: state.verifiedFp.sha256 }))}</span>`;
}

async function checkFingerprint() {
  const target = currentFingerprintTarget();
  if (!target?.host) { $('#login-form').host.focus(); return; }
  const btn = $('#fp-btn');
  btn.classList.add('loading');
  btn.disabled = true;
  let r;
  try {
    r = await api.call('fingerprint', { protocol: target.proto, host: target.host, port: target.port, ssl: target.proto === 'ftp' });
  } catch (e) {
    $('#login-error').textContent = e.message;
    $('#login-error').hidden = false;
    return;
  } finally {
    btn.classList.remove('loading');
    btn.disabled = false;
  }
  const dateFmt = (v) => (v ? new Date(typeof v === 'number' ? v * 1000 : v.replace(' ', 'T')).toLocaleDateString(currentLanguage()) : '');
  const statusHtml = {
    new: `${icon('info')}<div><b>${esc(t('First connection to this server'))}</b><br>${esc(t('Compare this fingerprint with the one from your hosting provider or server administrator before you connect.'))}</div>`,
    known: `${icon('check-circle')}<div><b>${esc(t('Same fingerprint as before'))}</b><br>${esc(t('This server has presented this fingerprint since {date}.', { date: dateFmt(r.knownSince) }))}</div>`,
    changed: `${icon('alert')}<div><b>${esc(t('WARNING: the fingerprint has changed!'))}</b><br>${esc(t('Since {date} this server presented {old}. This happens after a server reinstall, but it can also mean that someone is intercepting the connection (man-in-the-middle). Only continue if the server administrator confirms the new fingerprint.', { date: dateFmt(r.knownSince), old: r.knownFingerprint }))}</div>`,
  }[r.status];
  let rows = `<tr><th>${esc(t('Server'))}</th><td dir="ltr">${esc(`${r.host}:${r.port}`)}</td></tr>
    <tr><th>${esc(t('Key type'))}</th><td>${esc(r.algorithm)}</td></tr>
    <tr><th>SHA-256</th><td><code class="fp-value" dir="ltr">${esc(r.sha256)}</code></td></tr>`;
  if (r.md5) rows += `<tr><th>MD5</th><td><code class="fp-value" dir="ltr">${esc(r.md5)}</code></td></tr>`;
  if (r.cert) {
    const c = r.cert;
    const flag = (ok, good, bad) => `<span class="chip ${ok ? 'good' : 'bad'}">${esc(ok ? good : bad)}</span>`;
    rows += `<tr><th>${esc(t('Issued to'))}</th><td dir="ltr">${esc(c.subject)}</td></tr>
      <tr><th>${esc(t('Issued by'))}</th><td dir="ltr">${esc(c.issuer)}</td></tr>
      <tr><th>${esc(t('Valid until'))}</th><td>${esc(dateFmt(c.validTo))}</td></tr>
      <tr><th></th><td class="fp-flags">${flag(c.trusted, t('Trusted certificate authority'), c.selfSigned ? t('Self-signed') : t('Not trusted'))}
        ${flag(c.hostMatch, t('Name matches server'), t('Name does not match server'))}${flag(!c.expired, t('Valid'), t('Expired'))}</td></tr>`;
  }
  const ok = await dialog({
    title: t('Server fingerprint'),
    wide: true,
    body: `<div class="fp-status ${r.status}">${statusHtml}</div><table class="fp-table">${rows}</table>`,
    actions: [{ label: t('Cancel'), value: false }, { label: r.status === 'changed' ? t('I verified it — connect anyway') : t('Fingerprint is correct — connect'), value: true, primary: true, danger: r.status === 'changed' }],
  });
  if (!ok) return;
  state.verifiedFp = { key: target.key, sha256: r.sha256 };
  updateFingerprintUi();
  const form = $('#login-form');
  const secret = form.protocol.value === 'sftp' && $('#auth-method').value === 'key' ? form.privateKey : form.password;
  if (secret.value || form.dataset.savedId) form.requestSubmit(); else secret.focus();
}

/**
 * Remembered servers, listed on the left of the login page. The password stays on the server side
 * (encrypted cookie); the browser only sends the entry's id.
 */
function renderRecent() {
  const host = $('#recent');
  const allowed = allows('preferences');
  const list = allowed ? state.saved : [];
  const fatal = !!state.req.fatal.length;
  $('.servers').hidden = fatal;
  $('.portal-grid').classList.toggle('has-servers', list.length > 0 && !fatal);
  $('#servers-empty').hidden = list.length > 0;
  $('#servers-empty-on').hidden = !allowed;
  $('#servers-empty-off').hidden = allowed;
  $('#servers-count').textContent = list.length ? String(list.length) : '';
  const current = $('#login-form').dataset.savedId;
  host.hidden = !list.length;
  host.innerHTML = list.map((r, i) => {
    const p = r.protocol === 'ftp' && r.ssl ? 'ftps' : r.protocol;
    let name;
    let sub;
    if (r.protocol === 's3') {
      name = r.bucket || (r.endpoint ? r.endpoint.replace(/^https?:\/\//, '') : r.region) || 'Amazon S3';
      sub = r.label;
    } else {
      name = r.host + (r.port && +r.port !== (r.protocol === 'sftp' ? 22 : 21) ? ':' + r.port : '');
      // where the next login from this row starts: the last folder visited, else the date of the last login
      sub = (r.username || 'anonymous') + (r.lastDir ? ' · ' + r.lastDir : r.savedAt ? ' · ' + fmtDate(r.savedAt) : '');
    }
    return `<div class="server-row${r.id === current ? ' on' : ''}" role="listitem" tabindex="0" data-i="${i}" title="${esc(r.hasSecret ? t('Password saved') : t('No password saved'))}">`
      + `<span class="server-av p-${esc(p)}" aria-hidden="true">${esc(PROTO_LABEL[p] || p)}</span>`
      + `<span class="server-txt"><b dir="ltr">${esc(name)}</b><small dir="auto">${esc(sub)}</small></span>`
      + (r.hasSecret ? icon('lock', 'server-lock') : '')
      + `<button type="button" class="server-x" data-del="${i}" title="${esc(t('Forget'))}" aria-label="${esc(t('Forget'))}">${icon('x')}</button></div>`;
  }).join('');
  host.onclick = async (e) => {
    const del = e.target.closest('[data-del]');
    if (del) {
      const r = list[+del.dataset.del];
      try { state.saved = (await api.call('forget', { id: r.id })).saved; } catch (ex) { toast(ex.message, { type: 'error' }); }
      if ($('#login-form').dataset.savedId === r.id) clearSaved();
      renderRecent();
      return;
    }
    const b = e.target.closest('[data-i]');
    if (b) useSaved(list[+b.dataset.i]);
  };
  host.onkeydown = (e) => {
    const b = e.target.closest('.server-row');
    if (!b || e.target !== b) return;
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); useSaved(list[+b.dataset.i]); }
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); (e.key === 'ArrowDown' ? b.nextElementSibling : b.previousElementSibling)?.focus(); }
    if (e.key === 'Delete') b.querySelector('.server-x').click();
  };
}

function showPort(form, proto, port) {
  form.port.value = port && !STANDARD_PORTS[proto]?.includes(String(port)) ? String(port) : '';
}

function useSaved(r) {
  const form = $('#login-form');
  setProtocol(r.protocol);
  for (const k of ['host', 'port', 'username', 'initialDir', 'passive', 'ssl', 'accessKey', 'region', 'bucket', 'endpoint']) {
    const el = form.elements[k];
    if (!el) continue;
    if (el.type === 'checkbox') el.checked = r[k] !== undefined ? !!r[k] : el.defaultChecked;
    else el.value = r[k] ?? '';
  }
  showPort(form, r.protocol, r.port);
  if (r.protocol === 'sftp') { $('#auth-method').value = 'password'; $('#auth-method').dispatchEvent(new Event('change')); }
  form.password.value = '';
  form.secretKey.value = '';
  form.dataset.savedId = r.id;
  const secretField = r.protocol === 's3' ? form.secretKey : form.password;
  secretField.placeholder = r.hasSecret ? '•••••••• ' + t('saved — leave empty to use it') : '';
  form.remember.checked = true;
  $$('#recent .server-row').forEach((el) => el.classList.toggle('on', state.saved.indexOf(r) === +el.dataset.i));
  if (r.hasSecret) $('#login-btn').focus(); else secretField.focus();
}

function clearSaved() {
  const form = $('#login-form');
  if (!form.dataset.savedId) return;
  delete form.dataset.savedId;
  $$('#recent .server-row.on').forEach((el) => el.classList.remove('on'));
  form.password.placeholder = '';
  form.secretKey.placeholder = '';
}

function showLogin(message = '') {
  state.conn = null;
  state.cache.clear();
  $('#browser-view').hidden = true;
  $('#login-view').hidden = false;
  portalHead();
  renderRecent();   // the list may have changed during the session (e.g. the last folder visited)
  const err = $('#login-error');
  err.textContent = message;
  err.hidden = !message;
  $$('dialog[open]').forEach((d) => { d.close(); d.remove(); });
  $('#toasts').replaceChildren();
  $('#search-panel').hidden = true;
  $('#search-results').replaceChildren();
  $('#console-out').textContent = '';
  // the rows are forgotten; unfinished jobs and uploads stay on the server and are offered after the next login
  state.uploader?.reset();
  state.jobs?.reset();
  setTimeout(() => {
    const f = $('#login-form');
    const first = [...f.elements].find((el) => el.name && !el.closest('[hidden]') && !el.value && el.type !== 'checkbox' && el.type !== 'hidden');
    first?.focus();
  }, 50);
}

// ================================================================== browser
/** @param {object} [link] parsed bookmark: when it is an edit link, the file is opened in the editor */
function enterBrowser(conn, path, link = null) {
  state.conn = conn;
  state.cache.clear();
  $('#login-view').hidden = true;
  $('#browser-view').hidden = false;
  $('#conn-proto').textContent = PROTO_LABEL[conn.protocol] || conn.protocol.toUpperCase();
  $('#conn-proto').dataset.proto = conn.protocol;
  $('#conn-label').textContent = conn.label;
  $('#conn-pill').title = `${conn.protocol}://${conn.username}@${conn.server}${conn.port ? ':' + conn.port : ''}`
    + (conn.fingerprint ? `\n${t('Host key')}: ${conn.fingerprint}` : '');
  $('#btn-console').hidden = !conn.features?.exec;
  $('#btn-shares').hidden = !state.app?.shares || !!state.req.features.shares;
  $('#console').hidden = true;
  buildGrid(conn.protocol === 's3');
  if (!state.uploader) {
    state.uploader = new Uploader({
      chunkSize: state.app?.chunkSize,
      maxUpload: state.app?.maxUpload,
      onFileDone: (job) => { invalidateTree(job.dir); scheduleRefresh(job.dir); },
      onAllDone: () => {
        const q = state.uploader.queue;
        const failed = q.filter((j) => j.state === 'error').length;
        if (failed) toast(tn('{n} uploads failed — see the upload panel for details.', failed, { one: '{n} upload failed — see the upload panel for details.' }), { type: 'error' });
        else toast(t('Upload complete'), { type: 'success', timeout: 2000 });
      },
    });
  }
  if (!state.jobs) state.jobs = new JobPanel({ onFinished: jobFinished });
  // jobs and uploads this account left unfinished (closed browser, lost connection, a new session)
  state.jobs.restore();
  state.uploader.restore();
  if (link?.edit) {
    navigate(parentPath(link.path), { replace: true });
    openFile(link.path, { line: link.line });
  } else {
    navigate(path || conn.home, { replace: true });
  }
}

function buildGrid(isS3) {
  const columns = [
    { key: 'name', label: t('Name') },
    { key: 'size', label: t('Size') },
    { key: 'mtime', label: t('Modified') },
    { key: 'perms', label: isS3 ? t('Storage class') : t('Permissions') },
    { key: 'owner', label: t('Owner') },
  ];
  state.grid = new DataGrid($('#grid-host'), {
    columns,
    hrefFor: (e) => (e.isDir ? hashFor(joinPath(state.cwd, e.name)) : '#'),
    onOpen: openEntry,
    onSelect: updateSelectionBar,
    onContext: showContextMenu,
    onHover: (e) => { if (e?.isDir) prefetch(joinPath(state.cwd, e.name)); },
    onKey: (e) => {
      const sel = state.grid.getSelected();
      if (e.key === 'Backspace' || (e.altKey && e.key === 'ArrowUp')) { e.preventDefault(); goUp(); return true; }
      if (e.key === 'Delete' && sel.length) { e.preventDefault(); doDelete(sel); return true; }
      if (e.key === 'F2' && sel.length === 1) { e.preventDefault(); doRename(sel[0]); return true; }
      if (modKey(e) && e.key.toLowerCase() === 'c' && sel.length) { e.preventDefault(); doCopyMove(sel, 'copy'); return true; }
      return false;
    },
  });
  state.grid.setEmptyMessage(`<img src="assets/img/empty-folder.svg" alt="" width="120" height="96"><p><b>${esc(t('This folder is empty'))}</b></p>
    <p class="muted">${esc(t('Drop files here, or use Upload.'))}</p>`);
}

// ------------------------------------------------------------------ navigation
/** Bookmarkable address of a folder (or, with edit, of a file in the editor). */
const hashFor = (p, opts) => buildLink(state.conn?.public, p, opts);
/** Links from older versions looked like "#/path". */
function legacyHashPath() {
  const h = location.hash.slice(1);
  if (!h.startsWith('/')) return '';
  try { return decodeURIComponent(h); } catch { return ''; }
}

/** Open a file in the editor and keep the address bar in sync, so the edit page can be bookmarked. */
function openFile(path, { line = 0 } = {}) {
  const dirLink = () => hashFor(state.cwd);
  history.replaceState(null, '', hashFor(path, { edit: true, line }));
  return openEditor(path, {
    line,
    onSaved: () => { markStale(parentPath(path)); scheduleRefresh(parentPath(path)); },
    onClose: () => history.replaceState(null, '', dirLink()),
  }).then((ok) => { if (!ok) history.replaceState(null, '', dirLink()); });
}

/** A bookmark for another server was opened while connected: offer to switch. */
async function openForeignLink(link) {
  // the browser fires both "popstate" and "hashchange" for one address change: ask only once
  if (state.foreignPrompt) return;
  state.foreignPrompt = true;
  const ok = await confirmDialog({
    title: t('Open bookmarked page?'),
    message: t('This link opens {target}. You are connected to {current}. Disconnect and continue?', { target: linkLabel(link), current: state.conn.label }),
    okLabel: t('Disconnect and open'),
  });
  state.foreignPrompt = false;
  if (!ok) { history.replaceState(null, '', hashFor(state.cwd)); return; }
  try { await api.call('logout'); } catch { /* ignore */ }
  showLogin('');
  loginFromLink(link);
}

/** Prepare the login form from a bookmark; reconnect automatically when the password is remembered. */
function loginFromLink(link) {
  state.pendingLink = link;
  const saved = (allows('preferences') ? state.saved : []).find((sv) => sameConnection(sv, link));
  if (saved) useSaved(saved);
  else {
    const form = $('#login-form');
    setProtocol(link.protocol);
    clearSaved();
    for (const k of ['host', 'port', 'username', 'accessKey', 'region', 'endpoint', 'bucket']) {
      if (form.elements[k] && link[k] !== undefined) form.elements[k].value = link[k] ?? '';
    }
    showPort(form, link.protocol, link.port);
    if (link.protocol === 'ftp') { form.ssl.checked = !!link.ssl; form.passive.checked = link.passive !== false; }
    if (link.protocol === 's3' && link.endpoint) $('.advanced').open = true;
  }
  const info = $('#login-info');
  info.textContent = t('Log in to open the bookmarked page {path} on {server}.', { path: link.path, server: linkLabel(link) });
  info.hidden = false;
  if (saved?.hasSecret) $('#login-form').requestSubmit();
  else (link.protocol === 's3' ? $('#login-form').secretKey : $('#login-form').password).focus();
}

async function copyLink() {
  const url = location.href;
  try {
    await navigator.clipboard.writeText(url);
    toast(t('Link copied. Press {key} to bookmark this page.', { key: navigator.platform.includes('Mac') ? '⌘D' : 'Ctrl+D' }), { type: 'success' });
  } catch {
    await promptDialog({ title: t('Link to this page'), label: t('Copy this link or bookmark the page (passwords are never included).'), value: url, okLabel: t('Close') });
  }
}

function fetchList(path, { signal, silent = false } = {}) {
  if (state.inflight.has(path)) return state.inflight.get(path);
  if (!silent) progress.start();
  const p = api.call('list', { path }, { signal })
    .then((d) => { state.cache.set(path, { entries: d.entries, t: Date.now() }); return d.entries; })
    .finally(() => { if (state.inflight.get(path) === p) state.inflight.delete(path); if (!silent) progress.done(); });
  state.inflight.set(path, p);
  return p;
}

/** Warm the cache for a folder the pointer is resting on, so the click feels instant. */
function prefetch(path) {
  if (state.cache.has(path) || state.inflight.has(path) || state.prefetching >= 1) return;
  state.prefetching++;
  fetchList(path, { silent: true }).catch(() => {}).finally(() => { state.prefetching--; });
}

/**
 * For a remembered server, tell the server which folder the user is working in, so the next login
 * from the server list opens it. Only once the user stays in a folder for a moment (not for every
 * folder passed on the way), and not for folders merely prefetched on hover.
 */
let folderTimer = 0;
function rememberFolder(path) {
  clearTimeout(folderTimer);
  if (!state.conn?.remembered) return;
  folderTimer = setTimeout(() => {
    if (state.conn?.remembered && state.cwd === path && state.conn.reportedDir !== path) {
      state.conn.reportedDir = path;
      api.call('visited', { path }).catch(() => { state.conn && (state.conn.reportedDir = ''); });
    }
  }, 1500);
}

async function navigate(path, { replace = false, push = true, focusName = null, keepSelection = false } = {}) {
  if (!state.conn) return;
  path = path || '/';
  const changedDir = path !== state.cwd;
  state.cwd = path;
  if (changedDir) rememberFolder(path);
  if (changedDir) { $('#filter').value = ''; state.grid.filterText = ''; }
  renderCrumbs();
  updateSearchScope();
  document.title = envPrefix() + `${baseName(path) || state.conn.label} — ${state.app?.name || 'net2ftp'}`;
  if (push) {
    const h = hashFor(path);
    if (location.hash !== h) (replace ? history.replaceState : history.pushState).call(history, { path }, '', h);
  }

  const cached = state.cache.get(path);
  if (cached) {
    if (changedDir || !keepSelection) showListing(cached.entries, { focusName, keepSelection: !changedDir || keepSelection, resetScroll: changedDir });
    if (Date.now() - cached.t < CACHE_FRESH_MS) return;
  } else {
    state.grid.setLoading(true);
    updateStatus();
  }

  try {
    const fresh = state.inflight.get(path) || fetchList(path);
    const entries = await fresh;
    if (state.cwd !== path) return;
    if (cached && sameListing(cached.entries, entries) && !keepSelection) return;
    showListing(entries, { focusName, keepSelection: !!cached || keepSelection, resetScroll: !cached });
  } catch (e) {
    if (e.name === 'AbortError' || state.cwd !== path || !state.conn) return;
    if (cached) { toast(e.message, { type: 'error' }); return; }
    state.grid.setRows([]);
    state.grid.emptyEl.innerHTML = `${icon('alert', 'empty-ico err')}<p><b>${esc(t('Could not open this folder'))}</b></p><p class="muted">${esc(e.message)}</p>
      <p><button class="btn btn-ghost" data-retry>${icon('refresh')}${esc(t('Try again'))}</button>
      ${path !== state.conn.home ? `<button class="btn btn-ghost" data-home>${icon('home')}${esc(t('Go to start folder'))}</button>` : ''}</p>`;
    updateStatus();
  }
}

function sameListing(a, b) {
  if (a.length !== b.length) return false;
  const key = (e) => `${e.name}|${e.size}|${e.mtime}|${e.type}|${e.perms}`;
  const set = new Set(a.map(key));
  return b.every((e) => set.has(key(e)));
}

function showListing(entries, opts) {
  state.grid.setRows(entries, opts);
  updateStatus();
}

function goUp() {
  if (state.cwd === '/') return;
  navigate(parentPath(state.cwd), { focusName: baseName(state.cwd) });
}

function refresh() {
  markStale(state.cwd);
  navigate(state.cwd, { push: false, keepSelection: true });
}

/** Keep showing a cached listing but force a re-fetch next time (no skeleton flash). */
function markStale(path) {
  const c = state.cache.get(path);
  if (c) c.t = 0;
  state.inflight.delete(path);
}

/** Drop cached listings below a folder and mark the folder and its parent stale. */
function invalidateTree(path) {
  const prefix = path === '/' ? '/' : path + '/';
  for (const k of [...state.cache.keys()]) if (k !== path && k.startsWith(prefix)) state.cache.delete(k);
  markStale(path);
  markStale(parentPath(path));
}

const scheduleRefresh = debounce((dir) => {
  if (dir === state.cwd || dir.startsWith(state.cwd === '/' ? '/' : state.cwd + '/')) refresh();
}, 400);

// back/forward buttons, and links pasted into the address bar while net2ftp is open
function onAddressChange() {
  const link = parseLink(location.hash);
  if (!link) {
    const legacy = legacyHashPath();
    if (state.conn && legacy && legacy !== state.cwd) navigate(legacy, { push: false });
    return;
  }
  if (!state.conn) { if (!$('#login-view').hidden) loginFromLink(link); return; }
  if (!sameConnection(state.conn.public, link)) { openForeignLink(link); return; }
  if (link.edit) {
    if (!$('dialog.editor[open]') && !state.openingFile) {
      state.openingFile = true;
      navigate(parentPath(link.path), { push: false });
      openFile(link.path, { line: link.line }).finally(() => { state.openingFile = false; });
    }
    return;
  }
  const p = link.path;
  if (p !== state.cwd) {
    const from = state.cwd;
    navigate(p, { push: false, focusName: from.startsWith(p === '/' ? '/' : p + '/') ? from.slice(p.length).split('/').filter(Boolean)[0] : null });
  }
}
window.addEventListener('popstate', onAddressChange);
window.addEventListener('hashchange', onAddressChange);

// ------------------------------------------------------------------ breadcrumbs
function renderCrumbs() {
  const nav = $('#crumbs');
  const parts = state.cwd.split('/').filter(Boolean);
  const isS3 = state.conn?.protocol === 's3';
  let acc = '';
  let html = `<a class="crumb crumb-root" href="${hashFor('/')}" data-path="/" title="${esc(isS3 ? t('All buckets') : t('Root'))}">${icon(isS3 ? 'cloud' : 'server')}</a>`;
  parts.forEach((p, i) => {
    acc += '/' + p;
    const last = i === parts.length - 1;
    html += `${icon('chevron-right', 'crumb-sep')}<a class="crumb${last ? ' current' : ''}" dir="auto" href="${hashFor(acc)}" data-path="${esc(acc)}"${last ? ' aria-current="page"' : ''}>`
      + `${isS3 && i === 0 ? icon('bucket') : ''}${esc(p)}</a>`;
  });
  nav.innerHTML = html;
  nav.scrollLeft = nav.scrollWidth;
  $('#btn-up').disabled = state.cwd === '/';
}

function editPath() {
  const nav = $('#crumbs');
  const input = document.createElement('input');
  input.className = 'input path-input';
  input.value = state.cwd;
  input.spellcheck = false;
  nav.replaceChildren(input);
  input.focus();
  input.select();
  let done = false;
  const finish = (go) => {
    if (done) return;
    done = true;
    const v = input.value.trim();
    if (go && v) navigate(v.startsWith('/') ? normalize(v) : normalize(joinPath(state.cwd, v)));
    else renderCrumbs();
  };
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); finish(true); }
    if (e.key === 'Escape') { e.preventDefault(); finish(false); state.grid.focusGrid(); }
  });
  input.addEventListener('blur', () => finish(false));
}
function normalize(p) {
  const out = [];
  for (const s of p.split('/')) { if (!s || s === '.') continue; if (s === '..') out.pop(); else out.push(s); }
  return '/' + out.join('/');
}

// ------------------------------------------------------------------ status & selection bar
function updateStatus() {
  const rows = state.grid.view;
  const dirs = rows.filter((e) => e.isDir).length;
  const files = rows.length - dirs;
  const size = rows.reduce((a, e) => a + (e.isDir ? 0 : e.size || 0), 0);
  const sel = state.grid.getSelected();
  const selSize = sel.reduce((a, e) => a + (e.isDir ? 0 : e.size || 0), 0);
  $('#status-left').textContent = state.grid.loading ? t('Loading…')
    : `${tn('{n} folders', dirs, { one: '{n} folder' })} · ${tn('{n} files', files, { one: '{n} file' })}${files ? ` · ${fmtSize(size)}` : ''}`
      + (sel.length ? ` — ${tn('{n} selected', sel.length)}${selSize ? ` (${fmtSize(selSize)})` : ''}` : '');
}

function updateSelectionBar(sel) {
  updateStatus();
  const bar = $('#ab-selection');
  const def = $('#ab-default');
  const n = sel.length;
  bar.hidden = n === 0;
  def.hidden = n > 0;
  if (!n) return;
  $('#sel-count').textContent = tn('{n} selected', n);
  const one = n === 1 ? sel[0] : null;
  const show = (id, on) => { $(id).hidden = !on; };
  show('#act-open', one?.isDir);
  show('#act-edit', one && isEditable(one));
  show('#act-view', one && isPreviewable(one));
  show('#act-download', one && !one.isDir);
  show('#act-rename', !!one);
  const f = state.conn?.features || {};
  show('#act-extract', one && !one.isDir && f.extract && archiveKind(one.name) && !state.req.features.extract);
  show('#act-share', state.app?.shares && !state.req.features.shares && !(state.conn?.protocol === 's3' && state.cwd === '/'));
  show('#act-perms', f.chmod);
}

// ------------------------------------------------------------------ actions
function openEntry(e) {
  if (!e) return;
  const path = joinPath(state.cwd, e.name);
  if (e.isDir) navigate(path);
  else if (isEditable(e)) openFile(path);
  else if (isPreviewable(e)) window.open(api.previewUrl(path), '_blank', 'noopener');
  else doDownload(e);
}

async function doDownload(e) {
  const tst = toast(t('Preparing {name}…', { name: e.name }), { type: 'loading' });
  try {
    await api.download('download', { path: joinPath(state.cwd, e.name) });
    tst.update(t('Downloading {name}', { name: e.name }), 'success');
  } catch (ex) { tst.update(ex.message, 'error'); }
}

async function doZip(items) {
  if (state.req.features.zip) { toast(state.req.features.zip, { type: 'error' }); return; }
  const label = items.length === 1 ? items[0].name : tn('{n} items', items.length, { one: '{n} item' });
  const tst = toast(t('Zipping {name}… this can take a moment for large folders.', { name: label }), { type: 'loading' });
  try {
    await api.download('zip', { path: state.cwd, items: items.map(({ name, isDir }) => ({ name, isDir })) });
    tst.update(t('Downloading {name}', { name: `${items.length === 1 ? items[0].name : (baseName(state.cwd) || 'files')}.zip` }), 'success');
  } catch (ex) { tst.update(ex.message, 'error'); }
}

const nameError = (v, existing = []) => {
  if (!v) return t('Please enter a name.');
  if (/[/\\]/.test(v) || v === '.' || v === '..') return t('Names cannot contain / or \\.');
  if (existing.includes(v)) return t('“{name}” already exists in this folder.', { name: v });
  return '';
};

async function doRename(e) {
  const others = state.grid.rows.filter((r) => r.name !== e.name).map((r) => r.name);
  const to = await promptDialog({ title: e.isDir ? t('Rename folder') : t('Rename file'), label: t('New name'), value: e.name, okLabel: t('Rename'), selectBase: !e.isDir, validate: (v) => nameError(v, others) });
  if (!to || to === e.name) return;
  await run(t('Renaming {name}…', { name: e.name }), () => api.call('rename', { path: state.cwd, from: e.name, to, isDir: e.isDir }), t('Renamed to {name}', { name: to }));
  if (e.isDir) invalidateTree(joinPath(state.cwd, e.name));
  afterChange(to);
}

async function doNewFolder() {
  const existing = state.grid.rows.map((r) => r.name);
  const name = await promptDialog({ title: t('New folder'), label: t('Folder name'), value: freeName(t('New folder'), existing), okLabel: t('Create'), validate: (v) => nameError(v, existing) });
  if (!name) return;
  if (await run(t('Creating {name}…', { name }), () => api.call('mkdir', { path: state.cwd, name }), t('Created {name}', { name }))) afterChange(name);
}

async function doNewFile() {
  const existing = state.grid.rows.map((r) => r.name);
  const name = await promptDialog({ title: t('New file'), label: t('File name'), value: freeName('untitled.txt', existing), okLabel: t('Create & edit'), selectBase: true, validate: (v) => nameError(v, existing) });
  if (!name) return;
  if (await run(t('Creating {name}…', { name }), () => api.call('newfile', { path: state.cwd, name }), null)) {
    afterChange(name);
    openFile(joinPath(state.cwd, name));
  }
}

async function doDelete(items) {
  const names = items.map((i) => i.name);
  const dirs = items.filter((i) => i.isDir).length;
  const list = `<ul class="name-list">${names.slice(0, 6).map((n) => `<li>${esc(n)}</li>`).join('')}${names.length > 6 ? `<li class="muted">${esc(tn('… and {n} more', names.length - 6))}</li>` : ''}</ul>`;
  const ok = await confirmDialog({
    title: items.length === 1 ? t('Delete “{name}”?', { name: names[0] }) : tn('Delete {n} items?', items.length),
    message: dirs ? t('Folders are deleted with everything inside them. This cannot be undone.') : t('This cannot be undone.'),
    details: items.length > 1 ? list : '',
    okLabel: t('Delete'),
    danger: true,
  });
  if (!ok) return;
  const what = items.length === 1 ? names[0] : tn('{n} items', items.length, { one: '{n} item' });
  if (dirs || items.length > 20) {
    // folders can hold any number of files: a job (progress, pause, survives interruptions)
    try { await state.jobs.start('delete', state.cwd, items); } catch (e) { toast(e.message, { type: 'error' }); }
    return;
  }
  const r = await run(t('Deleting {name}…', { name: what }),
    () => api.call('delete', { path: state.cwd, items: items.map(({ name, isDir }) => ({ name, isDir })) }),
    (d) => t('Deleted {name}', { name: what }) + (d.deleted > items.length ? ` (${tn('{n} objects', d.deleted, { one: '{n} object' })})` : ''));
  items.filter((i) => i.isDir).forEach((i) => invalidateTree(joinPath(state.cwd, i.name)));
  afterChange();
  return r;
}

async function doCopyMove(items, mode) {
  const what = items.length === 1 ? `“${items[0].name}”` : tn('{n} items', items.length, { one: '{n} item' });
  const plain = items.length === 1 ? items[0].name : tn('{n} items', items.length, { one: '{n} item' });
  const target = await pickFolder({ title: mode === 'copy' ? t('Copy {name} to…', { name: what }) : t('Move {name} to…', { name: what }), okLabel: mode === 'copy' ? t('Copy here') : t('Move here'), start: state.cwd, mode });
  if (target == null) return;
  let r;
  try {
    r = await state.jobs.start(mode, state.cwd, items, target);
  } catch (e) {
    toast(e.message, { type: 'error' });
    return;
  }
  if (r.finished) {
    // a move on the same FTP/SFTP server is a rename: done at once
    invalidateTree(target);
    items.filter((i) => i.isDir).forEach((i) => invalidateTree(joinPath(state.cwd, i.name)));
    afterChange();
    toast(t('Moved {name} to {folder}', { name: plain, folder: baseName(target) || '/' }), {
      type: 'success', action: { label: t('Open folder'), run: () => navigate(target) },
    });
  }
}

/** A copy, move or delete job has ended: refresh what it changed, and say so. */
function jobFinished(job) {
  if (!state.conn) return;
  invalidateTree(job.src);
  if (job.target) invalidateTree(job.target);
  for (const n of job.names) invalidateTree(joinPath(job.src, n));
  if ([job.src, job.target].includes(state.cwd)) refresh();
  if (job.status !== 'done') return;
  const what = job.count === 1 ? job.names[0] : tn('{n} items', job.count, { one: '{n} item' });
  if (job.failed) {
    toast(tn('{n} items could not be processed', job.failed, { one: '{n} item could not be processed' }) + ' — ' + t('see the jobs panel for details.'), { type: 'error', timeout: 8000 });
  } else if (job.kind === 'delete') {
    toast(t('Deleted {name}', { name: what }), { type: 'success' });
  } else {
    const folder = baseName(job.target) || '/';
    const msg = job.kind === 'copy' ? t('Copied {name} to {folder}', { name: what, folder }) : t('Moved {name} to {folder}', { name: what, folder });
    toast(msg, { type: 'success', action: job.target !== state.cwd ? { label: t('Open folder'), run: () => navigate(job.target) } : undefined });
  }
}

async function run(busyMsg, fn, okMsg) {
  const tst = toast(busyMsg, { type: 'loading' });
  try {
    const r = await fn();
    // okMsg may be a function that returns null when the caller shows its own message (no empty "success" toast)
    const msg = typeof okMsg === 'function' ? okMsg(r) : okMsg;
    if (msg) tst.update(msg, 'success'); else tst.close();
    return r || true;
  } catch (e) {
    tst.update(e.message, 'error');
    return null;
  }
}

function afterChange(focusName = null) {
  markStale(state.cwd);
  navigate(state.cwd, { push: false, focusName, keepSelection: !focusName });
  state.grid.focusGrid();
}

function freeName(base, existing) {
  if (!existing.includes(base)) return base;
  const dot = base.lastIndexOf('.');
  const [b, x] = dot > 0 ? [base.slice(0, dot), base.slice(dot)] : [base, ''];
  for (let i = 2; i < 500; i++) if (!existing.includes(`${b} ${i}${x}`)) return `${b} ${i}${x}`;
  return base;
}

// ------------------------------------------------------------------ folder picker (copy / move)
function pickFolder({ title, okLabel, start }) {
  let cur = start;
  const body = document.createElement('div');
  body.className = 'picker';
  body.innerHTML = `
    <div class="picker-bar"><button type="button" class="icon-btn picker-up" title="${esc(t('Up one level'))}">${icon('arrow-up')}</button>
      <input class="input picker-path" spellcheck="false" aria-label="${esc(t('Target folder'))}"></div>
    <ul class="picker-list" role="listbox"></ul>`;
  const list = body.querySelector('.picker-list');
  const input = body.querySelector('.picker-path');
  const load = async (path) => {
    cur = path;
    input.value = path;
    list.innerHTML = `<li class="picker-msg">${icon('spinner', 'spin')} ${esc(t('Loading…'))}</li>`;
    try {
      const entries = state.cache.get(path)?.entries || await fetchList(path, { silent: true });
      if (cur !== path) return;
      const dirs = entries.filter((e) => e.isDir).sort((a, b) => collator.compare(a.name, b.name));
      list.innerHTML = dirs.length
        ? dirs.map((d) => `<li><button type="button" class="picker-item" data-name="${esc(d.name)}">${icon('folder', 'k-folder')}<span>${esc(d.name)}</span>${icon('chevron-right', 'muted')}</button></li>`).join('')
        : `<li class="picker-msg muted">${esc(t('No sub-folders'))}</li>`;
    } catch (e) {
      list.innerHTML = `<li class="picker-msg err">${esc(e.message)}</li>`;
    }
  };
  list.addEventListener('click', (e) => { const b = e.target.closest('.picker-item'); if (b) load(joinPath(cur, b.dataset.name)); });
  body.querySelector('.picker-up').onclick = () => load(parentPath(cur));
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); load(normalize(input.value)); } });
  return dialog({
    title, body, className: 'modal-picker',
    actions: [{ label: t('Cancel'), value: null }, { label: okLabel, primary: true }],
    onOpen: () => load(start),
    onSubmit: () => normalize(input.value || cur),
  }).then((v) => (typeof v === 'string' ? v : null));
}

// ------------------------------------------------------------------ context menu
function showContextMenu(e, entry) {
  const sel = state.grid.getSelected();
  const k = modKey({ metaKey: true, ctrlKey: true }) ? (navigator.platform.includes('Mac') ? '⌘' : 'Ctrl+') : '';
  if (!entry) {
    contextMenu(e.clientX, e.clientY, [
      { label: t('New folder'), icon: 'folder-plus', run: doNewFolder },
      { label: t('New file'), icon: 'file-plus', run: doNewFile },
      { label: t('Upload files'), icon: 'upload', run: () => $('#file-input').click() },
      { label: t('Upload a folder'), icon: 'folder-up', run: () => $('#folder-input').click() },
      '-',
      { label: t('Refresh'), icon: 'refresh', run: refresh },
    ]);
    return;
  }
  const one = sel.length === 1 ? sel[0] : null;
  contextMenu(e.clientX, e.clientY, [
    one?.isDir && { label: t('Open'), icon: 'folder-open', run: () => openEntry(one) },
    one && isEditable(one) && { label: t('Edit'), icon: 'edit', run: () => openEntry(one) },
    one && isPreviewable(one) && { label: t('View'), icon: 'eye', run: () => window.open(api.previewUrl(joinPath(state.cwd, one.name)), '_blank', 'noopener') },
    one && !one.isDir && { label: t('Download'), icon: 'download', run: () => doDownload(one) },
    { label: t('Download as zip'), icon: 'zip', run: () => doZip(sel) },
    one && !one.isDir && state.conn.features?.extract && archiveKind(one.name) && !state.req.features.extract && { label: t('Extract…'), icon: 'unzip', run: () => doExtract(one) },
    state.app?.shares && !state.req.features.shares && !(state.conn.protocol === 's3' && state.cwd === '/') && { label: t('Share link…'), icon: 'share', run: () => doShare(sel) },
    '-',
    one && { label: t('Rename'), icon: 'rename', kbd: 'F2', run: () => doRename(one) },
    { label: t('Copy to…'), icon: 'copy', kbd: `${k}C`, run: () => doCopyMove(sel, 'copy') },
    { label: t('Move to…'), icon: 'move', run: () => doCopyMove(sel, 'move') },
    state.conn.features?.chmod && { label: t('Permissions…'), icon: 'perms', run: () => doPermissions(sel) },
    '-',
    { label: t('Delete'), icon: 'trash', danger: true, kbd: 'Del', run: () => doDelete(sel) },
  ].filter(Boolean).filter((it, i, arr) => !(it === '-' && (i === 0 || arr[i - 1] === '-'))));
}

// ------------------------------------------------------------------ uploads
async function startUpload(items, dir = state.cwd) {
  if (!items.length) return;
  if (dir === state.cwd && state.conn.protocol === 's3' && dir === '/') { toast(t('Open a bucket first, then upload into it.'), { type: 'error' }); return; }
  if (dir === state.cwd) {
    const existing = new Set(state.grid.rows.filter((r) => !r.isDir).map((r) => r.name));
    const clash = items.filter((it) => !it.relPath && existing.has(it.file.name));
    if (clash.length) {
      const choice = await dialog({
        title: clash.length === 1 ? t('“{name}” already exists', { name: clash[0].file.name }) : tn('{n} files already exist', clash.length),
        body: `<p class="modal-text">${esc(tn('Replace the existing files on the server?', clash.length, { one: 'Replace the existing file on the server?' }))}</p>`,
        actions: [{ label: t('Cancel'), value: 'cancel' }, { label: t('Skip existing'), value: 'skip' }, { label: t('Replace'), value: 'replace', primary: true }],
      });
      if (!choice || choice === 'cancel') return;
      if (choice === 'skip') items = items.filter((it) => !clash.includes(it));
      if (choice === 'replace' || choice === undefined) { /* keep all */ }
    }
  }
  state.uploader.add(items, dir);
}

function initDropZone() {
  const overlay = $('#drop-overlay');
  let depth = 0;
  const hasFiles = (e) => [...(e.dataTransfer?.types || [])].includes('Files');
  window.addEventListener('dragenter', (e) => {
    if (!hasFiles(e) || !state.conn || $('dialog[open]')) return;
    depth++;
    $('#drop-target').textContent = state.cwd;
    overlay.hidden = false;
  });
  window.addEventListener('dragleave', (e) => { if (!hasFiles(e)) return; depth = Math.max(0, depth - 1); if (!depth) overlay.hidden = true; });
  window.addEventListener('dragover', (e) => { if (hasFiles(e)) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; } });
  window.addEventListener('drop', async (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    depth = 0;
    overlay.hidden = true;
    if (!state.conn) return;
    const dir = state.cwd;
    startUpload(await filesFromDrop(e.dataTransfer), dir);
  });
}

// ------------------------------------------------------------------ search
function initSearch() {
  const panel = $('#search-panel');
  const form = $('#search-form');
  const results = $('#search-results');
  $('#btn-search').onclick = () => toggleSearch();
  $('#search-close').onclick = () => toggleSearch(false);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (state.searchCtrl) { state.searchCtrl.abort(); return; }
    const needle = form.needle.value;
    if (!needle) return;
    const btn = $('#search-go');
    const scopePath = state.cwd;
    state.searchCtrl = new AbortController();
    btn.textContent = t('Stop');
    btn.classList.add('btn-danger-soft');
    results.innerHTML = `<div class="search-msg">${icon('spinner', 'spin')} ${esc(t('Searching in {path}…', { path: scopePath }))}</div>`;
    const t0 = performance.now();
    try {
      const r = await api.call('search', {
        path: scopePath, needle, scope: form.scope.value, caseSensitive: form.caseSensitive.checked,
        regex: form.regex.checked, filePattern: form.filePattern.value,
      }, { signal: state.searchCtrl.signal });
      renderSearch(r, needle, scopePath, ((performance.now() - t0) / 1000).toFixed(1));
    } catch (ex) {
      results.innerHTML = ex.name === 'AbortError' ? `<div class="search-msg muted">${esc(t('Search stopped.'))}</div>` : `<div class="search-msg err">${esc(ex.message)}</div>`;
    } finally {
      state.searchCtrl = null;
      btn.textContent = t('Search');
      btn.classList.remove('btn-danger-soft');
    }
  });
  results.addEventListener('click', (e) => {
    const line = e.target.closest('[data-line]');
    const file = e.target.closest('[data-file]');
    if (line) {
      openFile(line.dataset.path, { line: +line.dataset.line });
    } else if (file) {
      e.preventDefault();
      const p = file.dataset.file;
      navigate(file.dataset.isdir === '1' ? p : parentPath(p), { focusName: file.dataset.isdir === '1' ? null : baseName(p) });
    }
  });
  panel.addEventListener('keydown', (e) => { if (e.key === 'Escape') toggleSearch(false); });
}

function toggleSearch(force) {
  const panel = $('#search-panel');
  const open = force ?? panel.hidden;
  panel.hidden = !open;
  $('#btn-search').classList.toggle('active', open);
  if (open) { updateSearchScope(); $('#search-form').needle.focus(); } else state.grid.focusGrid();
}

function updateSearchScope() { const el = $('#search-scope'); if (el) el.textContent = state.cwd; }

function renderSearch(r, needle, scopePath, secs) {
  const results = $('#search-results');
  if (!r.results.length) {
    results.innerHTML = `<div class="search-msg">${esc(tn('No matches in {n} files.', r.scanned, { one: 'No matches in {n} file.' }))}${r.skipped ? ` ${esc(tn('{n} skipped (binary or too large).', r.skipped))}` : ''}</div>`;
    return;
  }
  const groups = new Map();
  for (const m of r.results) {
    if (!groups.has(m.path)) groups.set(m.path, []);
    groups.get(m.path).push(m);
  }
  const hl = (text) => {
    const safe = esc(text);
    if (!needle) return safe;
    try {
      const re = new RegExp(`(${esc(needle).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
      return safe.replace(re, '<mark>$1</mark>');
    } catch { return safe; }
  };
  const rel = (p) => (scopePath === '/' ? p.slice(1) : p.slice(scopePath.length + 1));
  const reasons = { time: t('time limit reached'), files: t('file limit reached'), results: t('result limit reached') };
  const matches = r.results.filter((m) => m.line).length || groups.size;
  let html = `<div class="search-summary">${esc(tn('{n} matches', matches, { one: '{n} match' }))} · ${esc(tn('{n} files scanned', r.scanned, { one: '{n} file scanned' }))} · ${secs} s
    ${r.truncated ? `<span class="warn">— ${esc(t('stopped early ({reason})', { reason: reasons[r.reason] || t('limit') }))}</span>` : ''}</div>`;
  for (const [path, ms] of groups) {
    const isDir = ms[0].isDir;
    html += `<div class="sr-group"><a href="#" class="sr-file" data-file="${esc(path)}" data-isdir="${isDir ? 1 : 0}" title="${esc(t('Show in folder'))}">
      ${icon(isDir ? 'folder' : 'file-text', isDir ? 'k-folder' : '')}<span>${hl(rel(path))}</span></a>`;
    for (const m of ms) {
      if (m.line) html += `<button class="sr-line" data-path="${esc(path)}" data-line="${m.line}"><span class="ln">${m.line}</span><code>${hl(m.text)}</code></button>`;
      else if (m.text) html += `<div class="sr-more muted">${esc(t(m.text))}</div>`;
    }
    html += '</div>';
  }
  results.innerHTML = html;
}

// ------------------------------------------------------------------ SSH console
function initConsole() {
  const panel = $('#console');
  const out = $('#console-out');
  const input = $('#console-input');
  const hist = [];
  let hi = 0;
  $('#btn-console').onclick = () => {
    panel.hidden = !panel.hidden;
    $('#btn-console').classList.toggle('active', !panel.hidden);
    if (!panel.hidden) input.focus();
  };
  $('#console-close').onclick = () => { panel.hidden = true; $('#btn-console').classList.remove('active'); };
  const print = (text, cls = '') => {
    const s = document.createElement('span');
    s.className = cls;
    s.textContent = text;
    out.appendChild(s);
    out.scrollTop = out.scrollHeight;
  };
  input.addEventListener('keydown', async (e) => {
    if (e.key === 'ArrowUp') { e.preventDefault(); if (hi > 0) input.value = hist[--hi]; return; }
    if (e.key === 'ArrowDown') { e.preventDefault(); hi = Math.min(hist.length, hi + 1); input.value = hist[hi] || ''; return; }
    if (e.key !== 'Enter') return;
    const cmd = input.value.trim();
    input.value = '';
    if (!cmd) return;
    hist.push(cmd);
    hi = hist.length;
    print(`${state.cwd} $ ${cmd}\n`, 'c-cmd');
    if (cmd === 'clear') { out.textContent = ''; return; }
    const cd = cmd.match(/^cd(?:\s+(.+))?$/);
    if (cd) {
      const arg = (cd[1] || state.conn.home).trim().replace(/^["']|["']$/g, '');
      const target = arg.startsWith('/') ? normalize(arg) : normalize(joinPath(state.cwd, arg));
      navigate(target);
      return;
    }
    input.disabled = true;
    try {
      const r = await api.call('exec', { path: state.cwd, command: cmd });
      if (r.output) print(r.output.endsWith('\n') ? r.output : r.output + '\n');
      if (r.stderr) print(r.stderr.endsWith('\n') ? r.stderr : r.stderr + '\n', 'c-err');
      if (r.exit) print(`[exit ${r.exit}]\n`, 'c-exit');
      if (/^(mkdir|rm|mv|cp|touch|tar|unzip|git|ln|chmod)\b/.test(cmd)) { invalidateTree(state.cwd); refresh(); }
    } catch (ex) {
      print(ex.message + '\n', 'c-err');
    } finally {
      input.disabled = false;
      input.focus();
    }
  });
}

// ------------------------------------------------------------------ chrome wiring
function initBrowserChrome() {
  const on = (sel, fn) => $(sel).addEventListener('click', fn);
  const sel = () => state.grid.getSelected();
  on('#btn-logout', async () => {
    // a folder opened just now is still waiting to be remembered: send it before logging out
    clearTimeout(folderTimer);
    if (state.conn?.remembered && state.conn.reportedDir !== state.cwd) {
      try { await api.call('visited', { path: state.cwd }); } catch { /* ignore */ }
    }
    try { const r = await api.call('logout'); if (r?.saved) state.saved = r.saved; } catch { /* ignore */ }
    history.replaceState(null, '', location.pathname);
    showLogin('');
  });
  on('#btn-refresh', refresh);
  on('#btn-link', copyLink);
  on('#btn-up', goUp);
  on('#btn-new-folder', doNewFolder);
  on('#btn-new-file', doNewFile);
  on('#btn-upload', (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    contextMenu(r.left, r.bottom + 6, [
      { label: t('Upload files'), icon: 'upload', run: () => $('#file-input').click() },
      { label: t('Upload a folder'), icon: 'folder-up', run: () => $('#folder-input').click() },
    ]);
  });
  on('#btn-path', editPath);
  on('#act-open', () => openEntry(sel()[0]));
  on('#act-edit', () => openEntry(sel()[0]));
  on('#act-view', () => window.open(api.previewUrl(joinPath(state.cwd, sel()[0].name)), '_blank', 'noopener'));
  on('#act-download', () => doDownload(sel()[0]));
  on('#act-zip', () => doZip(sel()));
  on('#act-rename', () => doRename(sel()[0]));
  on('#act-copy', () => doCopyMove(sel(), 'copy'));
  on('#act-move', () => doCopyMove(sel(), 'move'));
  on('#act-delete', () => doDelete(sel()));
  on('#act-perms', () => doPermissions(sel()));
  on('#act-extract', () => doExtract(sel()[0]));
  on('#act-share', () => doShare(sel()));
  on('#btn-shares', showShares);
  initTools({ state, run, afterChange, invalidateTree });
  on('#act-clear', () => state.grid.clearSelection());

  $('#crumbs').addEventListener('click', (e) => {
    const a = e.target.closest('.crumb');
    if (a) { e.preventDefault(); navigate(a.dataset.path); }
  });
  $('#crumbs').addEventListener('dblclick', (e) => { if (!e.target.closest('.crumb')) editPath(); });
  $('#crumbs').addEventListener('mouseover', (e) => { const a = e.target.closest('.crumb'); if (a) prefetch(a.dataset.path); });
  $('#grid-host').addEventListener('click', (e) => {
    if (e.target.closest('[data-retry]')) refresh();
    if (e.target.closest('[data-home]')) navigate(state.conn.home);
  });

  $('#filter').addEventListener('input', debounce((e) => { state.grid.filter(e.target.value.trim()); updateStatus(); }, 60));
  $('#filter').addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.target.value = ''; state.grid.filter(''); state.grid.focusGrid(); }
    if (e.key === 'ArrowDown' || e.key === 'Enter') { e.preventDefault(); state.grid.focusGrid(); }
  });

  $('#file-input').addEventListener('change', (e) => { startUpload([...e.target.files].map((file) => ({ file, relPath: '' }))); e.target.value = ''; });
  $('#folder-input').addEventListener('change', (e) => { startUpload(filesFromInput(e.target)); e.target.value = ''; });

  // global shortcuts
  document.addEventListener('keydown', (e) => {
    if (!state.conn || $('dialog[open]')) return;
    const typing = e.target.closest('input, textarea, select, [contenteditable]');
    if (modKey(e) && e.shiftKey && e.key.toLowerCase() === 'f') { e.preventDefault(); toggleSearch(true); return; }
    if (modKey(e) && e.key.toLowerCase() === 'l') { e.preventDefault(); editPath(); return; }
    if (typing) return;
    if (e.key === '/') { e.preventDefault(); $('#filter').focus(); return; }
    if (e.target === document.body && ['ArrowDown', 'ArrowUp', 'Backspace', 'Delete', 'F2', 'Enter'].includes(e.key)) {
      state.grid.focusGrid();
      state.grid.el.dispatchEvent(new KeyboardEvent('keydown', e));
      e.preventDefault();
    }
  });

  initDropZone();
  initSearch();
  initConsole();
}

boot();

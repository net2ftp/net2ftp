// net2ftp v2 — cookie / GDPR consent banner
//
// The visitor's choice is stored in the "n2f_consent" cookie (a necessary cookie) as JSON:
//   {"v":1,"necessary":true,"preferences":true,"statistics":false,"ads_personalized":false,"ads_nonpersonalized":false,"ts":…}
// Other scripts can read it via window.n2fConsent and listen for the "n2f:consent" event, so statistics or
// advertising code added later can be loaded only when the visitor allowed it.
import { esc } from './util.js';
import { readCookie, writeCookie } from './cookies.js';
import { t, currentLanguage } from './i18n.js';

const COOKIE = 'n2f_consent';
const CATS = () => [
  { key: 'necessary', label: t('Necessary'), desc: t('Keeps you logged in and protects the site. Always on.'), locked: true },
  { key: 'preferences', label: t('Preferences'), desc: t('Remembers your servers, user names, passwords and language on this device.') },
  { key: 'statistics', label: t('Statistics'), desc: t('Helps us understand how the site is used.') },
  { key: 'ads_personalized', label: t('Personalized ads'), desc: t('Ads based on your interests.') },
  { key: 'ads_nonpersonalized', label: t('Non-personalized ads'), desc: t('Ads not based on your interests.') },
];
export const CATEGORIES = CATS();

/** The banner text may be configured per language: a string, or {en: …, fr: …}. A plain string is translated. */
const pick = (v, fallback) => {
  if (v && typeof v === 'object') return v[currentLanguage()] || v.en || Object.values(v)[0] || fallback;
  return v ? t(v) : fallback;
};

export function getConsent() {
  const v = readCookie(COOKIE);
  if (v === null) return null;
  try {
    const c = JSON.parse(decodeURIComponent(v));
    return c && typeof c === 'object' ? c : null;
  } catch { return null; }
}

export const allows = (category) => !!getConsent()?.[category];

function saveConsent(choice, days) {
  const c = { v: 1, necessary: true, ...choice, ts: Date.now() };
  writeCookie(COOKIE, encodeURIComponent(JSON.stringify(c)), Math.max(1, days) * 86400);
  window.n2fConsent = c;
  window.dispatchEvent(new CustomEvent('n2f:consent', { detail: c }));
  return c;
}

let open = null;

/**
 * Show the banner. On the first visit it appears by itself; "Cookie settings" reopens it with the current choices.
 * @param {{title:string,text:string,defaults:object,privacyUrl:string,validDays:number}} cfg
 * @param {(consent:object, previous:object|null)=>void} onChange
 */
export function showCookieBanner(cfg, onChange) {
  open?.remove();
  const current = getConsent();
  const initial = current || cfg.defaults || {};
  const el = document.createElement('section');
  el.className = 'cookie-banner';
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-labelledby', 'cookie-title');
  el.innerHTML = `
    <h2 id="cookie-title">${esc(pick(cfg.title, t('This website uses cookies')))}</h2>
    <p class="cookie-text">${esc(pick(cfg.text, ''))}${cfg.privacyUrl ? ` <a href="${esc(cfg.privacyUrl)}" target="_blank" rel="noopener">${esc(t('Privacy policy'))}</a>` : ''}</p>
    <div class="cookie-cats">
      ${CATS().map((c) => `
        <label class="cookie-cat${c.locked ? ' locked' : ''}" title="${esc(c.desc)}">
          <input type="checkbox" name="${c.key}" ${c.locked || initial[c.key] ? 'checked' : ''} ${c.locked ? 'disabled aria-disabled="true"' : ''}>
          <span class="cookie-box" aria-hidden="true"></span>
          <span class="cookie-label">${esc(c.label)}<small>${esc(c.desc)}</small></span>
        </label>`).join('')}
    </div>
    <div class="cookie-actions">
      <button type="button" class="btn btn-ghost" data-act="necessary">${esc(t('Necessary only'))}</button>
      <button type="button" class="btn btn-primary" data-act="save">${esc(t('Allow selection'))}</button>
    </div>`;
  document.body.appendChild(el);
  open = el;
  requestAnimationFrame(() => el.classList.add('show'));

  el.addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const choice = {};
    for (const c of CATEGORIES) {
      if (c.locked) continue;
      choice[c.key] = b.dataset.act === 'save' ? el.querySelector(`input[name="${c.key}"]`).checked : false;
    }
    const saved = saveConsent(choice, cfg.validDays || 365);
    el.classList.remove('show');
    setTimeout(() => el.remove(), 200);
    open = null;
    onChange?.(saved, current);
  });
  el.querySelector('[data-act="save"]').focus({ preventScroll: true });
}

// expose the stored choice for other scripts
window.n2fConsent = getConsent();

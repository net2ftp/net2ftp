// net2ftp v2 — cookie names and path of this installation.
// Installations in different folders of one site (production at www.example.com/, a test version at
// www.example.com/test/) share the browser's cookies and storage for that host. At the root the names stay as they
// are ("n2f_lang"); in a folder they get its name ("n2f_lang_test") and the cookies are limited to that folder.
// src/App.php (App::cookie, App::basePath) derives the same from the script's address.

/** URL path of this installation, with a trailing slash: "/" or "/test/". */
export const BASE_PATH = location.pathname.replace(/[^/]*$/, '') || '/';

const SUFFIX = (() => {
  const p = BASE_PATH.replace(/^\/+|\/+$/g, '');
  return p === '' ? '' : '_' + p.replace(/[^A-Za-z0-9]+/g, '_');
})();

/** Name of a cookie (or storage key) of this installation. */
export const cookieName = (name) => name + SUFFIX;

/** Value of one of this installation's cookies, or null. */
export function readCookie(name) {
  const n = cookieName(name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const m = document.cookie.match(new RegExp('(?:^|;\\s*)' + n + '=([^;]*)'));
  return m ? m[1] : null;
}

/** Set one of this installation's cookies (value already encoded); maxAge in seconds, null = session cookie. */
export function writeCookie(name, value, maxAge = null) {
  document.cookie = `${cookieName(name)}=${value}; Path=${BASE_PATH}; SameSite=Strict`
    + (maxAge !== null ? `; Max-Age=${maxAge}` : '') + (location.protocol === 'https:' ? '; Secure' : '');
}

// net2ftp v2 — code editor with syntax highlighting (CodeMirror 6, self-hosted, loaded on first use)
import { call } from './api.js';
import { esc, icon, fmtSize, baseName, isMac } from './util.js';
import { toast, confirmDialog } from './ui.js';
import { t } from './i18n.js';

let cmModule = null;
const loadCodeMirror = () => (cmModule ??= import('../vendor/codemirror/editor.js'));

/** Strings of CodeMirror's own search panel, translated. */
const phrases = () => Object.fromEntries([
  'Find', 'Replace', 'next', 'previous', 'all', 'match case', 'regexp', 'by word', 'replace', 'replace all', 'close',
  'Go to line', 'go', 'Folded lines', 'Unfolded lines', 'Fold line', 'Unfold line',
].map((k) => [k, t(k)]));

/**
 * Open a remote file in the full-screen editor.
 * @param {string} path
 * @param {{line?:number, onSaved?:Function, onClose?:Function}} opts
 * @returns {Promise<boolean>} false when the file could not be opened
 */
export async function openEditor(path, { line = 0, onSaved, onClose } = {}) {
  const tst = toast(t('Opening {name}…', { name: baseName(path) }), { type: 'loading' });
  let file;
  let cm;
  try {
    [file, cm] = await Promise.all([call('read', { path }), loadCodeMirror()]);
    tst.close();
  } catch (e) {
    tst.update(e.message || t('The editor could not be loaded.'), 'error');
    return false;
  }

  const d = document.createElement('dialog');
  d.className = 'editor';
  d.innerHTML = `
    <header class="ed-head">
      <div class="ed-title">${icon('file-code')}<div><strong dir="auto">${esc(baseName(path))}</strong><small dir="ltr">${esc(path)}</small></div>
        <span class="ed-dirty" hidden title="${esc(t('Unsaved changes'))}"></span></div>
      <div class="ed-meta"><span class="chip ed-lang"></span><span class="chip">${esc(file.encoding)}</span><span class="chip">${file.eol.toUpperCase()}</span>
        <span class="chip ed-pos"></span></div>
      <div class="ed-actions">
        <button class="icon-btn ed-link" title="${esc(t('Copy link to this page (for bookmarks)'))}">${icon('link')}</button>
        <button class="icon-btn ed-find" title="${esc(t('Find and replace'))} (${isMac ? '⌘' : 'Ctrl+'}F)">${icon('search')}</button>
        <label class="switch-inline"><input type="checkbox" class="ed-wrap"> ${esc(t('Wrap'))}</label>
        <button class="btn btn-ghost ed-close">${esc(t('Close'))}</button>
        <button class="btn btn-primary ed-save">${icon('save')}${esc(t('Save'))} <kbd>${isMac ? '⌘' : 'Ctrl'} S</kbd></button>
      </div>
    </header>
    <div class="ed-body" dir="ltr" translate="no"></div>`;
  document.body.appendChild(d);
  const dirtyEl = d.querySelector('.ed-dirty');
  const posEl = d.querySelector('.ed-pos');
  let saved = file.content;
  let baseMtime = file.mtime;
  let dirtyTimer = 0;

  const setPos = (ln, col) => { posEl.textContent = t('Ln {line}, Col {col}', { line: ln, col }); };
  setPos(1, 1);
  const editor = await cm.createEditor({
    parent: d.querySelector('.ed-body'),
    doc: file.content,
    filename: baseName(path),
    phrases: phrases(),
    onCursor: setPos,
    onSave: () => save(),
    onChange: () => {
      clearTimeout(dirtyTimer); // comparing large documents on every keystroke is wasteful
      dirtyTimer = setTimeout(() => { dirtyEl.hidden = !isDirty(); }, 120);
    },
  });
  d.querySelector('.ed-lang').textContent = editor.language === 'Text' ? t('Plain text') : editor.language;
  const isDirty = () => editor.getValue() !== saved;

  d.querySelector('.ed-wrap').addEventListener('change', (e) => editor.setWrap(e.target.checked));
  d.querySelector('.ed-find').onclick = () => editor.openSearch();
  d.querySelector('.ed-link').onclick = async () => {
    try {
      await navigator.clipboard.writeText(location.href);
      toast(t('Link copied. Press {key} to bookmark this page.', { key: isMac ? '⌘D' : 'Ctrl+D' }), { type: 'success' });
    } catch { toast(location.href, { timeout: 10000 }); }
  };

  async function save(force = false) {
    const btn = d.querySelector('.ed-save');
    btn.disabled = true;
    btn.classList.add('loading');
    const content = editor.getValue();
    try {
      const r = await call('save', { path, content, encoding: file.encoding, eol: file.eol, bom: file.bom, baseMtime, force });
      saved = content;
      baseMtime = r.mtime;
      dirtyEl.hidden = !isDirty();
      toast(t('Saved {name} ({size})', { name: baseName(path), size: fmtSize(r.size) }), { type: 'success', timeout: 2000 });
      onSaved?.();
    } catch (e) {
      if (e.status === 409 && await confirmDialog({ title: t('File changed on server'), message: e.message, okLabel: t('Overwrite'), danger: true })) {
        return save(true);
      }
      toast(e.message, { type: 'error' });
    } finally {
      btn.disabled = false;
      btn.classList.remove('loading');
    }
  }

  const close = async () => {
    if (isDirty() && !(await confirmDialog({ title: t('Discard changes?'), message: t('{name} has unsaved changes.', { name: baseName(path) }), okLabel: t('Discard'), danger: true }))) return;
    window.removeEventListener('beforeunload', guard);
    editor.destroy();
    d.close();
    d.remove();
    onClose?.();
  };
  const guard = (e) => { if (isDirty()) { e.preventDefault(); e.returnValue = ''; } };
  window.addEventListener('beforeunload', guard);

  d.addEventListener('cancel', (e) => {
    e.preventDefault();
    // Esc first closes CodeMirror's search panel / autocomplete; only an Esc in the editor itself closes the dialog
    if (d.querySelector('.cm-panels, .cm-tooltip-autocomplete')) return;
    close();
  });
  d.querySelector('.ed-save').onclick = () => save();
  d.querySelector('.ed-close').onclick = close;

  d.showModal();
  if (line > 0) editor.gotoLine(line);
  editor.focus();
  return true;
}

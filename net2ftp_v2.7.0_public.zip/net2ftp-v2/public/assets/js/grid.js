// net2ftp v2 — virtualized, keyboard-driven datagrid for directory listings
import { esc, icon, fmtSize, fmtDate, fmtDateFull, fileKind, collator, modKey } from './util.js';
import { t } from './i18n.js';

const KIND_ICON = {
  folder: 'folder', image: 'file-image', code: 'file-code', text: 'file-text', archive: 'file-zip',
  pdf: 'file-pdf', doc: 'file-doc', audio: 'file-audio', video: 'file-video', file: 'file',
};

export class DataGrid {
  /**
   * @param {HTMLElement} host
   * @param {{columns:Array, rowHeight?:number, hrefFor?:Function, onOpen?:Function, onSelect?:Function,
   *          onContext?:Function, onHover?:Function, onKey?:Function}} opts
   */
  constructor(host, opts) {
    this.o = { rowHeight: 44, ...opts };
    this.rh = this.o.rowHeight;
    this.rows = [];      // all entries
    this.view = [];      // sorted + filtered entries
    this.sel = new Set();// selected names
    this.focus = -1;     // keyboard cursor (index in view)
    this.anchor = -1;    // shift-selection anchor
    this.sortKey = 'name';
    this.sortDir = 1;
    this.filterText = '';
    this.typeahead = '';
    this.loading = false;
    this.build(host);
  }

  /**
   * Widen a column whose header label doesn't fit its standard width (long words in some languages,
   * e.g. German "GRÖSSE", "BERECHTIGUNGEN"). Runs when the grid becomes visible or changes size.
   */
  fitHeader() {
    const head = this.el?.querySelector('.grid-head');
    if (!head || !head.offsetParent) return;
    const keys = this.o.columns.map((c) => c.key).filter((k) => k !== 'name');
    for (const k of keys) this.el.style.removeProperty(`--w-${k}`);
    for (const k of keys) {
      const cell = head.querySelector(`.gc-${k}`);
      if (cell?.offsetParent && cell.scrollWidth > cell.clientWidth) this.el.style.setProperty(`--w-${k}`, `${cell.scrollWidth + 2}px`);
    }
  }

  build(host) {
    const cols = this.o.columns;
    host.innerHTML = `
      <div class="grid" role="grid" aria-multiselectable="true" tabindex="0" aria-label="${esc(t('Files'))}">
        <div class="grid-head" role="row">
          <div class="gc gc-check" role="columnheader"><span class="cbox" role="checkbox" aria-checked="false" aria-label="${esc(t('Select all'))}" data-all></span></div>
          ${cols.map((c) => `<div class="gc gc-${c.key}" role="columnheader">${c.sortable === false ? `<span>${esc(c.label)}</span>`
            : `<button class="sort-btn" data-key="${c.key}">${esc(c.label)}${icon('chevron-down', 'sort-ico')}</button>`}</div>`).join('')}
        </div>
        <div class="grid-body">
          <div class="grid-spacer"><div class="grid-rows"></div></div>
          <div class="grid-empty" hidden></div>
          <div class="grid-skeleton" hidden>${'<div class="sk-row"><span></span><span></span><span></span></div>'.repeat(8)}</div>
        </div>
      </div>`;
    this.el = host.querySelector('.grid');
    this.body = this.el.querySelector('.grid-body');
    this.spacer = this.el.querySelector('.grid-spacer');
    this.rowsEl = this.el.querySelector('.grid-rows');
    this.emptyEl = this.el.querySelector('.grid-empty');
    this.skel = this.el.querySelector('.grid-skeleton');
    this.allBox = this.el.querySelector('[data-all]');
    this.el.style.setProperty('--row-h', `${this.rh}px`);

    let raf = 0;
    this.body.addEventListener('scroll', () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; this.render(); }); }, { passive: true });
    new ResizeObserver(() => { this.fitHeader(); this.render(); }).observe(this.body);

    this.el.querySelector('.grid-head').addEventListener('click', (e) => {
      const b = e.target.closest('.sort-btn');
      if (b) { this.sortBy(b.dataset.key); return; }
      if (e.target.closest('[data-all]')) this.toggleAll();
    });

    this.rowsEl.addEventListener('click', (e) => this.onClick(e));
    this.rowsEl.addEventListener('dblclick', (e) => {
      const r = e.target.closest('.gr');
      if (r && !e.target.closest('.cbox')) this.o.onOpen?.(this.view[+r.dataset.i]);
    });
    this.body.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      const r = e.target.closest('.gr');
      let entry = null;
      if (r) {
        const i = +r.dataset.i;
        entry = this.view[i];
        if (!this.sel.has(entry.name)) { this.sel = new Set([entry.name]); this.anchor = i; }
        this.focus = i;
        this.changed();
      }
      this.o.onContext?.(e, entry);
    });
    let hoverT;
    this.rowsEl.addEventListener('mouseover', (e) => {
      const r = e.target.closest('.gr');
      if (!r) return;
      clearTimeout(hoverT);
      hoverT = setTimeout(() => this.o.onHover?.(this.view[+r.dataset.i]), 70);
    });
    this.rowsEl.addEventListener('mouseleave', () => clearTimeout(hoverT));
    this.el.addEventListener('keydown', (e) => this.onKey(e));
  }

  // ------------------------------------------------------------ data
  setRows(entries, { keepSelection = false, focusName = null, resetScroll = true } = {}) {
    this.rows = entries;
    if (!keepSelection) this.sel.clear();
    else { const names = new Set(entries.map((e) => e.name)); this.sel = new Set([...this.sel].filter((n) => names.has(n))); }
    this.loading = false;
    this.skel.hidden = true;
    this.recompute();
    if (resetScroll) this.body.scrollTop = 0;
    this.focus = -1;
    if (focusName) {
      const i = this.view.findIndex((e) => e.name === focusName);
      if (i >= 0) { this.focus = i; this.anchor = i; this.sel = new Set([focusName]); this.scrollTo(i, true); }
    }
    this.changed();
  }

  setLoading(on) {
    this.loading = on;
    this.skel.hidden = !on;
    if (on) { this.rowsEl.innerHTML = ''; this.spacer.style.height = '0px'; this.emptyEl.hidden = true; }
  }

  setEmptyMessage(html) { this.emptyHtml = html; }

  recompute() {
    const f = this.filterText.toLowerCase();
    const list = f ? this.rows.filter((e) => e.name.toLowerCase().includes(f)) : this.rows.slice();
    const k = this.sortKey, d = this.sortDir;
    list.sort((a, b) => {
      if (a.isDir !== b.isDir) return a.isDir ? -1 : 1; // folders first
      let r = 0;
      if (k === 'name') r = collator.compare(a.name, b.name);
      else if (k === 'size' || k === 'mtime') r = (a[k] ?? 0) - (b[k] ?? 0);
      else r = collator.compare(a[k] ?? '', b[k] ?? '');
      return (r || collator.compare(a.name, b.name)) * d;
    });
    this.view = list;
    this.spacer.style.height = `${list.length * this.rh}px`;
    this.el.querySelectorAll('.sort-btn').forEach((b) => {
      b.classList.toggle('active', b.dataset.key === k);
      b.classList.toggle('desc', b.dataset.key === k && d < 0);
    });
  }

  sortBy(key) {
    if (this.sortKey === key) this.sortDir *= -1; else { this.sortKey = key; this.sortDir = key === 'mtime' || key === 'size' ? -1 : 1; }
    const focused = this.view[this.focus]?.name;
    this.recompute();
    this.focus = focused ? this.view.findIndex((e) => e.name === focused) : -1;
    this.render();
  }

  filter(text) {
    this.filterText = text;
    this.recompute();
    // never keep hidden rows selected (avoids deleting things you cannot see)
    const visible = new Set(this.view.map((e) => e.name));
    this.sel = new Set([...this.sel].filter((nm) => visible.has(nm)));
    this.focus = this.view.length ? 0 : -1;
    this.body.scrollTop = 0;
    this.changed();
  }

  // ------------------------------------------------------------ selection
  getSelected() { return this.view.filter((e) => this.sel.has(e.name)); }
  getFocused() { return this.view[this.focus] || null; }
  selectNames(names) { this.sel = new Set(names); this.changed(); }
  clearSelection() { this.sel.clear(); this.changed(); }
  toggleAll() {
    if (this.view.length && this.view.every((e) => this.sel.has(e.name))) this.sel.clear();
    else this.view.forEach((e) => this.sel.add(e.name));
    this.changed();
  }

  changed() {
    this.render();
    const n = this.sel.size, total = this.view.length;
    this.allBox.setAttribute('aria-checked', n === 0 ? 'false' : n >= total && total > 0 ? 'true' : 'mixed');
    this.o.onSelect?.(this.getSelected());
  }

  onClick(e) {
    const r = e.target.closest('.gr');
    if (!r) return;
    const i = +r.dataset.i;
    const entry = this.view[i];
    const link = e.target.closest('.name-link');
    if (link && !e.shiftKey && !modKey(e)) {
      e.preventDefault();
      this.o.onOpen?.(entry);
      return;
    }
    if (link) e.preventDefault();
    if (e.target.closest('.cbox') || modKey(e)) {
      this.sel.has(entry.name) ? this.sel.delete(entry.name) : this.sel.add(entry.name);
      this.anchor = i;
    } else if (e.shiftKey && this.anchor >= 0) {
      this.rangeSelect(this.anchor, i);
    } else {
      this.sel = new Set([entry.name]);
      this.anchor = i;
    }
    this.focus = i;
    this.el.focus({ preventScroll: true });
    this.changed();
  }

  rangeSelect(a, b) {
    const [lo, hi] = a < b ? [a, b] : [b, a];
    this.sel = new Set(this.view.slice(lo, hi + 1).map((e) => e.name));
  }

  onKey(e) {
    if (e.target.closest('input, textarea')) return;
    const n = this.view.length;
    const page = Math.max(1, Math.floor(this.body.clientHeight / this.rh) - 1);
    const move = (to) => {
      e.preventDefault();
      if (!n) return;
      to = Math.max(0, Math.min(n - 1, to));
      if (e.shiftKey) { if (this.anchor < 0) this.anchor = Math.max(0, this.focus); this.rangeSelect(this.anchor, to); }
      else if (!modKey(e)) { this.sel = new Set([this.view[to].name]); this.anchor = to; }
      this.focus = to;
      this.scrollTo(to);
      this.changed();
    };
    switch (e.key) {
      case 'ArrowDown': return move(this.focus + 1);
      case 'ArrowUp': return move(this.focus < 0 ? 0 : this.focus - 1);
      case 'PageDown': return move(this.focus + page);
      case 'PageUp': return move(this.focus - page);
      case 'Home': return move(0);
      case 'End': return move(n - 1);
      case ' ':
        if (this.focus >= 0) {
          e.preventDefault();
          const nm = this.view[this.focus].name;
          this.sel.has(nm) ? this.sel.delete(nm) : this.sel.add(nm);
          this.changed();
        }
        return;
      case 'Enter':
        if (this.focus >= 0) { e.preventDefault(); this.o.onOpen?.(this.view[this.focus]); }
        return;
      case 'Escape':
        if (this.sel.size) { e.preventDefault(); this.clearSelection(); }
        return;
      default:
    }
    if (modKey(e) && e.key.toLowerCase() === 'a') { e.preventDefault(); this.view.forEach((x) => this.sel.add(x.name)); this.changed(); return; }
    if (this.o.onKey?.(e) === true) return;
    // type-ahead: jump to the first entry starting with the typed letters
    if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
      clearTimeout(this.taT);
      this.typeahead += e.key.toLowerCase();
      this.taT = setTimeout(() => { this.typeahead = ''; }, 700);
      const i = this.view.findIndex((x) => x.name.toLowerCase().startsWith(this.typeahead));
      if (i >= 0) { this.sel = new Set([this.view[i].name]); this.focus = this.anchor = i; this.scrollTo(i); this.changed(); }
    }
  }

  scrollTo(i, center = false) {
    const top = i * this.rh, h = this.body.clientHeight;
    if (center) this.body.scrollTop = Math.max(0, top - h / 2 + this.rh);
    else if (top < this.body.scrollTop) this.body.scrollTop = top;
    else if (top + this.rh > this.body.scrollTop + h) this.body.scrollTop = top + this.rh - h;
  }

  focusGrid() { this.el.focus({ preventScroll: true }); if (this.focus < 0 && this.view.length) { this.focus = 0; this.render(); } }

  // ------------------------------------------------------------ rendering
  render() {
    if (this.loading) return;
    const n = this.view.length;
    this.emptyEl.hidden = n > 0;
    if (!n) {
      this.rowsEl.innerHTML = '';
      this.emptyEl.innerHTML = this.filterText
        ? `${icon('search', 'empty-ico')}<p>${esc(t('No items match “{text}”.', { text: this.filterText }))}</p>`
        : (this.emptyHtml || `<p>${esc(t('This folder is empty'))}</p>`);
      return;
    }
    this.el.style.setProperty('--sbw', `${this.body.offsetWidth - this.body.clientWidth}px`);
    const h = this.body.clientHeight || 600;
    const over = 8;
    const start = Math.max(0, Math.floor(this.body.scrollTop / this.rh) - over);
    const end = Math.min(n, Math.ceil((this.body.scrollTop + h) / this.rh) + over);
    const cols = this.o.columns;
    let html = '';
    for (let i = start; i < end; i++) {
      const e = this.view[i];
      const s = this.sel.has(e.name);
      const kind = fileKind(e);
      html += `<div class="gr${s ? ' sel' : ''}${i === this.focus ? ' focus' : ''}" role="row" aria-selected="${s}" data-i="${i}">`
        + `<div class="gc gc-check"><span class="cbox" role="checkbox" aria-checked="${s}"></span></div>`;
      for (const c of cols) {
        if (c.key === 'name') {
          html += `<div class="gc gc-name">${icon(KIND_ICON[kind] || 'file', `k-${kind}`)}`
            + `<a class="name-link" dir="auto" href="${esc(this.o.hrefFor?.(e) || '#')}" draggable="false" title="${esc(e.name)}">${esc(e.name)}</a>`
            + (e.type === 'link' ? `<span class="badge-link" title="${esc(e.target ? '→ ' + e.target : t('Symbolic link'))}">${icon('link')}</span>` : '')
            + `</div>`;
        } else if (c.key === 'size') {
          html += `<div class="gc gc-size">${e.isDir ? '<span class="muted">—</span>' : fmtSize(e.size)}</div>`;
        } else if (c.key === 'mtime') {
          html += `<div class="gc gc-mtime" title="${esc(fmtDateFull(e.mtime))}">${esc(fmtDate(e.mtime))}</div>`;
        } else {
          html += `<div class="gc gc-${c.key}">${esc(e[c.key] ?? '')}</div>`;
        }
      }
      html += '</div>';
    }
    this.rowsEl.style.transform = `translateY(${start * this.rh}px)`;
    this.rowsEl.innerHTML = html;
  }
}

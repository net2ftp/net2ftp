// net2ftp v2 — internationalisation
//
// Catalogs live in assets/i18n/<code>.json and map the English text (the key) to its translation.
// A value can be a string or, for counts, an object of plural forms keyed by Intl.PluralRules
// categories (zero, one, two, few, many, other). Missing keys fall back to English.
// The chosen language is kept in the "n2f_lang" cookie (persistent when "Preferences" cookies are
// allowed, otherwise until the browser is closed); the server reads it for its own messages.
import { readCookie, writeCookie } from './cookies.js';

export const LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'de', name: 'Deutsch' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
  { code: 'nl', name: 'Nederlands' },
  { code: 'ru', name: 'Русский' },
  { code: 'zh-Hans', name: '简体中文' },
  { code: 'zh-Hant', name: '繁體中文' },
  { code: 'ja', name: '日本語' },
  { code: 'he', name: 'עברית', rtl: true },
  { code: 'ar', name: 'العربية', rtl: true },
];
const CODES = LANGUAGES.map((l) => l.code);

let lang = 'en';
let dict = {};
let plural = new Intl.PluralRules('en');

export const currentLanguage = () => lang;
export const isRtl = () => !!LANGUAGES.find((l) => l.code === lang)?.rtl;
/** BCP-47 locale for Intl formatting. */
export const locale = () => lang;

function fill(s, params) {
  return params ? s.replace(/\{(\w+)\}/g, (m, k) => (params[k] !== undefined ? String(params[k]) : m)) : s;
}

/** Translate an English text. Placeholders like {name} are filled from params. */
export function t(key, params) {
  const v = dict[key];
  return fill(typeof v === 'string' && v !== '' ? v : key, params);
}

/**
 * Translate a count: tn('{n} files', n, { one: '{n} file' }).
 * The English forms are given in code; catalogs provide all forms their language needs.
 */
export function tn(key, n, english = {}) {
  const cat = plural.select(n);
  const v = dict[key];
  let s;
  if (v && typeof v === 'object') s = v[cat] ?? v.other ?? key;
  else if (typeof v === 'string' && v) s = v;
  else s = (cat === 'one' && english.one) || key;
  return fill(s, { n: n.toLocaleString(lang), ...english.params });
}

/**
 * The language in the address (?hl=de), as on the information pages: every language version of the login page
 * has its own address, so that search engines can index each one (they don't send a language cookie).
 */
export function urlLanguage() {
  const q = new URLSearchParams(location.search).get('hl');
  return q && CODES.includes(q) ? q : '';
}

/** Language from the address (?hl=), else the cookie, else the browser's preferred languages, else English. */
export function detectLanguage() {
  if (urlLanguage()) return urlLanguage();
  const m = readCookie('n2f_lang');
  if (m && CODES.includes(decodeURIComponent(m))) return decodeURIComponent(m);
  for (const raw of navigator.languages || [navigator.language || 'en']) {
    const l = raw.toLowerCase();
    if (l.startsWith('zh')) return /(tw|hk|mo|hant)/.test(l) ? 'zh-Hant' : 'zh-Hans';
    const base = l.split('-')[0];
    if (base === 'iw') return 'he';
    if (CODES.includes(base)) return base;
  }
  return 'en';
}

function remember(code, persistent) {
  writeCookie('n2f_lang', encodeURIComponent(code), persistent ? 365 * 86400 : null);
}

/** Make the current language choice permanent (Preferences allowed) or session-only. */
export function persistLanguage(persistent) {
  if (readCookie('n2f_lang') !== null) remember(lang, persistent);
}

/**
 * Switch the interface language: loads the catalog, sets lang/dir on <html>, translates the static page.
 * @param {string} code
 * @param {{persist?:boolean, save?:boolean}} opts persist = keep the cookie across browser restarts; save = write the cookie
 */
export async function setLanguage(code, { persist = false, save = true } = {}) {
  if (!CODES.includes(code)) code = 'en';
  let next = {};
  if (code !== 'en') {
    try {
      const r = await fetch(`assets/i18n/${code}.json`, { cache: 'force-cache' });
      if (r.ok) next = await r.json();
    } catch { /* keep English */ }
  }
  lang = code;
  dict = next;
  plural = new Intl.PluralRules(code);
  const html = document.documentElement;
  html.lang = code;
  html.dir = isRtl() ? 'rtl' : 'ltr';
  if (save) remember(code, persist);
  translateDom(document);
  window.dispatchEvent(new CustomEvent('n2f:language', { detail: code }));
}

/**
 * Translate static markup. The English text in the HTML is the key:
 *   data-i18n            → textContent
 *   data-i18n-html       → innerHTML (trusted static markup only)
 *   data-i18n-attr="placeholder,title,aria-label" → those attributes
 */
export function translateDom(root) {
  root.querySelectorAll('[data-i18n]').forEach((el) => {
    if (el.dataset.i18nSrc === undefined) el.dataset.i18nSrc = el.textContent.trim().replace(/\s+/g, ' ');
    el.textContent = t(el.dataset.i18nSrc);
  });
  root.querySelectorAll('[data-i18n-html]').forEach((el) => {
    if (el.dataset.i18nSrc === undefined) el.dataset.i18nSrc = el.innerHTML.trim().replace(/\s+/g, ' ');
    el.innerHTML = t(el.dataset.i18nSrc);
  });
  root.querySelectorAll('[data-i18n-attr]').forEach((el) => {
    for (const a of el.dataset.i18nAttr.split(',')) {
      const k = `i18nSrc${a.replace(/[^a-z]/gi, '')}`;
      if (el.dataset[k] === undefined) el.dataset[k] = el.getAttribute(a) || '';
      if (el.dataset[k]) el.setAttribute(a, t(el.dataset[k]));
    }
  });
}

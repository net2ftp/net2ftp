// net2ftp v2 — copy, move and delete jobs of any size.
//
// The server does the work in short steps; this module calls `jobstep` again and again, with 2 workers in
// parallel (fewer when the server allows few connections). Everything is saved on the server after each step,
// so a job survives network errors, crashed requests and closed browsers: after the next login it is offered
// again (and continued at once when it was interrupted rather than paused).
import * as api from './api.js';
import { t, tn } from './i18n.js';
import { dialog, confirmDialog } from './ui.js';
import { $, esc, icon, fmtSize, baseName } from './util.js';
import { retryable } from './uploads.js';

const RETRY_DELAYS = [1, 2, 4, 8, 15, 30, 30, 60];   // seconds between attempts after a connection problem
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const ICON = { copy: 'copy', move: 'move', delete: 'trash' };

export class JobPanel {
  constructor({ onFinished }) {
    this.onFinished = onFinished;
    this.jobs = new Map();
    this.gen = 0;
    this.panel = $('#jobs');
    this.list = this.panel.querySelector('.up-list');
    this.panel.querySelector('.up-toggle').onclick = () => this.panel.classList.toggle('collapsed');
    this.panel.querySelector('.up-clear').onclick = () => this.clearFinished();
    this.timer = setInterval(() => this.jobs.forEach((e) => this.paint(e)), 1000);
  }

  /** Start a job. Returns {finished:true} when the server did it at once (a move on FTP/SFTP is a rename). */
  async start(kind, path, items, target = null) {
    const d = await api.call('jobstart', { kind, path, items: items.map(({ name, isDir }) => ({ name, isDir })), ...(target != null ? { target } : {}) });
    if (d.finished) return { finished: true };
    const e = this.add(d.job, d.workers);
    this.run(e);
    return { job: d.job };
  }

  /** After a login: jobs of this account that are not finished. Interrupted ones continue at once. */
  async restore() {
    const gen = ++this.gen;
    let d;
    try { d = await api.call('jobs'); } catch { return; }
    if (gen !== this.gen) return;   // a newer restore (or a logout) came in meanwhile
    for (const job of d.jobs || []) {
      if (this.jobs.has(job.id) || !['running', 'paused'].includes(job.status)) continue;
      const e = this.add(job, d.workers);
      if (job.status === 'running') {
        api.call('jobcontrol', { id: job.id, op: 'resume' }).then((r) => { e.job = r.job; this.run(e); }).catch(() => {});
      }
    }
  }

  add(job, workers) {
    const e = { job, workers: workers || 2, running: 0, stopping: false, retrying: false, samples: [], el: null };
    this.list.insertAdjacentHTML('afterbegin', `<li class="up-item job"><div class="up-row">${icon(ICON[job.kind] || 'copy')}
      <span class="up-name" dir="auto" translate="no"></span><span class="up-stat"></span>
      <button class="icon-btn job-pause"></button><button class="icon-btn up-cancel" aria-label="${esc(t('Cancel'))}" title="${esc(t('Cancel'))}">${icon('x')}</button></div>
      <div class="up-bar"><i></i></div><div class="job-detail"></div></li>`);
    e.el = this.list.firstElementChild;
    e.el.querySelector('.job-pause').onclick = () => (this.isActive(e) ? this.pause(e) : this.resume(e));
    e.el.querySelector('.up-cancel').onclick = () => this.cancelOrDismiss(e);
    this.jobs.set(job.id, e);
    this.panel.hidden = false;
    this.panel.classList.remove('collapsed');
    this.paint(e);
    return e;
  }

  isActive(e) { return e.job.status === 'running' && !e.stopping; }

  /** Run the job's workers until it is finished, paused or cancelled. */
  run(e) {
    e.stopping = false;
    const n = Math.max(1, e.workers) - e.running;
    for (let i = 0; i < n; i++) this.worker(e);
  }

  async worker(e) {
    e.running++;
    let fails = 0;
    try {
      while (!e.stopping && e.job.status === 'running') {
        try {
          const r = await api.call('jobstep', { id: e.job.id });
          fails = 0;
          e.retrying = false;
          this.update(e, r);
          if (r.workers && r.workers !== e.workers) {
            e.workers = r.workers;        // the server learned it allows fewer connections
            if (e.running > e.workers) break;
            this.run(e);
          }
          if (r.wait) await sleep(r.busy ? 1500 : 400);
        } catch (err) {
          if (err.status === 404) { e.job.status = 'gone'; break; }
          if (err.status === 401 || !retryable(err) || fails >= RETRY_DELAYS.length) {
            e.error = err.message;
            e.stopping = true;
            break;
          }
          e.retrying = true;
          this.paint(e);
          await sleep(RETRY_DELAYS[fails++] * 1000);
        }
      }
    } finally {
      e.running--;
      this.paint(e);
    }
  }

  update(e, job) {
    const before = e.job.status;
    e.job = job;
    const now = Date.now();
    e.samples.push([now, job.done.bytes, job.done.files]);
    e.samples = e.samples.filter(([ts]) => now - ts < 15000);
    this.paint(e);
    if (before === 'running' && job.status !== 'running') this.finished(e);
  }

  finished(e) {
    const { job } = e;
    if (job.status === 'done' || job.status === 'cancelled') this.onFinished?.(job);
  }

  async pause(e) {
    e.stopping = true;
    this.paint(e);
    try { e.job = (await api.call('jobcontrol', { id: e.job.id, op: 'pause' })).job; } catch { /* the steps stop anyway */ }
    this.paint(e);
  }

  async resume(e) {
    e.error = null;
    try { e.job = (await api.call('jobcontrol', { id: e.job.id, op: 'resume' })).job; } catch (err) { e.error = err.message; this.paint(e); return; }
    this.run(e);
    this.paint(e);
  }

  async cancelOrDismiss(e) {
    const { job } = e;
    if (['done', 'cancelled', 'gone'].includes(job.status)) {
      api.call('jobcontrol', { id: job.id, op: 'dismiss' }).catch(() => {});
      this.removeRow(e);
      return;
    }
    const ok = await confirmDialog({
      title: t('Cancel this job?'),
      message: job.kind === 'delete' ? t('What is deleted so far stays deleted.') : t('What is copied so far stays in the target folder; a file copied only partly is removed.'),
      okLabel: t('Cancel job'), danger: true,
    });
    if (!ok) return;
    e.stopping = true;
    try {
      e.job = (await api.call('jobcontrol', { id: job.id, op: 'cancel' })).job;
      this.finished(e);
    } catch (err) { e.error = err.message; }
    this.paint(e);
  }

  removeRow(e) {
    e.stopping = true;
    e.el.remove();
    this.jobs.delete(e.job.id);
    if (!this.jobs.size) this.panel.hidden = true;
    this.summary();
  }

  clearFinished() {
    this.jobs.forEach((e) => {
      if (['done', 'cancelled', 'gone'].includes(e.job.status)) {
        api.call('jobcontrol', { id: e.job.id, op: 'dismiss' }).catch(() => {});
        this.removeRow(e);
      }
    });
  }

  /** Stop the workers and forget the rows (logout); the jobs stay on the server for the next login. */
  reset() {
    this.gen++;
    this.jobs.forEach((e) => { e.stopping = true; });
    this.jobs.clear();
    this.list.replaceChildren();
    this.panel.hidden = true;
  }

  // ---- display ----

  title(job) {
    const what = job.count === 1 ? job.names[0] : tn('{n} items', job.count, { one: '{n} item' });
    const folder = baseName(job.target || '') || '/';
    const done = job.status === 'done';
    if (job.kind === 'delete') return done ? t('Deleted {name}', { name: what }) : t('Deleting {name}…', { name: what });
    if (job.kind === 'move') return done ? t('Moved {name} to {folder}', { name: what, folder }) : t('Moving {name} to {folder}…', { name: what, folder });
    return done ? t('Copied {name} to {folder}', { name: what, folder }) : t('Copying {name} to {folder}…', { name: what, folder });
  }

  /** Bytes per second over the last seconds (copies), or files per second (delete). */
  speed(e) {
    const s = e.samples;
    if (s.length < 2) return null;
    const [t0, b0, f0] = s[0];
    const [t1, b1, f1] = s[s.length - 1];
    const secs = (t1 - t0) / 1000;
    if (secs < 1.5) return null;
    return { bytes: (b1 - b0) / secs, files: (f1 - f0) / secs };
  }

  paint(e) {
    const { job } = e;
    const isDelete = job.kind === 'delete';
    const total = isDelete ? job.totals.files + job.dirsTotal : job.totals.bytes;
    const done = isDelete ? job.done.files + job.dirsDone : job.done.bytes;
    const pct = job.status === 'done' ? 100 : (job.scanDone && total > 0 ? Math.min(99, Math.floor((done / total) * 100)) : 0);
    const active = this.isActive(e) && e.running > 0;
    let state = job.status;
    if (state === 'running' && !active) state = e.stopping ? 'paused' : 'waiting';
    e.el.className = `up-item job ${state === 'done' ? (job.failed ? 'error' : 'done') : state === 'cancelled' ? 'cancelled' : state}${!job.scanDone && active ? ' scanning' : ''}`;
    e.el.querySelector('.up-name').textContent = this.title(job);
    e.el.querySelector('.up-name').title = `${job.src}${job.target ? ' → ' + job.target : ''}`;
    e.el.querySelector('.up-bar i').style.width = `${pct}%`;

    let stat;
    if (e.error) stat = e.error;
    else if (e.retrying) stat = t('Connection problem — retrying…');
    else if (state === 'done') stat = job.failed ? tn('{n} failed', job.failed) : t('Done');
    else if (state === 'cancelled') stat = t('Cancelled');
    else if (state === 'paused') stat = `${pct}% · ${t('Paused')}`;
    else if (state === 'waiting') stat = `${pct}% · ${t('Interrupted')}`;
    else if (!job.scanDone) stat = t('Scanning…');
    else stat = `${pct}%`;
    e.el.querySelector('.up-stat').textContent = stat;
    e.el.querySelector('.up-stat').title = stat;

    // second line: what has been done, speed, time left
    const parts = [];
    const files = job.scanDone ? tn('{i} of {n} files', job.totals.files, { one: '{i} of {n} file', params: { i: job.done.files.toLocaleString() } })
      : tn('{n} files found', job.totals.files, { one: '{n} file found' });
    parts.push(files);
    if (!isDelete && job.totals.bytes) parts.push(job.scanDone ? `${fmtSize(job.done.bytes)} / ${fmtSize(job.totals.bytes)}` : fmtSize(job.totals.bytes));
    const sp = active ? this.speed(e) : null;
    if (sp && !isDelete && sp.bytes > 0) {
      parts.push(`${fmtSize(sp.bytes)}/s`);
      if (job.scanDone && total > done) parts.push(remaining((total - done) / sp.bytes));
    } else if (sp && isDelete && sp.files > 0 && job.scanDone && total > done) {
      parts.push(remaining((total - done) / sp.files));
    }
    let detail = esc(parts.join(' · '));
    if (job.failed && job.errors?.length) detail += ` · <button class="link-btn job-errors">${esc(t('Show problems'))}</button>`;
    const box = e.el.querySelector('.job-detail');
    if (box.dataset.html !== detail) {
      box.innerHTML = detail;
      box.dataset.html = detail;
      box.querySelector('.job-errors')?.addEventListener('click', () => this.showErrors(e));
    }

    const btn = e.el.querySelector('.job-pause');
    const canToggle = ['running', 'paused'].includes(job.status);
    btn.hidden = !canToggle;
    const pauseIt = this.isActive(e);
    btn.innerHTML = icon(pauseIt ? 'pause' : 'play');
    btn.title = pauseIt ? t('Pause') : t('Continue');
    btn.setAttribute('aria-label', btn.title);
    const x = e.el.querySelector('.up-cancel');
    x.title = ['done', 'cancelled', 'gone'].includes(job.status) ? t('Remove from the list') : t('Cancel');
    x.setAttribute('aria-label', x.title);
    this.summary();
  }

  summary() {
    const all = [...this.jobs.values()];
    const busy = all.filter((e) => this.isActive(e) && e.running > 0);
    const open = all.filter((e) => ['running', 'paused'].includes(e.job.status));
    this.panel.querySelector('.up-title').textContent = busy.length
      ? tn('{n} jobs running', busy.length, { one: '{n} job running' })
      : open.length ? tn('{n} unfinished jobs', open.length, { one: '{n} unfinished job' }) : t('Jobs');
    this.panel.classList.toggle('busy', busy.length > 0);
  }

  showErrors(e) {
    const { job } = e;
    const more = job.failed - job.errors.length;
    dialog({
      title: tn('{n} items could not be processed', job.failed, { one: '{n} item could not be processed' }),
      body: `<ul class="name-list err-list">${job.errors.map((m) => `<li dir="auto">${esc(m)}</li>`).join('')}${more > 0 ? `<li class="muted">${esc(tn('… and {n} more', more))}</li>` : ''}</ul>`,
      actions: [{ label: t('Close'), primary: true }],
    });
  }
}

function remaining(secs) {
  if (!isFinite(secs) || secs <= 0) return '';
  if (secs < 60) return t('less than a minute left');
  if (secs < 3600) return tn('about {n} minutes left', Math.round(secs / 60), { one: 'about {n} minute left' });
  return tn('about {n} hours left', Math.round(secs / 360) / 10, { one: 'about {n} hour left' });
}

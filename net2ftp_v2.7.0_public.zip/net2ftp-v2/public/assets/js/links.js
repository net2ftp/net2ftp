// net2ftp v2 — bookmarkable links
//
// Every page has a complete, self-describing address in the URL fragment (after "#"), e.g.
//   #ftp://alice@ftp.example.com/www
//   #ftps://alice@ftp.example.com:990/www/index.php?edit&line=12
//   #sftp://deploy@10.0.0.5:2222/var/www
//   #s3://AKIAEXAMPLE@eu-central-2/my-bucket/images            (AWS region)
//   #s3://AKIAEXAMPLE@sos-ch-gva-2.exo.io/my-bucket?bucket=1    (custom endpoint, login restricted to the bucket)
// Passwords and secret keys are never part of a link. The fragment is not sent to the web server, so links
// do not end up in server logs.

const DEFAULT_PORT = { ftp: 21, ftps: 21, sftp: 22 };
const encSeg = (p) => p.split('/').map(encodeURIComponent).join('/');

/** @param {object} pub connection details from the session (conn.public) */
export function buildLink(pub, path, { edit = false, line = 0 } = {}) {
  if (!pub) return `#${encSeg(path)}`;
  const q = new URLSearchParams();
  let auth;
  let scheme = pub.protocol;
  if (scheme === 's3') {
    let host = pub.region;
    if (pub.endpoint) {
      const u = new URL(pub.endpoint);
      host = u.host;
      if (u.protocol === 'http:') q.set('tls', '0');
    }
    auth = `${encodeURIComponent(pub.accessKey)}@${host}`;
    if (pub.bucket) q.set('bucket', '1');
  } else {
    if (scheme === 'ftp' && pub.ssl) scheme = 'ftps';
    const port = Number(pub.port) && Number(pub.port) !== DEFAULT_PORT[scheme] ? `:${pub.port}` : '';
    const host = pub.host.includes(':') && !pub.host.startsWith('[') ? `[${pub.host}]` : pub.host;
    auth = `${pub.username ? encodeURIComponent(pub.username) + '@' : ''}${host}${port}`;
    if (scheme.startsWith('ftp') && pub.passive === false) q.set('passive', '0');
  }
  let qs = q.toString();
  if (edit) qs = `edit${line ? `&line=${line}` : ''}${qs ? '&' + qs : ''}`;
  return `#${scheme}://${auth}${encSeg(path || '/')}${qs ? '?' + qs : ''}`;
}

/** Parse a fragment. Returns null when it is not a connection link (e.g. empty or an old "#/path" link). */
export function parseLink(hash) {
  const h = (hash || '').replace(/^#/, '');
  const m = h.match(/^(ftps?|sftp|s3):\/\/(?:([^@/?]*)@)?(\[[^\]]+\]|[^/:?]+)(?::(\d+))?(\/[^?]*)?(?:\?(.*))?$/i);
  if (!m) return null;
  const [, schemeRaw, user = '', hostRaw, port, pathRaw = '/', query = ''] = m;
  const scheme = schemeRaw.toLowerCase();
  const q = new URLSearchParams(query);
  let path = '/';
  try { path = decodeURIComponent(pathRaw) || '/'; } catch { path = pathRaw; }
  const host = hostRaw.replace(/^\[|\]$/g, '');
  let username = '';
  try { username = decodeURIComponent(user); } catch { username = user; }
  const link = { path: path.replace(/\/+$/, '') || '/', edit: q.has('edit'), line: parseInt(q.get('line') || '0', 10) || 0 };
  if (scheme === 's3') {
    const isRegion = !host.includes('.') && !port;
    const firstSeg = link.path.split('/').filter(Boolean)[0] || '';
    return {
      ...link, protocol: 's3', accessKey: username,
      region: isRegion ? host : '',
      endpoint: isRegion ? '' : `${q.get('tls') === '0' ? 'http' : 'https'}://${host}${port ? ':' + port : ''}`,
      bucket: q.get('bucket') === '1' ? firstSeg : '',
    };
  }
  return {
    ...link,
    protocol: scheme === 'ftps' ? 'ftp' : scheme,
    ssl: scheme === 'ftps',
    passive: q.get('passive') !== '0',
    host,
    port: port ? Number(port) : DEFAULT_PORT[scheme],
    username,
  };
}

/** Does a parsed link point to the connection described by pub? */
export function sameConnection(pub, link) {
  if (!pub || !link || pub.protocol !== link.protocol) return false;
  if (link.protocol === 's3') {
    const ep = (e) => (e || '').replace(/\/+$/, '').toLowerCase();
    return pub.accessKey === link.accessKey && ep(pub.endpoint) === ep(link.endpoint)
      && (link.endpoint ? true : pub.region === link.region);
  }
  return pub.host.toLowerCase() === link.host.toLowerCase() && Number(pub.port) === Number(link.port)
    && (pub.username || '') === (link.username || '') && !!pub.ssl === !!link.ssl;
}

/** Label for messages, e.g. "alice@ftp.example.com". */
export function linkLabel(l) {
  if (l.protocol === 's3') return `${l.accessKey} · ${l.endpoint ? new URL(l.endpoint).host : l.region}`;
  return `${l.username ? l.username + '@' : ''}${l.host}${l.port !== DEFAULT_PORT[l.ssl ? 'ftps' : l.protocol] ? ':' + l.port : ''}`;
}

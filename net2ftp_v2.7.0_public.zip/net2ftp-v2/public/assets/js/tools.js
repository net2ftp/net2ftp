// Permissions (chmod/chown), extract on the server, and share links.
import * as api from './api.js';
import { toast, dialog, confirmDialog } from './ui.js';
import { $, $$, esc, icon, fmtSize, fmtDateFull, joinPath } from './util.js';
import { t, tn } from './i18n.js';

let ctx; // { state, run, afterChange, invalidateTree }
export const initTools = (c) => { ctx = c; };

const plain = (items) => (items.length === 1 ? items[0].name : tn('{n} items', items.length, { one: '{n} item' }));

// ================================================================== permissions

/** "drwxr-xr-x" → 0o755 (also understands s/S/t/T). */
export function permsToMode(p) {
  if (!p || !/^[-dlbcps]?[-rwxsStT]{9}$/.test(p)) return null;
  const s = p.length === 10 ? p.slice(1) : p;
  let m = 0;
  [...s].forEach((c, i) => {
    const bit = 1 << (8 - i);
    if (c === 'r' || c === 'w' || c === 'x' || c === 's' || c === 't') m |= bit;
    if (i === 2 && (c === 's' || c === 'S')) m |= 0o4000;
    if (i === 5 && (c === 's' || c === 'S')) m |= 0o2000;
    if (i === 8 && (c === 't' || c === 'T')) m |= 0o1000;
  });
  return m;
}

const oct = (m) => m.toString(8).padStart(3, '0');

function permSet(kind, mode) {
  const rows = [[t('Owner'), 6], [t('Group'), 3], [t('Others'), 0]];
  const cols = [[t('Read'), 4], [t('Write'), 2], [kind === 'dir' ? t('Open') : t('Execute'), 1]];
  return `
  <fieldset class="perm-set" data-kind="${kind}">
    <legend><label class="check"><input type="checkbox" class="perm-on" checked>
      <span>${esc(kind === 'dir' ? t('Change folders') : t('Change files'))}</span></label></legend>
    <div class="perm-body">
      <table class="perm-grid"><thead><tr><th></th>${cols.map(([l]) => `<th>${esc(l)}</th>`).join('')}</tr></thead>
      <tbody>${rows.map(([who, sh]) => `<tr><th scope="row">${esc(who)}</th>${cols.map(([l, b]) =>
        `<td><input type="checkbox" data-bit="${b << sh}" aria-label="${esc(`${who} – ${l}`)}"></td>`).join('')}</tr>`).join('')}</tbody></table>
      <label class="perm-oct"><span>${esc(t('Octal'))}</span><input class="input oct mono" inputmode="numeric" maxlength="4" value="${oct(mode)}" dir="ltr" spellcheck="false"></label>
    </div>
  </fieldset>`;
}

function wirePermSet(fs, onChange) {
  const octIn = $('.oct', fs);
  const boxes = $$('input[data-bit]', fs);
  const fromOct = () => {
    const v = octIn.value.trim();
    const ok = /^[0-7]{3,4}$/.test(v);
    octIn.classList.toggle('invalid', !ok);
    if (!ok) return;
    const m = parseInt(v, 8);
    boxes.forEach((b) => { b.checked = !!(m & +b.dataset.bit); });
  };
  const toOct = () => {
    const cur = /^[0-7]{3,4}$/.test(octIn.value.trim()) ? parseInt(octIn.value.trim(), 8) : 0;
    let m = cur & 0o7000; // keep setuid/setgid/sticky typed in the octal field
    boxes.forEach((b) => { if (b.checked) m |= +b.dataset.bit; });
    octIn.value = m > 0o777 ? m.toString(8) : oct(m);
    octIn.classList.remove('invalid');
  };
  octIn.addEventListener('input', () => { fromOct(); onChange(); });
  boxes.forEach((b) => b.addEventListener('change', () => { toOct(); onChange(); }));
  $('.perm-on', fs).addEventListener('change', (e) => { fs.classList.toggle('off', !e.target.checked); onChange(); });
  fromOct();
  return {
    on: () => !fs.hidden && $('.perm-on', fs).checked,
    value: () => octIn.value.trim(),
    valid: () => /^[0-7]{3,4}$/.test(octIn.value.trim()),
  };
}

export async function doPermissions(items) {
  const f = ctx.state.conn?.features || {};
  if (!f.chmod) { toast(t('This server does not support changing permissions.'), { type: 'error' }); return; }
  const dirs = items.filter((i) => i.isDir);
  const files = items.filter((i) => !i.isDir);
  const dMode = permsToMode(dirs[0]?.perms) ?? 0o755;
  const fMode = permsToMode(files[0]?.perms) ?? 0o644;
  const body = document.createElement('div');
  body.className = 'perm-dlg';
  body.innerHTML = `
    ${permSet('dir', dMode & 0o7777)}
    ${permSet('file', fMode & 0o7777)}
    ${dirs.length ? `<label class="check perm-rec"><input type="checkbox" id="perm-rec">
      <span>${esc(t('Also change everything inside the selected folders (recursive)'))}</span></label>` : ''}
    ${f.chown ? `<div class="perm-owner">
      <label class="field"><span>${esc(t('Owner'))}</span><input class="input" id="perm-owner" placeholder="${esc(t('unchanged'))}" dir="ltr" autocomplete="off" spellcheck="false"></label>
      <label class="field"><span>${esc(t('Group'))}</span><input class="input" id="perm-group" placeholder="${esc(t('unchanged'))}" dir="ltr" autocomplete="off" spellcheck="false"></label>
      <small class="muted">${esc(t('User or group name, or numeric id. Usually only root may give files to another user.'))}</small>
    </div>` : ''}
    <p class="perm-warn" hidden>${icon('alert')}<span></span></p>
    <p class="perm-note muted" hidden>${icon('info')}<span>${esc(t('Folders are changed before their contents when the new permissions keep your access, and after their contents when they take it away — so you are never locked out halfway.'))}</span></p>`;
  const fsDir = $('[data-kind=dir]', body);
  const fsFile = $('[data-kind=file]', body);
  const rec = $('#perm-rec', body);
  const warn = $('.perm-warn', body);
  let D;
  let F;
  const update = () => {
    const recursive = !!rec?.checked;
    fsDir.hidden = !dirs.length;
    fsFile.hidden = !files.length && !recursive;
    $('.perm-note', body).hidden = !recursive;
    const dm = D?.on() && D.valid() ? parseInt(D.value(), 8) : null;
    const lock = dm !== null && (dm & 0o500) !== 0o500;
    warn.hidden = !lock;
    if (lock) $('span', warn).textContent = t('These folder permissions take away your own access (owner read + open). You will not be able to open these folders afterwards.');
  };
  D = wirePermSet(fsDir, update);
  F = wirePermSet(fsFile, update);
  rec?.addEventListener('change', update);
  update();

  const title = items.length === 1 ? t('Permissions of “{name}”', { name: items[0].name }) : t('Permissions of {name}', { name: plain(items) });
  const opts = await dialog({
    title, body, className: 'modal-perms',
    actions: [{ label: t('Cancel'), value: null }, { label: t('Apply'), primary: true }],
    onSubmit: () => {
      if ((D.on() && !D.valid()) || (F.on() && !F.valid())) { toast(t('Use 3 or 4 octal digits, e.g. 755.'), { type: 'error' }); return false; }
      const o = {
        dirMode: D.on() ? D.value() : '',
        fileMode: F.on() ? F.value() : '',
        recursive: !!rec?.checked,
        owner: $('#perm-owner', body)?.value.trim() || '',
        group: $('#perm-group', body)?.value.trim() || '',
      };
      if (!o.dirMode && !o.fileMode && !o.owner && !o.group) { toast(t('Nothing to change.'), { type: 'error' }); return false; }
      return o;
    },
  });
  if (!opts) return;
  const r = await ctx.run(t('Changing permissions of {name}…', { name: plain(items) }),
    () => api.call('chmod', { path: ctx.state.cwd, items: items.map(({ name, isDir }) => ({ name, isDir })), ...opts }),
    (d) => (d.errorCount || d.ignored?.length ? null : tn('Changed {n} items', d.changed, { one: 'Changed {n} item' })));
  if (!r) return;
  if (r.ignored?.length) {
    toast(t('The server accepted the change, but the permissions of {name} are unchanged. Windows servers usually ignore Unix permissions.',
      { name: plain(r.ignored.map((name) => ({ name }))) }), { type: 'error', timeout: 9000 });
  }
  if (r.errorCount) showErrors(tn('Changed {n} items', r.changed, { one: 'Changed {n} item' }) + ' · ' + tn('{n} could not be changed:', r.errorCount, { one: '{n} could not be changed:' }), r.errors, r.errorCount);
  ctx.afterChange();
}

function showErrors(title, errors, total = errors.length) {
  const more = total - errors.length;
  return dialog({
    title,
    body: `<ul class="name-list err-list">${errors.map((e) => `<li dir="auto">${esc(e)}</li>`).join('')}${more > 0 ? `<li class="muted">${esc(tn('… and {n} more', more))}</li>` : ''}</ul>`,
    actions: [{ label: t('Close'), primary: true }],
  });
}

// ================================================================== extract

export const archiveKind = (name) => {
  const n = name.toLowerCase();
  if (n.endsWith('.zip')) return 'zip';
  if (/\.(tar\.gz|tgz|tar\.bz2|tbz2?|tar)$/.test(n)) return 'tar';
  return null;
};

export async function doExtract(e) {
  const base = e.name.replace(/\.(tar\.gz|tar\.bz2|tgz|tbz2?|tar|zip)$/i, '') || `${e.name}-files`;
  const body = document.createElement('div');
  body.className = 'extract-dlg';
  body.innerHTML = `
    <label class="radio"><input type="radio" name="into" value="folder" checked><span>${esc(t('Into a new folder'))}</span></label>
    <input id="x-folder" class="input x-folder" value="${esc(base)}" dir="auto" spellcheck="false" aria-label="${esc(t('Folder name'))}">
    <label class="radio"><input type="radio" name="into" value="here"><span>${esc(t('Into this folder ({path})', { path: ctx.state.cwd }))}</span></label>
    <label class="check x-over"><input type="checkbox" id="x-over"><span>${esc(t('Overwrite files that already exist'))}</span></label>
    <p class="muted small">${icon('shield')} ${esc(t('Links, absolute paths and “..” in the archive are skipped, so nothing is written outside the target folder.'))}</p>`;
  const folder = $('#x-folder', body);
  $$('input[name=into]', body).forEach((r) => r.addEventListener('change', () => { folder.disabled = r.value === 'here' && r.checked; }));
  const opts = await dialog({
    title: t('Extract “{name}”', { name: e.name }), body,
    actions: [{ label: t('Cancel'), value: null }, { label: t('Extract'), primary: true }],
    onOpen: () => { folder.focus(); folder.select(); },
    onSubmit: () => {
      const into = $('input[name=into]:checked', body).value;
      const name = folder.value.trim();
      if (into === 'folder' && (!name || /[/\\]/.test(name) || name === '.' || name === '..')) { folder.focus(); return false; }
      return { into, folder: name, overwrite: $('#x-over', body).checked };
    },
  });
  if (!opts) return;
  const r = await ctx.run(t('Extracting {name}… this can take a moment for large archives.', { name: e.name }),
    () => api.call('extract', { path: ctx.state.cwd, name: e.name, ...opts }),
    (d) => t('Extracted {files} into {path}', { files: tn('{n} files', d.files, { one: '{n} file' }), path: d.target }));
  if (!r) return;
  ctx.invalidateTree(r.target);
  if (r.errors?.length) showErrors(tn('{n} entries were skipped:', r.skipped, { one: '{n} entry was skipped:' }), r.errors, r.skipped);
  ctx.afterChange(opts.into === 'folder' ? r.target.slice(r.target.lastIndexOf('/') + 1) : null);
}

// ================================================================== share links

function expiryOptions(max, def) {
  const choices = [[1 / 24, t('1 hour')], [1, t('1 day')], [3, t('3 days')], [7, t('7 days')], [14, t('14 days')], [30, t('30 days')]]
    .filter(([d]) => d <= max + 1e-9);
  return choices.map(([d, l]) => `<option value="${d}" ${Math.abs(d - def) < 1e-9 ? 'selected' : ''}>${esc(l)}</option>`).join('');
}

export async function doShare(items) {
  const days = ctx.state.app?.shareDays || { max: 30, default: 7 };
  const body = document.createElement('div');
  body.className = 'share-dlg';
  body.innerHTML = `
    <p class="muted">${esc(t('The selected files are copied to this web server. Anyone with the link can download them until it expires — without access to your server.'))}</p>
    <div class="share-grid">
      <label class="field"><span>${esc(t('Expires after'))}</span><select class="input" id="sh-days">${expiryOptions(days.max, days.default)}</select></label>
      <label class="field"><span>${esc(t('Maximum downloads'))} <small class="muted">${esc(t('(optional)'))}</small></span>
        <input class="input" id="sh-max" type="number" min="1" step="1" placeholder="${esc(t('unlimited'))}"></label>
    </div>
    <label class="field"><span>${esc(t('Password'))} <small class="muted">${esc(t('(optional)'))}</small></span>
      <input class="input" id="sh-pass" type="text" autocomplete="off" spellcheck="false" placeholder="${esc(t('no password'))}"></label>
    <label class="field"><span>${esc(t('Message to the recipient'))} <small class="muted">${esc(t('(optional)'))}</small></span>
      <textarea class="input" id="sh-msg" rows="3" maxlength="1000" dir="auto"></textarea></label>`;
  const opts = await dialog({
    title: t('Share {name}', { name: items.length === 1 ? `“${items[0].name}”` : plain(items) }), body, className: 'modal-share',
    actions: [{ label: t('Cancel'), value: null }, { label: t('Create link'), primary: true }],
    onSubmit: () => ({
      days: +$('#sh-days', body).value,
      maxDownloads: Math.max(0, parseInt($('#sh-max', body).value, 10) || 0),
      password: $('#sh-pass', body).value,
      message: $('#sh-msg', body).value.trim(),
    }),
  });
  if (!opts) return;
  const r = await ctx.run(t('Copying {name} for sharing…', { name: plain(items) }),
    () => api.call('share', { path: ctx.state.cwd, items: items.map(({ name, isDir }) => ({ name, isDir })), ...opts }), null);
  if (r) showLink(r);
}

async function copyText(text) {
  try { await navigator.clipboard.writeText(text); toast(t('Link copied'), { type: 'success' }); return true; } catch { return false; }
}

function showLink(s) {
  const body = document.createElement('div');
  body.className = 'share-done';
  body.innerHTML = `
    <div class="share-url"><input class="input" readonly value="${esc(s.url)}" dir="ltr" aria-label="${esc(t('Link'))}">
      <button type="button" class="btn btn-primary" data-copy>${icon('copy')}<span>${esc(t('Copy'))}</span></button></div>
    <p class="muted">${shareFacts(s)}</p>
    <p class="muted small">${esc(t('Send the password separately, not in the same message as the link.'))}</p>`;
  return dialog({
    title: t('Your link is ready'), body, className: 'modal-share',
    actions: [{ label: t('Done'), primary: true }],
    onOpen: (d) => {
      const inp = $('input', d);
      inp.focus(); inp.select();
      $('[data-copy]', d).onclick = async () => { if (!(await copyText(s.url))) { inp.select(); document.execCommand?.('copy'); } };
    },
  });
}

function shareFacts(s) {
  return [
    `${icon('clock')} ${esc(s.expired ? t('Expired') : t('Until {date}', { date: fmtDateFull(s.expires) }))}`,
    esc(`${tn('{n} files', s.count, { one: '{n} file' })} · ${fmtSize(s.bytes)}`),
    esc(s.maxDownloads ? t('{n} of {max} downloads', { n: s.downloads, max: s.maxDownloads }) : tn('{n} downloads', s.downloads, { one: '{n} download' })),
    s.password ? `${icon('lock')} ${esc(t('Password'))}` : '',
  ].filter(Boolean).join(' · ');
}

export async function showShares() {
  const body = document.createElement('div');
  body.className = 'shares-list';
  body.innerHTML = `<p class="muted">${esc(t('Loading…'))}</p>`;
  const render = (list) => {
    if (!list.length) {
      body.innerHTML = `<p class="muted empty">${esc(t('You have no share links for this server. Select files and choose “Share” to create one.'))}</p>`;
      return;
    }
    body.innerHTML = `<ul>${list.map((s) => `
      <li data-id="${esc(s.id)}" class="${s.expired ? 'expired' : ''}">
        <div class="sl-main"><strong dir="auto">${esc(s.title)}</strong><span class="muted small">${shareFacts(s)}</span>
          ${s.message ? `<span class="small sl-msg" dir="auto">${esc(s.message)}</span>` : ''}</div>
        <div class="sl-actions">
          ${s.url && !s.expired ? `<button type="button" class="btn btn-ghost" data-copy="${esc(s.url)}">${icon('link')}<span>${esc(t('Copy link'))}</span></button>` : ''}
          <button type="button" class="btn btn-ghost danger" data-revoke>${icon('trash')}<span>${esc(t('Delete'))}</span></button>
        </div>
      </li>`).join('')}</ul>`;
  };
  return dialog({
    title: t('Your share links'), body, wide: true, className: 'modal-shares',
    actions: [{ label: t('Close'), primary: true }],
    onOpen: async () => {
      body.addEventListener('click', async (e) => {
        const c = e.target.closest('[data-copy]');
        if (c) { copyText(c.dataset.copy); return; }
        const li = e.target.closest('[data-revoke]')?.closest('li');
        if (!li) return;
        const ok = await confirmDialog({ title: t('Delete this share link?'), message: t('The link stops working at once and the copied files are deleted from this web server. The files on your server are not affected.'), okLabel: t('Delete'), danger: true });
        if (!ok) return;
        try {
          await api.call('unshare', { id: li.dataset.id });
          li.remove();
          if (!$('li', body)) render([]);
          toast(t('Share link deleted'), { type: 'success' });
        } catch (ex) { toast(ex.message, { type: 'error' }); }
      });
      try {
        const r = await api.call('shares');
        if (r.problem) body.innerHTML = `<p class="perm-warn">${icon('alert')}<span>${esc(r.problem)}</span></p>`;
        else render(r.shares);
      } catch (ex) { body.innerHTML = `<p class="perm-warn">${icon('alert')}<span>${esc(ex.message)}</span></p>`; }
    },
  });
}

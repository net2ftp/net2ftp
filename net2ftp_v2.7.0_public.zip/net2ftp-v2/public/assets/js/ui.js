// net2ftp v2 — toasts, dialogs, context menu, progress bar
import { $, esc, icon } from './util.js';
import { t } from './i18n.js';

// ---------------------------------------------------------------- top progress bar
let pbCount = 0, pbTimer;
export const progress = {
  start() {
    pbCount++;
    const bar = $('#topbar-progress');
    clearTimeout(pbTimer);
    // only show for requests slower than 120 ms — keeps fast navigation flicker-free
    pbTimer = setTimeout(() => bar.classList.add('active'), 120);
  },
  done() {
    pbCount = Math.max(0, pbCount - 1);
    if (pbCount === 0) {
      clearTimeout(pbTimer);
      const bar = $('#topbar-progress');
      if (bar.classList.contains('active')) {
        bar.classList.add('finish');
        setTimeout(() => bar.classList.remove('active', 'finish'), 260);
      }
    }
  },
};

// ---------------------------------------------------------------- toasts
export function toast(message, { type = 'info', timeout = 3800, action } = {}) {
  const host = $('#toasts');
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.setAttribute('role', type === 'error' ? 'alert' : 'status');
  const ico = { info: 'info', success: 'check-circle', error: 'alert', loading: 'spinner' }[type] || 'info';
  el.innerHTML = `${icon(ico, type === 'loading' ? 'spin' : '')}<div class="toast-msg">${esc(message).replace(/\n/g, '<br>')}</div>`
    + (action ? `<button class="toast-action">${esc(action.label)}</button>` : '')
    + `<button class="toast-close" aria-label="${esc(t('Close'))}">${icon('x')}</button>`;
  host.appendChild(el);
  // keep the stack short: drop the oldest finished toasts
  const all = [...host.children].filter((t) => !t.classList.contains('toast-loading'));
  all.slice(0, Math.max(0, all.length - 3)).forEach((t) => t.remove());
  requestAnimationFrame(() => el.classList.add('show'));
  const close = () => { el.classList.remove('show'); setTimeout(() => el.remove(), 220); };
  el.querySelector('.toast-close').onclick = close;
  if (action) el.querySelector('.toast-action').onclick = () => { action.run(); close(); };
  if (timeout && type !== 'loading') setTimeout(close, type === 'error' ? Math.max(timeout, 7000) : timeout);
  return {
    close,
    update(msg, newType) {
      el.querySelector('.toast-msg').textContent = msg;
      if (newType) {
        el.className = `toast toast-${newType} show`;
        el.querySelector('svg use').setAttribute('href', `#i-${{ success: 'check-circle', error: 'alert', info: 'info' }[newType] || 'info'}`);
        el.querySelector('svg').classList.remove('spin');
        setTimeout(close, newType === 'error' ? 7000 : 2500);
      }
    },
  };
}

// ---------------------------------------------------------------- dialogs
/**
 * Generic modal based on <dialog>.
 * @returns {Promise<any>} resolves with the clicked action's value (undefined on Esc / close)
 */
export function dialog({ title, body = '', actions = [], wide = false, className = '', onOpen, onSubmit }) {
  return new Promise((resolve) => {
    const d = document.createElement('dialog');
    d.className = `modal ${wide ? 'modal-wide' : ''} ${className}`;
    d.innerHTML = `
      <form method="dialog" class="modal-inner" novalidate>
        <header class="modal-head"><h2>${esc(title)}</h2>
          <button type="button" class="icon-btn" data-close aria-label="${esc(t('Close'))}">${icon('x')}</button></header>
        <div class="modal-body"></div>
        <footer class="modal-foot"></footer>
      </form>`;
    const bodyEl = d.querySelector('.modal-body');
    if (typeof body === 'string') bodyEl.innerHTML = body; else bodyEl.appendChild(body);
    const foot = d.querySelector('.modal-foot');
    actions.forEach((a, i) => {
      const b = document.createElement('button');
      b.type = a.primary ? 'submit' : 'button';
      b.className = `btn ${a.primary ? (a.danger ? 'btn-danger' : 'btn-primary') : 'btn-ghost'}`;
      b.textContent = a.label;
      b.dataset.idx = i;
      if (!a.primary) b.onclick = () => finish(a.value);
      foot.appendChild(b);
    });
    let settled = false;
    const finish = (v) => {
      if (settled) return;
      settled = true;
      // close at once: while a modal is open the page behind it is inert, so focusing a field right after
      // the dialog (e.g. the password after a fingerprint check) would silently fail during an exit animation
      d.close();
      d.remove();
      resolve(v);
    };
    d.querySelector('[data-close]').onclick = () => finish(undefined);
    d.addEventListener('cancel', (e) => { e.preventDefault(); finish(undefined); });
    d.querySelector('form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const primary = actions.find((a) => a.primary);
      if (onSubmit) {
        const v = await onSubmit(d);
        if (v === false) return; // validation failed: keep open
        finish(v === undefined ? primary?.value : v);
      } else finish(primary?.value);
    });
    d.addEventListener('mousedown', (e) => { if (e.target === d) finish(undefined); });
    document.body.appendChild(d);
    d.showModal();
    onOpen?.(d, finish);
  });
}

export function confirmDialog({ title, message, okLabel = t('OK'), danger = false, details = '' }) {
  return dialog({
    title,
    body: `<p class="modal-text">${esc(message)}</p>${details}`,
    actions: [{ label: t('Cancel'), value: false }, { label: okLabel, value: true, primary: true, danger }],
  }).then((v) => v === true);
}

export function promptDialog({ title, label, value = '', okLabel = t('OK'), selectBase = false, placeholder = '', validate }) {
  return dialog({
    title,
    body: `<label class="field"><span>${esc(label)}</span>
             <input class="input" name="value" autocomplete="off" spellcheck="false" placeholder="${esc(placeholder)}" value="${esc(value)}"></label>
           <p class="field-error" hidden></p>`,
    actions: [{ label: t('Cancel'), value: null }, { label: okLabel, primary: true }],
    onOpen(d) {
      const inp = d.querySelector('input');
      inp.focus();
      const dot = value.lastIndexOf('.');
      if (selectBase && dot > 0) inp.setSelectionRange(0, dot); else inp.select();
    },
    onSubmit(d) {
      const v = d.querySelector('input').value.trim();
      const err = validate ? validate(v) : (v ? '' : t('Please enter a value.'));
      const p = d.querySelector('.field-error');
      if (err) { p.textContent = err; p.hidden = false; d.querySelector('input').focus(); return false; }
      return v;
    },
  }).then((v) => (typeof v === 'string' ? v : null));
}

// ---------------------------------------------------------------- context menu
let openMenu = null;
export function closeMenu() { openMenu?.remove(); openMenu = null; }

/** items: [{label, icon, run, danger, disabled, kbd}] or '-' for separators */
export function contextMenu(x, y, items) {
  closeMenu();
  const m = document.createElement('div');
  m.className = 'ctx-menu';
  m.setAttribute('role', 'menu');
  m.innerHTML = items.map((it, i) => (it === '-' ? '<div class="ctx-sep"></div>'
    : `<button role="menuitem" class="ctx-item ${it.danger ? 'danger' : ''}" data-i="${i}" ${it.disabled ? 'disabled' : ''}>
         ${icon(it.icon || 'dot')}<span>${esc(it.label)}</span>${it.kbd ? `<kbd>${esc(it.kbd)}</kbd>` : ''}</button>`)).join('');
  document.body.appendChild(m);
  const r = m.getBoundingClientRect();
  m.style.left = `${Math.min(x, innerWidth - r.width - 8)}px`;
  m.style.top = `${Math.min(y, innerHeight - r.height - 8)}px`;
  m.addEventListener('click', (e) => {
    const b = e.target.closest('.ctx-item');
    if (!b || b.disabled) return;
    closeMenu();
    items[+b.dataset.i].run();
  });
  m.querySelector('.ctx-item:not([disabled])')?.focus();
  m.addEventListener('keydown', (e) => {
    const btns = [...m.querySelectorAll('.ctx-item:not([disabled])')];
    const i = btns.indexOf(document.activeElement);
    if (e.key === 'ArrowDown') { e.preventDefault(); btns[(i + 1) % btns.length].focus(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); btns[(i - 1 + btns.length) % btns.length].focus(); }
    if (e.key === 'Escape') closeMenu();
  });
  openMenu = m;
}
document.addEventListener('mousedown', (e) => { if (openMenu && !openMenu.contains(e.target)) closeMenu(); });
window.addEventListener('blur', closeMenu);
window.addEventListener('resize', closeMenu);

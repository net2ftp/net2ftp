// net2ftp v2 — upload queue: drag & drop (files and folders), chunked transfer, live progress, resume.
//
// Every chunk goes straight on to the server. An upload that stops (network error, closed browser, crashed
// request) continues where it stopped: automatically after a connection problem, and after a new login when
// the same file is chosen again (the server recognises it by folder, name, size and modification time).
import * as api from './api.js';
import { uploadChunk } from './api.js';
import { t, tn } from './i18n.js';
import { dialog } from './ui.js';
import { $, esc, icon, fmtSize, joinPath } from './util.js';

const PARALLEL = 2; // = rate_limits.session_parallel: more would only wait in line on the server
const RETRY_DELAYS = [1, 2, 4, 8, 15, 30, 30, 60, 60, 60]; // seconds; then the upload is marked as failed
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Errors worth trying again: no connection, server busy or restarting, a crashed request. */
export const retryable = (e) => !e?.status || [408, 429, 500, 502, 503, 504].includes(e.status);

export class Uploader {
  constructor({ chunkSize, maxUpload, onFileDone, onAllDone }) {
    this.chunkSize = chunkSize || 4 * 1024 * 1024;
    this.maxUpload = maxUpload || Infinity;
    this.onFileDone = onFileDone;
    this.onAllDone = onAllDone;
    this.queue = [];
    this.active = 0;
    this.gen = 0;
    this.panel = $('#uploads');
    this.list = this.panel.querySelector('.up-list');
    this.panel.querySelector('.up-toggle').onclick = () => this.panel.classList.toggle('collapsed');
    this.panel.querySelector('.up-clear').onclick = () => this.clearFinished();
  }

  /** @param {Array<{file:File, relPath:string}>} items  @param {string} dir remote target directory */
  add(items, dir) {
    for (const { file, relPath } of items) {
      // choosing a file of an unfinished upload again continues it (the server finds where it stopped)
      const waiting = this.queue.find((j) => j.state === 'paused' && !j.file && j.target === joinPath(relPath ? joinPath(dir, relPath) : dir, file.name) && j.size === file.size);
      if (waiting) this.remove(waiting);
      const job = { file, relPath, dir, size: file.size, loaded: 0, state: 'queued', xhr: { current: null } };
      if (file.size > this.maxUpload) {
        job.state = 'error';
        job.error = t('Larger than the {size} limit', { size: fmtSize(this.maxUpload) });
      }
      this.push(job);
    }
    this.show();
    this.pump();
  }

  push(job) {
    this.queue.push(job);
    this.list.insertAdjacentHTML('beforeend', this.rowHtml(job));
    job.el = this.list.lastElementChild;
    job.el.querySelector('.up-cancel').onclick = () => this.cancel(job);
    job.el.querySelector('.up-resume')?.addEventListener('click', () => this.pickToResume(job));
    this.paint(job);
  }

  show() {
    this.panel.hidden = false;
    this.panel.classList.remove('collapsed');
    this.summary();
  }

  /** Unfinished uploads of this account (after a login): choose the same file again to continue. */
  async restore() {
    const gen = ++this.gen;
    let list = [];
    try { list = (await api.call('uploads')).uploads || []; } catch { return; }
    if (gen !== this.gen) return;   // a newer restore (or a logout) came in meanwhile
    for (const u of list) {
      if (this.queue.some((j) => j.uploadId === u.uploadId)) continue;
      this.push({ file: null, name: u.name, target: u.path, dir: u.dir, relPath: '', size: u.size, loaded: u.offset,
        uploadId: u.uploadId, lastModified: u.lastModified, state: 'paused', xhr: { current: null } });
    }
    if (list.length) this.show();
  }

  rowHtml(job) {
    const name = job.file ? job.file.name : job.name;
    const label = job.file ? (job.relPath ? job.relPath + '/' : '') + name : name;
    const resume = job.file ? '' : `<button class="icon-btn up-resume" title="${esc(t('Choose the file again to continue'))}" aria-label="${esc(t('Continue'))}">${icon('upload')}</button>`;
    return `<li class="up-item"><div class="up-row">${icon('file')}<span class="up-name" dir="auto" translate="no" title="${esc(label)}">${esc(label)}</span>
      <span class="up-stat"></span>${resume}<button class="icon-btn up-cancel" aria-label="${esc(t('Cancel'))}">${icon('x')}</button></div>
      <div class="up-bar"><i></i></div>${job.file ? '' : `<div class="job-detail"><span>${esc(t('Choose the file again to continue'))}</span> · <span dir="ltr" translate="no">${esc(job.dir)}</span></div>`}</li>`;
  }

  paint(job) {
    const pct = job.size ? Math.floor((job.loaded / job.size) * 100) : (job.state === 'done' ? 100 : 0);
    job.el.className = `up-item ${job.state}`;
    job.el.querySelector('.up-bar i').style.width = `${job.state === 'done' ? 100 : pct}%`;
    job.el.querySelector('.up-stat').textContent = {
      queued: t('Waiting'), running: `${pct}%`, done: fmtSize(job.size), error: job.error || t('Failed'), cancelled: t('Cancelled'),
      retrying: t('Connection problem — retrying…'), paused: `${pct}% · ${t('Paused')}`,
    }[job.state];
    job.el.title = job.state === 'error' ? job.error || '' : '';
  }

  summary() {
    const q = this.queue.filter((j) => j.state !== 'paused');
    const total = q.length;
    const done = q.filter((j) => j.state === 'done').length;
    const failed = q.filter((j) => j.state === 'error').length;
    const waiting = this.queue.length - q.length;
    const running = q.some((j) => ['running', 'queued', 'retrying'].includes(j.state));
    const bytes = q.reduce((a, j) => a + j.size, 0);
    const loaded = q.reduce((a, j) => a + (j.state === 'done' ? j.size : j.loaded), 0);
    this.panel.querySelector('.up-title').textContent = running
      ? `${t('Uploading {i} of {n}', { i: done + 1 > total ? total : done + 1, n: total })} · ${bytes ? Math.floor((loaded / bytes) * 100) : 0}%`
      : (total ? tn('{n} uploaded', done) + (failed ? ` · ${tn('{n} failed', failed)}` : '') : tn('{n} unfinished uploads', waiting, { one: '{n} unfinished upload' }));
    this.panel.querySelector('.up-total i').style.width = `${bytes ? (loaded / bytes) * 100 : (total ? 100 : 0)}%`;
    this.panel.classList.toggle('busy', running);
  }

  pump() {
    while (this.active < PARALLEL) {
      const job = this.queue.find((j) => j.state === 'queued');
      if (!job) break;
      this.active++;
      this.run(job).finally(() => {
        this.active--;
        this.summary();
        this.pump();
        if (this.active === 0 && !this.queue.some((j) => j.state === 'queued')) this.onAllDone?.();
      });
    }
  }

  /** Retry fn() after connection problems, with growing pauses; the row shows "retrying". */
  async withRetry(job, fn) {
    for (let i = 0; ; i++) {
      try {
        const r = await fn();
        if (job.state === 'retrying') { job.state = 'running'; this.paint(job); }
        return r;
      } catch (e) {
        if (job.state === 'cancelled' || e.name === 'AbortError' || !retryable(e) || i >= RETRY_DELAYS.length) throw e;
        job.state = 'retrying';
        this.paint(job);
        this.summary();
        await sleep(RETRY_DELAYS[i] * 1000);
        if (job.state === 'cancelled') throw new DOMException('Aborted', 'AbortError');
      }
    }
  }

  async run(job) {
    job.state = 'running';
    this.paint(job);
    const { file } = job;
    try {
      const st = await this.withRetry(job, () => api.call('uploadstart', {
        path: job.dir, name: file.name, relPath: job.relPath, size: file.size, lastModified: file.lastModified || 0,
      }));
      job.uploadId = st.uploadId;
      const chunkSize = st.chunkSize || this.chunkSize;
      let offset = st.offset;   // > 0: continued where an earlier attempt stopped
      job.loaded = offset;
      this.paint(job);
      for (;;) {
        const from = offset;
        const r = await this.withRetry(job, () => uploadChunk({ uploadId: job.uploadId, offset: from },
          file.slice(from, from + chunkSize), (loaded) => {
            job.loaded = from + loaded;
            this.paint(job);
            this.summary();
          }, job.xhr));
        if (r.uploaded) break;
        offset = r.received;      // normally from + chunk; after a lost answer, wherever the server is
        job.loaded = offset;
      }
      job.loaded = job.size;
      job.state = 'done';
      this.onFileDone?.(job);
    } catch (e) {
      if (job.state !== 'cancelled') {
        job.state = 'error';
        job.error = e.message;
      }
    }
    this.paint(job);
  }

  /** "Continue" on an unfinished upload: choose the file; it must be the same name and size. */
  pickToResume(job) {
    const input = document.createElement('input');
    input.type = 'file';
    input.onchange = async () => {
      const file = input.files[0];
      if (!file) return;
      if (file.name !== job.name || file.size !== job.size) {
        await dialog({ title: t('This is not the same file'), body: `<p class="modal-text">${esc(t('To continue, choose “{name}” ({size}) again.', { name: job.name, size: fmtSize(job.size) }))}</p>`, actions: [{ label: t('OK'), primary: true }] });
        return;
      }
      this.remove(job);
      this.add([{ file, relPath: '' }], job.dir);
    };
    input.click();
  }

  remove(job) {
    job.el.remove();
    this.queue = this.queue.filter((j) => j !== job);
    this.summary();
  }

  cancel(job) {
    if (job.state === 'done') { this.remove(job); return; }
    const was = job.state;
    job.state = 'cancelled';
    job.xhr.current?.abort();
    this.paint(job);
    this.summary();
    // throw away what already arrived on the server (the hidden part file)
    if (job.uploadId && was !== 'error') api.call('uploaddiscard', { uploadId: job.uploadId }).catch(() => {});
    if (was === 'paused') this.remove(job);
  }

  clearFinished() {
    this.queue = this.queue.filter((j) => {
      const keep = ['running', 'queued', 'retrying', 'paused'].includes(j.state);
      if (!keep) j.el.remove();
      return keep;
    });
    if (!this.queue.length) this.panel.hidden = true;
    else this.summary();
  }

  /** Forget the rows (logout): unfinished uploads are offered again after the next login. */
  reset() {
    this.gen++;
    this.queue.forEach((j) => { if (['running', 'queued', 'retrying'].includes(j.state)) { j.state = 'cancelled'; j.xhr.current?.abort(); } });
    this.queue = [];
    this.list.replaceChildren();
    this.panel.hidden = true;
  }
}

/** Turn a drop event into a flat list of {file, relPath}, walking dropped folders. */
export async function filesFromDrop(dt) {
  const out = [];
  const entries = [...dt.items].map((it) => it.webkitGetAsEntry?.()).filter(Boolean);
  if (!entries.length) return [...dt.files].map((file) => ({ file, relPath: '' }));
  const readAll = (reader) => new Promise((res, rej) => {
    const all = [];
    const next = () => reader.readEntries((batch) => { if (!batch.length) res(all); else { all.push(...batch); next(); } }, rej);
    next();
  });
  const walk = async (entry, rel) => {
    if (entry.isFile) {
      const file = await new Promise((res, rej) => entry.file(res, rej));
      out.push({ file, relPath: rel });
    } else if (entry.isDirectory) {
      const children = await readAll(entry.createReader());
      const sub = rel ? `${rel}/${entry.name}` : entry.name;
      if (!children.length) out.push({ file: null, relPath: sub, emptyDir: true });
      for (const c of children) await walk(c, sub);
    }
  };
  for (const e of entries) await walk(e, '');
  return out.filter((x) => x.file);
}

/** Files picked via <input webkitdirectory>. */
export function filesFromInput(input) {
  return [...input.files].map((file) => {
    const rp = file.webkitRelativePath || '';
    const rel = rp.includes('/') ? rp.slice(0, rp.lastIndexOf('/')) : '';
    return { file, relPath: rel };
  });
}

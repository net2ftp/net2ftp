import { t, locale } from './i18n.js';
// net2ftp v2 — small shared helpers

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ESC[c]);

export const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });

export function fmtSize(bytes) {
  if (bytes == null) return '';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0, v = bytes;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  // wrapped in Unicode "left-to-right isolate" marks so "316 B" does not become "B 316" in Arabic/Hebrew
  return `\u2066${i === 0 ? `${v} B` : `${v.toFixed(v < 10 ? 1 : 0)} ${u[i]}`}\u2069`;
}

// Date formats follow the interface language
const fmtCache = new Map();
const dtf = (opts) => {
  const key = locale() + JSON.stringify(opts);
  if (!fmtCache.has(key)) fmtCache.set(key, new Intl.DateTimeFormat(locale(), opts));
  return fmtCache.get(key);
};

export function fmtDate(ts) {
  if (!ts) return '';
  const d = new Date(ts * 1000), now = new Date();
  const diff = (now - d) / 1000;
  if (diff >= 0 && diff < 60) return t('Just now');
  if (diff >= 0 && diff < 3600) return new Intl.RelativeTimeFormat(locale(), { numeric: 'always', style: 'short' }).format(-Math.floor(diff / 60), 'minute');
  const time = dtf({ hour: '2-digit', minute: '2-digit' }).format(d);
  if (d.toDateString() === now.toDateString()) return t('Today {time}', { time });
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return t('Yesterday {time}', { time });
  return d.getFullYear() === now.getFullYear() ? dtf({ day: 'numeric', month: 'short' }).format(d) : dtf({ day: 'numeric', month: 'short', year: 'numeric' }).format(d);
}
export const fmtDateFull = (ts) => (ts ? dtf({ dateStyle: 'medium', timeStyle: 'short' }).format(new Date(ts * 1000)) : '');

export const joinPath = (dir, name) => (dir === '/' ? '' : dir.replace(/\/$/, '')) + '/' + name;
export const parentPath = (p) => { if (p === '/') return '/'; const i = p.lastIndexOf('/'); return i <= 0 ? '/' : p.slice(0, i); };
export const baseName = (p) => p.slice(p.lastIndexOf('/') + 1);

const KINDS = {
  image: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'ico', 'avif', 'tif', 'tiff', 'heic'],
  code: ['php', 'js', 'mjs', 'ts', 'tsx', 'jsx', 'css', 'scss', 'less', 'html', 'htm', 'xml', 'json', 'py', 'rb', 'go', 'rs', 'java', 'c', 'h', 'cpp', 'cs', 'sh', 'bash', 'sql', 'vue', 'svelte', 'yml', 'yaml', 'toml', 'ini', 'conf', 'pl', 'lua', 'kt', 'swift'],
  text: ['txt', 'md', 'log', 'csv', 'tsv', 'rtf', 'env', 'htaccess', 'gitignore', 'lock', 'cfg', 'properties'],
  archive: ['zip', 'gz', 'tgz', 'tar', 'bz2', 'xz', '7z', 'rar', 'zst'],
  pdf: ['pdf'],
  doc: ['doc', 'docx', 'odt', 'xls', 'xlsx', 'ods', 'ppt', 'pptx', 'odp', 'pages', 'numbers', 'key'],
  audio: ['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac'],
  video: ['mp4', 'mov', 'avi', 'mkv', 'webm', 'm4v'],
};
const EXT2KIND = Object.fromEntries(Object.entries(KINDS).flatMap(([k, list]) => list.map((e) => [e, k])));

export function ext(name) {
  const n = name.toLowerCase();
  if (n.startsWith('.') && n.indexOf('.', 1) === -1) return n.slice(1); // .htaccess
  const i = n.lastIndexOf('.');
  return i > 0 ? n.slice(i + 1) : '';
}
export function fileKind(entry) {
  if (entry.isDir) return 'folder';
  return EXT2KIND[ext(entry.name)] || 'file';
}
/** Text files we offer to open in the editor directly. */
export function isEditable(entry) {
  if (entry.isDir) return false;
  const k = fileKind(entry);
  return k === 'code' || k === 'text' || (k === 'file' && entry.size < 512 * 1024 && !/\.(exe|bin|dll|so|dmg|iso|class|o|pyc|woff2?|ttf|otf|eot)$/i.test(entry.name));
}
export const isPreviewable = (entry) => ['png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'pdf'].includes(ext(entry.name));

export const icon = (id, cls = '') => `<svg class="ico ${cls}" aria-hidden="true"><use href="#i-${id}"/></svg>`;

export function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

export const uid = (n = 16) => [...crypto.getRandomValues(new Uint8Array(n))].map((b) => 'abcdefghijklmnopqrstuvwxyz0123456789'[b % 36]).join('');

export const isMac = /Mac|iPhone|iPad/.test(navigator.platform);
export const modKey = (e) => (isMac ? e.metaKey : e.ctrlKey);

Put release packages (.zip, .tar.gz) here: page.php?p=download lists them with size and SHA-256.

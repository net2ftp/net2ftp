<?php
// net2ftp v2 — public information pages (features, help, privacy, abuse and GDPR forms …).
// The preflight check runs first and is written so that even very old PHP versions can parse it.
require dirname(__DIR__) . '/src/preflight.php';
n2f_preflight('html');
require dirname(__DIR__) . '/src/bootstrap.php';
require dirname(__DIR__) . '/src/site_page.php';

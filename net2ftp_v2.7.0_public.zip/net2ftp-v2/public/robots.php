<?php
// net2ftp v2 — robots.txt with the address of the sitemap (which a static file can't know) and the
// right paths when net2ftp is installed in a sub-folder. public/.htaccess serves this file for
// /robots.txt when mod_rewrite is available; otherwise the static robots.txt is used.
// Note: search engines only read robots.txt at the root of a domain (https://example.com/robots.txt).
require dirname(__DIR__) . '/src/preflight.php';
n2f_preflight('text');
require dirname(__DIR__) . '/src/bootstrap.php';

$base = Net2ftp\App::baseUrl();
$path = (string)(parse_url($base, PHP_URL_PATH) ?: '/');
header('Content-Type: text/plain; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=3600');
if (Net2ftp\App::noindex()) {
    // a test installation (site.noindex): nothing may be indexed
    echo "# net2ftp v2 (not for search engines)\nUser-agent: *\nDisallow: /\n";
    exit;
}
echo "# net2ftp v2\n",
    "User-agent: *\n",
    "Disallow: {$path}api.php\n",
    "Disallow: {$path}admin.php\n";
// e.g. a test installation in a sub-folder of this site: 'robots_disallow' => ['/test/'] (search engines only read
// the robots.txt at the root of a domain, so the production installation has to exclude it)
foreach ((array)(((array)Net2ftp\App::cfg('site', []))['robots_disallow'] ?? []) as $p) {
    $p = preg_replace('/[\r\n]/', '', (string)$p);
    if ($p !== '') {
        echo "Disallow: {$p}\n";
    }
}
echo "\n", "Sitemap: {$base}sitemap.php\n";

<?php
// net2ftp v2 — public download page for share links (share.php?t=…). Visitors need no account.
// The preflight check runs first and is written so that even very old PHP versions can parse it.
require dirname(__DIR__) . '/src/preflight.php';
n2f_preflight('html');
require dirname(__DIR__) . '/src/bootstrap.php';
require dirname(__DIR__) . '/src/share_page.php';

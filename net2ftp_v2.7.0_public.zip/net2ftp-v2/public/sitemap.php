<?php
// net2ftp v2 — sitemap for search engines: the home page and every information page in every language,
// with the language versions linked to each other (hreflang). Linked from robots.txt; you can also
// submit its address in Google Search Console and Bing Webmaster Tools.
require dirname(__DIR__) . '/src/preflight.php';
n2f_preflight('html');
require dirname(__DIR__) . '/src/bootstrap.php';

use Net2ftp\App;
use Net2ftp\I18n;

if (App::noindex()) {
    http_response_code(404);                  // a test installation has no sitemap
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Robots-Tag: noindex, nofollow');
    echo "No sitemap: this installation is not for search engines.\n";
    exit;
}
$site = (array)App::cfg('site', []);
$base = App::baseUrl();
$pagesOn = !(array_key_exists('pages', $site) && empty($site['pages']));
if (App::edition() === 'reduced') {
    $slugs = ['privacy' => 0.3, 'disclaimer' => 0.3];   // set below for the full edition
}
// the indexable pages; the forms (abuse, GDPR) are "noindex" and therefore not listed
$slugs ??= ['features' => 0.9, 'screenshots' => 0.8, 'download' => 0.8, 'help' => 0.7, 'install' => 0.7,
    'online-ftp' => 0.8, 'sftp-client' => 0.8, 's3-browser' => 0.8, 'edit-online' => 0.7, 'large-uploads' => 0.7,
    'guides' => 0.6, 'faq' => 0.6, 'active-passive' => 0.6, 'ftp-ftps-sftp' => 0.6, 'move-website' => 0.6,
    'privacy' => 0.3, 'disclaimer' => 0.3];
$x = static fn(string $s): string => htmlspecialchars($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
$page = static fn(string $slug, ?string $lang): string =>
    $base . 'page.php?' . http_build_query(['p' => $slug] + ($lang ? ['hl' => $lang] : []));
$date = static fn(string $file): string => date('Y-m-d', (int)@filemtime($file) ?: time());

header('Content-Type: application/xml; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=3600');
echo '<?xml version="1.0" encoding="UTF-8"?>', "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">', "\n";
// the home (login) page: language-neutral (x-default) and one address per language (?hl=), all linked to each other
$home = static fn(?string $lang): string => $base . ($lang ? '?hl=' . rawurlencode($lang) : '');
$homeAlts = '';
foreach (I18n::LANGUAGES as $alt) {
    $homeAlts .= '    <xhtml:link rel="alternate" hreflang="' . $x($alt) . '" href="' . $x($home($alt)) . '"/>' . "\n";
}
$homeAlts .= '    <xhtml:link rel="alternate" hreflang="x-default" href="' . $x($home(null)) . '"/>' . "\n";
foreach (array_merge([null], I18n::LANGUAGES) as $lang) {
    echo '  <url><loc>', $x($home($lang)), '</loc><lastmod>', $date(__DIR__ . '/index.html'), '</lastmod><priority>',
        $lang === null ? '1.0' : '0.9', '</priority>', "\n", $homeAlts, '  </url>', "\n";
}
if ($pagesOn) {
    foreach ($slugs as $slug => $priority) {
        foreach (I18n::LANGUAGES as $lang) {
            $file = N2F_ROOT . '/src/pages/' . $lang . '/' . $slug . '.php';
            if (!is_file($file)) {
                continue;   // not translated: the page would be English, so it isn't listed for this language
            }
            echo '  <url><loc>', $x($page($slug, $lang)), '</loc><lastmod>', $date($file), '</lastmod>',
                '<priority>', $lang === 'en' ? $priority : round($priority - 0.1, 1), '</priority>', "\n";
            foreach (I18n::LANGUAGES as $alt) {
                if (is_file(N2F_ROOT . '/src/pages/' . $alt . '/' . $slug . '.php')) {
                    echo '    <xhtml:link rel="alternate" hreflang="', $x($alt), '" href="', $x($page($slug, $alt)), '"/>', "\n";
                }
            }
            echo '    <xhtml:link rel="alternate" hreflang="x-default" href="', $x($page($slug, null)), '"/>', "\n";
            echo '  </url>', "\n";
        }
    }
}
echo '</urlset>', "\n";

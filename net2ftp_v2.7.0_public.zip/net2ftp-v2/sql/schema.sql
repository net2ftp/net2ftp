-- net2ftp v2 — MySQL / MariaDB schema
-- Usage:
--   mysql -u root -p -e "CREATE DATABASE net2ftp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
--   mysql -u root -p -e "CREATE USER 'net2ftp'@'localhost' IDENTIFIED BY 'change-me'; GRANT SELECT,INSERT,UPDATE,DELETE ON net2ftp.* TO 'net2ftp'@'localhost'"
--   mysql -u root -p net2ftp < sql/schema.sql

SET NAMES utf8mb4;

-- 1. ACCESS LOG: every user action (login, browse, upload, download, rename, ...) — like net2ftp_log_access.
--    Kept log_retention_days (90), then deleted by the cleanup job.
CREATE TABLE IF NOT EXISTS n2f_action_log (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    created_at    DATETIME(3)     NOT NULL,
    session_hash  CHAR(16)        NOT NULL DEFAULT '',     -- truncated SHA-256 of the PHP session id
    remote_addr   VARCHAR(45)     NOT NULL DEFAULT '',
    remote_port   INT UNSIGNED    NULL,
    user_agent    VARCHAR(255)    NOT NULL DEFAULT '',
    referer       VARCHAR(255)    NOT NULL DEFAULT '',
    protocol      VARCHAR(8)      NOT NULL DEFAULT '',     -- ftp | ftps | sftp | s3
    server        VARCHAR(255)    NOT NULL DEFAULT '',     -- host name / S3 endpoint
    port          INT UNSIGNED    NULL,
    username      VARCHAR(255)    NOT NULL DEFAULT '',     -- FTP/SSH user or S3 access key id
    action        VARCHAR(32)     NOT NULL,                -- login, list, upload, download, zip, rename, copy, move, delete, chmod, extract, share, share-download, …
    directory     VARCHAR(1024)   NOT NULL DEFAULT '',
    entry         TEXT            NULL,                    -- file/dir name(s) acted upon (JSON array when several)
    target        VARCHAR(1024)   NOT NULL DEFAULT '',     -- destination (copy/move/rename), search string, command
    bytes         BIGINT UNSIGNED NOT NULL DEFAULT 0,      -- data transferred
    item_count    INT UNSIGNED    NOT NULL DEFAULT 0,
    duration_ms   INT UNSIGNED    NOT NULL DEFAULT 0,
    status        ENUM('ok','error') NOT NULL DEFAULT 'ok',
    message       VARCHAR(1024)   NOT NULL DEFAULT '',
    file_hash     CHAR(64)        NOT NULL DEFAULT '',     -- SHA-256 of an uploaded file (finds the same file pushed to many servers)
    PRIMARY KEY (id),
    KEY idx_created   (created_at),
    KEY idx_action    (action, created_at),
    KEY idx_ip_status (remote_addr, action, status, created_at),
    KEY idx_server    (server, username),
    KEY idx_server_time (server, created_at),
    KEY idx_file_hash (file_hash, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- SSH host keys seen so far (trust on first use). Delete a row to accept a new key for a server.
CREATE TABLE IF NOT EXISTS n2f_known_hosts (
    host          VARCHAR(255)  NOT NULL,
    port          INT UNSIGNED  NOT NULL,
    fingerprint   VARCHAR(128)  NOT NULL,                  -- SHA256:base64
    first_seen    DATETIME      NOT NULL,
    last_seen     DATETIME      NOT NULL,
    PRIMARY KEY (host, port)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. CONSUMPTION PER IP ADDRESS, per day — like net2ftp_log_consumption_ipaddress.
--    Checked before every action against daily_limits; kept 30 days (personal data), then deleted.
CREATE TABLE IF NOT EXISTS n2f_usage_ip (
    day           DATE            NOT NULL,
    ip            VARCHAR(45)     NOT NULL,
    requests      INT UNSIGNED    NOT NULL DEFAULT 0,
    logins        INT UNSIGNED    NOT NULL DEFAULT 0,
    bytes         BIGINT UNSIGNED NOT NULL DEFAULT 0,      -- data transferred (uploads, downloads, zips, copies, share downloads …)
    ms            BIGINT UNSIGNED NOT NULL DEFAULT 0,      -- server time used (wall-clock duration of the requests)
    errors        INT UNSIGNED    NOT NULL DEFAULT 0,
    refused       INT UNSIGNED    NOT NULL DEFAULT 0,      -- requests refused by a limit or block
    PRIMARY KEY (day, ip),
    KEY idx_ip (ip, day)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. CONSUMPTION PER FTP/SSH/S3 SERVER, per day — like net2ftp_log_consumption_ftpserver.
--    Checked against daily_limits; also the source of the long-term statistics (kept 400 days).
CREATE TABLE IF NOT EXISTS n2f_usage_server (
    day           DATE            NOT NULL,
    server        VARCHAR(255)    NOT NULL,                -- host name, S3 endpoint, or "(share links)"
    requests      INT UNSIGNED    NOT NULL DEFAULT 0,
    logins        INT UNSIGNED    NOT NULL DEFAULT 0,
    bytes         BIGINT UNSIGNED NOT NULL DEFAULT 0,
    ms            BIGINT UNSIGNED NOT NULL DEFAULT 0,
    errors        INT UNSIGNED    NOT NULL DEFAULT 0,
    refused       INT UNSIGNED    NOT NULL DEFAULT 0,
    ips           INT UNSIGNED    NOT NULL DEFAULT 0,      -- distinct IPs that day (approximate, from n2f_usage_ip at cleanup)
    PRIMARY KEY (day, server),
    KEY idx_server (server, day)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. ERROR LOG: software errors (PHP exceptions and fatal errors, JavaScript errors in the browser),
--    GROUPED: one row per distinct error with a counter. User errors (wrong password …) are in the access log.
--    Kept 90 days after it was last seen.
CREATE TABLE IF NOT EXISTS n2f_error_log (
    fingerprint   CHAR(40)        NOT NULL,                -- SHA-1 of source + message pattern + file + line
    source        VARCHAR(8)      NOT NULL DEFAULT 'php',  -- php | js
    level         VARCHAR(16)     NOT NULL DEFAULT 'error',
    message       VARCHAR(1024)   NOT NULL DEFAULT '',
    file          VARCHAR(255)    NOT NULL DEFAULT '',
    line          INT UNSIGNED    NOT NULL DEFAULT 0,
    trace         TEXT            NULL,                    -- without function arguments (no passwords)
    action        VARCHAR(64)     NOT NULL DEFAULT '',     -- API action or page of the last occurrence
    url           VARCHAR(512)    NOT NULL DEFAULT '',
    app_version   VARCHAR(16)     NOT NULL DEFAULT '',
    php_version   VARCHAR(16)     NOT NULL DEFAULT '',
    user_agent    VARCHAR(255)    NOT NULL DEFAULT '',
    last_ip       VARCHAR(45)     NOT NULL DEFAULT '',
    occurrences   INT UNSIGNED    NOT NULL DEFAULT 0,
    first_seen    DATETIME        NOT NULL,
    last_seen     DATETIME        NOT NULL,
    status        ENUM('open','resolved') NOT NULL DEFAULT 'open',  -- reopened automatically when it happens again
    PRIMARY KEY (fingerprint),
    KEY idx_last (status, last_seen)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. SECURITY EVENTS: limits reached, blocked addresses/servers, private-network attempts, changed host keys,
--    mass uploads, admin logins and admin actions. Kept 180 days.
CREATE TABLE IF NOT EXISTS n2f_security_log (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    created_at    DATETIME        NOT NULL,
    event         VARCHAR(32)     NOT NULL,
    severity      ENUM('info','warning','critical') NOT NULL DEFAULT 'info',
    remote_addr   VARCHAR(45)     NOT NULL DEFAULT '',
    server        VARCHAR(255)    NOT NULL DEFAULT '',
    username      VARCHAR(255)    NOT NULL DEFAULT '',
    detail        VARCHAR(1024)   NOT NULL DEFAULT '',
    PRIMARY KEY (id),
    KEY idx_created (created_at),
    KEY idx_event (event, created_at),
    KEY idx_ip (remote_addr, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Block list, managed in admin.php → Blocks (in addition to banned_servers in config.php)
CREATE TABLE IF NOT EXISTS n2f_blocks (
    id            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    kind          ENUM('ip','server') NOT NULL,
    value         VARCHAR(255)    NOT NULL,                -- IP, CIDR range (203.0.113.0/24, 2001:db8::/32) or server pattern (*.example.com)
    reason        VARCHAR(255)    NOT NULL DEFAULT '',
    created_at    DATETIME        NOT NULL,
    expires_at    DATETIME        NULL,                    -- NULL = permanent
    created_by    VARCHAR(64)     NOT NULL DEFAULT '',     -- "admin" or "auto" (automatic block)
    hits          INT UNSIGNED    NOT NULL DEFAULT 0,
    last_hit      DATETIME        NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_block (kind, value)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Handy reporting view: daily activity per action
CREATE OR REPLACE VIEW n2f_daily_stats AS
SELECT DATE(created_at) AS day,
       action,
       COUNT(*)                        AS actions,
       SUM(status = 'error')           AS errors,
       COUNT(DISTINCT remote_addr)     AS ips,
       SUM(bytes)                      AS bytes
FROM n2f_action_log
GROUP BY DATE(created_at), action;

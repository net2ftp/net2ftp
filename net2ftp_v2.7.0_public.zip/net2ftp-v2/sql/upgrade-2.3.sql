-- net2ftp v2: upgrade an existing database from version 2.0–2.2 to 2.3.
--   mysql -u root -p net2ftp < sql/upgrade-2.3.sql
--   mysql -u root -p net2ftp < sql/schema.sql        (creates the new tables; existing ones are not touched)
-- net2ftp keeps working before this is done: the new logs and daily limits are simply inactive,
-- and admin.php → System check says what is missing.

ALTER TABLE n2f_action_log
    ADD COLUMN file_hash CHAR(64) NOT NULL DEFAULT '' AFTER message,
    ADD KEY idx_server_time (server, created_at),
    ADD KEY idx_file_hash (file_hash, created_at);

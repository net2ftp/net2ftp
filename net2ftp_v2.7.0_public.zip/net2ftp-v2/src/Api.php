<?php
declare(strict_types=1);

namespace Net2ftp;

use Net2ftp\Driver\Driver;
use Net2ftp\Driver\S3Driver;
use Net2ftp\Driver\FtpDriver;
use Net2ftp\Driver\SftpDriver;

/**
 * JSON API front controller (public/api.php).
 * Every action is timed and written to the action log, successful or not.
 */
final class Api
{
    private array $in = [];
    private string $action = '';
    /** connection parameters of this session (with secrets; never logged or sent to the browser) */
    private array $params = [];
    /** ConnGate key of this request's server account ('' = not limited, e.g. S3) */
    private string $gate = '';
    /** actions that never open a connection to the remote server (jobs open their own) */
    private const NO_REMOTE = ['shares', 'unshare', 'jobs', 'jobstep', 'jobcontrol', 'uploads'];
    private float $t0;
    private array $log = [];
    private ?Driver $driver = null;
    private int $obLevel = 0;

    public function run(): void
    {
        $this->t0 = microtime(true);
        header('X-Robots-Tag: noindex, nofollow');   // API answers and downloads never belong in search results
        // Capture anything PHP prints by itself (notices from the host's php.ini, auto_prepend files, …)
        // so it can never corrupt the JSON answer.
        ob_start();
        $this->obLevel = ob_get_level();
        // Turn fatal errors (time limit, memory, …) into a JSON answer instead of an HTML error page.
        $reserve = str_repeat(' ', 64 * 1024); // freed on fatal errors so the handler below can still run
        register_shutdown_function(function () use (&$reserve): void {
            $e = error_get_last();
            if (!$e || !in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
                return;
            }
            $reserve = null;
            if (str_contains($e['message'], 'Allowed memory size')) {
                @ini_set('memory_limit', (string)(memory_get_usage() + (32 << 20)));
            }
            error_log("net2ftp fatal: {$e['message']} in {$e['file']}:{$e['line']}");
            ErrorLog::fatal($e, $this->action);
            $msg = 'Server error: ' . preg_replace('/\s+/', ' ', $e['message'])
                . (App::cfg('debug') ? ' @ ' . basename($e['file']) . ':' . $e['line'] : '');
            $this->fail($msg, 500);
        });
        App::timeLimit((int)App::cfg('max_execution_time', 600));
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: same-origin');
        header('Cache-Control: no-store');
        Housekeeping::schedule();

        try {
            $this->in = $this->input();
            $this->action = preg_replace('/[^a-z]/', '', strtolower((string)($this->in['action'] ?? $_GET['action'] ?? '')));

            // Missing PHP extensions, unwritable folders, database down (if required)…
            // checked before anything else so the user gets a clear message instead of a crash.
            $req = Requirements::report($this->action === 'session');
            if ($req['fatal']) {
                foreach ($req['fatal'] as $m) {
                    error_log('net2ftp requirement: ' . $m . ' [' . Requirements::environment() . ']');
                }
                if ($this->action === 'session') {
                    $this->json(['csrf' => '', 'connected' => false, 'expired' => false, 'conn' => null,
                        'app' => $this->appInfo(), 'requirements' => Requirements::forClient()]);
                    return;
                }
                throw new UserError($req['fatal'][0], 503);
            }

            Session::start();
            if ($this->action === 'session') {
                $this->json($this->sessionInfo());
                return;
            }
            if ($this->action === 'clienterror') {
                // JavaScript error reported by the browser: grouped in the error log, at most 30 per IP per hour
                $this->log = ['skip' => true];
                if (Limiter::hit('client-error:' . App::clientIp(), 3600, 30)) {
                    ErrorLog::browser($this->in);
                }
                $this->json(['recorded' => true]);
                return;
            }
            $this->checkPostSize();
            Session::checkCsrf($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($this->in['_csrf'] ?? null));
            // consumption of this request is counted per IP and per server (n2f_usage_ip / n2f_usage_server)
            Usage::begin((string)(Session::meta()['server'] ?? ''));
            if ($this->action !== 'logout') {
                Maintenance::check();
            }
            // at most N requests at once per session and per IP (excess requests wait in line, then get 429)
            Limiter::request((string)session_id(), $this->action === 'jobstep');
            Blocks::checkIp();

            if ($this->action === 'login') {
                $this->json($this->login());
                return;
            }
            if ($this->action === 'fingerprint') {
                $this->json($this->fingerprint());
                return;
            }
            if ($this->action === 'forget') {
                // forget one remembered connection, or all of them (also used when "Preferences" is withdrawn)
                $id = (string)($this->in['id'] ?? '');
                SavedConnections::forget($id === '' ? null : $id);
                $this->json(['saved' => SavedConnections::publicList()]);
                return;
            }
            if ($this->action === 'visited') {
                // the folder the user settled in (sent by the browser, which often shows folders from its
                // cache): kept with the remembered connection so the next login opens it
                $params = Session::connection();
                if ($params) {
                    SavedConnections::setLastDir($params, Path::normalize((string)($this->in['path'] ?? '')));
                }
                Session::release();
                $this->json(['ok' => true]);
                return;
            }
            if ($this->action === 'logout') {
                $meta = Session::meta();
                Session::clearConnection();
                Logger::log('logout', $meta, ['ms' => $this->ms()]);
                $this->json(['loggedOut' => true, 'saved' => SavedConnections::publicList()]);
                return;
            }

            $params = Session::connection();
            if (!$params) {
                $expired = !empty($_SESSION['expired']);
                throw new UserError($expired ? 'Your session timed out. Please log in again.' : 'You are not logged in.', 401);
            }
            Session::release(); // no more session writes: let parallel requests run
            if (function_exists('ignore_user_abort')) {
                ignore_user_abort(false);
            }

            $server = (string)(Session::meta()['server'] ?? '');
            Blocks::checkServer($server);   // a block also ends sessions that are already open
            Usage::check($server);           // daily limits of this IP and this server
            // at most N connections at once to this server account; extra requests wait in line (ConnGate)
            $this->params = $params;
            if (in_array($this->action, self::NO_REMOTE, true)) {
                $this->driver = null;
            } else {
                $this->gate = ConnGate::applies($params) ? ConnGate::key($params) : '';
                $this->driver = $this->openDriver($params, $this->gate);
            }
            $method = 'act' . ucfirst($this->action);
            if (!method_exists($this, $method)) {
                throw new UserError('Unknown action.', 404);
            }
            $result = $this->$method();
            if ($result !== null) {
                $this->writeLog('ok');
                $this->json($result);
            }
        } catch (UserError $e) {
            $this->fail($e->getMessage(), $e->httpStatus(), $e->english);
        } catch (\Throwable $e) {
            error_log('net2ftp: ' . $e);
            ErrorLog::exception($e, $this->action);
            $msg = App::cfg('debug') ? $e->getMessage() . ' @ ' . basename($e->getFile()) . ':' . $e->getLine()
                : 'An unexpected error occurred: ' . self::cleanError($e->getMessage());
            $this->fail($msg, 500);
        } finally {
            $this->driver?->close();
        }
    }

    // =================================================================== actions

    private function sessionInfo(): array
    {
        $connected = Session::connection() !== null;
        $meta = Session::meta();
        $expired = !empty($_SESSION['expired']);
        Session::release();
        return [
            'csrf'         => Session::csrf(),
            'connected'    => $connected,
            'expired'      => $expired,
            'conn'         => $connected ? $meta : null,
            'app'          => $this->appInfo(),
            'requirements' => Requirements::forClient(),
            'saved'        => SavedConnections::publicList(),
        ];
    }

    private function appInfo(): array
    {
        return [
            'name'      => App::cfg('app_name', 'net2ftp'),
            'version'   => N2F_VERSION,
            'protocols' => App::cfg('protocols', ['ftp', 'sftp', 's3']),
            's3Region'  => App::cfg('s3_default_region', 'eu-central-2'),
            'maxEdit'   => (int)App::cfg('max_edit_bytes'),
            'maxUpload' => (int)App::cfg('max_upload_bytes'),
            'chunkSize' => $this->chunkSize(),
            'cookieBanner' => $this->cookieBanner(),
            'edition'   => App::edition(),
            // the configured public address (site.base_url), for the login page's canonical link
            'baseUrl' => trim((string)(((array)App::cfg('site', []))['base_url'] ?? '')) !== '' ? App::baseUrl() : '',
            'noindex'   => App::noindex(),
            'label'     => App::label(),
            'shares'    => (bool)Shares::cfg('enabled', true),
            'shareDays' => ['max' => (float)Shares::cfg('max_days', 30), 'default' => (float)Shares::cfg('default_days', 7)],
        ];
    }

    private function cookieBanner(): array
    {
        $c = (array)App::cfg('cookie_banner', []);
        return [
            'enabled'    => (bool)($c['enabled'] ?? true),
            'title'      => (string)($c['title'] ?? 'This website uses cookies'),
            'text'       => (string)($c['text'] ?? ''),
            'defaults'   => array_map('boolval', (array)($c['defaults'] ?? [])),
            'privacyUrl' => (string)($c['privacy_url'] ?? ''),
            'validDays'  => (int)($c['valid_days'] ?? 365),
        ];
    }

    private function login(): array
    {
        $meta = [];
        try {
            Security::throttleLogin();
            // a remembered connection: the browser sends only its id, the server fills in the password
            $this->in = SavedConnections::fillSecrets($this->in);
            [$params, $meta] = DriverFactory::fromLogin($this->in);
            $account = ($meta['protocol'] ?? '') . '://' . ($meta['username'] ?? '') . '@' . ($meta['server'] ?? '') . ':' . ($meta['port'] ?? '');
            Usage::server((string)$meta['server']);
            Usage::add('logins');
            Limiter::login((string)$meta['server'], $account);
            Usage::check((string)$meta['server']);
            $limited = false;
            $this->driver = DriverFactory::make($params);
            $expected = trim((string)($this->in['expectFingerprint'] ?? ''));
            if ($expected !== '' && $this->driver instanceof SftpDriver) {
                $this->driver->expectFingerprint($expected);
            } elseif ($expected !== '' && ($params['protocol'] ?? '') === 'ftp' && !empty($params['ssl'])) {
                // PHP's ftp extension cannot show the certificate it receives, so check it right before connecting
                $now = Fingerprint::ftpsCertificate($params['host'], (int)$params['port'], $params['pinnedIp'] ?? null);
                if (!hash_equals($expected, $now['sha256'])) {
                    SecurityLog::event('host-key-changed', 'critical', "FTPS certificate of {$params['host']}:{$params['port']} changed between the check and the login: {$now['sha256']}", (string)$params['host']);
                    throw new UserError("The server's certificate ({actual}) is not the one you checked. Your password was not sent.", 409, ['actual' => $now['sha256']]);
                }
            }
            $gate = ConnGate::applies($params) ? ConnGate::key($params) : '';
            if ($gate !== '') {
                ConnGate::enter($gate);
            }
            for ($try = 0; ; $try++) {
                try {
                    $this->driver->connect();
                    break;
                } catch (TooManyConnections $e) {
                    if ($gate === '' || $try >= 3) {
                        throw $e;
                    }
                    ConnGate::learn($gate);
                    ConnGate::leave($gate);
                    usleep(400000 * ($try + 1));
                    ConnGate::enter($gate);
                }
            }
            if ($expected !== '' && ($params['protocol'] ?? '') === 'ftp' && !empty($params['ssl'])) {
                Fingerprint::remember($params['host'], (int)$params['port'], $expected);
            }
            $home = $this->driver->home();
            // Start folder: the last folder visited (login from the server list, initial folder unchanged),
            // else the initial folder, else the account's home. A folder that no longer exists is skipped.
            $saved = !empty($this->in['savedId']) ? SavedConnections::find((string)$this->in['savedId']) : null;
            $candidates = [];
            if ($saved && ($saved['lastDir'] ?? '') !== '' && ($saved['initialDir'] ?? '') === ($params['initialDir'] ?? '')) {
                $candidates[] = (string)$saved['lastDir'];
            }
            if ($params['initialDir'] ?? '') {
                $candidates[] = (string)$params['initialDir'];
            }
            foreach ($candidates as $want) {
                $want = Path::normalize($want);
                try {
                    $st = $this->driver->stat($want);
                } catch (\Throwable) {
                    $st = null;
                }
                if ($st && $st['isDir']) {
                    $home = $want;
                    break;
                }
            }
            $meta['home'] = $home;
            $meta['remembered'] = !empty($this->in['remember']) && SavedConnections::allowed();
            $meta['features'] = $this->driver->features();
            if ($this->driver instanceof SftpDriver) {
                $meta['fingerprint'] = $this->driver->fingerprint();
            }
            Session::storeConnection($params, $meta);
            if (!empty($this->in['remember'])) {
                SavedConnections::remember($params, $meta);
            } elseif (!empty($this->in['savedId'])) {
                SavedConnections::forget((string)$this->in['savedId']);
            }
            Logger::log('login', $meta, ['directory' => $home, 'ms' => $this->ms()]);
            return ['conn' => $meta, 'csrf' => Session::csrf(), 'saved' => SavedConnections::publicList()];
        } catch (\Throwable $e) {
            if (isset($limited, $account) && !($e instanceof UserError && $e->httpStatus() === 429) && !($e instanceof TooManyConnections)) {
                Limiter::loginFailed((string)$meta['server'], $account); // counts towards the per-account limit
            }
            $msg = $e instanceof UserError ? $e->english : 'Login failed: ' . self::cleanError($e->getMessage());
            Logger::log('login', $meta ?: [
                'protocol' => (string)($this->in['protocol'] ?? ''),
                'server'   => (string)($this->in['host'] ?? $this->in['endpoint'] ?? ''),
                'username' => (string)($this->in['username'] ?? $this->in['accessKey'] ?? ''),
            ], ['status' => 'error', 'message' => $msg, 'ms' => $this->ms()]);
            $this->log = ['skip' => true];
            if ($e instanceof UserError) {
                throw $e;
            }
            throw new UserError('Login failed.', 401, [], self::cleanError($e->getMessage()));
        }
    }

    /** Fingerprint of a server, before logging in (no password involved). */
    private function fingerprint(): array
    {
        $protocol = strtolower((string)($this->in['protocol'] ?? ''));
        $host = trim((string)($this->in['host'] ?? ''));
        $port = (int)($this->in['port'] ?? 0) ?: ($protocol === 'sftp' ? 22 : 21);
        $log = ['protocol' => $protocol === 'ftp' ? 'ftps' : $protocol, 'server' => $host, 'port' => $port];
        try {
            if ($protocol === 'sftp') {
                Requirements::requireProtocol('sftp');
            } elseif ($protocol === 'ftp' && !empty($this->in['ssl'])) {
                Requirements::requireProtocol('ftp');
            } else {
                throw new UserError('Only SFTP and FTPS servers have a fingerprint. Plain FTP is not encrypted.');
            }
            Security::throttleLogin();
            $pin = Security::checkServer($host, $port);
            Limiter::login($host, '(fingerprint)');
            $r = Fingerprint::check($protocol, $host, $port, $pin);
            Logger::log('fingerprint', $log, ['target' => $r['sha256'], 'message' => $r['status'], 'ms' => $this->ms()]);
            return $r + ['host' => $host, 'port' => $port];
        } catch (UserError $e) {
            Logger::log('fingerprint', $log, ['status' => 'error', 'message' => $e->getMessage(), 'ms' => $this->ms()]);
            $this->log = ['skip' => true];
            throw $e;
        }
    }

    private function actList(): array
    {
        $dir = $this->path('path');
        $this->log = ['directory' => $dir];
        $entries = $this->driver->listDir($dir);
        $this->log['count'] = count($entries);
        return ['path' => $dir, 'entries' => $entries];
    }

    private function actMkdir(): array
    {
        $dir = $this->path('path');
        $name = Path::validName((string)($this->in['name'] ?? ''));
        $this->log = ['directory' => $dir, 'entry' => $name];
        $target = Path::join($dir, $name);
        if ($this->driver->stat($target)) {
            throw new UserError('“{name}” already exists in this folder.', 409, ['name' => $name]);
        }
        $this->driver->mkdir($target);
        return ['created' => $target];
    }

    private function actNewfile(): array
    {
        $dir = $this->path('path');
        $name = Path::validName((string)($this->in['name'] ?? ''));
        $this->log = ['directory' => $dir, 'entry' => $name];
        $target = Path::join($dir, $name);
        if ($this->driver->stat($target)) {
            throw new UserError('“{name}” already exists in this folder.', 409, ['name' => $name]);
        }
        $tmp = App::tempFile();
        try {
            $this->driver->put($tmp, $target);
        } finally {
            @unlink($tmp);
        }
        return ['created' => $target];
    }

    private function actRename(): array
    {
        $dir = $this->path('path');
        $from = Path::validName((string)($this->in['from'] ?? ''));
        $to = Path::validName((string)($this->in['to'] ?? ''));
        $isDir = !empty($this->in['isDir']);
        $this->log = ['directory' => $dir, 'entry' => $from, 'target' => $to];
        if ($from === $to) {
            return ['renamed' => false];
        }
        $dst = Path::join($dir, $to);
        if (strcasecmp($from, $to) !== 0 && $this->driver->stat($dst)) {
            throw new UserError('“{name}” already exists in this folder.', 409, ['name' => $to]);
        }
        $ops = new FileOps($this->driver);
        $ops->move(Path::join($dir, $from), $dst, $isDir);
        $this->log['count'] = $ops->count;
        return ['renamed' => true];
    }

    private function actDelete(): array
    {
        $dir = $this->path('path');
        $items = $this->items();
        $this->log = ['directory' => $dir, 'entry' => array_column($items, 'name')];
        $ops = new FileOps($this->driver);
        $errors = [];
        foreach ($items as $it) {
            try {
                $ops->delete(Path::join($dir, $it['name']), $it['isDir']);
            } catch (UserError $e) {
                $errors[] = $e->getMessage();
            }
        }
        $this->log['count'] = $ops->count;
        if ($errors) {
            $this->log['message'] = implode(' | ', $errors);
            throw new UserError(implode("\n", array_slice($errors, 0, 5)));
        }
        return ['deleted' => $ops->count];
    }

    private function actCopy(): array
    {
        return $this->copyOrMove(false);
    }

    private function actMove(): array
    {
        return $this->copyOrMove(true);
    }

    private function copyOrMove(bool $move): array
    {
        $dir = $this->path('path');
        $target = $this->path('target');
        $items = $this->items();
        $this->log = ['directory' => $dir, 'entry' => array_column($items, 'name'), 'target' => $target];
        $tst = $this->driver->stat($target);
        if (!$tst || !$tst['isDir']) {
            throw new UserError('The target folder {path} does not exist.', 404, ['path' => $target]);
        }
        $ops = new FileOps($this->driver);
        $done = [];
        foreach ($items as $it) {
            $src = Path::join($dir, $it['name']);
            $name = $it['name'];
            if ($target === $dir) {
                if ($move) {
                    throw new UserError('Source and target folder are the same.');
                }
                $name = $this->freeName($dir, $name);
            }
            $dst = Path::join($target, $name);
            if ($this->driver->stat($dst)) {
                throw new UserError('“{name}” already exists in {path}.', 409, ['name' => $name, 'path' => $target]);
            }
            $move ? $ops->move($src, $dst, $it['isDir']) : $ops->copy($src, $dst, $it['isDir']);
            $done[] = $name;
        }
        $this->log['count'] = $ops->count;
        $this->log['bytes'] = $ops->bytes;
        return ['done' => $done];
    }

    private function actRead(): array
    {
        $file = $this->path('path');
        $this->log = ['directory' => Path::parent($file), 'entry' => Path::basename($file)];
        $st = $this->driver->stat($file);
        if (!$st || $st['isDir']) {
            throw new UserError('This file does not exist.', 404);
        }
        $max = (int)App::cfg('max_edit_bytes', 2 << 20);
        if (($st['size'] ?? 0) > $max) {
            throw new UserError('This file is too large to edit online (limit {size}). Download it instead.', 413, ['size' => FileOps::human($max)]);
        }
        $tmp = App::tempFile();
        try {
            $this->driver->get($file, $tmp);
            $content = (string)file_get_contents($tmp);
        } finally {
            @unlink($tmp);
        }
        $this->log['bytes'] = strlen($content);
        if (str_contains(substr($content, 0, 8000), "\0")) {
            throw new UserError('This looks like a binary file and cannot be edited as text.', 415);
        }
        $encoding = 'UTF-8';
        $bom = false;
        if (str_starts_with($content, "\xEF\xBB\xBF")) {
            $bom = true;
            $content = substr($content, 3);
        }
        if (!mb_check_encoding($content, 'UTF-8')) {
            $encoding = 'ISO-8859-1';
            $content = mb_convert_encoding($content, 'UTF-8', 'ISO-8859-1');
        }
        $eol = str_contains($content, "\r\n") ? 'crlf' : (str_contains($content, "\r") ? 'cr' : 'lf');
        return [
            'path' => $file, 'content' => $content, 'size' => strlen($content),
            'mtime' => $st['mtime'] ?? null, 'encoding' => $encoding, 'eol' => $eol, 'bom' => $bom,
        ];
    }

    private function actSave(): array
    {
        $file = $this->path('path');
        $content = (string)($this->in['content'] ?? '');
        $this->log = ['directory' => Path::parent($file), 'entry' => Path::basename($file)];
        $eol = (string)($this->in['eol'] ?? 'lf');
        $content = str_replace(["\r\n", "\r"], "\n", $content);
        if ($eol === 'crlf') {
            $content = str_replace("\n", "\r\n", $content);
        } elseif ($eol === 'cr') {
            $content = str_replace("\n", "\r", $content);
        }
        if (($this->in['encoding'] ?? 'UTF-8') === 'ISO-8859-1') {
            $content = mb_convert_encoding($content, 'ISO-8859-1', 'UTF-8');
        }
        if (!empty($this->in['bom'])) {
            $content = "\xEF\xBB\xBF" . $content;
        }
        // Detect changes made by someone else since the file was opened
        if (empty($this->in['force']) && isset($this->in['baseMtime']) && $this->in['baseMtime'] !== null) {
            $st = $this->driver->stat($file);
            if ($st && $st['mtime'] && (int)$st['mtime'] > (int)$this->in['baseMtime']) {
                throw new UserError('The file was changed on the server after you opened it. Save anyway to overwrite those changes.', 409);
            }
        }
        $tmp = App::tempFile();
        try {
            file_put_contents($tmp, $content);
            $this->driver->put($tmp, $file);
        } finally {
            @unlink($tmp);
        }
        $this->log['bytes'] = strlen($content);
        $st = $this->driver->stat($file);
        return ['saved' => true, 'size' => strlen($content), 'mtime' => $st['mtime'] ?? null];
    }

    /**
     * Start (or continue) a resumable upload. Creates the target folders of a folder upload and returns the
     * upload id and the byte offset the browser should continue from (0 for a new upload).
     */
    private function actUploadstart(): array
    {
        $this->log = ['skip' => true];
        $dir = $this->path('path');
        $name = Path::validName((string)($this->in['name'] ?? ''));
        $rel = (string)($this->in['relPath'] ?? '');
        $size = max(0, (int)($this->in['size'] ?? 0));
        $lastModified = (int)($this->in['lastModified'] ?? 0);
        $max = (int)App::cfg('max_upload_bytes', 512 << 20);
        if ($size > $max) {
            throw new UserError('“{name}” is larger than the upload limit of {size}.', 413, ['name' => $name, 'size' => FileOps::human($max)]);
        }
        $targetDir = $dir;
        if ($rel !== '') {
            foreach (array_filter(explode('/', Path::normalize($rel))) as $seg) {
                $targetDir = Path::join($targetDir, Path::validName($seg));
                $st = $this->driver->stat($targetDir);
                if (!$st) {
                    $this->driver->mkdir($targetDir);
                } elseif (!$st['isDir']) {
                    throw new UserError('Cannot create folder {path}: a file with that name exists.', 400, ['path' => $targetDir]);
                }
            }
        }
        $target = Path::join($targetDir, $name);
        $account = ConnGate::account($this->params);
        $key = Uploads::key($account, $target, $size, $lastModified);
        $chunk = $this->chunkSize();
        $st = Uploads::load($account, $key);
        if ($st) {
            // continue: the server's part file is the truth (a chunk may have arrived after the browser gave up)
            if ($st['mode'] === 'append') {
                $ps = $this->driver->stat($st['part']);
                $have = $ps && !$ps['isDir'] ? (int)$ps['size'] : -1;
                if ($have < 0 || $have > $size) {
                    $st = null;
                } elseif ($have !== (int)$st['offset']) {
                    $st['offset'] = $have;
                    $st['hash'] = null;           // the hash no longer matches what is on the server
                }
            } elseif ($st['mode'] === 'local') {
                $lp = Uploads::localPart($account, $key);
                $have = is_file($lp) ? (int)filesize($lp) : -1;
                if ($have < 0 && (int)$st['offset'] > 0) {
                    $st = null;
                } else {
                    $st['offset'] = max(0, $have);
                }
            } elseif ($st['mode'] === 's3' && (int)$st['chunk'] !== $chunk) {
                $this->driver->multipartAbort($target, (string)$st['uploadId']);
                $st = null;
            }
        }
        if (!$st) {
            $proto = (string)($this->params['protocol'] ?? '');
            $mode = $proto === 's3' ? (($size > $chunk && $chunk >= 5 << 20) ? 's3' : 'local') : 'append';
            if ($mode === 'local') {
                DiskQuota::checkUpload($size);   // collected on this web server: limited per visitor address
            }
            $st = ['target' => $target, 'part' => Uploads::partPath($target), 'size' => $size, 'lastModified' => $lastModified,
                'offset' => 0, 'mode' => $mode, 'chunk' => $chunk, 'created' => time(), 'hash' => Uploads::hashStart($size),
                'ip' => DiskQuota::key()];
            if ($mode === 's3') {
                $st['uploadId'] = $this->driver->multipartStart($target);
                $st['etags'] = [];
            }
            Uploads::delete($account, $key);
            Uploads::forgetTarget($account, $target, $key);
        }
        Uploads::save($account, $key, $st);
        return ['uploadId' => $key, 'offset' => (int)$st['offset'], 'chunkSize' => $chunk, 'mode' => $st['mode']];
    }

    /**
     * One chunk of a resumable upload, sent on to the server right away (FTP/SFTP: appended to the part file;
     * S3: one multipart part). After the last chunk the part file becomes the real file.
     */
    private function actUpload(): ?array
    {
        $key = (string)($this->in['uploadId'] ?? '');
        $account = ConnGate::account($this->params);
        $st = Uploads::valid($key) ? Uploads::load($account, $key) : null;
        if (!$st) {
            throw new UserError('This upload has expired. Please upload the file again.', 410);
        }
        $offset = (int)($this->in['offset'] ?? -1);
        if ($offset !== (int)$st['offset']) {
            $this->log = ['skip' => true];
            return ['received' => (int)$st['offset'], 'resync' => true];   // the browser continues from there
        }
        $f = $_FILES['chunk'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new UserError(self::uploadError((int)($f['error'] ?? UPLOAD_ERR_NO_FILE)));
        }
        $chunkFile = (string)$f['tmp_name'];
        $n = (int)filesize($chunkFile);
        $target = (string)$st['target'];
        $name = Path::basename($target);
        if ($offset + $n > (int)$st['size']) {
            throw new UserError('Upload of “{name}” got out of sync — please try again.', 409, ['name' => $name]);
        }
        Usage::add('bytes', $n);

        if ($st['mode'] === 'append') {
            try {
                $this->appendFile((string)$st['part'], $chunkFile, $offset);
            } catch (UserError $e) {
                if ($offset === 0) {
                    throw $e;
                }
                // the server refuses to append: fetch what is there, and continue on the web server instead
                DiskQuota::checkUpload((int)$st['size'], Uploads::dir($account) . '/' . $key . '.json');
                $st['ip'] = DiskQuota::key();
                $lp = Uploads::localPart($account, $key);
                $this->driver->get((string)$st['part'], $lp);
                if ((int)filesize($lp) !== $offset) {
                    @unlink($lp);
                    throw $e;
                }
                try {
                    $this->driver->deleteFile((string)$st['part']);
                } catch (\Throwable) {
                }
                $st['mode'] = 'local';
            }
        }
        if ($st['mode'] === 'local') {
            $lp = Uploads::localPart($account, $key);
            $out = fopen($lp, $offset === 0 ? 'wb' : 'ab');
            $in = fopen($chunkFile, 'rb');
            stream_copy_to_stream($in, $out);
            fclose($in);
            fclose($out);
        } elseif ($st['mode'] === 's3') {
            if ($n > 0) {
                $part = intdiv($offset, (int)$st['chunk']) + 1;
                $st['etags'][(string)$part] = $this->driver->multipartPart($target, (string)$st['uploadId'], $part, $chunkFile);
            }
        }
        $st['hash'] = Uploads::hashUpdate($st['hash'] ?? null, $chunkFile);
        $st['offset'] = $offset + $n;
        Uploads::save($account, $key, $st);
        if ($st['offset'] < (int)$st['size']) {
            $this->log = ['skip' => true];
            return ['received' => $st['offset']];
        }

        // ---- last chunk: the file is complete ----
        $this->log = ['directory' => Path::parent($target), 'entry' => $name, 'bytes' => (int)$st['size'], 'count' => 1,
            'file_hash' => (int)$st['size'] > 0 ? Uploads::hashFinal($st['hash'] ?? null) : ''];
        if ($st['mode'] === 'append') {
            $ex = $this->driver->stat($target);
            if ($ex && !$ex['isDir']) {
                $this->driver->deleteFile($target);   // the user chose to replace it (renaming over a file fails on many servers)
            }
            $this->driver->rename((string)$st['part'], $target, false);
        } elseif ($st['mode'] === 'local') {
            $lp = Uploads::localPart($account, $key);
            if (!is_file($lp)) {
                touch($lp);
            }
            $this->driver->put($lp, $target);
        } else {
            $etags = [];
            foreach ((array)$st['etags'] as $k => $v) {
                $etags[(int)$k] = (string)$v;
            }
            $this->driver->multipartComplete($target, (string)$st['uploadId'], $etags);
        }
        Uploads::delete($account, $key);
        Uploads::forgetTarget($account, $target, $key);
        return ['uploaded' => $target, 'size' => (int)$st['size']];
    }

    /** Append (or, at offset 0, write) a local file to a remote file. */
    private function appendFile(string $remote, string $local, int $offset): void
    {
        $in = fopen($local, 'rb');
        try {
            $this->driver->writeStream($remote, static function (int $max) use ($in): ?string {
                $d = fread($in, max(8192, $max));
                return ($d === false || $d === '') ? null : $d;
            }, $offset);
        } finally {
            fclose($in);
        }
    }

    // ------------------------------------------------------------------ jobs (copy, move, delete of any size)

    /**
     * Start a copy, move or delete job. Moves within FTP/SFTP are a rename on the server and finish at once
     * (no job); everything else becomes a job the browser drives with `jobstep`.
     */
    private function actJobstart(): array
    {
        $kind = (string)($this->in['kind'] ?? '');
        if (!in_array($kind, ['copy', 'move', 'delete'], true)) {
            throw new UserError('Unknown action.', 404);
        }
        $dir = $this->path('path');
        $items = $this->items();
        $names = array_column($items, 'name');
        $this->log = ['directory' => $dir, 'entry' => $names, 'skip' => true];
        $target = null;
        $pairs = [];   // [src, dst, isDir]
        if ($kind !== 'delete') {
            $target = $this->path('target');
            $tst = $this->driver->stat($target);
            if (!$tst || !$tst['isDir']) {
                throw new UserError('The target folder {path} does not exist.', 404, ['path' => $target]);
            }
            if ($kind === 'move' && $target === $dir) {
                throw new UserError('Source and target folder are the same.');
            }
            foreach ($items as $it) {
                $src = Path::join($dir, $it['name']);
                $name = ($kind === 'copy' && $target === $dir) ? $this->freeName($dir, $it['name']) : $it['name'];
                $dst = Path::join($target, $name);
                if ($it['isDir'] && Path::isInside($dst, $src)) {
                    throw new UserError($kind === 'copy' ? 'A folder cannot be copied into itself.' : 'A folder cannot be moved into itself.');
                }
                if ($this->driver->stat($dst)) {
                    throw new UserError('“{name}” already exists in {path}.', 409, ['name' => $name, 'path' => $target]);
                }
                $pairs[] = [$src, $dst, $it['isDir']];
            }
            // a move on the same FTP/SFTP server is a rename: instant, whatever the size
            if ($kind === 'move' && ($this->params['protocol'] ?? '') !== 's3') {
                foreach ($pairs as [$src, $dst, $isDir]) {
                    $this->driver->rename($src, $dst, $isDir);
                }
                $this->log = ['directory' => $dir, 'entry' => $names, 'target' => $target, 'count' => count($pairs)];
                $this->action = 'move';
                $this->writeLog('ok');
                return ['finished' => true];
            }
        } else {
            foreach ($items as $it) {
                $pairs[] = [Path::join($dir, $it['name']), null, $it['isDir']];
            }
        }
        $files = [];
        $dirs = [];
        $remove = [];
        foreach ($pairs as [$src, $dst, $isDir]) {
            if ($isDir) {
                if ($dst !== null) {
                    $this->driver->mkdir($dst);
                }
                $dirs[] = [$src, $dst];
                if ($kind !== 'copy') {
                    $remove[] = $src;
                }
            } else {
                $st = $this->driver->stat($src);
                $files[] = [$src, $dst, (int)($st['size'] ?? 0)];
            }
        }
        $account = ConnGate::account($this->params);
        $st = Jobs::create($account, $kind, $dir, $target, $names, $files, $dirs, $remove);
        return ['job' => Jobs::summary($st), 'workers' => Jobs::workers($this->params, $this->gate)];
    }

    /** Work on a job for a few seconds (the browser calls this repeatedly, with several workers in parallel). */
    private function actJobstep(): array
    {
        $this->log = ['skip' => true];
        $id = (string)($this->in['id'] ?? '');
        $gate = ConnGate::applies($this->params) ? ConnGate::key($this->params) : '';
        $budget = (float)(((array)App::cfg('jobs', []))['step_seconds'] ?? 15);
        if ($gate !== '' && ConnGate::limit($gate) === 1) {
            $budget = min($budget, 6);          // one connection: keep steps short, so browsing never waits long
        }
        App::timeLimit((int)$budget + 300);
        $job = new Jobs(ConnGate::account($this->params), $id, $this->params, $gate);
        return $job->step($budget) + ['workers' => Jobs::workers($this->params, $gate)];
    }

    /** Jobs of this account (unfinished ones are offered again after a new login). */
    private function actJobs(): array
    {
        $this->log = ['skip' => true];
        $gate = ConnGate::applies($this->params) ? ConnGate::key($this->params) : '';
        return ['jobs' => Jobs::listFor(ConnGate::account($this->params)), 'workers' => Jobs::workers($this->params, $gate)];
    }

    /** pause | resume | cancel | dismiss */
    private function actJobcontrol(): array
    {
        $this->log = ['skip' => true];
        $id = (string)($this->in['id'] ?? '');
        $op = (string)($this->in['op'] ?? '');
        $account = ConnGate::account($this->params);
        $gate = ConnGate::applies($this->params) ? ConnGate::key($this->params) : '';
        if ($op === 'cancel') {
            return ['job' => (new Jobs($account, $id, $this->params, $gate))->cancel()];
        }
        if ($op === 'dismiss') {
            $st = Jobs::load($account, $id);
            if ($st && in_array($st['status'], ['running'], true)) {
                throw new UserError('Pause or cancel the job first.');
            }
            Jobs::delete($account, $id);
            return ['dismissed' => true];
        }
        if (!in_array($op, ['pause', 'resume'], true)) {
            throw new UserError('Unknown action.', 404);
        }
        Jobs::update($account, $id, static function (array &$st) use ($op): void {
            if (in_array($st['status'], ['running', 'paused'], true)) {
                $st['status'] = $op === 'pause' ? 'paused' : 'running';
                if ($op === 'resume') {
                    // whoever worked on these before is gone: they may be taken over at once
                    foreach ((array)$st['inflight'] as $k => $x) {
                        $st['inflight'][$k]['until'] = 0;
                    }
                    foreach ((array)$st['claims'] as $s => [$d, $u]) {
                        $st['claims'][$s] = [$d, 0];
                    }
                    $st['dirsLease'] = 0;
                }
            }
        });
        return ['job' => Jobs::summary(Jobs::load($account, $id), Jobs::dir($account))];
    }

    /** Unfinished uploads of this account (to continue them by choosing the same file again). */
    private function actUploads(): array
    {
        $this->log = ['skip' => true];
        return ['uploads' => Uploads::listFor(ConnGate::account($this->params))];
    }

    /** Give up an unfinished upload: delete the part file on the server (or abort the S3 multipart upload). */
    private function actUploaddiscard(): array
    {
        $this->log = ['skip' => true];
        $key = (string)($this->in['uploadId'] ?? '');
        $account = ConnGate::account($this->params);
        $st = Uploads::valid($key) ? Uploads::load($account, $key) : null;
        if ($st) {
            try {
                if ($st['mode'] === 'append') {
                    if ($this->driver->stat((string)$st['part'])) {
                        $this->driver->deleteFile((string)$st['part']);
                    }
                } elseif ($st['mode'] === 's3') {
                    $this->driver->multipartAbort((string)$st['target'], (string)$st['uploadId']);
                }
            } catch (\Throwable) {
            }
        }
        Uploads::delete($account, $key);
        return ['discarded' => true];
    }

    /**
     * Download a file: streamed from the server straight to the browser (no temporary file, the first bytes
     * arrive at once), with HTTP Range support so browsers can resume an interrupted download.
     * Falls back to fetching the whole file first when streaming fails before anything was sent.
     */
    private function actDownload(): ?array
    {
        $file = $this->path('path');
        $this->log = ['directory' => Path::parent($file), 'entry' => Path::basename($file)];
        $inline = !empty($this->in['inline']);
        $st = $this->driver->stat($file);
        if (!$st || $st['isDir']) {
            throw new UserError('This file does not exist.', 404);
        }
        $size = isset($st['size']) && $st['size'] !== null && (int)$st['size'] >= 0 ? (int)$st['size'] : null;
        $etag = '"' . substr(sha1($file . '|' . $size . '|' . ($st['mtime'] ?? '')), 0, 20) . '"';

        // ---- Range (resume) ----
        $start = 0;
        $length = -1;
        $range = trim((string)($_SERVER['HTTP_RANGE'] ?? ''));
        $ifRange = trim((string)($_SERVER['HTTP_IF_RANGE'] ?? ''));
        $rangeOk = $range !== '' && $size !== null && $size > 0
            && ($ifRange === '' || $ifRange === $etag || (!empty($st['mtime']) && strtotime($ifRange) === (int)$st['mtime']));
        if ($rangeOk && preg_match('/^bytes=(\d*)-(\d*)$/', $range, $m) && ($m[1] !== '' || $m[2] !== '')) {
            if ($m[1] === '') {                                   // last N bytes
                $start = max(0, $size - (int)$m[2]);
                $end = $size - 1;
            } else {
                $start = (int)$m[1];
                $end = $m[2] === '' ? $size - 1 : min((int)$m[2], $size - 1);
            }
            if ($start >= $size || $end < $start) {
                $this->log['skip'] = true;
                header('Content-Range: bytes */' . $size);
                http_response_code(416);
                return null;
            }
            $length = $end - $start + 1;
        }

        $sent = 0;
        $headersOut = false;
        $lastBeat = microtime(true);
        $sink = function (string $d) use (&$sent, &$headersOut, &$lastBeat, $file, $inline, $size, $start, $length, $etag, $st): bool {
            if (!$headersOut) {
                $this->downloadHeaders(Path::basename($file), $inline, self::mimeOf($file), $size, $start, $length, $etag, $st['mtime'] ?? null);
                $headersOut = true;
            }
            echo $d;
            flush();
            $sent += strlen($d);
            if (microtime(true) - $lastBeat > 5) {
                // as long as data flows the download may take as long as it needs (PHP's limit counts real time on Windows)
                App::timeLimit(max(60, (int)App::cfg('max_execution_time', 300)));
                $lastBeat = microtime(true);
            }
            return !connection_aborted();
        };
        while (ob_get_level()) {
            ob_end_clean();
        }
        try {
            $this->driver->readStream($file, $sink, $start, $length);
            if (!$headersOut) {                                   // empty file
                $this->downloadHeaders(Path::basename($file), $inline, self::mimeOf($file), $size ?? 0, $start, $length, $etag, $st['mtime'] ?? null);
            }
        } catch (UserError $e) {
            if ($headersOut) {
                $this->log['message'] = 'interrupted after ' . $sent . ' bytes: ' . $e->english;
                $this->log['bytes'] = $sent;
                $this->writeLog('error');
                return null;                                      // the browser can resume (Range)
            }
            // nothing sent yet: fall back to fetching the whole file first
            $tmp = App::tempFile();
            try {
                $this->driver->get($file, $tmp);
                $this->log['bytes'] = (int)filesize($tmp);
                $this->log['count'] = 1;
                $this->writeLog('ok');
                $this->sendFile($tmp, Path::basename($file), $inline);
            } finally {
                @unlink($tmp);
            }
            return null;
        }
        $this->log['bytes'] = $sent;
        $this->log['count'] = 1;
        if ($start > 0 || $length >= 0) {
            $this->log['message'] = 'range ' . $start . '-' . ($length >= 0 ? $start + $length - 1 : '');
        }
        $this->writeLog('ok');
        return null;
    }

    private static function mimeOf(string $name): string
    {
        return match (strtolower(pathinfo($name, PATHINFO_EXTENSION))) {
            'png' => 'image/png', 'jpg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp', 'avif' => 'image/avif',
            'pdf' => 'application/pdf', 'txt', 'log', 'md', 'csv' => 'text/plain', 'mp4', 'm4v' => 'video/mp4', 'mp3' => 'audio/mpeg',
            'zip' => 'application/zip',
            default => 'application/octet-stream',
        };
    }

    /** Response headers of a (possibly partial) download. */
    private function downloadHeaders(string $name, bool $inline, string $mime, ?int $size, int $start, int $length, string $etag, ?int $mtime): void
    {
        if (headers_sent()) {
            return;
        }
        $safeInline = ['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/avif', 'application/pdf', 'text/plain', 'video/mp4', 'audio/mpeg'];
        if ($inline && !in_array($mime, $safeInline, true)) {
            $inline = false;
        }
        if (!$inline) {
            $mime = 'application/octet-stream';
        }
        $tok = (string)($this->in['dlToken'] ?? '');
        if (preg_match('/^[a-z0-9]{6,32}$/', $tok)) {
            setcookie('n2fdl_' . $tok, '1', App::cookieOptions(['expires' => time() + 120]));
        }
        $ascii = preg_replace('/[^\x20-\x7E]|["\\\\]/', '_', $name);
        header('Content-Type: ' . $mime);
        if ($size !== null) {
            header('Accept-Ranges: bytes');
            header('ETag: ' . $etag);
            if ($mtime) {
                header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');
            }
            if ($length >= 0) {
                http_response_code(206);
                header('Content-Range: bytes ' . $start . '-' . ($start + $length - 1) . '/' . $size);
                header('Content-Length: ' . $length);
            } else {
                header('Content-Length: ' . max(0, $size - $start));
            }
        }
        header(sprintf('Content-Disposition: %s; filename="%s"; filename*=UTF-8\'\'%s', $inline ? 'inline' : 'attachment', $ascii, rawurlencode($name)));
        header("Content-Security-Policy: default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'; sandbox");
        header('Cache-Control: private, no-store');
    }

    /**
     * Zip download, streamed: the listing is checked first (limits → a normal error message), then the zip is
     * written to the browser while each file streams from the server. Nothing is stored on the web server.
     */
    private function actZip(): ?array
    {
        Limiter::heavy((string)session_id());
        $dir = $this->path('path');
        $items = $this->items();
        $this->log = ['directory' => $dir, 'entry' => array_column($items, 'name')];
        App::timeLimit((int)App::cfg('max_execution_time', 600));
        $ops = new FileOps($this->driver);
        $plan = $ops->zipPlan(array_map(fn($it) => ['path' => Path::join($dir, $it['name']), 'isDir' => $it['isDir']], $items));
        $base = count($items) === 1 ? $items[0]['name'] : (Path::basename($dir) ?: 'files');
        while (ob_get_level()) {
            ob_end_clean();
        }
        $this->downloadHeaders($base . '.zip', false, 'application/zip', null, 0, -1, '', null);
        header('Content-Type: application/zip');
        $lastBeat = microtime(true);
        $errors = $ops->zipStream($plan, static function (string $b) use (&$lastBeat): bool {
            echo $b;
            flush();
            if (microtime(true) - $lastBeat > 5) {
                App::timeLimit(max(60, (int)App::cfg('max_execution_time', 300)));   // as long as data flows
                $lastBeat = microtime(true);
            }
            return !connection_aborted();
        });
        $this->log['bytes'] = $ops->bytes;
        $this->log['count'] = $ops->count;
        $this->writeLog($errors ? 'error' : 'ok', $errors ? mb_substr(count($errors) . ' problems: ' . implode('; ', $errors), 0, 500) : '');
        return null;
    }

    private function actSearch(): array
    {
        $dir = $this->path('path');
        $needle = (string)($this->in['needle'] ?? '');
        if ($needle === '' || mb_strlen($needle) > 500) {
            throw new UserError('Please enter the text to search for.');
        }
        $this->log = ['directory' => $dir, 'target' => $needle];
        $ops = new FileOps($this->driver);
        $res = $ops->search($dir, $needle, [
            'caseSensitive' => !empty($this->in['caseSensitive']),
            'scope'         => ($this->in['scope'] ?? 'content') === 'name' ? 'name' : 'content',
            'regex'         => !empty($this->in['regex']),
            'filePattern'   => (string)($this->in['filePattern'] ?? ''),
        ]);
        $this->log['bytes'] = $ops->bytes;
        $this->log['count'] = $res['scanned'];
        $this->log['message'] = count($res['results']) . ' matches';
        return $res;
    }

    /** chmod / chown of the selected entries, optionally recursive. Continues after errors and reports them. */
    private function actChmod(): array
    {
        $f = $this->driver->features();
        $dir = $this->path('path');
        $items = $this->items();
        $mode = static function ($v): ?int {
            if ($v === null || $v === '' || $v === false) {
                return null;
            }
            $v = (string)$v;
            if (!preg_match('/^0?[0-7]{3,4}$/', $v)) {
                throw new UserError('“{mode}” is not a valid permission (use 3 or 4 octal digits, e.g. 755).', 400, ['mode' => $v]);
            }
            return octdec($v) & 07777;
        };
        $dirMode = $mode($this->in['dirMode'] ?? null);
        $fileMode = $mode($this->in['fileMode'] ?? null);
        $uid = $this->ownerId((string)($this->in['owner'] ?? ''), false);
        $gid = $this->ownerId((string)($this->in['group'] ?? ''), true);
        if (($dirMode !== null || $fileMode !== null) && empty($f['chmod'])) {
            throw new UserError('This server does not support changing permissions.', 400);
        }
        if (($uid !== null || $gid !== null) && empty($f['chown'])) {
            throw new UserError('Changing the owner is not possible over FTP. Use SFTP/SSH instead.', 400);
        }
        if ($dirMode === null && $fileMode === null && $uid === null && $gid === null) {
            throw new UserError('Nothing to change.');
        }
        $recursive = !empty($this->in['recursive']);
        $this->log = ['directory' => $dir, 'entry' => array_column($items, 'name'),
            'target' => trim(implode(' ', array_filter([
                $dirMode !== null ? 'dirs=' . decoct($dirMode) : '', $fileMode !== null ? 'files=' . decoct($fileMode) : '',
                $uid !== null ? "uid=$uid" : '', $gid !== null ? "gid=$gid" : '', $recursive ? 'recursive' : '']))),
        ];
        $ops = new FileOps($this->driver);
        $opt = ['dirMode' => $dirMode, 'fileMode' => $fileMode, 'uid' => $uid, 'gid' => $gid, 'recursive' => $recursive];
        foreach ($items as $it) {
            $ops->chmodTree(Path::join($dir, $it['name']), $it['isDir'], $opt);
        }
        $this->log['count'] = $ops->count;
        if ($ops->errors) {
            $this->log['message'] = count($ops->errors) . ' errors: ' . implode(' | ', array_slice($ops->errors, 0, 5));
            $this->writeLog('error');
        }
        // Some servers (Windows FTP and SSH servers in particular) answer "OK" but keep the old permissions.
        // Check the selected entries (not the whole tree), so the user is not told it worked when it did not.
        $ignored = [];
        if (!$ops->errors) {
            foreach (array_slice($items, 0, 20) as $it) {
                $want = $it['isDir'] ? $dirMode : $fileMode;
                if ($want === null || $want > 0777) {
                    continue;
                }
                try {
                    $st = $this->driver->stat(Path::join($dir, $it['name']));
                } catch (\Throwable) {
                    continue;
                }
                $have = substr((string)($st['perms'] ?? ''), 1, 9);
                if (preg_match('/^[rwx-]{9}$/', $have) && $have !== substr(FtpDriver::modeToString($want, $it['isDir']), 1)) {
                    $ignored[] = $it['name'];
                }
            }
            if ($ignored) {
                $this->log['message'] = 'server kept the old permissions: ' . implode(', ', array_slice($ignored, 0, 5));
            }
        }
        return ['changed' => $ops->count, 'errors' => array_slice($ops->errors, 0, 50), 'errorCount' => count($ops->errors),
            'ignored' => $ignored];
    }

    /** Extract an archive on the server into a new folder (default) or the current folder. */
    private function actExtract(): array
    {
        Limiter::heavy((string)session_id());
        $dir = $this->path('path');
        $name = Path::validName((string)($this->in['name'] ?? ''));
        $archive = Path::join($dir, $name);
        $kind = Extractor::kind($name);
        if ($kind === null) {
            throw new UserError('This type of archive cannot be extracted.');
        }
        if (($problem = Extractor::requirement($kind)) !== null) {
            throw new UserError($problem, 501);
        }
        if (($this->in['into'] ?? 'folder') === 'here') {
            $target = $dir;
        } else {
            $folder = trim((string)($this->in['folder'] ?? ''));
            if ($folder === '') {
                $folder = preg_replace('/\.(tar\.gz|tar\.bz2|tgz|tbz2?|tar|zip)$/i', '', $name) ?: $name . '-files';
            }
            $folder = Path::validName($folder);
            $target = Path::join($dir, $folder);
            if ($this->driver->stat($target) && empty($this->in['merge'])) {
                for ($i = 2; $i < 100 && $this->driver->stat($target); $i++) {
                    $target = Path::join($dir, "$folder ($i)");
                }
            }
        }
        $overwrite = !empty($this->in['overwrite']);
        $this->log = ['directory' => $dir, 'entry' => [$name], 'target' => $target];
        App::timeLimit((int)App::cfg('max_execution_time', 600));
        $x = new Extractor($this->driver, $overwrite);
        $existed = $target === $dir || (bool)$this->driver->stat($target);
        try {
            $x->extract($archive, $target);
        } catch (\Throwable $e) {
            if (!$existed && $x->files === 0) { // refused before anything was written: leave no empty folder
                try {
                    (new FileOps($this->driver))->delete($target, true);
                } catch (\Throwable) {
                }
            }
            throw $e;
        } finally {
            $this->log['count'] = $x->files;
            $this->log['bytes'] = $x->bytes;
        }
        if ($x->errors) {
            $this->log['message'] = $x->skipped . ' skipped: ' . implode(' | ', array_slice($x->errors, 0, 5));
        }
        return ['target' => $target, 'files' => $x->files, 'dirs' => $x->dirs, 'skipped' => $x->skipped,
            'bytes' => $x->bytes, 'errors' => $x->errors];
    }

    // ---------------------------------------------------------------- share links

    private function shareOwner(): string
    {
        $m = Session::meta();
        return Shares::owner((array)($m['public'] ?? ['label' => $m['label'] ?? '']));
    }

    private function actShare(): array
    {
        Limiter::heavy((string)session_id());
        $dir = $this->path('path');
        $items = $this->items();
        $this->log = ['directory' => $dir, 'entry' => array_column($items, 'name')];
        App::timeLimit((int)App::cfg('max_execution_time', 600));
        $max = (int)Shares::cfg('max_downloads_cap', 100000);
        $r = Shares::create($this->driver,
            array_map(fn($it) => ['path' => Path::join($dir, $it['name']), 'isDir' => $it['isDir']], $items),
            [
                'days' => (float)($this->in['days'] ?? Shares::cfg('default_days', 7)),
                'password' => mb_substr((string)($this->in['password'] ?? ''), 0, 200),
                'maxDownloads' => min($max, max(0, (int)($this->in['maxDownloads'] ?? 0))),
                'message' => (string)($this->in['message'] ?? ''),
            ],
            $this->shareOwner(), (string)(Session::meta()['label'] ?? ''));
        $this->log['target'] = 'share ' . $r['id'] . ' until ' . gmdate('Y-m-d H:i', $r['expires']) . ' UTC'
            . ($r['password'] ? ', password' : '') . ($r['maxDownloads'] ? ', max ' . $r['maxDownloads'] . ' downloads' : '');
        $this->log['count'] = $r['count'];
        $this->log['bytes'] = $r['bytes'];
        return $r;
    }

    private function actShares(): array
    {
        $this->log = ['skip' => true];
        if ($p = Shares::problem()) {
            return ['shares' => [], 'problem' => $p];
        }
        return ['shares' => Shares::listFor($this->shareOwner()), 'maxDays' => (float)Shares::cfg('max_days', 30),
            'defaultDays' => (float)Shares::cfg('default_days', 7)];
    }

    private function actUnshare(): array
    {
        $m = Shares::revoke((string)($this->in['id'] ?? ''), $this->shareOwner());
        $this->log = ['entry' => $m['items'] ?? [], 'target' => 'share ' . $m['id'], 'count' => $m['downloads'] ?? 0];
        return ['revoked' => true];
    }

    /**
     * The same file uploaded to many different servers from one IP within an hour is the typical pattern of a
     * mass defacement with stolen passwords: record it and (by default) block the IP for a day.
     */
    private function massUploadCheck(string $hash, string $server): void
    {
        $cfg = (array)App::cfg('mass_upload', []);
        $limit = (int)($cfg['servers'] ?? 5);
        $pdo = Db::get();
        if ($limit <= 0 || !$pdo) {
            return;
        }
        try {
            $st = $pdo->prepare("SELECT COUNT(DISTINCT server) FROM n2f_action_log
                WHERE file_hash = ? AND action = 'upload' AND status = 'ok' AND remote_addr = ? AND created_at >= ?");
            $st->execute([$hash, App::clientIp(), date('Y-m-d H:i:s', time() - (int)($cfg['window'] ?? 3600))]);
            $n = (int)$st->fetchColumn();
        } catch (\Throwable) {
            return; // database not upgraded yet
        }
        if ($n < $limit) {
            return;
        }
        $hours = (int)($cfg['block_hours'] ?? 24);
        SecurityLog::event('mass-upload', 'critical', "The same file (SHA-256 " . substr($hash, 0, 16) . "…) was uploaded to $n different servers within the hour"
            . ($hours > 0 ? "; IP blocked for $hours h" : ''), $server);
        if ($hours > 0) {
            try {
                Blocks::add('ip', App::clientIp(), "Same file uploaded to $n servers (possible mass defacement)", $hours, 'auto');
                SecurityLog::event('auto-block', 'critical', 'IP ' . App::clientIp() . " blocked for $hours h: same file uploaded to $n servers", $server);
            } catch (\Throwable) {
            }
        }
    }

    /** Numeric id, or a name resolved on the server (SSH). Empty = unchanged. */
    private function ownerId(string $v, bool $group): ?int
    {
        $v = trim($v);
        if ($v === '') {
            return null;
        }
        if (preg_match('/^\d{1,10}$/', $v)) {
            return (int)$v;
        }
        $id = $this->driver instanceof SftpDriver ? $this->driver->resolveId($v, $group) : null;
        if ($id === null) {
            throw new UserError($group ? 'Unknown group “{name}”. Enter the numeric group id instead.' : 'Unknown user “{name}”. Enter the numeric user id instead.', 400, ['name' => $v]);
        }
        return $id;
    }

    private function actExec(): array
    {
        Requirements::requireFeature('exec');
        if (!$this->driver instanceof SftpDriver) {
            throw new UserError('Running commands is only available for SSH connections.', 403);
        }
        $cmd = trim((string)($this->in['command'] ?? ''));
        $cwd = $this->path('path');
        if ($cmd === '' || strlen($cmd) > 4000) {
            throw new UserError('Please enter a command.');
        }
        $this->log = ['directory' => $cwd, 'target' => $cmd];
        $r = $this->driver->exec($cmd, $cwd);
        foreach (['output', 'stderr'] as $k) {
            if (strlen($r[$k]) > 1048576) {
                $r[$k] = substr($r[$k], -1048576);
            }
            if (!mb_check_encoding($r[$k], 'UTF-8')) {
                $r[$k] = mb_convert_encoding($r[$k], 'UTF-8', 'ISO-8859-1');
            }
        }
        $this->log['bytes'] = strlen($r['output']) + strlen($r['stderr']);
        $this->log['message'] = 'exit ' . ($r['exit'] ?? '?');
        return $r;
    }

    // =================================================================== helpers

    /**
     * A driver connected through the connection gate. When the server refuses the connection as "too many",
     * the real limit is learned, and the request waits for a free connection and tries again.
     */
    public static function connectGated(array $params, string $gate, string $holder = '', bool $job = false, bool $entered = false): Driver
    {
        if ($gate !== '' && !$entered) {
            ConnGate::enter($gate, -1, $holder, $job);
        }
        $d = DriverFactory::make($params);
        if ($gate === '') {
            return $d;                 // S3: plain HTTPS, connects lazily
        }
        for ($try = 0; ; $try++) {
            try {
                $d->connect();
                return $d;
            } catch (TooManyConnections $e) {
                ConnGate::learn($gate);
                ConnGate::leave($gate, $holder);
                if ($try >= 3) {
                    throw $e;
                }
                usleep(400000 * ($try + 1));   // the server may need a moment to notice a closed connection
                ConnGate::enter($gate, -1, $holder, $job);
            }
        }
    }

    private function openDriver(array $params, string $gate): Driver
    {
        return self::connectGated($params, $gate);
    }

    private function input(): array
    {
        $in = $_GET;
        $ct = (string)($_SERVER['CONTENT_TYPE'] ?? '');
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            if (str_contains($ct, 'application/json')) {
                $json = json_decode((string)file_get_contents('php://input'), true);
                if (is_array($json)) {
                    $in = array_merge($in, $json);
                }
            } else {
                $in = array_merge($in, $_POST);
            }
        }
        return $in;
    }

    private function path(string $key): string
    {
        $p = $this->in[$key] ?? null;
        if (!is_string($p) || $p === '') {
            throw new UserError('Missing path.');
        }
        return Path::normalize($p);
    }

    /** @return array<int,array{name:string,isDir:bool}> */
    private function items(): array
    {
        $raw = $this->in['items'] ?? [];
        if (is_string($raw)) {
            $raw = json_decode($raw, true) ?: [];
        }
        $out = [];
        foreach ((array)$raw as $it) {
            if (is_array($it) && isset($it['name'])) {
                $out[] = ['name' => Path::validName((string)$it['name']), 'isDir' => !empty($it['isDir'])];
            }
        }
        if (!$out) {
            throw new UserError('Nothing selected.');
        }
        return $out;
    }

    private function freeName(string $dir, string $name): string
    {
        $dot = strrpos($name, '.');
        $base = $dot > 0 ? substr($name, 0, $dot) : $name;
        $ext = $dot > 0 ? substr($name, $dot) : '';
        for ($i = 1; $i < 100; $i++) {
            $candidate = $base . ($i === 1 ? ' copy' : " copy $i") . $ext;
            if (!$this->driver->stat(Path::join($dir, $candidate))) {
                return $candidate;
            }
        }
        throw new UserError('Could not find a free name for the copy.');
    }

    private function chunkSize(): int
    {
        $toBytes = static function (string $v): int {
            $v = trim($v);
            $n = (int)$v;
            return match (strtolower(substr($v, -1))) {
                'g' => $n << 30, 'm' => $n << 20, 'k' => $n << 10, default => $n,
            };
        };
        $limit = min(
            $toBytes((string)ini_get('upload_max_filesize')) ?: PHP_INT_MAX,
            $toBytes((string)ini_get('post_max_size')) ?: PHP_INT_MAX
        );
        return (int)max(256 << 10, min(8 << 20, $limit - (64 << 10)));
    }

    private function checkPostSize(): void
    {
        $len = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
        if ($len > 0 && empty($_POST) && empty($_FILES) && !str_contains((string)($_SERVER['CONTENT_TYPE'] ?? ''), 'json')
            && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            throw new UserError('The request is larger than the server allows (post_max_size).', 413);
        }
    }

    private static function uploadError(int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'The file is larger than the server allows.',
            UPLOAD_ERR_PARTIAL => 'The upload was interrupted.',
            UPLOAD_ERR_NO_FILE => 'No file was received.',
            UPLOAD_ERR_NO_TMP_DIR, UPLOAD_ERR_CANT_WRITE => 'The server could not store the upload (temp folder).',
            default => 'The upload failed.',
        };
    }

    private function sendFile(string $path, string $name, bool $inline, ?string $mime = null): void
    {
        $mime ??= (function_exists('mime_content_type') ? @mime_content_type($path) : null) ?: 'application/octet-stream';
        $safeInline = ['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/avif', 'application/pdf', 'text/plain', 'video/mp4', 'audio/mpeg'];
        if ($inline && !in_array($mime, $safeInline, true)) {
            $inline = false;
        }
        if (!$inline) {
            $mime = $mime === 'application/zip' ? $mime : 'application/octet-stream';
        }
        $ascii = preg_replace('/[^\x20-\x7E]|["\\\\]/', '_', $name);
        while (ob_get_level()) {
            ob_end_clean();
        }
        // Lets the front-end know that the (possibly long-prepared) download has started
        $tok = (string)($this->in['dlToken'] ?? '');
        if (preg_match('/^[a-z0-9]{6,32}$/', $tok)) {
            setcookie('n2fdl_' . $tok, '1', App::cookieOptions(['expires' => time() + 120]));
        }
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($path));
        header(sprintf('Content-Disposition: %s; filename="%s"; filename*=UTF-8\'\'%s', $inline ? 'inline' : 'attachment', $ascii, rawurlencode($name)));
        header("Content-Security-Policy: default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'; sandbox");
        $fp = fopen($path, 'rb');
        while (!feof($fp) && !connection_aborted()) {
            echo fread($fp, 1 << 16);
            flush();
        }
        fclose($fp);
    }

    private function writeLog(string $status, string $message = ''): void
    {
        if (!empty($this->log['skip']) || !empty($this->log['done'])) {
            return;
        }
        $d = $this->log;
        $d['status'] = $status;
        $d['ms'] = $this->ms();
        if ($message !== '') {
            $d['message'] = $message;
        }
        Logger::log($this->action ?: 'unknown', Session::meta() + ['protocol' => $this->driver?->protocol()], $d);
        $this->log['done'] = true;
        if ($this->action !== 'upload') {
            Usage::add('bytes', (int)($d['bytes'] ?? 0)); // uploads are counted per chunk as they arrive
        } elseif ($status === 'ok' && ($d['file_hash'] ?? '') !== '') {
            $this->massUploadCheck((string)$d['file_hash'], (string)(Session::meta()['server'] ?? ''));
        }
    }

    private function fail(string $message, int $status, ?string $logMessage = null): void
    {
        Usage::add('errors');
        if ($status === 403 || $status === 429) {
            Usage::add('refused');
        }
        if ($this->action !== '' && $this->action !== 'session' && $status !== 419 && $status !== 401) {
            $this->writeLog('error', $logMessage ?? $message);
        }
        if (headers_sent()) {
            return;
        }
        http_response_code($status);
        $this->json(['error' => $message, 'status' => $status], false);
    }

    private function json(array $data, bool $ok = true): void
    {
        $this->discardStrayOutput();
        if (headers_sent()) {
            return;
        }
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => $ok] + ($ok ? ['data' => $data] : $data), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    }

    /** Drop (but log) any output PHP produced outside our own JSON / file responses. */
    private function discardStrayOutput(): void
    {
        $stray = '';
        while (ob_get_level() >= max(1, $this->obLevel)) {
            $stray .= (string)ob_get_clean();
        }
        if (trim($stray) !== '') {
            error_log('net2ftp: discarded unexpected output: ' . substr(trim(strip_tags($stray)), 0, 500));
        }
    }

    private function ms(): int
    {
        return (int)round((microtime(true) - $this->t0) * 1000);
    }

    private static function cleanError(string $m): string
    {
        return preg_replace('/^\w+\(\):\s*/', '', $m) ?? $m;
    }
}

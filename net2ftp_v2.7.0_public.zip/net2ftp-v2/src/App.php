<?php
declare(strict_types=1);

namespace Net2ftp;

/** Static configuration holder and small shared helpers. */
final class App
{
    private static array $config = [];

    public static function init(array $config): void
    {
        self::$config = $config;
        $tmp = self::tmpDir();
        if (!is_dir($tmp)) {
            @mkdir($tmp, 0700, true);
        }
    }

    /** ini_set() that tolerates hosts where ini_set is disabled. */
    public static function ini(string $key, string $value): void
    {
        if (function_exists('ini_set')) {
            @ini_set($key, $value);
        }
    }

    /** Raise the time limit when the host allows it. */
    public static function timeLimit(int $seconds): void
    {
        if (function_exists('set_time_limit')) {
            @set_time_limit($seconds);
        }
    }

    public static function cfg(string $key, mixed $default = null): mixed
    {
        return self::$config[$key] ?? $default;
    }

    /** The whole effective configuration (for the read-only settings view of the admin panel). */
    public static function all(): array
    {
        return self::$config;
    }

    public static function tmpDir(): string
    {
        return rtrim((string)(self::$config['tmp_dir'] ?? (N2F_ROOT . '/storage/tmp')), '/');
    }

    /** Create a unique temp file path; the caller must delete it. */
    public static function tempFile(string $prefix = 'n2f'): string
    {
        $path = false;
        if (function_exists('tempnam')) {
            $path = @tempnam(self::tmpDir(), $prefix);
        } else {
            for ($i = 0; $i < 10 && $path === false; $i++) {
                $candidate = self::tmpDir() . '/' . $prefix . bin2hex(random_bytes(8));
                $fp = @fopen($candidate, 'x');
                if ($fp) {
                    fclose($fp);
                    $path = $candidate;
                }
            }
        }
        if ($path === false) {
            throw new UserError('Cannot create temporary file — check that tmp_dir is writable.');
        }
        return $path;
    }

    /** Create a unique temp directory; the caller must remove it with rrmdirLocal(). */
    public static function tempDir(string $prefix = 'n2f'): string
    {
        $dir = self::tmpDir() . '/' . $prefix . bin2hex(random_bytes(8));
        if (!@mkdir($dir, 0700, true)) {
            throw new UserError('Cannot create temporary folder — check that tmp_dir is writable.');
        }
        return $dir;
    }

    /**
     * Replace $dest with $tmp atomically. On Windows, rename() fails with "Access is denied (code: 5)" while
     * another request has $dest open for reading (a job step reading the job's state, say): try again for up
     * to a second, then write the content in place.
     */
    public static function replaceFile(string $tmp, string $dest): bool
    {
        for ($i = 0; $i < 25; $i++) {
            if (@rename($tmp, $dest)) {
                return true;
            }
            if (!is_file($tmp)) {
                return false;
            }
            usleep(20000 + $i * 2000);
        }
        $data = @file_get_contents($tmp);
        $ok = $data !== false && @file_put_contents($dest, $data, LOCK_EX) === strlen($data);
        @unlink($tmp);
        return $ok;
    }

    public static function rrmdirLocal(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($it as $f) {
            $f->isDir() && !$f->isLink() ? @rmdir($f->getPathname()) : @unlink($f->getPathname());
        }
        @rmdir($dir);
    }

    /** Remove stale temp files left behind by aborted requests (older than 6 h). */
    /**
     * The visitor's IP address. X-Forwarded-For is used only when the request comes from one of the
     * configured trusted_proxies (otherwise anyone could fake it to dodge the limits); the right-most
     * address in it that is not a trusted proxy is the client.
     */
    public static function clientIp(): string
    {
        static $ip = null;
        if ($ip !== null) {
            return $ip;
        }
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
        $trusted = (array)self::cfg('trusted_proxies', []);
        if ($trusted && in_array($ip, $trusted, true) && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            foreach (array_reverse(array_map('trim', explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR']))) as $hop) {
                if (filter_var($hop, FILTER_VALIDATE_IP) && !in_array($hop, $trusted, true)) {
                    $ip = $hop;
                    break;
                }
            }
        }
        return $ip;
    }

    /**
     * The public address of the public/ folder, ending with "/", e.g. https://www.net2ftp.com/.
     * Used for absolute links that leave the site: canonical and hreflang links, the sitemap, Open Graph.
     * Set 'site' => ['base_url' => …] in config.php: the address is then never taken from the request,
     * so a forged Host header can't put another domain into those links. Without it, the address is
     * derived from the request (fine for a single-domain installation).
     */
    /**
     * URL path of the public/ folder, with a trailing slash: "/" when net2ftp is the whole site, "/test/" for
     * www.example.com/test/. Cookies are limited to this path.
     */
    public static function basePath(): string
    {
        $dir = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
        return $dir . '/';
    }

    /**
     * Name of a cookie of this installation. Installations in different folders of one site (e.g. production at
     * www.example.com/ and a test version at www.example.com/test/) share the browser's cookies for that host:
     * at the root the names stay as they are ("N2FSESSID"), in a folder they get its name ("N2FSESSID_test").
     * public/assets/js/util.js derives the same suffix from the page's address.
     */
    public static function cookie(string $name): string
    {
        $p = trim(self::basePath(), '/');
        return $p === '' ? $name : $name . '_' . preg_replace('/[^A-Za-z0-9]+/', '_', $p);
    }

    /**
     * A test or staging installation that search engines must not index ('site.noindex' in config.php): every page
     * says "noindex", robots.txt disallows everything and there is no sitemap.
     */
    public static function noindex(): bool
    {
        return !empty(((array)self::cfg('site', []))['noindex']);
    }

    /** Short label shown on every page of a test installation, e.g. "TEST" ('site.label'); '' = none. */
    public static function label(): string
    {
        return mb_substr(trim((string)(((array)self::cfg('site', []))['label'] ?? '')), 0, 20);
    }

    /** Options for setcookie(): this installation's path, Secure over HTTPS, SameSite=Strict. */
    public static function cookieOptions(array $more = []): array
    {
        return $more + ['path' => self::basePath(), 'secure' => Session::isHttps(), 'samesite' => 'Strict'];
    }

    public static function baseUrl(): string
    {
        $cfg = trim((string)(((array)self::cfg('site', []))['base_url'] ?? ''));
        if ($cfg !== '' && preg_match('~^https?://~i', $cfg)) {
            return rtrim($cfg, '/') . '/';
        }
        $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? 'localhost'));
        if (!preg_match('/^[a-z0-9.\-]+(:\d{1,5})?$|^\[[0-9a-f:.]+\](:\d{1,5})?$/', $host)) {
            $host = 'localhost';
        }
        $dir = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
        return (Session::isHttps() ? 'https' : 'http') . '://' . $host . $dir . '/';
    }

    /**
     * 'full': the net2ftp.com website (login page with feature sections, and the Screenshots, Features,
     * Download, How to use and Install pages). 'reduced': for your own installation — a lightweight login
     * page and only the legal pages (privacy policy, disclaimer, abuse and GDPR forms).
     */
    public static function edition(): string
    {
        return self::cfg('edition', 'full') === 'reduced' ? 'reduced' : 'full';
    }
}

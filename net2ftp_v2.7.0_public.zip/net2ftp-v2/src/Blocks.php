<?php
declare(strict_types=1);

namespace Net2ftp;

/**
 * Block list (n2f_blocks): IP addresses / CIDR ranges and servers (with * wildcards), permanent or until
 * a date. Managed in admin.php → Blocks; automatic blocks (e.g. mass uploads) are added here too.
 */
final class Blocks
{
    /** @var array<int,array>|null active blocks, loaded once per request */
    private static ?array $active = null;

    private static function active(): array
    {
        if (self::$active !== null) {
            return self::$active;
        }
        self::$active = [];
        $pdo = Db::get();
        if (!$pdo) {
            return self::$active;
        }
        try {
            $st = $pdo->prepare('SELECT * FROM n2f_blocks WHERE expires_at IS NULL OR expires_at > ?');
            $st->execute([date('Y-m-d H:i:s')]);
            self::$active = $st->fetchAll();
        } catch (\Throwable) {
            // table not created yet (sql/upgrade-2.3.sql not run): no database blocks
        }
        return self::$active;
    }

    /** The block that matches this IP (or server), or null. */
    public static function find(string $kind, string $value): ?array
    {
        $value = strtolower(trim($value));
        if ($value === '') {
            return null;
        }
        foreach (self::active() as $b) {
            if ($b['kind'] !== $kind) {
                continue;
            }
            $hit = $kind === 'ip' ? self::ipMatches($value, (string)$b['value']) : self::serverMatches($value, (string)$b['value']);
            if ($hit) {
                try {
                    Db::get()?->prepare('UPDATE n2f_blocks SET hits = hits + 1, last_hit = ? WHERE id = ?')->execute([date('Y-m-d H:i:s'), $b['id']]);
                } catch (\Throwable) {
                }
                return $b;
            }
        }
        return null;
    }

    /** Throws UserError 403 when the visitor's IP is blocked. */
    public static function checkIp(): void
    {
        if ($b = self::find('ip', App::clientIp())) {
            SecurityLog::event('blocked', 'info', 'IP block "' . $b['value'] . '": ' . $b['reason']);
            throw new UserError(self::message($b), 403);
        }
    }

    /** Throws UserError 403 when the server is blocked. */
    public static function checkServer(string $host): void
    {
        if ($b = self::find('server', $host)) {
            SecurityLog::event('blocked', 'info', 'Server block "' . $b['value'] . '": ' . $b['reason'], $host);
            throw new UserError('The server {host} is not allowed on this installation.', 403, ['host' => $host]);
        }
    }

    public static function message(array $b): string
    {
        $site = (array)App::cfg('site', []);
        $contact = (string)($site['abuse_email'] ?? $site['email'] ?? '');
        return $b['expires_at']
            ? I18n::t('Access from your address is blocked until {date}.', ['date' => substr((string)$b['expires_at'], 0, 16)])
                . ($contact !== '' ? ' ' . I18n::t('Questions: {email}', ['email' => $contact]) : '')
            : I18n::t('Access from your address is blocked.') . ($contact !== '' ? ' ' . I18n::t('Questions: {email}', ['email' => $contact]) : '');
    }

    /** Add or replace a block. $hours = 0 → permanent. */
    public static function add(string $kind, string $value, string $reason, int $hours, string $by): void
    {
        $value = strtolower(trim($value));
        if (!in_array($kind, ['ip', 'server'], true) || !self::valid($kind, $value)) {
            throw new UserError('Invalid IP address, range or server name.');
        }
        $pdo = Db::get() ?? throw new UserError('The database is not available.', 503);
        $exp = $hours > 0 ? date('Y-m-d H:i:s', time() + $hours * 3600) : null;
        $pdo->prepare('DELETE FROM n2f_blocks WHERE kind = ? AND value = ?')->execute([$kind, $value]);
        $pdo->prepare('INSERT INTO n2f_blocks (kind, value, reason, created_at, expires_at, created_by) VALUES (?,?,?,?,?,?)')
            ->execute([$kind, $value, mb_substr($reason, 0, 255), date('Y-m-d H:i:s'), $exp, $by]);
        self::$active = null;
    }

    public static function valid(string $kind, string $value): bool
    {
        if ($kind === 'server') {
            return (bool)preg_match('/^[a-z0-9.*\-:\[\]_]{1,255}$/', $value);
        }
        [$ip, $bits] = array_pad(explode('/', $value, 2), 2, null);
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            return false;
        }
        $max = str_contains($ip, ':') ? 128 : 32;
        return $bits === null || (preg_match('/^\d+$/', (string)$bits) && (int)$bits >= 8 && (int)$bits <= $max);
    }

    public static function ipMatches(string $ip, string $rule): bool
    {
        [$net, $bits] = array_pad(explode('/', $rule, 2), 2, null);
        $a = @inet_pton($ip);
        $b = @inet_pton($net);
        if ($a === false || $b === false || strlen($a) !== strlen($b)) {
            return false;
        }
        $bits = $bits === null ? strlen($a) * 8 : (int)$bits;
        $bytes = intdiv($bits, 8);
        if (substr($a, 0, $bytes) !== substr($b, 0, $bytes)) {
            return false;
        }
        $rest = $bits % 8;
        if ($rest === 0) {
            return true;
        }
        $mask = (0xFF << (8 - $rest)) & 0xFF;
        return (ord($a[$bytes]) & $mask) === (ord($b[$bytes]) & $mask);
    }

    private static function serverMatches(string $host, string $pattern): bool
    {
        return (bool)preg_match('/^' . str_replace('\*', '.*', preg_quote($pattern, '/')) . '$/', $host);
    }
}

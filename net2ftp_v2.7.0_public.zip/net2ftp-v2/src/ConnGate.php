<?php
declare(strict_types=1);

namespace Net2ftp;

/**
 * At most N connections at a time to one FTP/SFTP account (server + port + user), for all of that account's
 * net2ftp sessions together. Many servers refuse a second login of the same user ("421 Too many
 * connections"); instead of failing, extra requests wait in line for a free connection.
 *
 * N is `connections_per_server` (default 4). When a server refuses a connection as "too many", net2ftp
 * learns the real limit (the number of connections it had open at that moment) and keeps it for a day.
 * Background jobs never take the last connection, so browsing keeps working while a job runs.
 *
 * Slots are file locks (see Limiter), released automatically when the request ends.
 * S3 is plain HTTPS without logins and is not limited here.
 */
final class ConnGate
{
    private const LEARN_TTL = 86400;

    /** Account key of a connection (no secrets; keyed hash so the file names reveal nothing). */
    public static function key(array $params): string
    {
        return substr(Session::mac('conn|' . strtolower((string)($params['protocol'] ?? '')) . '|' . strtolower((string)($params['host'] ?? ''))
            . '|' . (int)($params['port'] ?? 0) . '|' . (string)($params['username'] ?? '')), 0, 32);
    }

    /** Key of the account for any protocol (S3 included): owner of resumable uploads and jobs. */
    public static function account(array $params): string
    {
        if (($params['protocol'] ?? '') === 's3') {
            return substr(Session::mac('s3|' . ($params['accessKey'] ?? '') . '|' . strtolower((string)($params['endpoint'] ?? ''))
                . '|' . ($params['region'] ?? '') . '|' . ($params['bucket'] ?? '')), 0, 32);
        }
        return self::key($params);
    }

    public static function applies(array $params): bool
    {
        return in_array($params['protocol'] ?? '', ['ftp', 'sftp'], true);
    }

    public static function configured(): int
    {
        return max(1, (int)App::cfg('connections_per_server', 4));
    }

    /** Connections net2ftp may open to this account at once: configured, or less if the server said so. */
    public static function limit(string $key): int
    {
        $f = self::learnFile($key);
        $max = self::configured();
        if ($f !== null && is_file($f)) {
            $d = json_decode((string)@file_get_contents($f), true);
            if (is_array($d) && (int)($d['until'] ?? 0) > time()) {
                return max(1, min($max, (int)($d['limit'] ?? $max)));
            }
        }
        return $max;
    }

    /** Connections a background job may use: all but one (browsing keeps one), at least one. */
    public static function jobLimit(string $key): int
    {
        return max(1, self::limit($key) - 1);
    }

    /**
     * Take a connection slot for this request, waiting in line up to $wait seconds.
     * $holder distinguishes several connections of one request ("", "2"…).
     */
    public static function enter(string $key, float $wait = -1, string $holder = '', bool $job = false): void
    {
        $wait = $wait < 0 ? (float)Limiter::cfg('queue_seconds', 20) : $wait;
        if ($job && !Limiter::acquire('conn-job:' . $key, self::jobLimit($key), $wait, $holder)) {
            throw self::busyError($key);
        }
        if (!Limiter::acquire('conn:' . $key, self::limit($key), $wait, $holder)) {
            if ($job) {
                Limiter::release('conn-job:' . $key, $holder);
            }
            throw self::busyError($key);
        }
    }

    /** A second connection for a job, only if one is free right now (then a copy can stream between two). */
    public static function tryExtra(string $key, string $holder): bool
    {
        if (!Limiter::acquire('conn-job:' . $key, self::jobLimit($key), 0, $holder)) {
            return false;
        }
        if (!Limiter::acquire('conn:' . $key, self::limit($key), 0, $holder)) {
            Limiter::release('conn-job:' . $key, $holder);
            return false;
        }
        return true;
    }

    public static function leave(string $key, string $holder = ''): void
    {
        Limiter::release('conn:' . $key, $holder);
        Limiter::release('conn-job:' . $key, $holder);
    }

    /** The server refused a connection as "too many": remember how many it accepts. Returns the new limit. */
    public static function learn(string $key): int
    {
        $limit = self::limit($key);
        // connections open right now, this request's refused one included
        $open = Limiter::busy('conn:' . $key, $limit);
        $new = max(1, min($limit, $open - 1));
        $f = self::learnFile($key);
        if ($f !== null) {
            @file_put_contents($f, json_encode(['limit' => $new, 'until' => time() + self::LEARN_TTL]), LOCK_EX);
        }
        if ($new < $limit) {
            SecurityLog::event('connection-limit', 'info', "Server allows only $new connection(s) per user; net2ftp now opens at most $new", (string)(Session::meta()['server'] ?? ''));
        }
        return $new;
    }

    /** Does this server message mean "you have too many connections open"? */
    public static function isTooMany(string $message): bool
    {
        if (preg_match('/authentication failures|too many (failed|login|auth)/i', $message)) {
            return false;   // wrong passwords, not a connection limit
        }
        return (bool)preg_match('/\b421\b|too many (connections|users|clients|sessions|connected)|maximum (number of )?(connections|sessions|clients|users)'
            . '|(connection|session|login|client)s? limit|limit of \d+ (connections|sessions)|already logged in|max(imum)? ?(connections|sessions) (reached|exceeded)'
            . '|too many from your|no more connections|server is full/i', $message);
    }

    private static function busyError(string $key): UserError
    {
        $n = self::limit($key);
        if ($n === 1) {
            return new UserError('This server allows only one connection at a time, and it is busy (a transfer is running). Please try again in a moment.', 429);
        }
        return new UserError('All {n} connections this server allows are busy (transfers are running). Please try again in a moment.', 429, ['n' => $n]);
    }

    private static function learnFile(string $key): ?string
    {
        $d = App::tmpDir() . '/limits/conn';
        if (!is_dir($d) && !@mkdir($d, 0700, true) && !is_dir($d)) {
            return null;
        }
        return $d . '/' . $key . '.json';
    }
}

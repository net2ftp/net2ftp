<?php
declare(strict_types=1);

namespace Net2ftp;

use PDO;

/** Lazy PDO connection. Returns null when the database is not configured or unreachable. */
final class Db
{
    private static ?PDO $pdo = null;
    private static bool $failed = false;
    private static string $lastError = '';

    public static function lastError(): string
    {
        return self::$lastError;
    }

    public static function get(): ?PDO
    {
        if (self::$pdo || self::$failed) {
            return self::$pdo;
        }
        $cfg = App::cfg('db', []);
        if (empty($cfg['dsn']) || !class_exists('PDO')) {
            self::$failed = true;
            self::$lastError = empty($cfg['dsn']) ? 'no dsn' : 'could not find driver (PDO missing)';
            return null;
        }
        try {
            self::$pdo = new PDO($cfg['dsn'], $cfg['user'] ?? null, $cfg['password'] ?? null, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_TIMEOUT            => 5,
            ]);
        } catch (\Throwable $e) {
            self::$failed = true;
            self::$lastError = $e->getMessage();
            error_log('net2ftp: database connection failed: ' . $e->getMessage());
        }
        return self::$pdo;
    }

    public static function isMysql(): bool
    {
        $pdo = self::get();
        return $pdo !== null && $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql';
    }
}

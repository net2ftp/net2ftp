<?php
declare(strict_types=1);

namespace Net2ftp;

/**
 * Disk space on the web server per visitor IP address ('disk_quota' in config.php).
 *
 * Two things can stay on the web server's disk for days:
 *  - uploads collected on the web server ("local" mode: small S3 uploads, servers that refuse appending),
 *    kept up to Uploads::KEEP_DAYS so they can be continued;
 *  - share links (copies of the shared files), kept until they expire.
 * Without a limit per address, one visitor could fill the disk for everyone. Zip downloads and archive
 * extraction are temporary (deleted when the request ends) and limited by max_zip_bytes and the "heavy" slots.
 *
 * IPv6 addresses count per /64: one connection usually gets a whole /64, so single addresses are free to vary.
 */
final class DiskQuota
{
    public static function cfg(string $key): int
    {
        $c = (array)App::cfg('disk_quota', []);
        return (int)($c[$key] ?? ['ip_upload_bytes' => 2 << 30, 'ip_share_bytes' => 2 << 30][$key] ?? 0);
    }

    /** The address as counted: IPv4 as is, IPv6 as its /64 network ("2001:db8:1:2::/64"). */
    public static function network(?string $ip = null): string
    {
        $ip = $ip ?? App::clientIp();
        if (preg_match('/^::ffff:(\d+\.\d+\.\d+\.\d+)$/i', $ip, $m)) {
            return $m[1];
        }
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $bin = (string)inet_pton($ip);
            return inet_ntop(substr($bin, 0, 8) . str_repeat("\0", 8)) . '/64';
        }
        return $ip;
    }

    /** Pseudonymous key of the address, stored with upload states (no IP address in clear text in tmp_dir). */
    public static function key(?string $ip = null): string
    {
        return substr(Session::mac('disk-ip|' . self::network($ip)), 0, 24);
    }

    // ------------------------------------------------------------------ uploads collected on the web server

    /** Bytes reserved by unfinished "local" uploads of this address (their full size, from all sessions and accounts). */
    public static function uploadBytes(string $key): int
    {
        $sum = 0;
        $old = time() - Uploads::KEEP_DAYS * 86400;
        foreach (glob(App::tmpDir() . '/uploads/*/*.json') ?: [] as $f) {
            $st = json_decode((string)@file_get_contents($f), true);
            if (is_array($st) && ($st['mode'] ?? '') === 'local' && ($st['ip'] ?? '') === $key && (int)($st['updated'] ?? 0) >= $old) {
                $sum += (int)($st['size'] ?? 0);
            }
        }
        return $sum;
    }

    /**
     * Before an upload starts (or switches) to being collected on the web server: refuse it when this address
     * would then reserve more than ip_upload_bytes. $exceptFile: the upload's own state file, not counted twice.
     */
    public static function checkUpload(int $size, string $exceptFile = ''): void
    {
        $max = self::cfg('ip_upload_bytes');
        if ($max <= 0) {
            return;
        }
        $key = self::key();
        $used = self::uploadBytes($key);
        if ($exceptFile !== '' && is_file($exceptFile)) {
            $st = json_decode((string)@file_get_contents($exceptFile), true);
            if (is_array($st) && ($st['mode'] ?? '') === 'local' && ($st['ip'] ?? '') === $key) {
                $used -= (int)($st['size'] ?? 0);
            }
        }
        if ($used + $size > $max) {
            SecurityLog::event('disk-quota', 'info', 'Upload refused: ' . FileOps::human($used) . ' of ' . FileOps::human($max)
                . ' of temporary upload space in use by this address');
            throw new UserError('Your unfinished uploads already use {used} of the {max} this site keeps per visitor. Finish or discard them first (they are listed after login), or wait until they expire.', 507,
                ['used' => FileOps::human($used), 'max' => FileOps::human($max)]);
        }
    }

    // ------------------------------------------------------------------ share links

    /** Bytes of the active share links created from this address. */
    public static function shareBytes(?string $ip = null): int
    {
        $net = self::network($ip);
        $sum = 0;
        foreach (Shares::all() as $m) {
            if (isset($m['creatorIp']) && self::network((string)$m['creatorIp']) === $net && !Shares::isExpired($m)) {
                $sum += (int)$m['bytes'];
            }
        }
        return $sum;
    }

    /** Space left for share links of this address; PHP_INT_MAX when there is no limit. */
    public static function shareRoom(): int
    {
        $max = self::cfg('ip_share_bytes');
        return $max > 0 ? $max - self::shareBytes() : PHP_INT_MAX;
    }
}

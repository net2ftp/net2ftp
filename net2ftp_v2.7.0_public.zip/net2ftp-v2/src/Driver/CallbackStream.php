<?php
declare(strict_types=1);

namespace Net2ftp\Driver;

/**
 * A PHP stream backed by two callbacks, so functions that only take a stream or a file name
 * (ftp_fget, ftp_fput, ftp_append) can stream data to and from anywhere without a temporary file.
 *
 *   read:  fn(int $max): ?string   — next piece of data, or null / '' at the end
 *   write: fn(string $data): mixed — receives each piece; return false to ask the caller to stop
 *
 * Streams are opened as "n2fcb://<id>"; the callbacks are kept in a static registry under that id.
 */
final class CallbackStream
{
    /** @var array<string,array{read:?callable,write:?callable}> */
    private static array $registry = [];
    private static bool $registered = false;

    /** @var resource|null set by PHP */
    public $context;
    private string $id = '';
    private bool $eof = false;
    private int $pos = 0;

    /** URL of a new callback stream (for functions that open a "file name" themselves, like ftp_append). */
    public static function url(?callable $read, ?callable $write = null): string
    {
        if (!self::$registered) {
            if (in_array('n2fcb', stream_get_wrappers(), true)) {
                stream_wrapper_unregister('n2fcb');
            }
            stream_wrapper_register('n2fcb', self::class);
            self::$registered = true;
        }
        $id = bin2hex(random_bytes(8));
        self::$registry[$id] = ['read' => $read, 'write' => $write];
        return 'n2fcb://' . $id;
    }

    /** @return resource */
    public static function open(?callable $read, ?callable $write = null)
    {
        $fp = fopen(self::url($read, $write), $read !== null ? 'rb' : 'wb');
        if ($fp === false) {
            throw new \RuntimeException('Could not open a callback stream.');
        }
        // no read-ahead: a callback must not be asked for more than the caller reads
        stream_set_read_buffer($fp, 0);
        stream_set_write_buffer($fp, 0);
        return $fp;
    }

    public static function forget(string $url): void
    {
        unset(self::$registry[substr($url, 8)]);
    }

    // ---- stream wrapper protocol ----

    public function stream_open(string $path, string $mode, int $options, ?string &$opened): bool
    {
        $this->id = substr($path, 8);
        return isset(self::$registry[$this->id]);
    }

    public function stream_read(int $count): string|false
    {
        $cb = self::$registry[$this->id]['read'] ?? null;
        if ($this->eof || $cb === null) {
            $this->eof = true;
            return '';
        }
        $d = $cb($count);
        if ($d === null || $d === '' || $d === false) {
            $this->eof = true;
            return '';
        }
        $this->pos += strlen((string)$d);
        return (string)$d;
    }

    public function stream_write(string $data): int
    {
        $cb = self::$registry[$this->id]['write'] ?? null;
        if ($cb !== null) {
            $cb($data);
        }
        $this->pos += strlen($data);
        return strlen($data);
    }

    /**
     * ext/ftp seeks the local stream to the resume position before a ranged download (REST): the callback
     * only sees the bytes that follow, so seeking just moves the reported position.
     */
    public function stream_seek(int $offset, int $whence = SEEK_SET): bool
    {
        if ($whence === SEEK_SET) {
            $this->pos = $offset;
        } elseif ($whence === SEEK_CUR) {
            $this->pos += $offset;
        }
        return true;
    }

    public function stream_tell(): int
    {
        return $this->pos;
    }

    public function stream_eof(): bool
    {
        return $this->eof;
    }

    public function stream_stat(): array
    {
        return [];
    }

    public function url_stat(string $path, int $flags): array|false
    {
        return isset(self::$registry[substr($path, 8)]) ? ['size' => 0, 'mode' => 0100644] : false;
    }

    public function stream_flush(): bool
    {
        return true;
    }

    public function stream_close(): void
    {
        unset(self::$registry[$this->id]);
    }

    public function stream_set_option(int $option, int $arg1, ?int $arg2): bool
    {
        return false;
    }
}

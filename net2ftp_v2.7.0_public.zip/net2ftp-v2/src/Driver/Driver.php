<?php
declare(strict_types=1);

namespace Net2ftp\Driver;

/**
 * Common interface for remote file systems (FTP, SFTP, S3).
 *
 * Entries returned by listDir()/stat() are arrays:
 *   ['name'=>string, 'type'=>'dir'|'file'|'link', 'size'=>int, 'mtime'=>?int,
 *    'perms'=>?string, 'owner'=>?string, 'group'=>?string, 'target'=>?string, 'isDir'=>bool]
 * 'isDir' is true for directories and for links that point to directories.
 */
interface Driver
{
    public function connect(): void;

    public function close(): void;

    /** Directory shown after login. */
    public function home(): string;

    /** @return array<int,array> */
    public function listDir(string $dir): array;

    /** Entry info, or null when the path does not exist. */
    public function stat(string $path): ?array;

    /** Download a remote file into a local file. */
    public function get(string $remote, string $localFile): void;

    /** Upload a local file to a remote path (overwrites). */
    public function put(string $localFile, string $remote): void;

    /**
     * Stream a remote file into $sink(string $data), starting at byte $offset, at most $length bytes (-1 = to the end),
     * without a temporary file. $sink may return false to stop early. Returns the number of bytes delivered.
     */
    public function readStream(string $remote, callable $sink, int $offset = 0, int $length = -1): int;

    /**
     * Write $source(int $max): ?string (null or '' = end) to a remote file. $offset 0 creates or overwrites it;
     * $offset > 0 continues a file that is exactly $offset bytes long (resume). Returns the bytes written.
     */
    public function writeStream(string $remote, callable $source, int $offset = 0): int;

    public function mkdir(string $path): void;

    /** Remove an EMPTY directory. */
    public function rmdir(string $path): void;

    public function deleteFile(string $path): void;

    /** Rename/move within the same server. Return false if the driver cannot do it natively (caller falls back to copy+delete). */
    public function rename(string $from, string $to, bool $isDir): bool;

    /** Server-side file copy. Return false if unsupported (caller falls back to download+upload). */
    public function copyFile(string $from, string $to): bool;

    /** Change permission bits (e.g. 0755). Throws UserError when the protocol cannot do it. */
    public function chmod(string $path, int $mode): void;

    /** Change owner and/or group (numeric ids; null = unchanged). Throws UserError when unsupported. */
    public function chown(string $path, ?int $uid, ?int $gid): void;

    /** Protocol id used in logs: ftp, ftps, sftp, s3 */
    public function protocol(): string;

    /** Feature flags for the UI, e.g. ['exec'=>true] */
    public function features(): array;
}

<?php
declare(strict_types=1);

namespace Net2ftp\Driver;

use FTP\Connection;
use Net2ftp\App;
use Net2ftp\ConnGate;
use Net2ftp\TooManyConnections;
use Net2ftp\Path;
use Net2ftp\UserError;

/** FTP and explicit FTPS (FTP over TLS) using PHP's ext-ftp. */
final class FtpDriver implements Driver
{
    private ?Connection $c = null;
    private ?string $home = null;

    public function __construct(
        private string $host,
        private int $port,
        private string $user,
        private string $pass,
        private bool $passive = true,
        private bool $ssl = false,
        private ?string $address = null,   // the IP address checked at login (DNS rebinding); null = resolve $host
    ) {
    }

    public function protocol(): string
    {
        return $this->ssl ? 'ftps' : 'ftp';
    }

    public function features(): array
    {
        return ['exec' => false, 'serverCopy' => false, 'chmod' => true, 'chown' => false, 'extract' => true];
    }

    public function connect(): void
    {
        $timeout = (int)App::cfg('ftp_timeout', 20);
        for ($attempt = 0; ; $attempt++) {
            $cmsg = '';
            try {
                $c = $this->ssl
                    ? ftp_ssl_connect($this->address ?? $this->host, $this->port, $timeout)
                    : ftp_connect($this->address ?? $this->host, $this->port, $timeout);
            } catch (\Throwable $e) {
                $c = false;
                $cmsg = self::clean($e->getMessage());
            }
            if ($c || $attempt > 0) {
                break;
            }
            // PHP does not say why: a server at its connection limit answers "421 Too many connections" at once
            $why = $cmsg !== '' ? $cmsg : self::greeting($this->address ?? $this->host, $this->port);
            if (ConnGate::isTooMany($why)) {
                throw new TooManyConnections($why);
            }
            if (!str_starts_with($why, '220')) {
                break;          // really unreachable
            }
            // the server welcomes us now (a connection was freed meanwhile): try once more
        }
        if (!$c) {
            throw new UserError($this->ssl
                ? 'Could not connect to {server}. Check the server name and port, and that the server supports FTP over TLS.'
                : 'Could not connect to {server}. Check the server name and port.', 400, ['server' => "{$this->host}:{$this->port}"]);
        }
        try {
            $ok = ftp_login($c, $this->user === '' ? 'anonymous' : $this->user, $this->pass);
        } catch (\Throwable $e) {
            $ok = false;
            $msg = $e->getMessage();
        }
        if (!$ok) {
            @ftp_close($c);
            $detail = isset($msg) ? (string)preg_replace('/^ftp_login\(\): /', '', $msg) : '';
            if (ConnGate::isTooMany($detail)) {
                throw new TooManyConnections($detail);   // e.g. "530 Maximum number of connections reached"
            }
            throw new UserError('Login failed: wrong user name or password.', 401, [], $detail);
        }
        if (defined('FTP_USEPASVADDRESS')) {
            @ftp_set_option($c, FTP_USEPASVADDRESS, (bool)App::cfg('ftp_use_pasv_address', false));
        }
        // Passive mode sends PASV/EPSV right away. Some servers (or a firewall in front of them) never answer it:
        // report that as a user error that suggests active mode, not as an internal server error.
        $pmsg = '';
        try {
            $pok = ftp_pasv($c, $this->passive);
        } catch (\Throwable $e) {
            $pok = false;
            $pmsg = self::clean($e->getMessage());
        }
        if (!$pok) {
            @ftp_close($c);
            throw new UserError('{server} did not answer the request for passive mode. Log in again with passive mode turned off.',
                502, ['server' => "{$this->host}:{$this->port}"], $pmsg);
        }
        // Ask for Unix permissions/owner in MLSD listings (servers ignore facts they do not know)
        try {
            @ftp_raw($c, 'OPTS MLST type;size;modify;perm;unix.mode;unix.owner;unix.group;unix.uid;unix.gid;');
        } catch (\Throwable) {
        }
        @ftp_set_option($c, FTP_TIMEOUT_SEC, (int)App::cfg('ftp_timeout', 20) * 3);
        $this->c = $c;
    }

    public function close(): void
    {
        if ($this->c) {
            try {
                ftp_close($this->c);
            } catch (\Throwable) {
            }
            $this->c = null;
        }
    }

    public function home(): string
    {
        if ($this->home === null) {
            try {
                $pwd = ftp_pwd($this->conn());
            } catch (\Throwable) {
                $pwd = '/';
            }
            $this->home = Path::normalize($pwd ?: '/');
        }
        return $this->home;
    }

    public function listDir(string $dir): array
    {
        $c = $this->conn();
        $dir = Path::normalize($dir);
        $this->chdir($dir);

        // 1) MLSD gives machine-readable facts (RFC 3659)
        $rows = null;
        try {
            $rows = ftp_mlsd($c, '.');
        } catch (\Throwable) {
            $rows = null;
        }
        if (is_array($rows) && $rows !== []) {
            return $this->fromMlsd($rows, $dir);
        }

        // 2) LIST fallback (Unix and Windows/IIS formats)
        $raw = null;
        foreach (['-a', '.', ''] as $arg) {
            try {
                $raw = $arg === '' ? ftp_rawlist($c, '') : ftp_rawlist($c, $arg);
            } catch (\Throwable) {
                $raw = false;
            }
            if (is_array($raw) && ($raw !== [] || $arg === '')) {
                break;
            }
        }
        if (!is_array($raw)) {
            throw new UserError('Could not list the directory {path}.', 400, ['path' => $dir]);
        }
        return $this->fromRawList($raw, $dir);
    }

    public function stat(string $path): ?array
    {
        $path = Path::normalize($path);
        if ($path === '/') {
            return ['name' => '/', 'type' => 'dir', 'isDir' => true, 'size' => 0, 'mtime' => null];
        }
        $c = $this->conn();
        // Directory?
        try {
            $cwd = ftp_pwd($c);
            if (@ftp_chdir($c, $path)) {
                @ftp_chdir($c, $cwd ?: '/');
                return ['name' => Path::basename($path), 'type' => 'dir', 'isDir' => true, 'size' => 0, 'mtime' => null];
            }
        } catch (\Throwable) {
        }
        try {
            $size = ftp_size($c, $path);
        } catch (\Throwable) {
            $size = -1;
        }
        if ($size >= 0) {
            $mtime = null;
            try {
                $m = ftp_mdtm($c, $path);
                $mtime = $m > 0 ? $m : null;
            } catch (\Throwable) {
            }
            return ['name' => Path::basename($path), 'type' => 'file', 'isDir' => false, 'size' => $size, 'mtime' => $mtime];
        }
        // Some servers do not support SIZE: look the entry up in its parent listing.
        try {
            foreach ($this->listDir(Path::parent($path)) as $e) {
                if ($e['name'] === Path::basename($path)) {
                    return $e;
                }
            }
        } catch (\Throwable) {
        }
        return null;
    }

    public function get(string $remote, string $localFile): void
    {
        try {
            $ok = ftp_get($this->conn(), $localFile, $remote, FTP_BINARY);
        } catch (\Throwable $e) {
            $this->abandon();
            throw new UserError('Could not download {path}.', 400, ['path' => $remote], self::clean($e->getMessage()));
        }
        if (!$ok) {
            $this->abandon();
            throw new UserError('Could not download {path}.', 400, ['path' => $remote]);
        }
    }

    public function put(string $localFile, string $remote): void
    {
        try {
            $ok = ftp_put($this->conn(), $remote, $localFile, FTP_BINARY);
        } catch (\Throwable $e) {
            $this->abandon();
            throw new UserError('Could not upload to {path}.', 400, ['path' => $remote], self::clean($e->getMessage()));
        }
        if (!$ok) {
            $this->abandon();
            throw new UserError('Could not upload to {path}.', 400, ['path' => $remote]);
        }
    }

    /**
     * Stream $remote (from byte $offset, at most $length bytes, -1 = to the end) into $sink(string): no temp file.
     * $sink may return false to stop early. Returns the number of bytes delivered.
     */
    public function readStream(string $remote, callable $sink, int $offset = 0, int $length = -1): int
    {
        $got = 0;
        $stop = false;
        $skip = 0;
        $fp = CallbackStream::open(null, function (string $d) use (&$got, &$stop, &$skip, $length, $sink) {
            if ($stop) {
                return;
            }
            if ($skip > 0) {                       // server without REST: throw away the bytes before $offset
                $cut = min($skip, strlen($d));
                $skip -= $cut;
                $d = substr($d, $cut);
            }
            if ($length >= 0 && $got + strlen($d) > $length) {
                $d = substr($d, 0, $length - $got);
            }
            if ($d !== '') {
                $got += strlen($d);
                if ($sink($d) === false) {
                    $stop = true;
                }
            }
            if ($length >= 0 && $got >= $length) {
                $stop = true;
            }
        });
        try {
            $c = $this->conn();
            // "@": in non-blocking mode PHP warns "Connection timed out" whenever no data came for a second,
            // although the transfer simply continues; real failures are reported as FTP_FAILED.
            $r = @ftp_nb_fget($c, $fp, $remote, FTP_BINARY, $offset);
            if ($r === FTP_FAILED) {
                $err = (string)(error_get_last()['message'] ?? '');
            }
            if ($r === FTP_FAILED && $offset > 0 && $got === 0) {
                // REST not supported: read from the start and skip (on a fresh connection, see abandon())
                $skip = $offset;
                $this->abandon();
                $c = $this->conn();
                $r = @ftp_nb_fget($c, $fp, $remote, FTP_BINARY, 0);
            }
            $idle = microtime(true);
            $seen = 0;
            $limit = (int)App::cfg('ftp_timeout', 20) * 3;
            while ($r === FTP_MOREDATA && !$stop) {
                $r = @ftp_nb_continue($c);
                if ($got !== $seen) {
                    $seen = $got;
                    $idle = microtime(true);
                } elseif (microtime(true) - $idle > $limit) {
                    $this->abandon();
                    throw new UserError('Could not download {path}.', 400, ['path' => $remote], 'no data for ' . $limit . ' s');
                }
            }
            if ($r === FTP_FAILED && !isset($err)) {
                $err = (string)(error_get_last()['message'] ?? '');
            }
        } catch (\Throwable $e) {
            $this->abandon();
            throw new UserError('Could not download {path}.', 400, ['path' => $remote], self::clean($e->getMessage()));
        } finally {
            fclose($fp);
        }
        if ($r === FTP_MOREDATA) {
            $this->abandon();                      // stopped in the middle of a transfer: this connection is unusable
        } elseif ($r === FTP_FAILED && !$stop) {
            $this->abandon();
            throw new UserError('Could not download {path}.', 400, ['path' => $remote], isset($err) ? self::clean($err) : '');
        }
        return $got;
    }

    /**
     * Write data from $source(int $max): ?string (null = end) to $remote. $offset 0 creates/overwrites the file;
     * $offset > 0 appends to a file that is exactly $offset bytes long (resume). Returns the bytes written.
     */
    public function writeStream(string $remote, callable $source, int $offset = 0): int
    {
        $sent = 0;
        $src = function (int $max) use ($source, &$sent): ?string {
            $d = $source($max);
            if ($d === null || $d === '') {
                return null;
            }
            $sent += strlen($d);
            return $d;
        };
        $c = $this->conn();
        try {
            if ($offset === 0) {
                $fp = CallbackStream::open($src);
                try {
                    $ok = ftp_fput($c, $remote, $fp, FTP_BINARY);
                } finally {
                    fclose($fp);
                }
            } else {
                // APPE is supported almost everywhere; REST + STOR is the fallback
                $url = CallbackStream::url($src);
                try {
                    $ok = @ftp_append($c, $remote, $url, FTP_BINARY);
                } finally {
                    CallbackStream::forget($url);
                }
                if (!$ok && $sent === 0) {
                    // the failed APPE may still answer later (e.g. after a timeout): REST + STOR on a fresh connection
                    $this->abandon();
                    $c = $this->conn();
                    $fp = CallbackStream::open($src);
                    try {
                        $ok = ftp_fput($c, $remote, $fp, FTP_BINARY, $offset);
                    } finally {
                        fclose($fp);
                    }
                }
            }
        } catch (\Throwable $e) {
            $this->abandon();
            throw new UserError('Could not upload to {path}.', 400, ['path' => $remote], self::clean($e->getMessage()));
        }
        if (!$ok) {
            $this->abandon();
        }
        if (!$ok && $offset > 0) {
            throw new UserError('The server does not allow resuming (appending to) {path}.', 400, ['path' => $remote]);
        }
        if (!$ok) {
            throw new UserError('Could not upload to {path}.', 400, ['path' => $remote]);
        }
        return $sent;
    }

    /**
     * Drop a connection that is in the middle of a transfer, or after a transfer failed; the next call reconnects.
     * After a failure (above all a timeout) the server may still send the answer to the failed command later; on
     * the same connection it would be read as the answer to the next command ("Could not rename … (Entering
     * Passive Mode …)", seen with ftp.dlptest.com). A fresh connection can't get out of step.
     * Not ftp_close(): it sends QUIT and waits for the reply, which the server only sends after it has finished
     * pushing the rest of the file — up to the full timeout (60 s) with Windows servers. Freeing the connection
     * object closes the sockets at once without QUIT.
     */
    private function abandon(): void
    {
        $this->c = null;
    }

    public function mkdir(string $path): void
    {
        $this->wrap(fn() => ftp_mkdir($this->conn(), $path), 'Could not create the folder {path}.', $path);
    }

    public function rmdir(string $path): void
    {
        $this->chdir('/');
        $this->wrap(fn() => ftp_rmdir($this->conn(), $path), 'Could not delete the folder {path}.', $path);
    }

    public function deleteFile(string $path): void
    {
        $this->wrap(fn() => ftp_delete($this->conn(), $path), 'Could not delete {path}.', $path);
    }

    public function rename(string $from, string $to, bool $isDir): bool
    {
        $this->wrap(fn() => ftp_rename($this->conn(), $from, $to), 'Could not rename {path}.', $from);
        return true;
    }

    public function copyFile(string $from, string $to): bool
    {
        return false; // FTP has no server-side copy
    }

    public function chmod(string $path, int $mode): void
    {
        // SITE CHMOD: supported by nearly all Unix FTP servers; Windows/IIS servers usually refuse it
        // always 3/4 octal digits: ftp_chmod() would send "SITE CHMOD 0 …" for 000, which servers reject
        $this->wrap(fn() => ftp_site($this->conn(), sprintf('CHMOD %03o %s', $mode, $path)), 'Could not change the permissions of {path}.', $path);
    }

    public function chown(string $path, ?int $uid, ?int $gid): void
    {
        throw new UserError('Changing the owner is not possible over FTP. Use SFTP/SSH instead.', 400);
    }

    // ------------------------------------------------------------------

    private function conn(): Connection
    {
        if (!$this->c) {
            $this->connect();
        }
        return $this->c;
    }

    private function chdir(string $dir): void
    {
        try {
            $ok = ftp_chdir($this->conn(), $dir);
        } catch (\Throwable $e) {
            $ok = false;
        }
        if (!$ok) {
            throw new UserError('The directory {path} does not exist or cannot be opened.', 404, ['path' => $dir]);
        }
    }

    private function wrap(callable $fn, string $template, string $path): void
    {
        try {
            $ok = $fn();
        } catch (\Throwable $e) {
            throw new UserError($template, 400, ['path' => $path], self::clean($e->getMessage()));
        }
        if ($ok === false) {
            throw new UserError($template, 400, ['path' => $path]);
        }
    }

    /** First line the server sends (used only to explain a failed connection). */
    private static function greeting(string $host, int $port): string
    {
        try {
            $fp = @fsockopen($host, $port, $errno, $errstr, 5);
            if (!$fp) {
                return '';
            }
            stream_set_timeout($fp, 5);
            $line = (string)fgets($fp, 512);
            fclose($fp);
            return trim($line);
        } catch (\Throwable) {
            return '';
        }
    }

    private static function clean(string $msg): string
    {
        return preg_replace('/^ftp_\w+\(\):\s*/', '', $msg) ?? $msg;
    }

    private function fromMlsd(array $rows, string $dir): array
    {
        $out = [];
        foreach ($rows as $r) {
            $name = $r['name'] ?? '';
            $type = strtolower($r['type'] ?? 'file');
            if ($name === '' || $name === '.' || $name === '..' || $type === 'cdir' || $type === 'pdir') {
                continue;
            }
            $isLink = str_contains($type, 'slink') || str_contains($type, 'symlink');
            $isDir = $type === 'dir';
            $mtime = null;
            if (!empty($r['modify']) && preg_match('/^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)/', $r['modify'], $m)) {
                $mtime = gmmktime((int)$m[4], (int)$m[5], (int)$m[6], (int)$m[2], (int)$m[3], (int)$m[1]);
            }
            $mode = $r['unix.mode'] ?? $r['UNIX.mode'] ?? null;
            $entry = [
                'name'  => $name,
                'type'  => $isLink ? 'link' : ($isDir ? 'dir' : 'file'),
                'isDir' => $isDir,
                'size'  => (int)($r['size'] ?? $r['sizd'] ?? 0),
                'mtime' => $mtime,
                'perms' => $mode !== null ? self::modeToString(octdec((string)$mode), $isDir, $isLink) : null,
                'owner' => $r['unix.owner'] ?? $r['UNIX.owner'] ?? $r['unix.uid'] ?? null,
                'group' => $r['unix.group'] ?? $r['UNIX.group'] ?? $r['unix.gid'] ?? null,
                'target' => null,
            ];
            if ($isLink) {
                $entry['isDir'] = $this->isDirQuick(Path::join($dir, $name));
            }
            $out[] = $entry;
        }
        return $out;
    }

    private function fromRawList(array $lines, string $dir): array
    {
        $out = [];
        $now = time();
        foreach ($lines as $line) {
            $line = rtrim((string)$line, "\r\n");
            if ($line === '' || str_starts_with($line, 'total ')) {
                continue;
            }
            // Unix: drwxr-xr-x  2 owner group  4096 Jan  1 12:00 name
            if (preg_match('/^([\-dlbcps])([rwxsStT\-]{9})[+@.]?\s+\d+\s+(\S+)\s+(\S+)\s+(\d+)\s+(\w{3})\s+(\d{1,2})\s+(\d{1,2}:\d{2}|\d{4})\s+(.+)$/', $line, $m)
                || preg_match('/^([\-dlbcps])([rwxsStT\-]{9})[+@.]?\s+\d+\s+(\S+)\s+()(\d+)\s+(\w{3})\s+(\d{1,2})\s+(\d{1,2}:\d{2}|\d{4})\s+(.+)$/', $line, $m)) {
                [$all, $t, $perm, $owner, $group, $size, $mon, $day, $yt, $name] = $m;
                $target = null;
                if ($t === 'l' && str_contains($name, ' -> ')) {
                    [$name, $target] = explode(' -> ', $name, 2);
                }
                if ($name === '.' || $name === '..') {
                    continue;
                }
                $mtime = null;
                if (str_contains($yt, ':')) {
                    $ts = strtotime("$mon $day " . date('Y') . " $yt");
                    if ($ts !== false && $ts > $now + 86400) {
                        $ts = strtotime("$mon $day " . (date('Y') - 1) . " $yt");
                    }
                    $mtime = $ts ?: null;
                } else {
                    $mtime = strtotime("$mon $day $yt") ?: null;
                }
                $isLink = $t === 'l';
                $isDir = $t === 'd';
                $out[] = [
                    'name' => $name, 'type' => $isLink ? 'link' : ($isDir ? 'dir' : 'file'),
                    'isDir' => $isLink ? $this->isDirQuick(Path::join($dir, $name)) : $isDir,
                    'size' => (int)$size, 'mtime' => $mtime, 'perms' => $t . $perm,
                    'owner' => $owner, 'group' => $group !== '' ? $group : null, 'target' => $target,
                ];
                continue;
            }
            // Windows/IIS: 01-31-24  09:15PM       <DIR>          name
            if (preg_match('/^(\d{2})-(\d{2})-(\d{2,4})\s+(\d{1,2}):(\d{2})(AM|PM)\s+(<DIR>|\d+)\s+(.+)$/i', $line, $m)) {
                $year = (int)$m[3] < 100 ? 2000 + (int)$m[3] : (int)$m[3];
                $hour = (int)$m[4] % 12 + (strtoupper($m[6]) === 'PM' ? 12 : 0);
                $isDir = strtoupper($m[7]) === '<DIR>';
                $out[] = [
                    'name' => $m[8], 'type' => $isDir ? 'dir' : 'file', 'isDir' => $isDir,
                    'size' => $isDir ? 0 : (int)$m[7], 'mtime' => mktime($hour, (int)$m[5], 0, (int)$m[1], (int)$m[2], $year),
                    'perms' => null, 'owner' => null, 'group' => null, 'target' => null,
                ];
            }
        }
        return $out;
    }

    private function isDirQuick(string $path): bool
    {
        $c = $this->conn();
        try {
            $cwd = ftp_pwd($c);
            if (@ftp_chdir($c, $path)) {
                @ftp_chdir($c, $cwd ?: '/');
                return true;
            }
        } catch (\Throwable) {
        }
        return false;
    }

    public static function modeToString(int $mode, bool $isDir, bool $isLink = false): string
    {
        $s = $isLink ? 'l' : ($isDir ? 'd' : '-');
        foreach ([6, 3, 0] as $shift) {
            $b = ($mode >> $shift) & 7;
            $s .= ($b & 4 ? 'r' : '-') . ($b & 2 ? 'w' : '-') . ($b & 1 ? 'x' : '-');
        }
        return $s;
    }
}

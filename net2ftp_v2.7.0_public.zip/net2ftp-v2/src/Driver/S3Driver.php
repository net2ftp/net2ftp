<?php
declare(strict_types=1);

namespace Net2ftp\Driver;

use Net2ftp\App;
use Net2ftp\Path;
use Net2ftp\UserError;

/**
 * Amazon S3 (and S3-compatible storage: Exoscale SOS, Infomaniak, Wasabi, MinIO, Cloudflare R2, …)
 * Lean dependency-free client using AWS Signature Version 4 over cURL.
 *
 * Path model:  /                → list of buckets (or only the configured bucket)
 *              /bucket          → bucket root
 *              /bucket/a/b.txt  → object "a/b.txt"
 * "Folders" are key prefixes; empty folders are stored as zero-byte "prefix/" marker objects.
 */
final class S3Driver implements Driver
{
    private const EMPTY_SHA = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';
    private array $bucketRegion = [];
    private bool $connected = false;

    public function __construct(
        private string $accessKey,
        private string $secretKey,
        private string $region = 'us-east-1',
        private string $bucket = '',
        private string $endpoint = '',   // '' = AWS; otherwise e.g. https://sos-ch-gva-2.exo.io
        private bool $pathStyle = false,
        private string $sessionToken = '',
        private ?string $pinnedIp = null,   // the endpoint's IP address checked at login (DNS rebinding)
    ) {
        $this->region = $this->region !== '' ? $this->region : 'us-east-1';
        $this->endpoint = rtrim($this->endpoint, '/');
        if ($this->endpoint !== '') {
            $this->pathStyle = true;
        }
    }

    public function protocol(): string
    {
        return 's3';
    }

    public function features(): array
    {
        return ['exec' => false, 'serverCopy' => true, 'buckets' => $this->bucket === '', 'chmod' => false, 'chown' => false, 'extract' => true];
    }

    public function endpointHost(): string
    {
        return $this->endpoint !== '' ? (string)parse_url($this->endpoint, PHP_URL_HOST) : "s3.{$this->region}.amazonaws.com";
    }

    public function endpointPort(): int
    {
        if ($this->endpoint === '') {
            return 443;
        }
        $p = parse_url($this->endpoint, PHP_URL_PORT);
        return $p ? (int)$p : (str_starts_with($this->endpoint, 'http://') ? 80 : 443);
    }

    public function connect(): void
    {
        if ($this->connected) {
            return;
        }
        // Validate credentials with a cheap call
        if ($this->bucket !== '') {
            $r = $this->request('GET', $this->bucket, '', ['list-type' => '2', 'max-keys' => '1']);
        } else {
            $r = $this->request('GET', '', '');
        }
        if ($r['status'] >= 300) {
            $code = $this->errorCode($r);
            if (in_array($code, ['InvalidAccessKeyId', 'SignatureDoesNotMatch', 'AccessDenied', 'InvalidToken'], true) || $r['status'] === 403) {
                throw new UserError('Login failed: the access key or secret key is wrong, or lacks permission.', 401, [], $this->errorMessage($r, ''));
            }
            if ($code === 'NoSuchBucket') {
                throw new UserError('The bucket "{name}" does not exist.', 404, ['name' => $this->bucket]);
            }
            throw new UserError('Could not connect to S3.', 400, [], $this->errorMessage($r));
        }
        $this->connected = true;
    }

    public function close(): void
    {
    }

    public function home(): string
    {
        return $this->bucket !== '' ? '/' . $this->bucket : '/';
    }

    public function listDir(string $dir): array
    {
        [$bucket, $key] = $this->split($dir);
        if ($bucket === '') {
            return $this->listBuckets();
        }
        $prefix = $key === '' ? '' : $key . '/';
        $out = [];
        $token = null;
        $pages = 0;
        do {
            $q = ['list-type' => '2', 'delimiter' => '/', 'prefix' => $prefix, 'max-keys' => '1000'];
            if ($token) {
                $q['continuation-token'] = $token;
            }
            $r = $this->request('GET', $bucket, '', $q);
            $this->ensureOk($r, 'Could not list the directory {path}.', $dir);
            $xml = $this->xml($r['body']);
            foreach ($xml->CommonPrefixes ?? [] as $cp) {
                $name = rtrim(substr((string)$cp->Prefix, strlen($prefix)), '/');
                if ($name !== '') {
                    $out[] = ['name' => $name, 'type' => 'dir', 'isDir' => true, 'size' => 0, 'mtime' => null,
                        'perms' => null, 'owner' => null, 'group' => null, 'target' => null];
                }
            }
            foreach ($xml->Contents ?? [] as $c) {
                $k = (string)$c->Key;
                if ($k === $prefix) {
                    continue; // folder marker
                }
                $out[] = [
                    'name' => substr($k, strlen($prefix)), 'type' => 'file', 'isDir' => false,
                    'size' => (int)$c->Size, 'mtime' => strtotime((string)$c->LastModified) ?: null,
                    'perms' => (string)($c->StorageClass ?? '') ?: null,
                    'owner' => isset($c->Owner->DisplayName) ? (string)$c->Owner->DisplayName : null,
                    'group' => null, 'target' => null,
                ];
            }
            $token = ((string)$xml->IsTruncated === 'true') ? (string)$xml->NextContinuationToken : null;
        } while ($token && ++$pages < 100);

        if ($out === [] && $key !== '' && !$this->prefixExists($bucket, $key)) {
            throw new UserError('The directory {path} does not exist or cannot be opened.', 404, ['path' => $dir]);
        }
        return $out;
    }

    public function stat(string $path): ?array
    {
        [$bucket, $key] = $this->split($path);
        if ($bucket === '') {
            return ['name' => '/', 'type' => 'dir', 'isDir' => true, 'size' => 0, 'mtime' => null];
        }
        if ($key === '') {
            $r = $this->request('HEAD', $bucket, '');
            return $r['status'] < 300 ? ['name' => $bucket, 'type' => 'dir', 'isDir' => true, 'size' => 0, 'mtime' => null] : null;
        }
        $r = $this->request('HEAD', $bucket, $key);
        if ($r['status'] < 300) {
            return [
                'name' => Path::basename($path), 'type' => 'file', 'isDir' => false,
                'size' => (int)($r['headers']['content-length'] ?? 0),
                'mtime' => isset($r['headers']['last-modified']) ? (strtotime($r['headers']['last-modified']) ?: null) : null,
            ];
        }
        if ($this->prefixExists($bucket, $key)) {
            return ['name' => Path::basename($path), 'type' => 'dir', 'isDir' => true, 'size' => 0, 'mtime' => null];
        }
        return null;
    }

    public function get(string $remote, string $localFile): void
    {
        [$bucket, $key] = $this->objectPath($remote);
        $r = $this->request('GET', $bucket, $key, [], [], null, null, $localFile);
        $this->ensureOk($r, 'Could not download {path}.', $remote);
    }

    public function put(string $localFile, string $remote): void
    {
        [$bucket, $key] = $this->objectPath($remote);
        $mime = (function_exists('mime_content_type') ? @mime_content_type($localFile) : null) ?: 'application/octet-stream';
        $mime = self::mimeByExtension($key) ?? $mime;
        $r = $this->request('PUT', $bucket, $key, [], ['content-type' => $mime], null, $localFile);
        $this->ensureOk($r, 'Could not upload to {path}.', $remote);
    }

    /** Stream an object into $sink(string) from $offset (HTTP Range); $sink may return false to stop. */
    public function readStream(string $remote, callable $sink, int $offset = 0, int $length = -1): int
    {
        [$bucket, $key] = $this->objectPath($remote);
        $got = 0;
        $headers = [];
        if ($offset > 0 || $length >= 0) {
            $headers['range'] = 'bytes=' . $offset . '-' . ($length >= 0 ? $offset + $length - 1 : '');
        }
        if ($length === 0) {
            return 0;
        }
        $r = $this->request('GET', $bucket, $key, [], $headers, null, null, function (string $d) use (&$got, $sink) {
            $got += strlen($d);
            return $sink($d);
        });
        if ($r['status'] === 416) {
            return 0;   // offset at or past the end
        }
        $this->ensureOk($r, 'Could not download {path}.', $remote);
        return $got;
    }

    /** S3 objects cannot be appended to: only $offset 0 (the data is collected in a temp file, then sent). */
    public function writeStream(string $remote, callable $source, int $offset = 0): int
    {
        if ($offset > 0) {
            throw new UserError('Amazon S3 cannot append to {path}.', 400, ['path' => $remote]);
        }
        $tmp = App::tempFile();
        $n = 0;
        try {
            $fp = fopen($tmp, 'wb');
            while (($d = $source(1 << 20)) !== null && $d !== '') {
                fwrite($fp, $d);
                $n += strlen($d);
            }
            fclose($fp);
            $this->put($tmp, $remote);
        } finally {
            @unlink($tmp);
        }
        return $n;
    }

    // ---- multipart uploads (resumable uploads of large files: one part per uploaded chunk) ----

    public function multipartStart(string $remote): string
    {
        [$bucket, $key] = $this->objectPath($remote);
        $mime = self::mimeByExtension($key) ?? 'application/octet-stream';
        $r = $this->request('POST', $bucket, $key, ['uploads' => ''], ['content-type' => $mime], '');
        $this->ensureOk($r, 'Could not upload to {path}.', $remote);
        if (!preg_match('#<UploadId>([^<]+)</UploadId>#', $r['body'], $m)) {
            throw new UserError('Could not upload to {path}.', 400, ['path' => $remote], 'no UploadId');
        }
        return html_entity_decode($m[1]);
    }

    /** Upload one part from a local file; returns its ETag. */
    public function multipartPart(string $remote, string $uploadId, int $partNumber, string $localFile): string
    {
        [$bucket, $key] = $this->objectPath($remote);
        $r = $this->request('PUT', $bucket, $key, ['partNumber' => $partNumber, 'uploadId' => $uploadId], [], null, $localFile);
        $this->ensureOk($r, 'Could not upload to {path}.', $remote);
        return trim((string)($r['headers']['etag'] ?? ''), '"');
    }

    /** @param array<int,string> $etags part number → ETag */
    public function multipartComplete(string $remote, string $uploadId, array $etags): void
    {
        [$bucket, $key] = $this->objectPath($remote);
        ksort($etags);
        $xml = '<CompleteMultipartUpload>';
        foreach ($etags as $n => $etag) {
            $xml .= '<Part><PartNumber>' . (int)$n . '</PartNumber><ETag>"' . htmlspecialchars($etag, ENT_XML1) . '"</ETag></Part>';
        }
        $xml .= '</CompleteMultipartUpload>';
        $r = $this->request('POST', $bucket, $key, ['uploadId' => $uploadId], ['content-type' => 'application/xml'], $xml);
        // S3 may answer 200 with an <Error> body
        if ($r['status'] >= 300 || str_contains($r['body'], '<Error>')) {
            throw new UserError('Could not upload to {path}.', 400, ['path' => $remote], $this->errorMessage($r));
        }
    }

    public function multipartAbort(string $remote, string $uploadId): void
    {
        [$bucket, $key] = $this->objectPath($remote);
        try {
            $this->request('DELETE', $bucket, $key, ['uploadId' => $uploadId]);
        } catch (\Throwable) {
        }
    }

    public function mkdir(string $path): void
    {
        [$bucket, $key] = $this->split($path);
        if ($bucket === '') {
            throw new UserError('Invalid folder name.');
        }
        if ($key === '') {
            // create a bucket
            $body = $this->region === 'us-east-1' ? '' :
                '<CreateBucketConfiguration xmlns="http://s3.amazonaws.com/doc/2006-03-01/"><LocationConstraint>'
                . htmlspecialchars($this->region) . '</LocationConstraint></CreateBucketConfiguration>';
            $r = $this->request('PUT', $bucket, '', [], [], $body);
            $this->ensureOk($r, 'Could not create the bucket {path}.', $bucket);
            return;
        }
        $r = $this->request('PUT', $bucket, $key . '/', [], ['content-type' => 'application/x-directory'], '');
        $this->ensureOk($r, 'Could not create the folder {path}.', $path);
    }

    public function rmdir(string $path): void
    {
        [$bucket, $key] = $this->split($path);
        if ($key === '') {
            $r = $this->request('DELETE', $bucket, '');
            $this->ensureOk($r, 'Could not delete the bucket {path}.', $bucket);
            return;
        }
        $r = $this->request('DELETE', $bucket, $key . '/');
        if ($r['status'] >= 300 && $r['status'] !== 404) {
            $this->ensureOk($r, 'Could not delete the folder {path}.', $path);
        }
    }

    public function deleteFile(string $path): void
    {
        [$bucket, $key] = $this->objectPath($path);
        $r = $this->request('DELETE', $bucket, $key);
        $this->ensureOk($r, 'Could not delete {path}.', $path);
    }

    public function rename(string $from, string $to, bool $isDir): bool
    {
        if ($isDir) {
            return false; // prefixes are moved object-by-object by the caller
        }
        $this->copyFile($from, $to);
        $this->deleteFile($from);
        return true;
    }

    public function chmod(string $path, int $mode): void
    {
        throw new UserError('Amazon S3 has no Unix permissions.', 400);
    }

    public function chown(string $path, ?int $uid, ?int $gid): void
    {
        throw new UserError('Amazon S3 has no Unix permissions.', 400);
    }

    public function copyFile(string $from, string $to): bool
    {
        [$sb, $sk] = $this->objectPath($from);
        [$db, $dk] = $this->objectPath($to);
        $src = '/' . $sb . '/' . self::encodeKey($sk);
        $r = $this->request('PUT', $db, $dk, [], ['x-amz-copy-source' => $src, 'x-amz-metadata-directive' => 'COPY'], '');
        if ($r['status'] >= 300 && str_contains($this->errorMessage($r), 'maximum allowable size')) {
            // CopyObject is limited to 5 GiB: copy in parts (jobs do this step by step, see Jobs::partCopy)
            $st = $this->stat($from);
            $this->copyLarge($from, $to, (int)($st['size'] ?? 0));
            return true;
        }
        $this->ensureOk($r, 'Could not copy {path}.', $from);
        // CopyObject can return 200 with an <Error> body
        if (str_contains($r['body'], '<Error>')) {
            throw new UserError('Could not copy {path}.', 400, ['path' => $from], $this->errorMessage($r));
        }
        return true;
    }

    // ---- copies of objects over 5 GiB: multipart upload whose parts are copied on the server (UploadPartCopy) ----

    /** Objects of this size or more are copied in parts ('s3_copy_part_threshold'; S3 allows CopyObject up to 5 GiB). */
    public function partCopyThreshold(): int
    {
        return min(5 << 30, max(5 << 20, (int)App::cfg('s3_copy_part_threshold', 5 << 30)));
    }

    /** Size of one copied part: 's3_copy_part_size' (512 MiB), at least 5 MiB, at most 5 GiB, and at most 10,000 parts. */
    public function partCopySize(int $size): int
    {
        $p = min(5 << 30, max(5 << 20, (int)App::cfg('s3_copy_part_size', 512 << 20)));
        return max($p, (int)ceil($size / 10000));
    }

    /** Copy bytes $start…$end (inclusive) of $from as part $part of a multipart upload to $to; returns its ETag. */
    public function copyPart(string $from, string $to, string $uploadId, int $part, int $start, int $end): string
    {
        [$sb, $sk] = $this->objectPath($from);
        [$db, $dk] = $this->objectPath($to);
        $r = $this->request('PUT', $db, $dk, ['partNumber' => $part, 'uploadId' => $uploadId], [
            'x-amz-copy-source' => '/' . $sb . '/' . self::encodeKey($sk),
            'x-amz-copy-source-range' => "bytes=$start-$end",
        ], '');
        $this->ensureOk($r, 'Could not copy {path}.', $from);
        if (str_contains($r['body'], '<Error>') || !preg_match('#<ETag>([^<]+)</ETag>#', $r['body'], $m)) {
            throw new UserError('Could not copy {path}.', 400, ['path' => $from], $this->errorMessage($r, 'no ETag'));
        }
        return trim(html_entity_decode($m[1]), '"');
    }

    /** The whole multipart copy in one go (outside jobs, e.g. a single rename). */
    public function copyLarge(string $from, string $to, int $size): void
    {
        $id = $this->multipartStart($to);
        try {
            $part = $this->partCopySize($size);
            $etags = [];
            for ($n = 1, $start = 0; $start < $size; $n++, $start += $part) {
                $etags[$n] = $this->copyPart($from, $to, $id, $n, $start, min($size, $start + $part) - 1);
                App::timeLimit(max(60, (int)App::cfg('max_execution_time', 300)));
            }
            $this->multipartComplete($to, $id, $etags);
        } catch (\Throwable $e) {
            $this->multipartAbort($to, $id);
            throw $e;
        }
    }

    // ------------------------------------------------------------------

    private function listBuckets(): array
    {
        if ($this->bucket !== '') {
            return [['name' => $this->bucket, 'type' => 'dir', 'isDir' => true, 'size' => 0, 'mtime' => null,
                'perms' => null, 'owner' => null, 'group' => null, 'target' => null]];
        }
        $r = $this->request('GET', '', '');
        $this->ensureOk($r, 'Could not list the buckets.', '');
        $xml = $this->xml($r['body']);
        $out = [];
        foreach ($xml->Buckets->Bucket ?? [] as $b) {
            $out[] = ['name' => (string)$b->Name, 'type' => 'dir', 'isDir' => true, 'size' => 0,
                'mtime' => strtotime((string)$b->CreationDate) ?: null, 'perms' => 'bucket',
                'owner' => isset($xml->Owner->DisplayName) ? (string)$xml->Owner->DisplayName : null, 'group' => null, 'target' => null];
        }
        return $out;
    }

    private function prefixExists(string $bucket, string $key): bool
    {
        $r = $this->request('GET', $bucket, '', ['list-type' => '2', 'prefix' => $key . '/', 'max-keys' => '1']);
        if ($r['status'] >= 300) {
            return false;
        }
        $xml = $this->xml($r['body']);
        return (int)($xml->KeyCount ?? 0) > 0 || isset($xml->Contents[0]);
    }

    /** @return array{0:string,1:string} bucket, key (no leading/trailing slash) */
    private function split(string $path): array
    {
        $p = ltrim(Path::normalize($path), '/');
        if ($p === '') {
            return ['', ''];
        }
        $parts = explode('/', $p, 2);
        return [$parts[0], $parts[1] ?? ''];
    }

    private function objectPath(string $path): array
    {
        [$b, $k] = $this->split($path);
        if ($b === '' || $k === '') {
            throw new UserError('Files must be inside a bucket. Open a bucket first.');
        }
        return [$b, $k];
    }

    private static function encodeKey(string $key): string
    {
        return implode('/', array_map('rawurlencode', explode('/', $key)));
    }

    private function regionFor(string $bucket): string
    {
        return $this->bucketRegion[$bucket] ?? $this->region;
    }

    /**
     * Perform a signed S3 request.
     * @return array{status:int,headers:array<string,string>,body:string}
     */
    private function request(string $method, string $bucket, string $key, array $query = [], array $headers = [],
        ?string $body = null, ?string $bodyFile = null, string|\Closure|null $sinkFile = null, bool $retried = false): array
    {
        $region = $bucket !== '' ? $this->regionFor($bucket) : $this->region;

        // ---- URL ----
        $virtual = !$this->pathStyle && $bucket !== '' && preg_match('/^[a-z0-9][a-z0-9\-]{1,61}[a-z0-9]$/', $bucket);
        if ($this->endpoint !== '') {
            $scheme = str_starts_with($this->endpoint, 'http://') ? 'http' : 'https';
            $hostPort = (string)parse_url($this->endpoint, PHP_URL_HOST);
            $port = parse_url($this->endpoint, PHP_URL_PORT);
            $host = $hostPort . ($port ? ':' . $port : '');
            $basePath = rtrim((string)parse_url($this->endpoint, PHP_URL_PATH), '/');
        } else {
            $scheme = 'https';
            $host = ($region === 'us-east-1' && $bucket === '') ? 's3.amazonaws.com' : "s3.$region.amazonaws.com";
            $basePath = '';
        }
        if ($virtual) {
            $host = $bucket . '.' . $host;
            $uri = '/' . self::encodeKey($key);
        } else {
            $uri = $basePath . '/' . ($bucket !== '' ? rawurlencode($bucket) . '/' : '') . self::encodeKey($key);
            if ($bucket !== '' && $key === '') {
                $uri = $basePath . '/' . rawurlencode($bucket);
                if ($method === 'GET' || $method === 'PUT' || $method === 'DELETE' || $method === 'HEAD') {
                    $uri .= '/';
                }
            }
        }
        $uri = $uri === '' ? '/' : $uri;

        ksort($query, SORT_STRING);
        $qs = [];
        foreach ($query as $k => $v) {
            $qs[] = rawurlencode((string)$k) . '=' . rawurlencode((string)$v);
        }
        $canonicalQuery = implode('&', $qs);

        // ---- Signature V4 ----
        $amzDate = gmdate('Ymd\THis\Z');
        $date = substr($amzDate, 0, 8);
        if ($bodyFile !== null) {
            $payloadHash = 'UNSIGNED-PAYLOAD';
        } else {
            $payloadHash = ($body === null || $body === '') ? self::EMPTY_SHA : hash('sha256', $body);
        }
        $h = array_change_key_case($headers, CASE_LOWER);
        $h['host'] = $host;
        $h['x-amz-date'] = $amzDate;
        $h['x-amz-content-sha256'] = $payloadHash;
        if ($this->sessionToken !== '') {
            $h['x-amz-security-token'] = $this->sessionToken;
        }
        ksort($h, SORT_STRING);
        $canonHeaders = '';
        foreach ($h as $k => $v) {
            $canonHeaders .= $k . ':' . trim(preg_replace('/\s+/', ' ', (string)$v)) . "\n";
        }
        $signed = implode(';', array_keys($h));
        $canonical = "$method\n$uri\n$canonicalQuery\n$canonHeaders\n$signed\n$payloadHash";
        $scope = "$date/$region/s3/aws4_request";
        $toSign = "AWS4-HMAC-SHA256\n$amzDate\n$scope\n" . hash('sha256', $canonical);
        $kDate = hash_hmac('sha256', $date, 'AWS4' . $this->secretKey, true);
        $kRegion = hash_hmac('sha256', $region, $kDate, true);
        $kService = hash_hmac('sha256', 's3', $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $toSign, $kSigning);
        $h['authorization'] = "AWS4-HMAC-SHA256 Credential={$this->accessKey}/$scope, SignedHeaders=$signed, Signature=$signature";

        // ---- cURL ----
        $url = "$scheme://$host$uri" . ($canonicalQuery !== '' ? '?' . $canonicalQuery : '');
        $ch = curl_init($url);
        $hdrLines = [];
        foreach ($h as $k => $v) {
            if ($k !== 'host') {
                $hdrLines[] = "$k: $v";
            }
        }
        $hdrLines[] = 'Expect:';
        $respHeaders = [];
        $respBody = '';
        $sink = null;
        $opts = [
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => $hdrLines,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT        => 0,
            CURLOPT_LOW_SPEED_LIMIT => 1,
            CURLOPT_LOW_SPEED_TIME => (int)App::cfg('s3_timeout', 60),
            CURLOPT_HEADERFUNCTION => static function ($ch, string $line) use (&$respHeaders): int {
                $p = strpos($line, ':');
                if ($p !== false) {
                    $respHeaders[strtolower(trim(substr($line, 0, $p)))] = trim(substr($line, $p + 1));
                }
                return strlen($line);
            },
            CURLOPT_WRITEFUNCTION  => static function ($ch, string $chunk) use (&$respBody, &$sink, $sinkFile): int {
                $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                if ($sinkFile instanceof \Closure && $code >= 200 && $code < 300) {
                    // streaming: returning a short count makes cURL stop (the caller asked for no more data)
                    return $sinkFile($chunk) === false ? 0 : strlen($chunk);
                }
                if ($sinkFile !== null && $code >= 200 && $code < 300) {
                    if ($sink === null) {
                        $sink = fopen($sinkFile, 'wb');
                    }
                    return (int)fwrite($sink, $chunk);
                }
                $respBody .= $chunk;
                return strlen($chunk);
            },
        ];
        $in = null;
        if ($method === 'HEAD') {
            $opts[CURLOPT_NOBODY] = true;
        } elseif ($bodyFile !== null) {
            $in = fopen($bodyFile, 'rb');
            $opts[CURLOPT_UPLOAD] = true;
            $opts[CURLOPT_INFILE] = $in;
            $opts[CURLOPT_INFILESIZE] = filesize($bodyFile);
        } elseif ($body !== null) {
            $opts[CURLOPT_POSTFIELDS] = $body;
        } elseif ($method === 'PUT') {
            $opts[CURLOPT_POSTFIELDS] = '';
        }
        if ($this->pinnedIp !== null && $this->endpoint !== '') {
            // connect to the address checked at login, whatever the DNS answers now (TLS still checks the name)
            $eh = (string)parse_url($this->endpoint, PHP_URL_HOST);
            $ep = (int)(parse_url($this->endpoint, PHP_URL_PORT) ?: ($scheme === 'http' ? 80 : 443));
            $ip = str_contains($this->pinnedIp, ':') ? '[' . $this->pinnedIp . ']' : $this->pinnedIp;
            $opts[CURLOPT_RESOLVE] = ["$eh:$ep:$ip"];
        }
        curl_setopt_array($ch, $opts);
        $ok = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        if ($in) {
            fclose($in);
        }
        if ($sink) {
            fclose($sink);
        } elseif (is_string($sinkFile) && $status >= 200 && $status < 300) {
            file_put_contents($sinkFile, ''); // empty object
        }
        if ($ok === false && $sinkFile instanceof \Closure && $status >= 200 && $status < 300 && str_contains($err, 'Failed writing')) {
            $ok = true;   // the sink stopped the transfer on purpose
        }
        if ($ok === false) {
            throw new UserError('Network error while talking to S3.', 502, [], $err);
        }

        // Bucket lives in another region → learn it and retry once
        $realRegion = $respHeaders['x-amz-bucket-region'] ?? null;
        if (!$retried && $bucket !== '' && $realRegion && $realRegion !== $region && in_array($status, [301, 307, 400], true)) {
            $this->bucketRegion[$bucket] = $realRegion;
            return $this->request($method, $bucket, $key, $query, $headers, $body, $bodyFile, $sinkFile, true);
        }
        return ['status' => $status, 'headers' => $respHeaders, 'body' => $respBody];
    }

    private function ensureOk(array $r, string $template, string $path): void
    {
        if ($r['status'] >= 200 && $r['status'] < 300) {
            return;
        }
        $code = $r['status'] === 404 ? 404 : ($r['status'] === 403 ? 403 : 400);
        throw new UserError($template, $code, ['path' => $path], $this->errorMessage($r));
    }

    private function errorCode(array $r): string
    {
        return preg_match('#<Code>([^<]+)</Code>#', $r['body'], $m) ? $m[1] : '';
    }

    private function errorMessage(array $r, string $fallback = ''): string
    {
        $msg = preg_match('#<Message>([^<]+)</Message>#', $r['body'], $m) ? html_entity_decode($m[1]) : '';
        $code = $this->errorCode($r);
        if ($msg === '' && $code === '') {
            return $fallback !== '' ? $fallback : 'HTTP ' . $r['status'];
        }
        return trim($code . ($msg !== '' ? ' — ' . $msg : ''));
    }

    private function xml(string $body): \SimpleXMLElement
    {
        $prev = libxml_use_internal_errors(true);
        $xml = simplexml_load_string($body, \SimpleXMLElement::class, LIBXML_NONET);
        libxml_use_internal_errors($prev);
        if ($xml === false) {
            throw new UserError('Unexpected response from S3.');
        }
        return $xml;
    }

    private static function mimeByExtension(string $key): ?string
    {
        static $map = [
            'html' => 'text/html', 'htm' => 'text/html', 'css' => 'text/css', 'js' => 'application/javascript',
            'json' => 'application/json', 'svg' => 'image/svg+xml', 'txt' => 'text/plain', 'md' => 'text/markdown',
            'xml' => 'application/xml', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg',
            'gif' => 'image/gif', 'webp' => 'image/webp', 'pdf' => 'application/pdf', 'zip' => 'application/zip',
            'mp4' => 'video/mp4', 'mp3' => 'audio/mpeg', 'csv' => 'text/csv', 'woff2' => 'font/woff2',
        ];
        $ext = strtolower(pathinfo($key, PATHINFO_EXTENSION));
        return $map[$ext] ?? null;
    }
}

<?php
declare(strict_types=1);

namespace Net2ftp\Driver;

use Net2ftp\App;
use Net2ftp\ConnGate;
use Net2ftp\TooManyConnections;
use Net2ftp\Db;
use Net2ftp\Path;
use Net2ftp\UserError;
use phpseclib3\Crypt\PublicKeyLoader;
use phpseclib3\Net\SFTP;

/** SFTP / SSH using phpseclib 3 (pure PHP, no PECL extension needed). Supports password and private-key login. */
final class SftpDriver implements Driver
{
    private ?SFTP $s = null;
    private ?string $home = null;
    private string $fingerprint = '';
    private ?string $expected = null;

    public function __construct(
        private string $host,
        private int $port,
        private string $user,
        private string $pass,
        private string $privateKey = '',
        private string $passphrase = '',
        private ?string $address = null,   // the IP address checked at login (DNS rebinding); null = resolve $host
    ) {
    }

    public function protocol(): string
    {
        return 'sftp';
    }

    public function features(): array
    {
        return ['exec' => (bool)App::cfg('ssh_exec_enabled', true), 'serverCopy' => false, 'chmod' => true, 'chown' => true, 'extract' => true];
    }

    public function fingerprint(): string
    {
        return $this->fingerprint;
    }

    /** The fingerprint the user verified on the login screen: login is refused if the server presents another key. */
    public function expectFingerprint(?string $fp): void
    {
        $this->expected = ($fp !== null && $fp !== '') ? $fp : null;
    }

    public function connect(): void
    {
        $cmsg = '';
        try {
            // the host key is still looked up by server name ($this->host); only the connection uses the pinned address
            $addr = $this->address === null ? $this->host
                : (str_contains($this->address, ':') ? '[' . $this->address . ']' : $this->address);
            $s = new SFTP($addr, $this->port, (int)App::cfg('sftp_timeout', 20));
            $hostKey = $s->getServerPublicHostKey();
        } catch (\Throwable $e) {
            $hostKey = false;
            $cmsg = $e->getMessage();
        }
        if (empty($hostKey) && ConnGate::isTooMany($cmsg . ' ' . (isset($s) ? implode(' ', (array)$s->getErrors()) : ''))) {
            throw new TooManyConnections(trim($cmsg));
        }
        if (empty($hostKey)) {
            throw new UserError('Could not connect to {server}. Check the server name and port, and that it runs an SSH server.', 400, ['server' => "{$this->host}:{$this->port}"]);
        }
        $this->fingerprint = self::fingerprintOf((string)$hostKey);
        if ($this->expected !== null && !hash_equals($this->expected, $this->fingerprint)) {
            \Net2ftp\SecurityLog::event('host-key-changed', 'critical', "SSH host key of {$this->host}:{$this->port} differs from the one the user checked: {$this->fingerprint} vs {$this->expected}", $this->host);
            throw new UserError("The server's fingerprint ({actual}) is not the one you checked ({expected}). Your password was not sent. This could be a man-in-the-middle attack.", 409,
                ['actual' => $this->fingerprint, 'expected' => $this->expected]);
        }
        $this->checkHostKey();

        $credential = $this->pass;
        if (trim($this->privateKey) !== '') {
            try {
                $credential = PublicKeyLoader::load($this->privateKey, $this->passphrase !== '' ? $this->passphrase : false);
            } catch (\Throwable $e) {
                throw new UserError('The private key could not be read (wrong format or passphrase).');
            }
        }
        $lmsg = '';
        try {
            $ok = $s->login($this->user, $credential);
        } catch (\Throwable $e) {
            $ok = false;
            $lmsg = $e->getMessage();
        }
        if (!$ok) {
            // a server that closes the session because of a connection limit says so in its disconnect message
            $why = trim($lmsg . ' ' . implode(' ', (array)$s->getErrors()) . ' ' . (string)$s->getLastError());
            if (ConnGate::isTooMany($why)) {
                throw new TooManyConnections($why);
            }
        }
        if (!$ok) {
            throw new UserError('Login failed: wrong user name, password or key.', 401);
        }
        $s->disableStatCache();
        $s->setTimeout((int)App::cfg('sftp_timeout', 20) * 3);
        $this->s = $s;
    }

    public function close(): void
    {
        if ($this->s) {
            try {
                $this->s->disconnect();
            } catch (\Throwable) {
            }
            $this->s = null;
        }
    }

    public function home(): string
    {
        if ($this->home === null) {
            $this->home = Path::normalize((string)($this->conn()->pwd() ?: '/'));
        }
        return $this->home;
    }

    public function listDir(string $dir): array
    {
        $s = $this->conn();
        $dir = Path::normalize($dir);
        $raw = $s->rawlist($dir);
        if (!is_array($raw)) {
            throw new UserError('The directory {path} does not exist or cannot be opened.', 404, ['path' => $dir]);
        }
        $out = [];
        foreach ($raw as $name => $a) {
            $name = (string)($a['filename'] ?? $name);
            if ($name === '.' || $name === '..') {
                continue;
            }
            $out[] = $this->toEntry($name, $a, Path::join($dir, $name));
        }
        return $out;
    }

    public function stat(string $path): ?array
    {
        $path = Path::normalize($path);
        $a = $this->conn()->lstat($path);
        if (!is_array($a)) {
            return null;
        }
        return $this->toEntry(Path::basename($path) ?: '/', $a, $path);
    }

    public function get(string $remote, string $localFile): void
    {
        if (!$this->conn()->get($remote, $localFile)) {
            throw new UserError('Could not download {path}.', 400, ['path' => $remote], $this->lastError());
        }
    }

    public function put(string $localFile, string $remote): void
    {
        if (!$this->conn()->put($remote, $localFile, SFTP::SOURCE_LOCAL_FILE)) {
            throw new UserError('Could not upload to {path}.', 400, ['path' => $remote], $this->lastError());
        }
    }

    /** Stream $remote into $sink(string) from $offset (at most $length bytes); $sink may return false to stop. */
    public function readStream(string $remote, callable $sink, int $offset = 0, int $length = -1): int
    {
        $s = $this->conn();
        $got = 0;
        $slice = 4 << 20;   // read in slices, so stopping early never leaves the SFTP channel in the middle of a read
        while ($length < 0 || $got < $length) {
            $want = $length < 0 ? $slice : min($slice, $length - $got);
            $stop = false;
            $n = 0;
            $ok = $s->get($remote, function (string $d) use (&$n, &$stop, $sink): void {
                $n += strlen($d);
                if (!$stop && $sink($d) === false) {
                    $stop = true;
                }
            }, $offset + $got, $want);
            if ($ok === false) {
                throw new UserError('Could not download {path}.', 400, ['path' => $remote], $this->lastError());
            }
            $got += $n;
            if ($stop || $n < $want) {
                break;       // asked to stop, or end of file
            }
        }
        return $got;
    }

    /** Write $source(int $max): ?string (null = end) to $remote; $offset > 0 continues a file of exactly that size. */
    public function writeStream(string $remote, callable $source, int $offset = 0): int
    {
        $sent = 0;
        $cb = function (int $max) use ($source, &$sent): ?string {
            $d = $source($max);
            if ($d === null || $d === '') {
                return null;
            }
            $sent += strlen($d);
            return $d;
        };
        $ok = $this->conn()->put($remote, $cb, SFTP::SOURCE_CALLBACK, $offset > 0 ? $offset : -1);
        if (!$ok) {
            throw new UserError('Could not upload to {path}.', 400, ['path' => $remote], $this->lastError());
        }
        return $sent;
    }

    public function mkdir(string $path): void
    {
        if (!$this->conn()->mkdir($path)) {
            throw new UserError('Could not create the folder {path}.', 400, ['path' => $path], $this->lastError());
        }
    }

    public function rmdir(string $path): void
    {
        if (!$this->conn()->rmdir($path)) {
            throw new UserError('Could not delete the folder {path}.', 400, ['path' => $path], $this->lastError());
        }
    }

    public function deleteFile(string $path): void
    {
        if (!$this->conn()->delete($path, false)) {
            throw new UserError('Could not delete {path}.', 400, ['path' => $path], $this->lastError());
        }
    }

    public function rename(string $from, string $to, bool $isDir): bool
    {
        if (!$this->conn()->rename($from, $to)) {
            throw new UserError('Could not rename {path}.', 400, ['path' => $from], $this->lastError());
        }
        return true;
    }

    public function copyFile(string $from, string $to): bool
    {
        return false;
    }

    public function chmod(string $path, int $mode): void
    {
        if ($this->conn()->chmod($mode, $path) === false) {
            throw new UserError('Could not change the permissions of {path}.', 400, ['path' => $path], $this->lastError());
        }
    }

    public function chown(string $path, ?int $uid, ?int $gid): void
    {
        $s = $this->conn();
        if ($uid !== null && !$s->chown($path, $uid)) {
            throw new UserError('Could not change the owner of {path}.', 400, ['path' => $path], $this->lastError() ?: 'usually only root may change owners');
        }
        if ($gid !== null && !$s->chgrp($path, $gid)) {
            throw new UserError('Could not change the group of {path}.', 400, ['path' => $path], $this->lastError() ?: 'you must be a member of that group');
        }
    }

    /** Turn a user or group name into its numeric id via SSH ("id -u", "getent group"). */
    public function resolveId(string $name, bool $group): ?int
    {
        if (!App::cfg('ssh_exec_enabled', true) || !preg_match('/^[A-Za-z0-9._][A-Za-z0-9._-]{0,31}\$?$/', $name)) {
            return null;
        }
        $q = "'" . str_replace("'", "'\\''", $name) . "'";
        $r = $this->exec($group ? "getent group $q | cut -d: -f3" : "id -u -- $q", '/');
        $id = trim($r['output']);
        return preg_match('/^\d+$/', $id) ? (int)$id : null;
    }

    /**
     * Run a shell command over SSH.
     * @return array{output:string,stderr:string,exit:int|null}
     */
    public function exec(string $command, string $cwd): array
    {
        $s = $this->conn();
        $posix = $this->posixShell();
        $s->enableQuietMode();
        $s->setTimeout(60);
        // Change to the current folder first. If that fails the command is NOT run (it would otherwise run in the
        // home folder, where e.g. "rm *" does damage), and the shell's error message is shown.
        // Double quotes work in bash/sh/zsh and in Bitvise's BvShell, which accepts neither single quotes nor
        // /dev/null.
        $q = '"' . addcslashes($cwd, '\\"$`') . '"';
        $full = $posix
            ? 'cd ' . $q . " && {\n" . $command . "\n}"   // braces: "a; b" does not run b when cd failed
            : 'cd ' . $q . ' && ' . $command;
        $out = $s->exec($full);
        $err = $s->getStdError();
        $exit = $s->getExitStatus();
        $s->disableQuietMode();
        return [
            'output' => is_string($out) ? $out : '',
            'stderr' => is_string($err) ? $err : '',
            'exit'   => $exit === false ? null : (int)$exit,
        ];
    }

    /**
     * Does the server's shell run a "{ … }" group? Unix shells do; Windows SSH servers (Bitvise BvShell, OpenSSH for
     * Windows) and minimal built-in shells (e.g. the Rebex demo server) don't, and some of those silently do nothing.
     * Known Windows servers are recognised by name; for all others a tiny group is tried once and the answer is
     * remembered for the session (per server).
     */
    private function posixShell(): bool
    {
        $id = (string)$this->conn()->getServerIdentification();
        if (preg_match('/Bitvise|WinSSHD|for_Windows/i', $id)) {
            return false;
        }
        $key = strtolower($this->host) . ':' . $this->port . '|' . $id;
        static $known = [];
        if (!isset($known[$key]) && session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['n2f_shell'][$key])) {
            $known[$key] = (bool)$_SESSION['n2f_shell'][$key];
        }
        if (!isset($known[$key])) {
            $s = $this->conn();
            $out = $s->exec("{\necho n2f-group-ok\n}");
            $known[$key] = is_string($out) && str_contains($out, 'n2f-group-ok');
            if (session_status() === PHP_SESSION_ACTIVE) {
                $_SESSION['n2f_shell'][$key] = $known[$key];
            }
        }
        return $known[$key];
    }

    // ------------------------------------------------------------------

    private function conn(): SFTP
    {
        if (!$this->s) {
            $this->connect();
        }
        return $this->s;
    }

    private function toEntry(string $name, array $a, string $fullPath): array
    {
        $type = (int)($a['type'] ?? 0);
        $isLink = $type === 3; // NET_SFTP_TYPE_SYMLINK
        $isDir = $type === 2;  // NET_SFTP_TYPE_DIRECTORY
        $target = null;
        if ($isLink) {
            $t = $this->s?->stat($fullPath);
            $isDir = is_array($t) && (int)($t['type'] ?? 0) === 2;
            $rl = $this->s?->readlink($fullPath);
            $target = is_string($rl) ? $rl : null;
        }
        $mode = isset($a['mode']) ? (int)$a['mode'] : (isset($a['permissions']) ? (int)$a['permissions'] : null);
        return [
            'name'   => $name,
            'type'   => $isLink ? 'link' : ($isDir ? 'dir' : 'file'),
            'isDir'  => $isDir,
            'size'   => (int)($a['size'] ?? 0),
            'mtime'  => isset($a['mtime']) ? (int)$a['mtime'] : null,
            'perms'  => $mode !== null ? FtpDriver::modeToString($mode & 0777, $isDir && !$isLink, $isLink) : null,
            'owner'  => isset($a['uid']) ? (string)$a['uid'] : null,
            'group'  => isset($a['gid']) ? (string)$a['gid'] : null,
            'target' => $target,
        ];
    }

    private function lastError(): string
    {
        return (string)($this->s?->getLastSFTPError() ?: '');
    }

    public static function fingerprintOf(string $hostKey): string
    {
        $parts = explode(' ', trim($hostKey));
        $blob = base64_decode($parts[1] ?? $parts[0], true) ?: $hostKey;
        return 'SHA256:' . rtrim(base64_encode(hash('sha256', $blob, true)), '=');
    }

    /** Trust-on-first-use host key check, persisted in n2f_known_hosts. */
    private function checkHostKey(): void
    {
        if (!App::cfg('ssh_strict_host_keys', true) || !($pdo = Db::get())) {
            return;
        }
        $host = strtolower($this->host);
        $now = date('Y-m-d H:i:s');
        try {
            $st = $pdo->prepare('SELECT fingerprint FROM n2f_known_hosts WHERE host = ? AND port = ?');
            $st->execute([$host, $this->port]);
            $known = $st->fetchColumn();
            if ($known === false) {
                $pdo->prepare('INSERT INTO n2f_known_hosts (host, port, fingerprint, first_seen, last_seen) VALUES (?,?,?,?,?)')
                    ->execute([$host, $this->port, $this->fingerprint, $now, $now]);
                return;
            }
            if (!hash_equals((string)$known, $this->fingerprint) && $this->expected !== null) {
                // the user explicitly verified the new key on the login screen: accept and remember it
                $pdo->prepare('UPDATE n2f_known_hosts SET fingerprint = ?, last_seen = ? WHERE host = ? AND port = ?')
                    ->execute([$this->fingerprint, $now, $host, $this->port]);
                return;
            }
            if (!hash_equals((string)$known, $this->fingerprint)) {
                \Net2ftp\SecurityLog::event('host-key-changed', 'critical', "SSH host key of {$host}:{$this->port} changed: now {$this->fingerprint}, known " . $known, $host);
                throw new UserError('WARNING: the SSH host key of {host} has changed (now {actual}, expected {expected}). This could be a man-in-the-middle attack. If the change is legitimate, use "Check server fingerprint" to verify and accept the new key, or ask the administrator to reset it.', 409,
                    ['host' => $this->host, 'actual' => $this->fingerprint, 'expected' => (string)$known]);
            }
            $pdo->prepare('UPDATE n2f_known_hosts SET last_seen = ? WHERE host = ? AND port = ?')->execute([$now, $host, $this->port]);
        } catch (UserError $e) {
            throw $e;
        } catch (\Throwable $e) {
            error_log('net2ftp: known_hosts check skipped: ' . $e->getMessage());
        }
    }
}

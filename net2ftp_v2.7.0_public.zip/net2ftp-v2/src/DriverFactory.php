<?php
declare(strict_types=1);

namespace Net2ftp;

use Net2ftp\Driver\Driver;
use Net2ftp\Driver\FtpDriver;
use Net2ftp\Driver\S3Driver;
use Net2ftp\Driver\SftpDriver;

final class DriverFactory
{
    /**
     * Normalise and validate the login form, returning [params-to-store, meta-for-ui/logs].
     */
    public static function fromLogin(array $in): array
    {
        $protocol = strtolower((string)($in['protocol'] ?? 'ftp'));
        if (!in_array($protocol, (array)App::cfg('protocols', ['ftp', 'sftp', 's3']), true)) {
            throw new UserError('This protocol is not enabled.');
        }
        Requirements::requireProtocol($protocol);
        if ($protocol === 'ftp' && !empty($in['ssl'])) {
            Requirements::requireFeature('ftps');
        }
        $p = ['protocol' => $protocol];
        if ($protocol === 's3') {
            $p['accessKey'] = trim((string)($in['accessKey'] ?? ''));
            $p['secretKey'] = trim((string)($in['secretKey'] ?? ''));
            $p['region'] = trim((string)($in['region'] ?? '')) ?: (string)App::cfg('s3_default_region', 'us-east-1');
            $p['bucket'] = trim((string)($in['bucket'] ?? ''), " /");
            $p['endpoint'] = trim((string)($in['endpoint'] ?? ''));
            $p['sessionToken'] = trim((string)($in['sessionToken'] ?? ''));
            if ($p['accessKey'] === '' || $p['secretKey'] === '') {
                throw new UserError('Please enter your access key ID and secret access key.');
            }
            if (!preg_match('/^[a-z0-9\-]{1,30}$/', $p['region'])) {
                throw new UserError('Please enter a valid region, e.g. eu-central-2.');
            }
            if ($p['bucket'] !== '' && !preg_match('/^[a-zA-Z0-9.\-_]{3,63}$/', $p['bucket'])) {
                throw new UserError('Please enter a valid bucket name.');
            }
            if ($p['endpoint'] !== '') {
                if (!preg_match('#^https?://#i', $p['endpoint'])) {
                    $p['endpoint'] = 'https://' . $p['endpoint'];
                }
                $host = (string)parse_url($p['endpoint'], PHP_URL_HOST);
                $port = (int)(parse_url($p['endpoint'], PHP_URL_PORT) ?: (str_starts_with(strtolower($p['endpoint']), 'http://') ? 80 : 443));
                $pin = Security::checkServer($host, $port);
                if ($pin !== null) {
                    $p['pinnedIp'] = $pin;
                }
            }
            $meta = [
                'protocol' => 's3',
                'server'   => $p['endpoint'] !== '' ? (string)parse_url($p['endpoint'], PHP_URL_HOST) : 's3.' . $p['region'] . '.amazonaws.com',
                'port'     => $p['endpoint'] !== ''
                    ? (int)(parse_url($p['endpoint'], PHP_URL_PORT) ?: (str_starts_with(strtolower($p['endpoint']), 'http://') ? 80 : 443))
                    : 443,
                'username' => $p['accessKey'],
                // e.g. "AKIA…7Q2X · my-bucket" or "AKIA…7Q2X · eu-central-2" — distinguishes several S3 accounts
                'label'    => self::shortKey($p['accessKey']) . ' · '
                    . ($p['bucket'] !== '' ? $p['bucket'] : ($p['endpoint'] !== '' ? (string)parse_url($p['endpoint'], PHP_URL_HOST) : $p['region'])),
            ];
            // non-secret connection details: used to build bookmarkable links (never the secret key)
            $meta['public'] = ['protocol' => 's3', 'accessKey' => $p['accessKey'], 'region' => $p['region'],
                'endpoint' => $p['endpoint'], 'bucket' => $p['bucket']];
            return [$p, $meta];
        }

        $p['host'] = trim((string)($in['host'] ?? ''));
        // Accept "ftp://user@host:21/path" style input
        if (preg_match('#^(s?ftp|ftps)://#i', $p['host'])) {
            $u = parse_url($p['host']);
            $p['host'] = $u['host'] ?? '';
            if (!empty($u['port']) && empty($in['port'])) {
                $in['port'] = $u['port'];
            }
            if (!empty($u['user']) && empty($in['username'])) {
                $in['username'] = urldecode($u['user']);
            }
            if (!empty($u['path']) && empty($in['initialDir'])) {
                $in['initialDir'] = $u['path'];
            }
        }
        $p['port'] = (int)($in['port'] ?? 0) ?: ($protocol === 'sftp' ? 22 : 21);
        $p['username'] = (string)($in['username'] ?? '');
        $p['password'] = (string)($in['password'] ?? '');
        $p['initialDir'] = trim((string)($in['initialDir'] ?? ''));
        if ($protocol === 'ftp') {
            $p['passive'] = !isset($in['passive']) || (bool)$in['passive'];
            $p['ssl'] = !empty($in['ssl']);
        } else {
            $p['privateKey'] = (string)($in['privateKey'] ?? '');
            $p['passphrase'] = (string)($in['passphrase'] ?? '');
            if ($p['username'] === '') {
                throw new UserError('Please enter your user name.');
            }
        }
        $pin = Security::checkServer($p['host'], $p['port']);
        if ($pin !== null) {
            $p['pinnedIp'] = $pin;   // later requests connect to this address only (DNS rebinding)
        }
        $meta = [
            'protocol' => $protocol === 'ftp' && $p['ssl'] ? 'ftps' : $protocol,
            'server'   => $p['host'],
            'port'     => $p['port'],
            'username' => $p['username'] !== '' ? $p['username'] : 'anonymous',
            'label'    => ($p['username'] !== '' ? $p['username'] . '@' : '') . $p['host']
                . ($p['port'] !== ($protocol === 'sftp' ? 22 : 21) ? ':' . $p['port'] : ''),
        ];
        $meta['public'] = ['protocol' => $protocol, 'host' => $p['host'], 'port' => $p['port'], 'username' => $p['username'],
            'ssl' => $p['ssl'] ?? false, 'passive' => $p['passive'] ?? true];
        return [$p, $meta];
    }

    private static function shortKey(string $key): string
    {
        return strlen($key) > 10 ? substr($key, 0, 4) . '…' . substr($key, -4) : $key;
    }

    public static function make(array $p): Driver
    {
        Requirements::requireProtocol((string)($p['protocol'] ?? ''));
        return match ($p['protocol'] ?? '') {
            'ftp'  => new FtpDriver($p['host'], (int)$p['port'], $p['username'], $p['password'], (bool)$p['passive'], (bool)$p['ssl'],
                $p['pinnedIp'] ?? null),
            'sftp' => new SftpDriver($p['host'], (int)$p['port'], $p['username'], $p['password'], $p['privateKey'] ?? '', $p['passphrase'] ?? '',
                $p['pinnedIp'] ?? null),
            's3'   => new S3Driver($p['accessKey'], $p['secretKey'], $p['region'], $p['bucket'] ?? '', $p['endpoint'] ?? '', false, $p['sessionToken'] ?? '',
                $p['pinnedIp'] ?? null),
            default => throw new UserError('Unknown protocol.'),
        };
    }
}

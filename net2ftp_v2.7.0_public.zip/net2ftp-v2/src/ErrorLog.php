<?php
declare(strict_types=1);

namespace Net2ftp;

/**
 * Software errors (n2f_error_log), grouped: one row per distinct error with a counter, so a bug that
 * happens 10,000 times is one row with occurrences = 10,000. An error marked "resolved" in the admin page
 * is reopened when it happens again.
 *
 * Only real software errors are recorded — PHP exceptions, fatal errors, and JavaScript errors in the browser.
 * User errors (wrong password, permission denied, file not found …) are part of the access log instead.
 * Stack traces are stored WITHOUT function arguments, so passwords passed to a function never end up here.
 */
final class ErrorLog
{
    private static int $written = 0;

    public static function exception(\Throwable $e, string $action = ''): void
    {
        $trace = [];
        foreach (array_slice($e->getTrace(), 0, 20) as $i => $f) {
            $trace[] = '#' . $i . ' ' . self::rel((string)($f['file'] ?? '?')) . ':' . ($f['line'] ?? '?') . ' '
                . ($f['class'] ?? '') . ($f['type'] ?? '') . ($f['function'] ?? '') . '()';
        }
        self::record('php', get_class($e), $e->getMessage(), $e->getFile(), $e->getLine(), implode("\n", $trace), $action);
    }

    /** A fatal error from error_get_last() (no trace available). */
    public static function fatal(array $err, string $action = ''): void
    {
        self::record('php', 'fatal', (string)$err['message'], (string)$err['file'], (int)$err['line'], '', $action);
    }

    /** An error reported by the browser (window.onerror / unhandled promise rejection). */
    public static function browser(array $in): void
    {
        $msg = trim((string)($in['message'] ?? ''));
        if ($msg === '') {
            return;
        }
        $file = (string)($in['file'] ?? '');
        // only our own scripts: errors from browser extensions or injected ads are not ours to fix
        $path = (string)parse_url($file, PHP_URL_PATH);
        if ($file !== '' && !str_contains($path, '/assets/js/') && !str_contains($path, '/assets/vendor/')) {
            return;
        }
        self::record('js', 'error', $msg, $path !== '' ? $path : $file, (int)($in['line'] ?? 0),
            mb_substr((string)($in['stack'] ?? ''), 0, 4000), mb_substr((string)($in['page'] ?? ''), 0, 64), (string)($in['url'] ?? ''));
    }

    public static function record(string $source, string $level, string $message, string $file, int $line, string $trace, string $action = '', string $url = ''): void
    {
        if (self::$written++ > 5) {
            return; // one broken request doesn't write hundreds of rows
        }
        $file = self::rel($file);
        // the same error with another number (an id, a size, a path) is still the same error
        $pattern = preg_replace(['/\d+/', "/'[^']*'|\"[^\"]*\"/"], ['N', '…'], $message) ?? $message;
        $fp = sha1($source . '|' . $pattern . '|' . $file . '|' . $line);
        $url = $url !== '' ? $url : (string)($_SERVER['REQUEST_URI'] ?? '');
        $url = preg_replace('/([?&](t|token|password|_csrf)=)[^&]*/i', '$1…', $url) ?? $url; // no secrets from query strings
        $pdo = Db::get();
        if (!$pdo) {
            return;
        }
        $now = date('Y-m-d H:i:s');
        $vals = [$fp, $source, mb_substr($level, 0, 16), mb_substr($message, 0, 1024), mb_substr($file, 0, 255), max(0, $line),
            mb_substr($trace, 0, 8000), mb_substr($action, 0, 64), mb_substr($url, 0, 512), N2F_VERSION, PHP_VERSION,
            mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255), App::clientIp(), $now, $now];
        try {
            $sql = 'INSERT INTO n2f_error_log (fingerprint, source, level, message, file, line, trace, action, url, app_version, php_version,
                    user_agent, last_ip, occurrences, first_seen, last_seen, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,\'open\')';
            $sql .= Db::isMysql()
                ? ' ON DUPLICATE KEY UPDATE occurrences = occurrences + 1, last_seen = VALUES(last_seen), message = VALUES(message),
                    trace = VALUES(trace), action = VALUES(action), url = VALUES(url), app_version = VALUES(app_version),
                    user_agent = VALUES(user_agent), last_ip = VALUES(last_ip), status = \'open\''
                : ' ON CONFLICT(fingerprint) DO UPDATE SET occurrences = occurrences + 1, last_seen = excluded.last_seen, message = excluded.message,
                    trace = excluded.trace, action = excluded.action, url = excluded.url, app_version = excluded.app_version,
                    user_agent = excluded.user_agent, last_ip = excluded.last_ip, status = \'open\'';
            $pdo->prepare($sql)->execute($vals);
        } catch (\Throwable $e) {
            error_log('net2ftp: error log unavailable: ' . $e->getMessage());
        }
    }

    private static function rel(string $file): string
    {
        return str_starts_with($file, N2F_ROOT) ? ltrim(substr($file, strlen(N2F_ROOT)), '/\\') : $file;
    }
}

<?php
declare(strict_types=1);

namespace Net2ftp;

use Net2ftp\Driver\Driver;

/**
 * Extracts an archive that lives on the FTP/SSH/S3 server, into a folder on that same server.
 * The archive is downloaded to a temporary file, unpacked entry by entry (each entry streamed to a temp file
 * and uploaded), so it works for every protocol.
 *
 * Safety:
 *  - "zip slip": entries with absolute paths, drive letters or ".." are refused, so nothing is written
 *    outside the target folder;
 *  - "zip bombs": total uncompressed bytes, number of entries and compression ratio are limited, and bytes are
 *    COUNTED while decompressing (the sizes in the archive header can lie);
 *  - symbolic links and device files inside the archive are skipped.
 */
final class Extractor
{
    public int $files = 0;
    public int $dirs = 0;
    public int $skipped = 0;
    public int $bytes = 0;
    /** @var string[] */
    public array $errors = [];

    /** @var array<string,array<string,bool>|null> remote dir => names that already existed (null = new dir) */
    private array $dirs_ = [];
    private int $maxBytes;
    private int $maxFiles;
    private int $maxRatio;

    public function __construct(private Driver $d, private bool $overwrite)
    {
        $this->maxBytes = (int)App::cfg('max_unzip_bytes', 2 << 30);
        $this->maxFiles = (int)App::cfg('max_unzip_files', 20000);
        $this->maxRatio = (int)App::cfg('max_unzip_ratio', 200);
    }

    /** Archive types we can open, by file name. */
    public static function kind(string $name): ?string
    {
        $n = strtolower($name);
        return match (true) {
            str_ends_with($n, '.zip') => 'zip',
            (bool)preg_match('/\.(tar\.gz|tgz)$/', $n) => 'tgz',
            (bool)preg_match('/\.(tar\.bz2|tbz2?)$/', $n) => 'tbz',
            str_ends_with($n, '.tar') => 'tar',
            default => null,
        };
    }

    public static function requirement(string $kind): ?string
    {
        return match ($kind) {
            'zip' => class_exists('ZipArchive') ? null : Requirements::missing('zip'),
            'tgz' => !class_exists('PharData') ? Requirements::missing('phar') : (function_exists('gzopen') ? null : Requirements::missing('zlib')),
            'tbz' => !class_exists('PharData') ? Requirements::missing('phar') : (function_exists('bzopen') ? null : Requirements::missing('bz2')),
            'tar' => class_exists('PharData') ? null : Requirements::missing('phar'),
            default => I18n::t('This type of archive cannot be extracted.'),
        };
    }

    /** Extract $archive (remote path) into $target (remote folder, created when missing). */
    public function extract(string $archive, string $target): void
    {
        $kind = self::kind(Path::basename($archive));
        if ($kind === null || ($problem = self::requirement($kind)) !== null) {
            throw new UserError($problem ?? 'This type of archive cannot be extracted.', 400);
        }
        $work = App::tempDir('n2fx');
        try {
            $local = $work . '/archive';
            $this->d->get($archive, $local);
            $this->ensureDir($target);
            match ($kind) {
                'zip' => $this->fromZip($local, $target, $work),
                'tar' => $this->fromTar($local, $target, $work),
                'tgz', 'tbz' => $this->fromTar($this->decompress($local, $kind, $work), $target, $work),
            };
        } finally {
            App::rrmdirLocal($work);
        }
    }

    // ------------------------------------------------------------------ zip

    private function fromZip(string $local, string $target, string $work): void
    {
        $zip = new \ZipArchive();
        if ($zip->open($local, \ZipArchive::RDONLY) !== true) {
            throw new UserError('This file is not a valid zip archive.');
        }
        try {
            if ($zip->numFiles > $this->maxFiles) {
                throw new UserError('The archive contains more than {n} files.', 413, ['n' => $this->maxFiles]);
            }
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $st = $zip->statIndex($i, \ZipArchive::FL_ENC_RAW);
                if ($st === false) {
                    continue;
                }
                $name = self::zipName((string)$st['name']);
                $isDir = str_ends_with($name, '/');
                // Unix file type is in the high 16 bits of the external attributes: skip links, devices, …
                if ($zip->getExternalAttributesIndex($i, $opsys, $attr) && $opsys === \ZipArchive::OPSYS_UNIX) {
                    $type = ($attr >> 16) & 0170000;
                    if ($type !== 0 && $type !== 0100000 && $type !== 0040000) {
                        $this->skip($name, 'symbolic links and special files are not extracted');
                        continue;
                    }
                    $isDir = $isDir || $type === 0040000;
                }
                $rel = $this->safeRelative($name);
                if ($rel === null) {
                    continue;
                }
                if ($isDir) {
                    $this->ensureDir(Path::join($target, $rel));
                    continue;
                }
                $declared = (int)$st['size'];
                if ($st['comp_size'] > 0 && $declared / max(1, (int)$st['comp_size']) > $this->maxRatio && $declared > 1 << 20) {
                    throw new UserError('“{name}” is compressed suspiciously well (a "zip bomb"?). Extraction was stopped.', 413, ['name' => $name]);
                }
                // by index: a lookup by name fails for non-UTF-8 names, which libzip converts
                $in = method_exists($zip, 'getStreamIndex') ? $zip->getStreamIndex($i) : $zip->getStream((string)$zip->getNameIndex($i));
                if ($in === false) {
                    $this->skip($name, 'cannot be read (encrypted or damaged)');
                    continue;
                }
                $this->writeEntry($in, $target, $rel, $work);
            }
        } finally {
            $zip->close();
        }
    }

    /** Zip entry names are UTF-8 when flagged, otherwise usually CP437 (Windows "Send to → Compressed folder"). */
    private static function zipName(string $raw): string
    {
        if (preg_match('//u', $raw)) {
            return $raw;
        }
        if (function_exists('iconv') && ($u = @iconv('CP437', 'UTF-8//IGNORE', $raw)) !== false) {
            return $u;
        }
        static $hi = null;
        $hi ??= preg_split('//u', 'ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜ¢£¥₧ƒáíóúñÑªº¿⌐¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ ', -1, PREG_SPLIT_NO_EMPTY);
        $out = '';
        foreach (str_split($raw) as $c) {
            $o = ord($c);
            $out .= $o < 128 ? $c : $hi[$o - 128];
        }
        return $out;
    }

    // ------------------------------------------------------------------ tar

    /** Decompress .tar.gz / .tar.bz2 to a plain .tar ourselves, counting bytes (PharData would not limit them). */
    private function decompress(string $local, string $kind, string $work): string
    {
        $tar = $work . '/archive.tar';
        $in = $kind === 'tgz' ? @gzopen($local, 'rb') : @bzopen($local, 'r');
        $out = @fopen($tar, 'wb');
        if (!$in || !$out) {
            throw new UserError('This file is not a valid archive.');
        }
        $limit = $this->maxBytes + ($this->maxFiles * 1024) + 10240; // tar headers on top of the data
        $total = 0;
        try {
            while (!($kind === 'tgz' ? gzeof($in) : feof($in))) {
                $buf = $kind === 'tgz' ? gzread($in, 1 << 20) : bzread($in, 1 << 20);
                if ($buf === false || ($buf === '' && $kind === 'tbz' && bzerrno($in) !== 0)) {
                    throw new UserError('This file is not a valid archive.');
                }
                if ($buf === '') {
                    break;
                }
                $total += strlen($buf);
                if ($total > $limit) {
                    throw new UserError('The archive is larger than {size} when unpacked. Extraction was stopped.', 413, ['size' => FileOps::human($this->maxBytes)]);
                }
                fwrite($out, $buf);
            }
        } finally {
            $kind === 'tgz' ? gzclose($in) : bzclose($in);
            fclose($out);
            @unlink($local);
        }
        return $tar;
    }

    private function fromTar(string $local, string $target, string $work): void
    {
        // PharData decides the format by extension
        if (!str_ends_with($local, '.tar')) {
            rename($local, $local . '.tar');
            $local .= '.tar';
        }
        try {
            $phar = new \PharData($local, \FilesystemIterator::SKIP_DOTS | \FilesystemIterator::KEY_AS_PATHNAME | \FilesystemIterator::CURRENT_AS_FILEINFO);
        } catch (\Throwable $e) {
            throw new UserError('This file is not a valid archive.', 400, [], $e->getMessage());
        }
        $prefix = 'phar://' . $local . '/';
        $n = 0;
        foreach (new \RecursiveIteratorIterator($phar, \RecursiveIteratorIterator::SELF_FIRST) as $path => $info) {
            if (++$n > $this->maxFiles) {
                throw new UserError('The archive contains more than {n} files.', 413, ['n' => $this->maxFiles]);
            }
            $name = str_starts_with($path, $prefix) ? substr($path, strlen($prefix)) : basename($path);
            $rel = $this->safeRelative($name);
            if ($rel === null) {
                continue;
            }
            if ($info->isDir()) {
                $this->ensureDir(Path::join($target, $rel));
            } elseif ($info->isFile()) {
                $in = @fopen($path, 'rb');
                if (!$in) {
                    $this->skip($name, 'cannot be read');
                    continue;
                }
                $this->writeEntry($in, $target, $rel, $work);
            } else {
                $this->skip($name, 'symbolic links and special files are not extracted');
            }
        }
        unset($phar);
    }

    // ------------------------------------------------------------------ common

    /** A relative path that cannot escape the target folder, or null (entry refused). */
    private function safeRelative(string $name): ?string
    {
        $n = str_replace('\\', '/', $name);
        if ($n === '' || $n[0] === '/' || preg_match('#^[a-zA-Z]:#', $n) || str_contains($n, "\0")) {
            $this->skip($name, 'absolute path');
            return null;
        }
        $parts = [];
        foreach (explode('/', $n) as $p) {
            if ($p === '' || $p === '.') {
                continue;
            }
            if ($p === '..') {
                $this->skip($name, 'path leads outside the target folder');
                return null;
            }
            $parts[] = $p;
        }
        if (!$parts) {
            return null;
        }
        // metadata macOS adds to zips — never wanted on a server
        if ($parts[0] === '__MACOSX' || end($parts) === '.DS_Store') {
            return null;
        }
        return implode('/', $parts);
    }

    /** @param resource $in */
    private function writeEntry($in, string $target, string $rel, string $work): void
    {
        if (++$this->files > $this->maxFiles) {
            fclose($in);
            throw new UserError('The archive contains more than {n} files.', 413, ['n' => $this->maxFiles]);
        }
        $remote = Path::join($target, $rel);
        $dir = Path::parent($remote);
        $this->ensureDir($dir);
        $base = Path::basename($remote);
        if (!$this->overwrite && isset($this->dirs_[$dir][$base])) {
            fclose($in);
            $this->files--;
            $this->skipped++;
            return;
        }
        $tmp = $work . '/entry';
        $out = fopen($tmp, 'wb');
        try {
            while (!feof($in)) {
                $buf = fread($in, 1 << 20);
                if ($buf === false || $buf === '') {
                    break;
                }
                $this->bytes += strlen($buf);
                if ($this->bytes > $this->maxBytes) {
                    throw new UserError('The archive is larger than {size} when unpacked. Extraction was stopped.', 413, ['size' => FileOps::human($this->maxBytes)]);
                }
                fwrite($out, $buf);
            }
        } finally {
            fclose($in);
            fclose($out);
        }
        try {
            $this->d->put($tmp, $remote);
        } catch (UserError $e) {
            $this->files--;
            $this->error($e->getMessage());
        } finally {
            @unlink($tmp);
        }
    }

    private function ensureDir(string $dir): void
    {
        if (array_key_exists($dir, $this->dirs_)) {
            return;
        }
        if ($dir !== '/') {
            $this->ensureDir(Path::parent($dir));
        }
        $st = $dir === '/' ? ['isDir' => true] : $this->d->stat($dir);
        if ($st && !$st['isDir']) {
            throw new UserError('“{name}” exists as a file, so the folder cannot be created.', 409, ['name' => $dir]);
        }
        if ($st) {
            $names = [];
            if (!$this->overwrite) {
                foreach ($this->d->listDir($dir) as $e) {
                    $names[$e['name']] = true;
                }
            }
            $this->dirs_[$dir] = $names;
            return;
        }
        $this->d->mkdir($dir);
        $this->dirs++;
        $this->dirs_[$dir] = [];
    }

    private function skip(string $name, string $why): void
    {
        $this->skipped++;
        $this->error($name . ': ' . I18n::t($why));
    }

    private function error(string $msg): void
    {
        if (count($this->errors) < 100) {
            $this->errors[] = $msg;
        }
    }
}

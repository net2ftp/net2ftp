<?php
declare(strict_types=1);

namespace Net2ftp;

use Net2ftp\Driver\Driver;

/** Protocol-independent recursive operations built on top of a Driver. */
final class FileOps
{
    public int $bytes = 0;
    public int $count = 0;

    public function __construct(private Driver $d)
    {
    }

    // ---------------------------------------------------------------- delete

    public function delete(string $path, bool $isDir): void
    {
        if (!$isDir) {
            $this->d->deleteFile($path);
            $this->count++;
            return;
        }
        foreach ($this->d->listDir($path) as $e) {
            $child = Path::join($path, $e['name']);
            // Never recurse into symlinked directories: delete the link itself
            if ($e['type'] === 'link') {
                $this->d->deleteFile($child);
                $this->count++;
            } else {
                $this->delete($child, $e['isDir']);
            }
        }
        $this->d->rmdir($path);
        $this->count++;
    }

    // ---------------------------------------------------------------- copy / move

    public function copy(string $src, string $dst, bool $isDir): void
    {
        if (Path::isInside($dst, $src) && $isDir) {
            throw new UserError('A folder cannot be copied into itself.');
        }
        if (!$isDir) {
            $this->copyFile($src, $dst);
            return;
        }
        $this->d->mkdir($dst);
        foreach ($this->d->listDir($src) as $e) {
            if ($e['type'] === 'link' && $e['isDir']) {
                continue; // skip directory symlinks to avoid loops
            }
            $this->copy(Path::join($src, $e['name']), Path::join($dst, $e['name']), $e['isDir']);
        }
        $this->count++;
    }

    public function move(string $src, string $dst, bool $isDir): void
    {
        if ($isDir && Path::isInside($dst, $src)) {
            throw new UserError('A folder cannot be moved into itself.');
        }
        if ($this->d->rename($src, $dst, $isDir)) {
            $this->count++;
            return;
        }
        $this->copy($src, $dst, $isDir);
        $this->delete($src, $isDir);
    }

    private function copyFile(string $src, string $dst): void
    {
        if ($this->d->copyFile($src, $dst)) {
            $this->count++;
            return;
        }
        $tmp = App::tempFile();
        try {
            $this->d->get($src, $tmp);
            $this->bytes += (int)filesize($tmp);
            $this->d->put($tmp, $dst);
            $this->count++;
        } finally {
            @unlink($tmp);
        }
    }

    // ---------------------------------------------------------------- chmod / chown

    /** @var string[] errors collected while changing permissions (processing continues after an error) */
    public array $errors = [];

    /**
     * Change permissions and/or owner of one entry, optionally recursively.
     *
     * Order matters for directories, so you never lock yourself out halfway:
     *  - if the new folder mode keeps the owner's read+execute (e.g. 755), the folder is changed FIRST —
     *    which also regains access to a folder that was locked (e.g. 000 → 755) before descending into it;
     *  - if the new mode removes owner read/execute (e.g. 600 or 000), the CONTENTS are changed first and the
     *    folder last, because afterwards it can no longer be listed;
     *  - owner/group changes always happen children-first: after giving a folder away you may lose the right
     *    to change what is inside it.
     * Symbolic links are never followed.
     *
     * @param array{dirMode:?int,fileMode:?int,uid:?int,gid:?int,recursive:bool} $o
     */
    public function chmodTree(string $path, bool $isDir, array $o, bool $top = true): void
    {
        if (!$isDir) {
            $this->apply($path, $o['fileMode'], $o['uid'], $o['gid']);
            return;
        }
        if (!$o['recursive']) {
            $this->apply($path, $o['dirMode'], $o['uid'], $o['gid']);
            return;
        }
        $dirFirst = $o['dirMode'] === null || ($o['dirMode'] & 0500) === 0500;
        if ($dirFirst) {
            $this->apply($path, $o['dirMode'], null, null);
        }
        try {
            $children = $this->d->listDir($path);
        } catch (UserError $e) {
            $this->errors[] = $e->getMessage();
            $children = [];
        }
        foreach ($children as $e) {
            if ($e['type'] === 'link') {
                continue;
            }
            $this->chmodTree(Path::join($path, $e['name']), $e['isDir'], $o, false);
        }
        if (!$dirFirst) {
            $this->apply($path, $o['dirMode'], null, null);
        }
        $this->apply($path, null, $o['uid'], $o['gid']);
    }

    private function apply(string $path, ?int $mode, ?int $uid, ?int $gid): void
    {
        if ($mode === null && $uid === null && $gid === null) {
            return;
        }
        try {
            if ($mode !== null) {
                $this->d->chmod($path, $mode);
            }
            if ($uid !== null || $gid !== null) {
                $this->d->chown($path, $uid, $gid);
            }
            $this->count++;
        } catch (UserError $e) {
            if (count($this->errors) < 200) {
                $this->errors[] = $e->getMessage();
            }
        }
    }

    // ---------------------------------------------------------------- zip

    /**
     * List what a zip download will contain (recursively), before anything is sent: the limits give a clean
     * error message here, while the browser still waits for the answer.
     * @param array<int,array{path:string,isDir:bool}> $items
     * @return array<int,array{remote:string,name:string,isDir:bool,size:?int,mtime:?int}>
     */
    public function zipPlan(array $items): array
    {
        $maxBytes = (int)App::cfg('max_zip_bytes', 1 << 30);
        $maxFiles = (int)App::cfg('max_zip_files', 20000);
        $plan = [];
        $files = 0;
        $bytes = 0;
        $walk = function (string $remote, string $inZip, bool $isDir, ?int $size, ?int $mtime) use (&$walk, &$plan, &$files, &$bytes, $maxBytes, $maxFiles): void {
            $plan[] = ['remote' => $remote, 'name' => $inZip, 'isDir' => $isDir, 'size' => $size, 'mtime' => $mtime];
            if ($isDir) {
                foreach ($this->d->listDir($remote) as $e) {
                    if ($e['type'] === 'link' && $e['isDir']) {
                        continue;
                    }
                    $walk(Path::join($remote, $e['name']), $inZip . '/' . $e['name'], $e['isDir'], isset($e['size']) ? (int)$e['size'] : null,
                        isset($e['mtime']) ? (int)$e['mtime'] : null);
                }
                return;
            }
            if (++$files > $maxFiles) {
                throw new UserError('The selection contains more than {n} files — please zip a smaller selection.', 413, ['n' => $maxFiles]);
            }
            $bytes += (int)$size;
            if ($maxBytes > 0 && $bytes > $maxBytes) {
                throw new UserError('The selection is larger than {size} — please zip a smaller selection.', 413, ['size' => self::human($maxBytes)]);
            }
        };
        foreach ($items as $it) {
            $st = $it['isDir'] ? null : $this->d->stat($it['path']);
            $walk($it['path'], Path::basename($it['path']) ?: 'root', $it['isDir'], $st['size'] ?? null, $st['mtime'] ?? null);
        }
        return $plan;
    }

    /**
     * Stream the planned entries as a zip to $out, each file straight from the server (nothing stored here).
     * A file that can't be read is left out, or ends early when the server stops sending; either way it is
     * listed in "net2ftp-errors.txt" inside the zip, because the HTTP status was sent long ago.
     * $out returns false when the browser has gone away: then streaming stops.
     * @param callable(string):bool $out
     * @return string[] the problems
     */
    public function zipStream(array $plan, callable $out): array
    {
        $gone = false;
        $zip = new ZipStream(static function (string $b) use ($out, &$gone): void {
            if (!$gone && $out($b) === false) {
                $gone = true;
            }
        });
        $errors = [];
        foreach ($plan as $e) {
            if ($gone) {
                break;
            }
            if ($e['isDir']) {
                $zip->addDir($e['name'], $e['mtime']);
                continue;
            }
            $started = false;
            $sink = function (string $chunk) use ($zip, $e, &$started, &$gone): bool {
                if (!$started) {
                    $zip->beginFile($e['name'], $e['mtime'], $e['size']);   // only once the server delivers: a refused file leaves no trace
                    $started = true;
                }
                $zip->write($chunk);
                $this->bytes += strlen($chunk);
                return !$gone;
            };
            try {
                $this->d->readStream($e['remote'], $sink);
                if (!$started) {
                    $zip->beginFile($e['name'], $e['mtime'], 0);                 // an empty file
                }
                $zip->endFile();
                $this->count++;
            } catch (UserError $ex) {
                if ($started) {
                    $zip->endFile();
                    $errors[] = $e['name'] . ': ' . I18n::t('incomplete') . ' — ' . $ex->getMessage();
                } else {
                    $errors[] = $e['name'] . ': ' . $ex->getMessage();
                }
            }
        }
        if (!$gone) {
            if ($errors) {
                $zip->addString('net2ftp-errors.txt', implode("\r\n", $errors) . "\r\n");
            }
            $zip->finish();
        }
        return $gone ? array_merge($errors, ['(download cancelled by the browser)']) : $errors;
    }

    // ---------------------------------------------------------------- search

    /**
     * Search for a string in file contents (or names) below $dir.
     * @return array{results:array,scanned:int,skipped:int,truncated:bool,reason:string}
     */
    public function search(string $dir, string $needle, array $opt): array
    {
        $case = !empty($opt['caseSensitive']);
        $inNames = ($opt['scope'] ?? 'content') === 'name';
        $regex = !empty($opt['regex']);
        $pattern = trim((string)($opt['filePattern'] ?? ''));
        $maxFiles = (int)App::cfg('search_max_files', 5000);
        $maxSize = (int)App::cfg('search_max_file_bytes', 2 << 20);
        $maxResults = (int)App::cfg('search_max_results', 1000);
        $deadline = microtime(true) + (int)App::cfg('search_time_limit', 60);

        if ($regex) {
            $re = '~' . str_replace('~', '\~', $needle) . '~u' . ($case ? '' : 'i');
            if (@preg_match($re, '') === false) {
                throw new UserError('The regular expression is not valid.');
            }
            $match = static fn(string $hay): bool => (bool)preg_match($re, $hay);
        } else {
            $match = $case
                ? static fn(string $hay): bool => str_contains($hay, $needle)
                : static fn(string $hay): bool => mb_stripos($hay, $needle) !== false;
        }
        $globs = array_filter(array_map('trim', preg_split('/[,;\s]+/', $pattern) ?: []));

        $results = [];
        $scanned = $skipped = 0;
        $reason = '';
        $queue = [Path::normalize($dir)];
        $tmp = App::tempFile('n2fs');

        try {
            while ($queue) {
                $current = array_shift($queue);
                try {
                    $entries = $this->d->listDir($current);
                } catch (\Throwable) {
                    $skipped++;
                    continue;
                }
                usort($entries, fn($a, $b) => strnatcasecmp($a['name'], $b['name']));
                foreach ($entries as $e) {
                    if (microtime(true) > $deadline) {
                        $reason = 'time';
                        break 2;
                    }
                    $full = Path::join($current, $e['name']);
                    if ($e['isDir']) {
                        if ($e['type'] !== 'link') {
                            $queue[] = $full;
                        }
                        if ($inNames && $match($e['name'])) {
                            $results[] = ['path' => $full, 'dir' => $current, 'name' => $e['name'], 'isDir' => true, 'line' => null, 'text' => null];
                        }
                        continue;
                    }
                    if ($globs && !self::globMatch($e['name'], $globs)) {
                        continue;
                    }
                    if ($inNames) {
                        $scanned++;
                        if ($match($e['name'])) {
                            $results[] = ['path' => $full, 'dir' => $current, 'name' => $e['name'], 'isDir' => false, 'line' => null, 'text' => null];
                        }
                    } else {
                        if ($e['size'] > $maxSize) {
                            $skipped++;
                            continue;
                        }
                        if (++$scanned > $maxFiles) {
                            $reason = 'files';
                            break 2;
                        }
                        try {
                            $this->d->get($full, $tmp);
                        } catch (\Throwable) {
                            $skipped++;
                            continue;
                        }
                        $content = (string)file_get_contents($tmp);
                        $this->bytes += strlen($content);
                        if (str_contains(substr($content, 0, 8000), "\0")) {
                            $skipped++; // binary
                            continue;
                        }
                        if (!mb_check_encoding($content, 'UTF-8')) {
                            $content = mb_convert_encoding($content, 'UTF-8', 'ISO-8859-1');
                        }
                        if (!$match($content)) {
                            continue;
                        }
                        $perFile = 0;
                        foreach (preg_split('/\r\n|\r|\n/', $content) as $i => $line) {
                            if ($match($line)) {
                                if (++$perFile > 50) {
                                    $results[] = ['path' => $full, 'dir' => $current, 'name' => $e['name'], 'isDir' => false,
                                        'line' => null, 'text' => '… more matches in this file not shown'];
                                    break;
                                }
                                $results[] = ['path' => $full, 'dir' => $current, 'name' => $e['name'], 'isDir' => false,
                                    'line' => $i + 1, 'text' => mb_substr(trim($line), 0, 300)];
                                if (count($results) >= $maxResults) {
                                    break;
                                }
                            }
                        }
                    }
                    if (count($results) >= $maxResults) {
                        $reason = 'results';
                        break 2;
                    }
                }
            }
        } finally {
            @unlink($tmp);
        }
        $this->count = $scanned;
        return ['results' => $results, 'scanned' => $scanned, 'skipped' => $skipped, 'truncated' => $reason !== '', 'reason' => $reason];
    }

    private static function globMatch(string $name, array $globs): bool
    {
        foreach ($globs as $g) {
            if (fnmatch($g, $name, FNM_CASEFOLD)) {
                return true;
            }
        }
        return false;
    }

    public static function human(int $bytes): string
    {
        $u = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        $v = (float)$bytes;
        while ($v >= 1024 && $i < 4) {
            $v /= 1024;
            $i++;
        }
        return ($i ? number_format($v, 1) : (string)$bytes) . ' ' . $u[$i];
    }
}

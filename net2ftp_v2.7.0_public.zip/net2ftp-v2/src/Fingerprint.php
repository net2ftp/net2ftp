<?php
declare(strict_types=1);

namespace Net2ftp;

use phpseclib3\Net\SSH2;

/**
 * "Check the server fingerprint" before sending a password.
 *  - SFTP/SSH: the SSH host key (SHA256 + legacy MD5 fingerprint), no login performed.
 *  - FTPS: the TLS certificate obtained via AUTH TLS (PHP's ftp extension itself never verifies
 *    certificates, so this is the only certificate check FTPS gets).
 * The result is compared with the fingerprint remembered for this server (n2f_known_hosts).
 */
final class Fingerprint
{
    /** @return array{type:string,algorithm:string,sha256:string,md5:?string,status:string,knownSince:?string,knownFingerprint:?string,cert:?array} */
    public static function check(string $protocol, string $host, int $port, ?string $address = null): array
    {
        $r = $protocol === 'sftp' ? self::ssh($host, $port, $address) : self::ftpsCertificate($host, $port, $address);
        [$known, $since] = self::known($host, $port, $protocol === 'sftp' ? 'ssh' : 'x509');
        $r['status'] = $known === null ? 'new' : (hash_equals($known, $r['sha256']) ? 'known' : 'changed');
        $r['knownSince'] = $since;
        $r['knownFingerprint'] = $r['status'] === 'changed' ? $known : null;
        return $r;
    }

    /** $address: the IP address checked by Security::checkServer (connect there, not to a new DNS answer) */
    public static function ssh(string $host, int $port, ?string $address = null): array
    {
        try {
            $addr = $address === null ? $host : (str_contains($address, ':') ? "[$address]" : $address);
            $ssh = new SSH2($addr, $port, (int)App::cfg('sftp_timeout', 20));
            $key = $ssh->getServerPublicHostKey();
            $ssh->disconnect();
        } catch (\Throwable) {
            $key = false;
        }
        if (empty($key)) {
            throw new UserError('Could not connect to {server}. Check the server name and port, and that it runs an SSH server.', 400, ['server' => "$host:$port"]);
        }
        $parts = explode(' ', trim((string)$key));
        $blob = base64_decode($parts[1] ?? '', true) ?: (string)$key;
        return [
            'type'      => 'ssh',
            'algorithm' => $parts[0] ?? 'ssh',
            'sha256'    => 'SHA256:' . rtrim(base64_encode(hash('sha256', $blob, true)), '='),
            'md5'       => 'MD5:' . implode(':', str_split(md5($blob), 2)),
            'cert'      => null,
        ];
    }

    /** Explicit FTPS: plain connection, "AUTH TLS", then read the server certificate. */
    public static function ftpsCertificate(string $host, int $port, ?string $address = null): array
    {
        if (!function_exists('openssl_x509_fingerprint') || !function_exists('stream_socket_client')) {
            throw new UserError(Requirements::missing('openssl'), 503);
        }
        $timeout = (int)App::cfg('ftp_timeout', 20);
        $ctx = stream_context_create(['ssl' => [
            'capture_peer_cert' => true, 'verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true,
            'SNI_enabled' => true, 'peer_name' => $host,
        ]]);
        $addr = $address ?? $host;
        $target = 'tcp://' . (str_contains($addr, ':') ? "[$addr]" : $addr) . ':' . $port;
        $fp = @stream_socket_client($target, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $ctx);
        if (!$fp) {
            throw new UserError('Could not connect to {server}. Check the server name and port.', 400, ['server' => "$host:$port"]);
        }
        stream_set_timeout($fp, $timeout);
        try {
            $banner = self::reply($fp);
            if (!str_starts_with($banner, '220')) {
                throw new UserError('The server did not answer like an FTP server.');
            }
            fwrite($fp, "AUTH TLS\r\n");
            $auth = self::reply($fp);
            if (!str_starts_with($auth, '234')) {
                throw new UserError('This server does not support FTP over TLS (FTPS), so it has no certificate to check.');
            }
            if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                throw new UserError('The TLS handshake with the server failed.');
            }
            $cert = stream_context_get_params($fp)['options']['ssl']['peer_certificate'] ?? null;
        } finally {
            @fclose($fp);
        }
        if (!$cert) {
            throw new UserError('The server did not present a certificate.');
        }
        $info = openssl_x509_parse($cert) ?: [];
        $sha = strtoupper((string)openssl_x509_fingerprint($cert, 'sha256'));
        $names = [];
        foreach (explode(',', (string)($info['extensions']['subjectAltName'] ?? '')) as $alt) {
            $alt = trim($alt);
            if (str_starts_with($alt, 'DNS:') || str_starts_with($alt, 'IP Address:')) {
                $names[] = trim(substr($alt, strpos($alt, ':') + 1));
            }
        }
        if (!$names && !empty($info['subject']['CN'])) {
            $names[] = (string)$info['subject']['CN'];
        }
        $hostOk = false;
        foreach ($names as $n) {
            $re = '/^' . str_replace('\*', '[^.]+', preg_quote(strtolower($n), '/')) . '$/';
            $hostOk = $hostOk || (bool)preg_match($re, strtolower($host));
        }
        $now = time();
        $validFrom = (int)($info['validFrom_time_t'] ?? 0);
        $validTo = (int)($info['validTo_time_t'] ?? 0);
        $trusted = false;
        if (function_exists('openssl_x509_checkpurpose')) {
            // the CA bundle may be outside open_basedir (e.g. /usr/lib/ssl/cert.pem): then "not verified", no error
            try {
                $loc = function_exists('openssl_get_cert_locations') ? openssl_get_cert_locations() : [];
                $ca = array_values(array_filter([(string)ini_get('openssl.cafile'), (string)($loc['default_cert_file'] ?? '')],
                    static fn(string $f): bool => $f !== '' && @is_file($f) && @is_readable($f)));
                $trusted = @openssl_x509_checkpurpose($cert, X509_PURPOSE_SSL_SERVER, $ca) === true;
            } catch (\Throwable) {
                $trusted = false;
            }
        }
        return [
            'type'      => 'x509',
            'algorithm' => 'X.509',
            'sha256'    => 'SHA256:' . implode(':', str_split($sha, 2)),
            'md5'       => null,
            'cert'      => [
                'subject'   => self::dn($info['subject'] ?? []),
                'issuer'    => self::dn($info['issuer'] ?? []),
                'names'     => $names,
                'validFrom' => $validFrom ?: null,
                'validTo'   => $validTo ?: null,
                'expired'   => $validTo > 0 && $validTo < $now,
                'hostMatch' => $hostOk,
                'trusted'   => $trusted,                 // signed by a CA the web server trusts
                'selfSigned'=> self::dn($info['subject'] ?? []) === self::dn($info['issuer'] ?? []),
            ],
        ];
    }

    /** Remember a fingerprint the user confirmed (FTPS); SSH keys are remembered by SftpDriver at login. */
    public static function remember(string $host, int $port, string $fingerprint): void
    {
        $pdo = Db::get();
        if (!$pdo) {
            return;
        }
        $now = date('Y-m-d H:i:s');
        try {
            $st = $pdo->prepare('UPDATE n2f_known_hosts SET fingerprint = ?, last_seen = ? WHERE host = ? AND port = ?');
            $st->execute([$fingerprint, $now, strtolower($host), $port]);
            if ($st->rowCount() === 0) {
                $pdo->prepare('INSERT INTO n2f_known_hosts (host, port, fingerprint, first_seen, last_seen) VALUES (?,?,?,?,?)')
                    ->execute([strtolower($host), $port, $fingerprint, $now, $now]);
            }
        } catch (\Throwable $e) {
            error_log('net2ftp: could not store fingerprint: ' . $e->getMessage());
        }
    }

    /** @return array{0:?string,1:?string} fingerprint and first-seen date */
    private static function known(string $host, int $port, string $kind): array
    {
        $pdo = Db::get();
        if (!$pdo) {
            return [null, null];
        }
        try {
            $st = $pdo->prepare('SELECT fingerprint, first_seen FROM n2f_known_hosts WHERE host = ? AND port = ?');
            $st->execute([strtolower($host), $port]);
            $row = $st->fetch();
        } catch (\Throwable) {
            return [null, null];
        }
        if (!$row) {
            return [null, null];
        }
        // SSH keys are stored as "SHA256:base64", certificates as "SHA256:AA:BB:…"
        $isCert = (bool)preg_match('/^SHA256:([0-9A-F]{2}:){31}[0-9A-F]{2}$/', (string)$row['fingerprint']);
        if (($kind === 'x509') !== $isCert) {
            return [null, null];
        }
        return [(string)$row['fingerprint'], (string)$row['first_seen']];
    }

    private static function reply($fp): string
    {
        $all = '';
        while (($line = fgets($fp, 1024)) !== false) {
            $all .= $line;
            if (preg_match('/^\d{3} /', $line)) { // last line of a (multi-line) reply
                break;
            }
        }
        return $all;
    }

    private static function dn(array $parts): string
    {
        $out = [];
        foreach ($parts as $k => $v) {
            $out[] = $k . '=' . (is_array($v) ? implode('+', $v) : $v);
        }
        return implode(', ', $out);
    }
}

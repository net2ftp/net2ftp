<?php
declare(strict_types=1);

namespace Net2ftp;

/**
 * Scheduled cleanup: one job that deletes everything net2ftp leaves behind.
 *
 *  - temporary files left by cancelled uploads, interrupted zips/extracts/editor saves, crashed requests
 *    (after housekeeping.tmp_days; sooner when the disk is nearly full),
 *  - expired share links and their files, and half-created shares,
 *  - old rate-limit files,
 *  - access-log rows older than log_retention_days (deleted in small batches, so the table is never locked for long),
 *  - consumption rows (per IP after 30 days, per server after 400 days), errors not seen for 90 days,
 *    security events after 180 days, blocks that ended more than 90 days ago,
 *  - abuse/GDPR requests marked "done" after housekeeping.requests_days.
 *
 * How it is started (config housekeeping.mode):
 *  - 'cron' (recommended): a cron job or systemd timer runs `php bin/cleanup.php` every hour. Web requests never
 *    do cleanup work, so no visitor ever waits for it.
 *  - 'auto' (default, for hosting without cron): at most once per housekeeping.interval, the request that finds
 *    the job due runs it AFTER its response has been sent (PHP-FPM) or just before finishing (mod_php).
 *    A lock file makes sure only one request runs it, however many arrive at the same moment.
 */
final class Housekeeping
{
    private static bool $scheduled = false;

    private static function cfg(string $key, mixed $default): mixed
    {
        return ((array)App::cfg('housekeeping', []))[$key] ?? $default;
    }

    private static function stateFile(): string
    {
        return App::tmpDir() . '/housekeeping.json';
    }

    /** Called at the start of web requests: in 'auto' mode, runs the job after the response if it is due. */
    public static function schedule(): void
    {
        if (self::$scheduled || self::cfg('mode', 'auto') !== 'auto' || PHP_SAPI === 'cli') {
            return;
        }
        self::$scheduled = true;
        if (!self::due()) {
            return;
        }
        register_shutdown_function(static function (): void {
            // send the response first: the visitor doesn't wait for the cleanup
            while (ob_get_level() > 0) {
                @ob_end_flush();
            }
            @flush();
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            }
            if (function_exists('ignore_user_abort')) {
                ignore_user_abort(true);
            }
            try {
                self::run(false);
            } catch (\Throwable $e) {
                error_log('net2ftp housekeeping: ' . $e->getMessage());
            }
        });
    }

    public static function due(): bool
    {
        $last = (int)@filemtime(self::stateFile());
        return time() - $last >= (int)self::cfg('interval', 3600);
    }

    /** Last run: time, duration, what was deleted, errors. */
    public static function status(): array
    {
        $s = json_decode((string)@file_get_contents(self::stateFile()), true);
        return is_array($s) ? $s : [];
    }

    /**
     * Run the cleanup now. $force = even if it ran recently (CLI).
     * @return array{ran:bool, report?:array}
     */
    public static function run(bool $force): array
    {
        $lock = @fopen(App::tmpDir() . '/housekeeping.lock', 'c');
        if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
            return ['ran' => false]; // another request or the cron job is on it
        }
        try {
            if (!$force && !self::due()) {
                return ['ran' => false];
            }
            // claim this run at once, so a crash doesn't make every following request retry it
            @touch(self::stateFile());
            App::timeLimit(300);
            $t0 = microtime(true);
            $r = ['started' => time(), 'mode' => PHP_SAPI === 'cli' ? 'cli' : self::cfg('mode', 'auto'), 'errors' => []];
            foreach (['tmp' => 'cleanTemp', 'shares' => 'cleanShares', 'limits' => 'cleanLimits', 'log' => 'cleanLog',
                'usage' => 'cleanUsage', 'errorlog' => 'cleanErrorLog', 'security' => 'cleanSecurityLog', 'blocks' => 'cleanBlocks',
                'requests' => 'cleanRequests', 'transfers' => 'cleanTransfers'] as $k => $fn) {
                try {
                    $r[$k] = self::$fn();
                } catch (\Throwable $e) {
                    $r['errors'][] = "$k: " . $e->getMessage();
                }
            }
            $r['seconds'] = round(microtime(true) - $t0, 2);
            @file_put_contents(self::stateFile(), json_encode($r, JSON_UNESCAPED_SLASHES), LOCK_EX);
            if ($r['errors']) {
                error_log('net2ftp housekeeping: ' . implode('; ', $r['errors']));
            }
            return ['ran' => true, 'report' => $r];
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    // ------------------------------------------------------------------ tasks

    /** Leftover temporary files and folders (all start with "n2f"). */
    private static function cleanTemp(): array
    {
        $dir = App::tmpDir();
        $days = (float)self::cfg('tmp_days', 7);
        $maxAge = (int)($days * 86400);
        // Disk nearly full: anything not touched for an hour is abandoned (a running upload touches its file
        // with every chunk, a zip or extract finishes within max_execution_time).
        $free = function_exists('disk_free_space') ? @disk_free_space($dir) : false;
        $low = $free !== false && $free < (float)self::cfg('min_free_mb', 2048) * 1048576;
        if ($low) {
            $maxAge = min($maxAge, 3600);
        }
        $limit = time() - $maxAge;
        $n = 0;
        $bytes = 0;
        foreach (glob($dir . '/n2f*') ?: [] as $p) {
            if ((int)@filemtime($p) >= $limit) {
                continue;
            }
            if (is_dir($p)) {
                $bytes += self::size($p);
                App::rrmdirLocal($p);
            } else {
                $bytes += (int)@filesize($p);
                @unlink($p);
            }
            $n++;
        }
        return ['deleted' => $n, 'bytes' => $bytes, 'olderThanHours' => round($maxAge / 3600, 1), 'lowDisk' => $low,
            'freeMb' => $free === false ? null : (int)($free / 1048576)];
    }

    /** Jobs and resumable uploads not touched for 7 days (their state on the web server; nothing on the remote server). */
    private static function cleanTransfers(): array
    {
        return ['jobs' => Jobs::purge(), 'uploads' => Uploads::purge()];
    }

    private static function cleanShares(): array
    {
        if (Shares::problem() !== null) {
            return ['skipped' => 'share links disabled or folder not writable'];
        }
        return ['deleted' => Shares::gc(true)];
    }

    /** Rate files: only the last hour matters. Slot files: touched on every use, so old ones are unused. */
    private static function cleanLimits(): array
    {
        $n = 0;
        $limit = time() - 86400;
        foreach (['rates', 'slots', 'conn'] as $sub) {
            foreach (glob(App::tmpDir() . '/limits/' . $sub . '/*') ?: [] as $f) {
                if ((int)@filemtime($f) < $limit && @unlink($f)) {
                    $n++;
                }
            }
        }
        return ['deleted' => $n];
    }

    /** Action log: delete expired rows in batches (short locks, small transactions), at most ~60 s per run. */
    private static function cleanLog(): array
    {
        $days = (int)App::cfg('log_retention_days', 90);
        $pdo = Db::get();
        if ($days <= 0 || !$pdo) {
            return ['skipped' => $days <= 0 ? 'log_retention_days = 0 (keep forever)' : 'no database'];
        }
        $before = (new \DateTimeImmutable("-{$days} days"))->format('Y-m-d H:i:s');
        $stmt = $pdo->prepare('DELETE FROM n2f_action_log WHERE created_at < ? LIMIT 5000');
        $n = 0;
        $t0 = time();
        do {
            $stmt->execute([$before]);
            $c = $stmt->rowCount();
            $n += $c;
        } while ($c === 5000 && time() - $t0 < 60);
        return ['deleted' => $n, 'olderThan' => $before];
    }

    /** Delete rows older than $days in batches (short locks), at most ~30 s. */
    private static function purge(string $table, string $col, string $before, string $extra = ''): int
    {
        $pdo = Db::get();
        $limit = Db::isMysql() ? ' LIMIT 5000' : '';
        $st = $pdo->prepare("DELETE FROM $table WHERE $col < ?$extra$limit");
        $n = 0;
        $t0 = time();
        do {
            $st->execute([$before]);
            $c = $st->rowCount();
            $n += $c;
        } while ($limit !== '' && $c === 5000 && time() - $t0 < 30);
        return $n;
    }

    /**
     * Consumption: per-IP rows are personal data, kept usage_ip_days (30); per-server rows are the long-term
     * statistics, kept usage_server_days (400). The number of distinct visitors per server is filled in for the
     * last two days from the access log before its rows are deleted.
     */
    private static function cleanUsage(): array
    {
        $pdo = Db::get();
        if (!$pdo) {
            return ['skipped' => 'no database'];
        }
        $ipDays = (int)self::cfg('usage_ip_days', 30);
        $srvDays = (int)self::cfg('usage_server_days', 400);
        $r = ['ipRows' => 0, 'serverRows' => 0];
        if (Db::isMysql()) {
            $pdo->prepare('UPDATE n2f_usage_server s SET ips = (SELECT COUNT(DISTINCT remote_addr) FROM n2f_action_log a
                WHERE a.server = s.server AND a.created_at >= s.day AND a.created_at < s.day + INTERVAL 1 DAY) WHERE s.day >= ?')
                ->execute([date('Y-m-d', time() - 86400)]);
        }
        if ($ipDays > 0) {
            $r['ipRows'] = self::purge('n2f_usage_ip', 'day', date('Y-m-d', time() - $ipDays * 86400));
        }
        if ($srvDays > 0) {
            $r['serverRows'] = self::purge('n2f_usage_server', 'day', date('Y-m-d', time() - $srvDays * 86400));
        }
        return $r;
    }

    /** Errors not seen for errors_days (90) are deleted; the IP of the last occurrence is shortened after 30 days. */
    private static function cleanErrorLog(): array
    {
        $pdo = Db::get();
        if (!$pdo) {
            return ['skipped' => 'no database'];
        }
        $deleted = self::purge('n2f_error_log', 'last_seen', date('Y-m-d H:i:s', time() - (int)self::cfg('errors_days', 90) * 86400));
        $st = $pdo->prepare("UPDATE n2f_error_log SET last_ip = '' WHERE last_seen < ? AND last_ip <> ''");
        $st->execute([date('Y-m-d H:i:s', time() - 30 * 86400)]);
        return ['deleted' => $deleted, 'anonymised' => $st->rowCount()];
    }

    private static function cleanSecurityLog(): array
    {
        if (!Db::get()) {
            return ['skipped' => 'no database'];
        }
        return ['deleted' => self::purge('n2f_security_log', 'created_at', date('Y-m-d H:i:s', time() - (int)self::cfg('security_days', 180) * 86400))];
    }

    /** Blocks that ended more than blocks_days (90) ago (permanent blocks stay). */
    private static function cleanBlocks(): array
    {
        if (!Db::get()) {
            return ['skipped' => 'no database'];
        }
        return ['deleted' => self::purge('n2f_blocks', 'expires_at', date('Y-m-d H:i:s', time() - (int)self::cfg('blocks_days', 90) * 86400), ' AND expires_at IS NOT NULL')];
    }

    /** Abuse/GDPR requests that were handled ("done") and are older than housekeeping.requests_days. */
    private static function cleanRequests(): array
    {
        $days = (int)self::cfg('requests_days', 1095);
        if ($days <= 0) {
            return ['skipped' => 'kept forever'];
        }
        $limit = time() - $days * 86400;
        $n = 0;
        foreach (SiteRequests::all() as $r) {
            if ($r['status'] === 'done' && (int)$r['created'] < $limit) {
                SiteRequests::update($r['_file'], 'delete');
                $n++;
            }
        }
        return ['deleted' => $n];
    }

    private static function size(string $dir): int
    {
        $b = 0;
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS)) as $f) {
            $b += $f->isFile() ? $f->getSize() : 0;
        }
        return $b;
    }
}

<?php
declare(strict_types=1);

namespace Net2ftp;

/**
 * Server-side translations. Uses the same catalogs as the browser (public/assets/i18n/<code>.json),
 * keyed by the English text. The language comes from the "n2f_lang" cookie, else Accept-Language.
 */
final class I18n
{
    public const LANGUAGES = ['en', 'de', 'es', 'fr', 'nl', 'ru', 'zh-Hans', 'zh-Hant', 'ja', 'he', 'ar'];
    private static ?string $lang = null;
    private static ?array $dict = null;

    public static function language(): string
    {
        if (self::$lang !== null) {
            return self::$lang;
        }
        $c = (string)($_COOKIE[App::cookie('n2f_lang')] ?? '');
        if (in_array($c, self::LANGUAGES, true)) {
            return self::$lang = $c;
        }
        foreach (explode(',', strtolower((string)($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? ''))) as $part) {
            $l = trim(explode(';', $part)[0]);
            if (str_starts_with($l, 'zh')) {
                return self::$lang = preg_match('/(tw|hk|mo|hant)/', $l) ? 'zh-Hant' : 'zh-Hans';
            }
            $base = explode('-', $l)[0];
            $base = $base === 'iw' ? 'he' : $base;
            if (in_array($base, self::LANGUAGES, true)) {
                return self::$lang = $base;
            }
        }
        return self::$lang = 'en';
    }

    /** Use this language for the rest of the request (e.g. from page.php?hl=fr), whatever the cookie says. */
    public static function useLanguage(string $code): void
    {
        if (in_array($code, self::LANGUAGES, true) && $code !== self::$lang) {
            self::$lang = $code;
            self::$dict = null;
        }
    }

    /** Translate an English text; {placeholders} are replaced by $params. */
    public static function t(string $text, array $params = []): string
    {
        $dict = self::dict();
        $s = isset($dict[$text]) && is_string($dict[$text]) && $dict[$text] !== '' ? $dict[$text] : $text;
        if ($params) {
            $s = preg_replace_callback('/\{(\w+)\}/', static fn($m) => array_key_exists($m[1], $params) ? (string)$params[$m[1]] : $m[0], $s) ?? $s;
        }
        return $s;
    }

    /**
     * Count-dependent text: the catalog holds plural forms (CLDR categories, like Intl.PluralRules in the
     * browser). $one is the English singular; {n} is replaced by the number.
     */
    public static function tn(string $text, int $n, ?string $one = null, array $params = []): string
    {
        $params['n'] = $n;
        $v = self::dict()[$text] ?? null;
        if (is_array($v)) {
            $s = $v[self::category($n)] ?? $v['other'] ?? $text;
        } else {
            $s = is_string($v) && $v !== '' ? $v : ($n === 1 && $one !== null ? $one : $text);
        }
        return preg_replace_callback('/\{(\w+)\}/', static fn($m) => array_key_exists($m[1], $params) ? (string)$params[$m[1]] : $m[0], $s) ?? $s;
    }

    /** CLDR plural category of an integer for the current language. */
    public static function category(int $n): string
    {
        $n = abs($n);
        switch (self::language()) {
            case 'fr':
                return $n <= 1 ? 'one' : 'other';
            case 'ru':
                $m10 = $n % 10;
                $m100 = $n % 100;
                return $m10 === 1 && $m100 !== 11 ? 'one'
                    : ($m10 >= 2 && $m10 <= 4 && ($m100 < 12 || $m100 > 14) ? 'few' : 'many');
            case 'he':
                return $n === 1 ? 'one' : ($n === 2 ? 'two' : 'other');
            case 'ar':
                $m100 = $n % 100;
                return match (true) {
                    $n === 0 => 'zero', $n === 1 => 'one', $n === 2 => 'two',
                    $m100 >= 3 && $m100 <= 10 => 'few', $m100 >= 11 => 'many', default => 'other',
                };
            case 'ja':
            case 'zh-Hans':
            case 'zh-Hant':
                return 'other';
            default:
                return $n === 1 ? 'one' : 'other';
        }
    }

    private static function dict(): array
    {
        if (self::$dict !== null) {
            return self::$dict;
        }
        $lang = self::language();
        self::$dict = [];
        if ($lang !== 'en') {
            $file = N2F_ROOT . '/public/assets/i18n/' . $lang . '.json';
            $json = is_file($file) ? json_decode((string)file_get_contents($file), true) : null;
            self::$dict = is_array($json) ? $json : [];
        }
        return self::$dict;
    }
}

<?php
declare(strict_types=1);

namespace Net2ftp;

use Net2ftp\Driver\S3Driver;

use Net2ftp\Driver\Driver;

/**
 * Copy, move and delete of folders of any size, as resumable background jobs driven by the browser.
 *
 * A job is worked on in short steps (the browser calls `jobstep` again and again, by default with 2 workers in
 * parallel), so no request comes near a PHP, web-server or proxy timeout. Everything a step does is saved
 * right away, so a job continues where it stopped after a network error, a crashed request, a closed browser
 * or a new login.
 *
 *  1. scan   — folders are listed one at a time (in parallel by the workers). Copies create the target
 *              folders during the scan; files are written to the job's plan (one JSON line per file).
 *  2. files  — workers take files from the plan. Large files are copied in pieces and resumed at the byte
 *              where they stopped. When a second connection is free, data streams directly from one connection
 *              to the other; otherwise each piece passes through memory (and a temp file if it is large).
 *              Files can be worked on while the scan is still running.
 *  3. dirs   — delete and move remove the emptied source folders, deepest first.
 *
 * Files under tmp_dir/jobs/<account>/: <id>.json (state, saved under <id>.lock), <id>.plan, <id>.dirs, <id>.err.
 * No passwords are stored: a job can only be continued by someone logged in to the same account.
 */
final class Jobs
{
    /** A claimed folder or file belongs to its worker for this long; then another worker may take it over. */
    private const LEASE = 90;
    private const TRIES = 3;
    public const KEEP_DAYS = 7;

    private ?Driver $a = null;        // main connection of this step
    private ?Driver $b = null;        // second connection (streaming copies), when one is free
    private bool $noStream = false;
    private int $moved = 0;
    private int $streamed = 0;
    private int $buffered = 0;
    private float $deadline = 0;

    public function __construct(private string $account, private string $id, private array $params, private string $gate)
    {
    }

    // ================================================================== storage

    public static function dir(string $account): string
    {
        $d = App::tmpDir() . '/jobs/' . preg_replace('/[^a-f0-9]/', '', $account);
        if (!is_dir($d) && !@mkdir($d, 0700, true) && !is_dir($d)) {
            throw new UserError('The folder for temporary files is not writable.', 500);
        }
        return $d;
    }

    private static function file(string $account, string $id, string $ext): string
    {
        if (!preg_match('/^[a-f0-9]{16}$/', $id)) {
            throw new UserError('This job no longer exists.', 404);
        }
        return self::dir($account) . '/' . $id . '.' . $ext;
    }

    public static function load(string $account, string $id): ?array
    {
        $f = self::file($account, $id, 'json');
        for ($i = 0; $i < 5; $i++) {
            if (!is_file($f)) {
                return null;
            }
            $st = json_decode((string)@file_get_contents($f), true);
            if (is_array($st)) {
                return $st;
            }
            usleep(20000);   // being replaced right now (Windows: written in place, see App::replaceFile)
        }
        return null;
    }

    /** Read-modify-write the state under the job's lock. $fn receives the state by reference. */
    public static function update(string $account, string $id, callable $fn): mixed
    {
        $lock = fopen(self::file($account, $id, 'lock'), 'c');
        flock($lock, LOCK_EX);
        try {
            $st = self::load($account, $id);
            if ($st === null) {
                throw new UserError('This job no longer exists.', 404);
            }
            $r = $fn($st);
            $st['updated'] = time();
            $tmp = self::file($account, $id, 'json') . '.new';
            file_put_contents($tmp, json_encode($st, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
            if (!App::replaceFile($tmp, self::file($account, $id, 'json'))) {
                throw new UserError('The folder for temporary files is not writable.', 500);
            }
            return $r;
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    /**
     * Create a job. $files: [[src, dst|null, size]] known files; $dirs: [[src, dst|null]] folders to scan;
     * $remove: source folders to remove at the end (delete, move).
     */
    public static function create(string $account, string $kind, string $src, ?string $target, array $names, array $files, array $dirs, array $remove): array
    {
        $id = bin2hex(random_bytes(8));
        $plan = '';
        $bytes = 0;
        foreach ($files as [$s, $d, $z]) {
            $plan .= json_encode(['s' => $s, 'd' => $d, 'z' => (int)$z], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
            $bytes += (int)$z;
        }
        $dl = '';
        foreach ($remove as $p) {
            $dl .= json_encode(['p' => $p, 'n' => substr_count(trim($p, '/'), '/')], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
        }
        file_put_contents(self::file($account, $id, 'plan'), $plan);
        file_put_contents(self::file($account, $id, 'dirs'), $dl);
        $st = [
            'id' => $id, 'kind' => $kind, 'status' => 'running', 'phase' => 'scan',
            'src' => $src, 'target' => $target, 'names' => array_slice($names, 0, 20), 'count' => count($names),
            'queue' => array_values(array_map(static fn($x) => [$x[0], $x[1]], $dirs)), 'claims' => [],
            'cursor' => 0, 'inflight' => (object)[], 'scanDone' => !$dirs,
            'totals' => ['files' => count($files), 'bytes' => $bytes, 'dirs' => count($dirs)],
            'done' => ['files' => 0, 'bytes' => 0, 'dirs' => 0], 'failed' => 0,
            'dirsDone' => 0, 'dirsTotal' => count($remove), 'dirsLease' => 0,
            'rate' => 0, 'created' => time(), 'updated' => time(), 'finished' => 0, 'logged' => false,
            'meta' => Session::meta(),
        ];
        file_put_contents(self::file($account, $id, 'json'), json_encode($st, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        return $st;
    }

    public static function delete(string $account, string $id): void
    {
        foreach (['json', 'plan', 'dirs', 'err', 'lock', 'dirs.sorted'] as $ext) {
            @unlink(self::file($account, $id, $ext));
        }
        foreach (glob(self::file($account, $id, 'mp*')) ?: [] as $f) {
            @unlink($f);                            // a cancelled job has aborted these already
        }
    }

    /** Jobs of this account: unfinished ones, and finished ones from the last day that were not dismissed. */
    public static function listFor(string $account): array
    {
        $out = [];
        foreach (glob(self::dir($account) . '/*.json') ?: [] as $f) {
            $st = json_decode((string)@file_get_contents($f), true);
            if (!is_array($st) || !empty($st['dismissed'])) {
                continue;
            }
            if (in_array($st['status'], ['done', 'cancelled'], true) && (int)$st['updated'] < time() - 86400) {
                continue;
            }
            $out[] = self::summary($st, self::dir($account));
        }
        usort($out, static fn($a, $b) => $b['created'] <=> $a['created']);
        return $out;
    }

    /** What the browser shows. */
    public static function summary(array $st, ?string $dir = null): array
    {
        $current = [];
        foreach ((array)$st['inflight'] as $x) {
            if ((int)($x['until'] ?? 0) > time()) {
                $current[] = ['path' => $x['s'], 'size' => (int)$x['z'], 'done' => (int)$x['done']];
            }
        }
        $errors = [];
        if ($dir !== null && (int)$st['failed'] > 0 && is_file($dir . '/' . $st['id'] . '.err')) {
            foreach (array_slice(file($dir . '/' . $st['id'] . '.err', FILE_IGNORE_NEW_LINES) ?: [], 0, 50) as $line) {
                $e = json_decode($line, true);
                if (is_array($e)) {
                    $errors[] = $e['m'];
                }
            }
        }
        return [
            'id' => $st['id'], 'kind' => $st['kind'], 'status' => $st['status'], 'phase' => $st['phase'],
            'src' => $st['src'], 'target' => $st['target'], 'names' => $st['names'], 'count' => $st['count'],
            'scanDone' => (bool)$st['scanDone'], 'totals' => $st['totals'], 'done' => $st['done'], 'failed' => (int)$st['failed'],
            'dirsTotal' => (int)$st['dirsTotal'], 'dirsDone' => (int)$st['dirsDone'],
            'rate' => (int)$st['rate'], 'current' => array_slice($current, 0, 3), 'errors' => $errors,
            'created' => (int)$st['created'], 'updated' => (int)$st['updated'], 'finished' => (int)$st['finished'],
        ];
    }

    public static function workers(array $params, string $gate): int
    {
        $w = max(1, (int)(((array)App::cfg('jobs', []))['workers'] ?? 2));
        return $gate === '' ? $w : max(1, min($w, ConnGate::jobLimit($gate)));
    }

    /** Housekeeping: delete jobs untouched for KEEP_DAYS. */
    public static function purge(): int
    {
        $n = 0;
        $limit = time() - self::KEEP_DAYS * 86400;
        foreach (glob(App::tmpDir() . '/jobs/*/*') ?: [] as $f) {
            if (@filemtime($f) < $limit && @unlink($f)) {
                $n++;
            }
        }
        foreach (glob(App::tmpDir() . '/jobs/*', GLOB_ONLYDIR) ?: [] as $d) {
            @rmdir($d);
        }
        return $n;
    }

    // ================================================================== one step

    /** Work for about $budget seconds; returns the job summary (+ 'wait' when another worker holds the rest). */
    public function step(float $budget): array
    {
        $this->deadline = microtime(true) + $budget;
        $wait = false;
        try {
            $st = self::load($this->account, $this->id) ?? throw new UserError('This job no longer exists.', 404);
            if ($st['status'] === 'running') {
                try {
                    $this->main();
                } catch (UserError $e) {
                    // no free connection (the server's limit is reached by browsing or other jobs):
                    // not an error — the browser tries again in a moment, browsing goes first
                    if (!$e instanceof TooManyConnections && $e->httpStatus() !== 429) {
                        throw $e;
                    }
                    $s2 = self::load($this->account, $this->id);
                    return self::summary($s2, self::dir($this->account)) + ['wait' => true, 'busy' => true];
                }
            }
            while (microtime(true) < $this->deadline) {
                $task = $this->claim();
                if ($task['type'] === 'scan') {
                    $this->scanDir($task);
                } elseif ($task['type'] === 'file') {
                    try {
                        $this->doFile($task);
                    } catch (StepYield) {
                        $wait = true;
                        break;
                    }
                } elseif ($task['type'] === 'dirs') {
                    $this->doDirs();
                } else {
                    $wait = $task['type'] === 'wait';
                    break;
                }
            }
        } finally {
            Usage::add('bytes', $this->moved);
            $this->a?->close();
            $this->b?->close();
        }
        $st = self::load($this->account, $this->id) ?? throw new UserError('This job no longer exists.', 404);
        $this->logIfFinished($st);
        return self::summary($st, self::dir($this->account)) + ['wait' => $wait,
            'step' => ['streamed' => $this->streamed, 'buffered' => $this->buffered]];
    }

    /** Take the next piece of work, under the job lock. */
    private function claim(): array
    {
        return self::update($this->account, $this->id, function (array &$st): array {
            if ($st['status'] !== 'running') {
                return ['type' => 'end'];
            }
            $now = time();
            // 1. a folder to scan (new, or one whose worker vanished)
            if ($st['queue']) {
                $q = array_shift($st['queue']);
                $st['claims'][$q[0]] = [$q[1], $now + self::LEASE];
                return ['type' => 'scan', 's' => $q[0], 'd' => $q[1]];
            }
            foreach ((array)$st['claims'] as $s => [$d, $until]) {
                if ($until < $now) {
                    $st['claims'][$s] = [$d, $now + self::LEASE];
                    return ['type' => 'scan', 's' => $s, 'd' => $d];
                }
            }
            if (!$st['claims'] && !$st['scanDone']) {
                $st['scanDone'] = true;
            }
            if ($st['phase'] === 'scan' && $st['scanDone']) {
                $st['phase'] = 'files';
            }
            // 2. a file: one a vanished worker left half done, or the next one in the plan
            $st['inflight'] = (array)$st['inflight'];
            foreach ($st['inflight'] as $k => $x) {
                if ((int)$x['until'] < $now) {
                    $st['inflight'][$k]['until'] = $now + self::LEASE;
                    return ['type' => 'file', 'key' => (string)$k] + $st['inflight'][$k];
                }
            }
            $planFile = self::file($this->account, $this->id, 'plan');
            clearstatcache(true, $planFile);
            if ($st['cursor'] < (int)@filesize($planFile)) {
                $fp = fopen($planFile, 'rb');
                fseek($fp, (int)$st['cursor']);
                $line = (string)fgets($fp);
                fclose($fp);
                $key = (string)$st['cursor'];
                $st['cursor'] += strlen($line);
                $e = json_decode($line, true);
                if (is_array($e)) {
                    $st['inflight'][$key] = ['s' => $e['s'], 'd' => $e['d'] ?? null, 'z' => (int)$e['z'], 'done' => 0, 'tries' => 0,
                        'until' => $now + self::LEASE];
                    return ['type' => 'file', 'key' => $key] + $st['inflight'][$key];
                }
                return ['type' => 'wait'];
            }
            if (!$st['scanDone'] || $st['inflight']) {
                return ['type' => 'wait'];    // other workers are still scanning or copying
            }
            // 3. remove the emptied folders (delete, move)
            if ((int)$st['dirsDone'] < (int)$st['dirsTotal']) {
                if ((int)$st['dirsLease'] < $now) {
                    $st['phase'] = 'dirs';
                    $st['dirsLease'] = $now + self::LEASE;
                    return ['type' => 'dirs'];
                }
                return ['type' => 'wait'];
            }
            $st['phase'] = 'done';
            $st['status'] = 'done';
            $st['finished'] = $now;
            return ['type' => 'end'];
        });
    }

    // ------------------------------------------------------------------ connections

    private function main(): Driver
    {
        if ($this->a === null && $this->gate !== '') {
            ConnGate::enter($this->gate, 5, 'job-a', true);    // jobs wait briefly, then let browsing go first
        }
        return $this->a ??= Api::connectGated($this->params, $this->gate, 'job-a', true, true);
    }

    /** A second connection to stream copies between, if one is free right now. */
    private function second(): ?Driver
    {
        if ($this->b !== null || $this->noStream || $this->gate === '') {
            return $this->b;
        }
        if (!ConnGate::tryExtra($this->gate, 'job-b')) {
            $this->noStream = true;     // not this step
            return null;
        }
        try {
            $d = DriverFactory::make($this->params);
            $d->connect();
            return $this->b = $d;
        } catch (TooManyConnections) {
            ConnGate::learn($this->gate);
        } catch (\Throwable) {
        }
        ConnGate::leave($this->gate, 'job-b');
        $this->noStream = true;
        return null;
    }

    /** Run $fn, reconnecting when the server briefly refuses (it may still count a connection we just closed). */
    private function retry(callable $fn): mixed
    {
        for ($i = 0; ; $i++) {
            try {
                return $fn();
            } catch (TooManyConnections $e) {
                if ($i >= 3) {
                    throw $e;
                }
                usleep(700000 * ($i + 1));
            }
        }
    }

    // ------------------------------------------------------------------ scan

    private function scanDir(array $t): void
    {
        $s = (string)$t['s'];
        $d = $t['d'] !== null ? (string)$t['d'] : null;
        $kind = self::load($this->account, $this->id)['kind'] ?? '';
        $lines = '';
        $dirLines = '';
        $queue = [];
        $files = 0;
        $bytes = 0;
        $error = null;
        try {
            $entries = $this->retry(fn() => $this->main()->listDir($s));
            foreach ($entries as $e) {
                $cs = Path::join($s, $e['name']);
                $cd = $d !== null ? Path::join($d, $e['name']) : null;
                if ($e['isDir'] && $e['type'] !== 'link') {
                    if ($cd !== null) {
                        $this->mkdirQuiet($cd);
                    }
                    $queue[] = [$cs, $cd];
                    if ($kind !== 'copy') {
                        $dirLines .= json_encode(['p' => $cs, 'n' => substr_count(trim($cs, '/'), '/')], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
                    }
                    continue;
                }
                if ($e['type'] === 'link' && $e['isDir'] && $kind !== 'delete') {
                    continue;   // never follow links to folders (loops; outside the selection)
                }
                $lines .= json_encode(['s' => $cs, 'd' => $cd, 'z' => (int)($e['size'] ?? 0)], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
                $files++;
                $bytes += (int)($e['size'] ?? 0);
            }
        } catch (UserError $e) {
            $error = $e->getMessage();
        }
        self::update($this->account, $this->id, function (array &$st) use ($s, $lines, $dirLines, $queue, $files, $bytes, $error): void {
            if ($lines !== '') {
                file_put_contents(self::file($this->account, $this->id, 'plan'), $lines, FILE_APPEND);
            }
            if ($dirLines !== '') {
                file_put_contents(self::file($this->account, $this->id, 'dirs'), $dirLines, FILE_APPEND);
            }
            unset($st['claims'][$s]);
            $st['queue'] = array_merge($st['queue'], $queue);
            $st['totals']['files'] += $files;
            $st['totals']['bytes'] += $bytes;
            $st['totals']['dirs'] += count($queue);
            $st['dirsTotal'] += substr_count($dirLines, "\n");
            $st['done']['dirs']++;
            if ($error !== null) {
                $this->recordError($st, $s, $error);
            }
        });
    }

    private function mkdirQuiet(string $path): void
    {
        try {
            $this->retry(fn() => $this->main()->mkdir($path));
        } catch (UserError $e) {
            $st = $this->main()->stat($path);
            if (!$st || !$st['isDir']) {
                throw $e;
            }
        }
    }

    // ------------------------------------------------------------------ files

    private function doFile(array $t): void
    {
        $key = (string)$t['key'];
        $s = (string)$t['s'];
        $d = $t['d'] !== null ? (string)$t['d'] : null;
        $z = (int)$t['z'];
        $off = (int)$t['done'];
        $kind = self::load($this->account, $this->id)['kind'] ?? '';
        try {
            if ($kind === 'delete') {
                try {
                    $this->retry(fn() => $this->main()->deleteFile($s));
                } catch (UserError $e) {
                    if ($this->main()->stat($s)) {
                        throw $e;
                    }   // already gone (e.g. deleted by a worker that crashed before saving): fine
                }
                $this->finishFile($key, 0);
                return;
            }
            $main = $this->main();
            if ($main instanceof S3Driver && $z >= $main->partCopyThreshold()) {
                if (!$this->partCopy($main, $key, $s, (string)$d, $z, $off)) {
                    return;                     // continues in the next step
                }
            } elseif ($off === 0 && $main->copyFile($s, $d)) {
                $this->moved += $z;             // server-side copy (S3)
                $this->progress($key, $z, $z);
            } else {
                $resumed = $off > 0;
                $pieces = 0;
                do {
                    if (microtime(true) >= $this->deadline && $pieces > 0) {
                        $this->release($key);   // continue in the next step
                        return;
                    }
                    $n = $this->transfer($s, (string)$d, $off, $z);
                    $pieces++;
                    $off += $n;
                    $this->moved += $n;
                    $this->progress($key, $off, $n);
                    if ($n === 0 && $off < $z && microtime(true) >= $this->deadline) {
                        $this->release($key);   // out of time before any data moved: next step
                        return;
                    }
                    if ($n === 0 && $off < $z) {
                        // nothing more to read: the source got shorter since the scan
                        $now = $this->main()->stat($s);
                        if ($now && (int)$now['size'] <= $off) {
                            break;
                        }
                        throw new UserError('Could not download {path}.', 400, ['path' => $s]);
                    }
                } while ($off < $z);
                if ($resumed || $pieces > 1) {
                    $ds = $this->main()->stat((string)$d);
                    if (!$ds || (int)$ds['size'] !== $off) {
                        throw new UserError('The copy of {path} has the wrong size; it will be copied again.', 500, ['path' => $s]);
                    }
                }
            }
            if ($kind === 'move') {
                $this->retry(fn() => $this->main()->deleteFile($s));
            }
            $this->finishFile($key, 0);
        } catch (\Throwable $e) {
            if ($e instanceof TooManyConnections || ($e instanceof UserError && $e->httpStatus() === 429)) {
                $this->release($key);           // no connection right now: not the file's fault, try again later
                $this->a?->close();
                $this->a = null;
                ConnGate::leave($this->gate, 'job-a');
                throw new StepYield();
            }
            $msg = $e instanceof UserError ? $e->getMessage() : 'An unexpected error occurred: ' . $e->getMessage();
            if (!$e instanceof UserError) {
                ErrorLog::exception($e, 'jobstep');
            }
            $wrongSize = $e instanceof UserError && $e->httpStatus() === 500;
            self::update($this->account, $this->id, function (array &$st) use ($key, $s, $msg, $wrongSize): void {
                $st['inflight'] = (array)$st['inflight'];
                if (!isset($st['inflight'][$key])) {
                    return;
                }
                $x = &$st['inflight'][$key];
                $x['tries']++;
                $x['until'] = 0;
                if ($wrongSize) {
                    $st['done']['bytes'] = max(0, $st['done']['bytes'] - (int)$x['done']);
                    $x['done'] = 0;
                }
                if ($x['tries'] >= self::TRIES) {
                    $st['done']['bytes'] = max(0, $st['done']['bytes'] - (int)$x['done']);
                    unset($st['inflight'][$key]);
                    $this->recordError($st, $s, $msg);
                }
            });
            // a broken connection is not reused
            $this->a?->close();
            $this->a = null;
            ConnGate::leave($this->gate, 'job-a');
            $this->b?->close();
            $this->b = null;
            ConnGate::leave($this->gate, 'job-b');
        }
    }

    /**
     * S3 objects over 5 GiB: a multipart upload whose parts are copied on the S3 side (UploadPartCopy), a few per
     * step. The upload id and the finished parts are kept in <id>.mp<key>, so any worker continues where the last
     * one stopped. Returns false when the time of this step is up before the last part.
     */
    private function partCopy(S3Driver $s3, string $key, string $s, string $d, int $z, int $off): bool
    {
        $f = self::file($this->account, $this->id, 'mp' . $key);
        $mp = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
        if (!is_array($mp) || (int)($mp['z'] ?? -1) !== $z || ($mp['d'] ?? '') !== $d) {
            if ($off > 0) {
                $this->progress($key, 0, -$off);    // the parts counted before are lost: start again
            }
            $mp = ['uploadId' => $s3->multipartStart($d), 'd' => $d, 'z' => $z, 'part' => $s3->partCopySize($z), 'etags' => []];
            file_put_contents($f, json_encode($mp));
        }
        $part = (int)$mp['part'];
        $parts = (int)ceil($z / $part);
        $copied = 0;
        while (count($mp['etags']) < $parts) {
            if ($copied > 0 && microtime(true) >= $this->deadline) {
                $this->release($key);
                return false;
            }
            $n = count($mp['etags']) + 1;
            $start = ($n - 1) * $part;
            $end = min($z, $start + $part) - 1;
            try {
                $mp['etags'][(string)$n] = $s3->copyPart($s, $d, (string)$mp['uploadId'], $n, $start, $end);
            } catch (UserError $e) {
                if (str_contains($e->english, 'NoSuchUpload')) {
                    @unlink($f);                    // the upload expired or was aborted: the next try starts over
                }
                throw $e;
            }
            file_put_contents($f, json_encode($mp));
            $copied++;
            $this->moved += $end - $start + 1;
            $this->progress($key, $end + 1, $end - $start + 1);
        }
        $etags = [];
        foreach ($mp['etags'] as $n => $etag) {
            $etags[(int)$n] = (string)$etag;
        }
        $s3->multipartComplete($d, (string)$mp['uploadId'], $etags);
        @unlink($f);
        return true;
    }

    /** Abort the unfinished multipart copies of this job (cancelled or deleted), so S3 doesn't keep their parts. */
    private function abortPartCopies(): void
    {
        foreach (glob(self::dir($this->account) . '/' . $this->id . '.mp*') ?: [] as $f) {
            $mp = json_decode((string)@file_get_contents($f), true);
            $main = $this->main();
            if (is_array($mp) && $main instanceof S3Driver) {
                $main->multipartAbort((string)$mp['d'], (string)$mp['uploadId']);
            }
            @unlink($f);
        }
    }

    /** Copy the next part of a file; returns the bytes written. */
    private function transfer(string $s, string $d, int $off, int $z): int
    {
        if ($z > $off && !$this->noStream && ($src = $this->second()) !== null) {
            try {
                $n = $this->streamCopy($src, $s, $d, $off);
                $this->streamed += $n;
                return $n;
            } catch (\FiberError) {
                $this->noStream = true;         // this PHP build cannot switch fibers here: use pieces
            }
        }
        $n = $this->pieceCopy($s, $d, $off, $z);
        $this->buffered += $n;
        return $n;
    }

    /**
     * Streaming copy between two connections: the reader runs in a Fiber and hands over each block as it
     * arrives, the writer pulls the blocks — no temp file, nothing held in memory beyond one block.
     * Stops at the step's deadline; the next step resumes at the returned offset.
     */
    private function streamCopy(Driver $src, string $s, string $d, int $off): int
    {
        $fiber = new \Fiber(static function () use ($src, $s, $off): void {
            $src->readStream($s, static fn(string $x): bool => \Fiber::suspend($x) !== false, $off);
        });
        $buf = '';
        $ended = false;
        $started = false;
        $readError = null;
        $deadline = $this->deadline;
        $limit = $this->pieceMax();
        $given = 0;
        $source = static function (int $max) use (&$buf, &$ended, &$started, &$readError, &$given, $fiber, $deadline, $limit): ?string {
            if ($limit > 0 && $given >= $limit) {
                return null;
            }
            while ($buf === '' && !$ended) {
                if ($given > 0 && microtime(true) >= $deadline) {   // at least one block per call
                    $ended = true;
                    break;
                }
                try {
                    $x = $started ? $fiber->resume(true) : $fiber->start();
                    $started = true;
                } catch (\FiberError $e) {
                    throw $e;
                } catch (\Throwable $e) {
                    $readError = $e;
                    $ended = true;
                    break;
                }
                if ($fiber->isTerminated()) {
                    $ended = true;
                    break;
                }
                $buf .= (string)$x;
            }
            if ($buf === '') {
                return null;
            }
            $out = substr($buf, 0, $limit > 0 ? min(max(8192, $max), $limit - $given) : max(8192, $max));
            $buf = substr($buf, strlen($out));
            $given += strlen($out);
            return $out;
        };
        try {
            $n = $this->main()->writeStream($d, $source, $off);
        } finally {
            if ($started && !$fiber->isTerminated()) {
                try {
                    $fiber->resume(false);      // tell the reader to stop
                } catch (\Throwable) {
                }
            }
        }
        if ($readError !== null) {
            throw $readError;
        }
        return $n;
    }

    /** One connection: read a piece into a buffer (memory, then a temp file), then write it. */
    private function pieceCopy(string $s, string $d, int $off, int $z): int
    {
        $left = max(0.5, $this->deadline - microtime(true));
        $rate = $this->rate();
        $maxPiece = $this->pieceMax() ?: 256 << 20;
        $piece = (int)min($maxPiece, max(1 << 20, min(256 << 20, $rate > 0 ? $rate * $left * 0.4 : 8 << 20)));
        $len = $z > $off ? min($z - $off, $piece) : -1;
        $buf = fopen('php://temp/maxmemory:' . (16 << 20), 'w+b');
        try {
            $t0 = microtime(true);
            if ($z > $off) {
                $this->retry(fn() => $this->main()->readStream($s, static fn(string $x): bool => fwrite($buf, $x) !== false, $off, $len));
            }
            rewind($buf);
            $n = $this->retry(fn() => $this->main()->writeStream($d, static function (int $max) use ($buf): ?string {
                $x = fread($buf, max(8192, $max));
                return ($x === false || $x === '') ? null : $x;
            }, $off));
            $this->learnRate($n, microtime(true) - $t0);
            return $n;
        } finally {
            fclose($buf);
        }
    }

    /** jobs.piece_max: most bytes per transfer call (0 = automatic; streams are not split). */
    private function pieceMax(): int
    {
        $v = (int)(((array)App::cfg('jobs', []))['piece_max'] ?? 0);
        return $v > 0 ? max(65536, $v) : 0;
    }

    private function rate(): float
    {
        return (float)(self::load($this->account, $this->id)['rate'] ?? 0);
    }

    private function learnRate(int $bytes, float $secs): void
    {
        if ($bytes < (256 << 10) || $secs <= 0) {
            return;
        }
        $r = $bytes / $secs;
        self::update($this->account, $this->id, static function (array &$st) use ($r): void {
            $st['rate'] = (int)($st['rate'] > 0 ? $st['rate'] * 0.6 + $r * 0.4 : $r);
        });
    }

    private function progress(string $key, int $off, int $n): void
    {
        self::update($this->account, $this->id, static function (array &$st) use ($key, $off, $n): void {
            $st['inflight'] = (array)$st['inflight'];
            if (isset($st['inflight'][$key])) {
                $st['inflight'][$key]['done'] = $off;
                $st['inflight'][$key]['until'] = time() + self::LEASE;
            }
            $st['done']['bytes'] += $n;
        });
    }

    private function release(string $key): void
    {
        self::update($this->account, $this->id, static function (array &$st) use ($key): void {
            $st['inflight'] = (array)$st['inflight'];
            if (isset($st['inflight'][$key])) {
                $st['inflight'][$key]['until'] = 0;
            }
        });
    }

    private function finishFile(string $key, int $bytes): void
    {
        self::update($this->account, $this->id, static function (array &$st) use ($key, $bytes): void {
            $st['inflight'] = (array)$st['inflight'];
            unset($st['inflight'][$key]);
            $st['done']['files']++;
            $st['done']['bytes'] += $bytes;
        });
    }

    // ------------------------------------------------------------------ folders (delete, move)

    private function doDirs(): void
    {
        $sorted = self::file($this->account, $this->id, 'dirs.sorted');
        if (!is_file($sorted)) {
            $all = [];
            foreach (file(self::file($this->account, $this->id, 'dirs'), FILE_IGNORE_NEW_LINES) ?: [] as $line) {
                $e = json_decode($line, true);
                if (is_array($e)) {
                    $all[$e['p']] = (int)$e['n'];
                }
            }
            arsort($all);                       // deepest first
            file_put_contents($sorted, implode("\n", array_keys($all)) . "\n");
        }
        $list = file($sorted, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
        $i = (int)(self::load($this->account, $this->id)['dirsDone'] ?? 0);
        $errors = [];
        while ($i < count($list) && microtime(true) < $this->deadline) {
            $p = $list[$i];
            try {
                $this->retry(fn() => $this->main()->rmdir($p));
            } catch (UserError $e) {
                if ($this->main()->stat($p)) {
                    $errors[] = [$p, $e->getMessage()];
                }
            }
            $i++;
        }
        $total = count($list);
        self::update($this->account, $this->id, function (array &$st) use ($i, $total, $errors): void {
            $st['dirsDone'] = $i;
            $st['dirsTotal'] = $total;
            $st['dirsLease'] = 0;
            foreach ($errors as [$p, $m]) {
                $this->recordError($st, $p, $m);
            }
        });
    }

    // ------------------------------------------------------------------ errors, cancel, log

    private function recordError(array &$st, string $path, string $message): void
    {
        $st['failed']++;
        if ($st['failed'] <= 1000) {
            file_put_contents(self::file($this->account, $this->id, 'err'),
                json_encode(['p' => $path, 'm' => $message], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND);
        }
    }

    /** Cancel: stop, and remove the copies of files that were only half done. */
    public function cancel(): array
    {
        $half = self::update($this->account, $this->id, static function (array &$st): array {
            $st['status'] = 'cancelled';
            $st['finished'] = time();
            $out = [];
            if ($st['kind'] !== 'delete') {
                foreach ((array)$st['inflight'] as $x) {
                    if ($x['d'] !== null && (int)$x['done'] > 0 && (int)$x['done'] < (int)$x['z']) {
                        $out[] = $x['d'];
                    }
                }
            }
            $st['inflight'] = (object)[];
            return $out;
        });
        foreach ($half as $d) {
            try {
                $this->main()->deleteFile($d);
            } catch (\Throwable) {
            }
        }
        try {
            $this->abortPartCopies();
        } catch (\Throwable) {
        }
        $this->a?->close();
        $st = self::load($this->account, $this->id);
        $this->logIfFinished($st);
        return self::summary($st, self::dir($this->account));
    }

    /** One row in the action log when the job ends. */
    private function logIfFinished(array $st): void
    {
        if (!in_array($st['status'], ['done', 'cancelled'], true) || !empty($st['logged'])) {
            return;
        }
        $first = self::update($this->account, $this->id, static function (array &$st): bool {
            $was = !empty($st['logged']);
            $st['logged'] = true;
            return !$was;
        });
        if (!$first) {
            return;
        }
        $msg = trim(($st['status'] === 'cancelled' ? 'cancelled; ' : '') . ($st['failed'] ? $st['failed'] . ' failed; ' : '')
            . 'job ' . $st['id'] . ', ' . (time() - (int)$st['created']) . ' s', '; ');
        Logger::log($st['kind'], (array)$st['meta'], [
            'directory' => $st['src'], 'entry' => $st['names'], 'target' => $st['target'] ?? '',
            'count' => (int)$st['done']['files'], 'bytes' => (int)$st['done']['bytes'],
            'status' => $st['failed'] || $st['status'] === 'cancelled' ? 'error' : 'ok', 'message' => $msg,
            'ms' => (int)(((int)($st['finished'] ?: time()) - (int)$st['created']) * 1000),
        ]);
    }
}

/** Internal: a step stops early because no connection is free right now. */
final class StepYield extends \RuntimeException
{
}

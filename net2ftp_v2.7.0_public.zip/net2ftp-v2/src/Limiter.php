<?php
declare(strict_types=1);

namespace Net2ftp;

/**
 * Rate and concurrency limits, using only files and flock() — works without MySQL, on Linux and Windows.
 *
 * Concurrency ("at most N requests at once"): a key has N slot files. A request takes a slot by locking one
 * of them; the lock is held until the request ends, and released by PHP even if the request crashes or times
 * out (the operating system drops the lock with the file handle). No stale state is possible.
 * A request that finds every slot busy waits in line (polling) for up to `queue_seconds`, so a browser's own
 * parallel requests are queued rather than refused; only real overload gets "429 Too many requests".
 *
 * Rates ("at most N events per hour"): a small JSON file per key with the timestamps of recent events, read and
 * written under a lock (sliding window).
 *
 * The files live in storage/tmp/limits/ (names are hashes, so they reveal no IP addresses).
 * Note: on NFS or other network file systems flock() may not be reliable; keep tmp_dir on a local disk.
 */
final class Limiter
{
    /** @var array<string,resource> slot handles held until the request ends */
    private static array $held = [];

    public static function cfg(string $key, int $default): int
    {
        return (int)(((array)App::cfg('rate_limits', []))[$key] ?? $default);
    }

    private static function dir(string $sub): ?string
    {
        $d = App::tmpDir() . '/limits/' . $sub;
        if (!is_dir($d) && !@mkdir($d, 0700, true) && !is_dir($d)) {
            return null;
        }
        return $d;
    }

    private static function file(string $sub, string $key): ?string
    {
        $d = self::dir($sub);
        return $d === null ? null : $d . '/' . substr(hash('sha256', $key), 0, 40);
    }

    // ------------------------------------------------------------------ concurrency

    /**
     * Take one of $slots slots for $key, waiting up to $wait seconds for one to become free.
     * Returns true when a slot is held (or limits are off / the folder is unusable: fail open, logged).
     */
    public static function acquire(string $key, int $slots, float $wait = 0.0, string $holder = ''): bool
    {
        // $holder lets one request hold several slots of the same key (e.g. two connections to one server)
        $hk = $holder === '' ? $key : $key . '#' . $holder;
        if ($slots <= 0 || isset(self::$held[$hk])) {
            return true;
        }
        $base = self::file('slots', $key);
        if ($base === null) {
            error_log('net2ftp: limiter disabled, cannot create ' . App::tmpDir() . '/limits');
            return true;
        }
        $deadline = microtime(true) + $wait;
        do {
            // start at a random slot, so waiting requests don't all fight over slot 0
            $start = random_int(0, $slots - 1);
            for ($i = 0; $i < $slots; $i++) {
                $fp = @fopen($base . '.' . (($start + $i) % $slots), 'c');
                if ($fp === false) {
                    return true;
                }
                if (flock($fp, LOCK_EX | LOCK_NB)) {
                    @touch($base . '.' . (($start + $i) % $slots)); // mtime = last use, for housekeeping
                    self::$held[$hk] = $fp;
                    return true;
                }
                fclose($fp);
            }
            if (microtime(true) >= $deadline) {
                return false;
            }
            usleep(random_int(80000, 160000));
        } while (true);
    }

    public static function release(string $key, string $holder = ''): void
    {
        $hk = $holder === '' ? $key : $key . '#' . $holder;
        if (isset(self::$held[$hk])) {
            flock(self::$held[$hk], LOCK_UN);
            fclose(self::$held[$hk]);
            unset(self::$held[$hk]);
        }
    }

    /** How many of the first $slots slots of $key are taken right now (by anyone, this request included). */
    public static function busy(string $key, int $slots): int
    {
        $base = self::file('slots', $key);
        if ($base === null) {
            return 0;
        }
        $mine = [];
        foreach (self::$held as $hk => $fp) {
            if ($hk === $key || str_starts_with($hk, $key . '#')) {
                $mine[] = (string)stream_get_meta_data($fp)['uri'];
            }
        }
        $n = 0;
        for ($i = 0; $i < $slots; $i++) {
            $f = $base . '.' . $i;
            if (in_array($f, $mine, true)) {
                $n++;
                continue;
            }
            $fp = @fopen($f, 'c');
            if ($fp === false) {
                continue;
            }
            if (flock($fp, LOCK_EX | LOCK_NB)) {
                flock($fp, LOCK_UN);
            } else {
                $n++;
            }
            fclose($fp);
        }
        return $n;
    }

    // ------------------------------------------------------------------ rates

    /** Number of events for $key in the last $window seconds. */
    public static function count(string $key, int $window): int
    {
        $f = self::file('rates', $key);
        if ($f === null || !is_file($f)) {
            return 0;
        }
        $since = time() - $window;
        $ts = json_decode((string)@file_get_contents($f), true);
        return is_array($ts) ? count(array_filter($ts, static fn($t) => is_int($t) && $t > $since)) : 0;
    }

    /**
     * Record one event for $key, unless $max events already happened in the last $window seconds.
     * Returns false (and records nothing) when the limit is reached. $max <= 0 = no limit.
     */
    public static function hit(string $key, int $window, int $max): bool
    {
        if ($max <= 0) {
            return true;
        }
        $f = self::file('rates', $key);
        $fp = $f === null ? false : @fopen($f, 'c+');
        if ($fp === false) {
            return true;
        }
        try {
            flock($fp, LOCK_EX);
            $since = time() - $window;
            $ts = json_decode((string)stream_get_contents($fp), true);
            $ts = array_values(array_filter(is_array($ts) ? $ts : [], static fn($t) => is_int($t) && $t > $since));
            if (count($ts) >= $max) {
                return false;
            }
            $ts[] = time();
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, json_encode(array_slice($ts, -1000)));
            return true;
        } finally {
            flock($fp, LOCK_UN);
            fclose($fp);
        }
    }

    // ------------------------------------------------------------------ the limits net2ftp uses

    /** Every API request: N at once per browser session, M at once per IP address. */
    public static function request(string $sessionId, bool $jobStep = false): void
    {
        $wait = (float)self::cfg('queue_seconds', 20);
        if ($jobStep) {
            // background job steps have their own slots, so they never make the user's browsing wait
            $w = max(1, (int)(((array)App::cfg('jobs', []))['workers'] ?? 2));
            if (!self::acquire('ip:' . App::clientIp(), self::cfg('ip_parallel', 6) + $w, $wait)
                || !self::acquire('job-session:' . $sessionId, $w * 2, $wait)) {
                throw new UserError('Too many requests at the same time. Please wait a moment and try again.', 429);
            }
            return;
        }
        if (!self::acquire('ip:' . App::clientIp(), self::cfg('ip_parallel', 6), $wait)) {
            SecurityLog::event('rate-limit', 'warning', 'Too many parallel requests from this IP (' . self::cfg('ip_parallel', 6) . ')');
            throw new UserError('Too many requests at the same time from your address. Please wait a moment and try again.', 429);
        }
        if ($sessionId !== '' && !self::acquire('session:' . $sessionId, self::cfg('session_parallel', 2), $wait)) {
            SecurityLog::event('rate-limit', 'info', 'Too many parallel requests in one session');
            throw new UserError('Too many requests at the same time. Please wait a moment and try again.', 429);
        }
    }

    /** Zip, extract, share: a few at once on the whole server, one at a time per session. */
    public static function heavy(string $sessionId): void
    {
        if (!self::acquire('heavy-session:' . $sessionId, self::cfg('heavy_per_session', 1), 2)) {
            throw new UserError('Please wait until your other zip, extract or share job has finished.', 429);
        }
        if (!self::acquire('heavy', self::cfg('heavy_parallel', 4), (float)self::cfg('queue_seconds', 20))) {
            SecurityLog::event('rate-limit', 'warning', 'All ' . self::cfg('heavy_parallel', 4) . ' slots for zip/extract/share jobs busy');
            throw new UserError('The server is busy with other large jobs. Please try again in a minute.', 503);
        }
    }

    /**
     * Before a login (or fingerprint check): attempts per IP, per target server, and failed attempts per account.
     * Counted whether or not the login succeeds — scripted mass logins with stolen passwords are slowed down too.
     */
    public static function login(string $host, string $user): void
    {
        $window = self::cfg('login_window', 3600);
        $account = 'fail:' . strtolower($host) . '|' . $user;
        if (self::count($account, $window) >= self::cfg('failed_logins_per_account', 10)) {
            SecurityLog::event('rate-limit', 'warning', 'Too many failed logins for account ' . $user, $host);
            throw new UserError('Too many failed logins for this account on this server. Please wait an hour and try again.', 429);
        }
        if (!self::hit('login-ip:' . App::clientIp(), $window, self::cfg('logins_per_ip', 30))) {
            SecurityLog::event('rate-limit', 'warning', 'Too many logins from this IP (' . self::cfg('logins_per_ip', 30) . ' per hour)', $host);
            throw new UserError('Too many logins from your address. Please wait an hour and try again.', 429);
        }
        if (!self::hit('login-host:' . strtolower($host), $window, self::cfg('logins_per_server', 100))) {
            SecurityLog::event('rate-limit', 'warning', 'Too many logins to this server from all visitors (' . self::cfg('logins_per_server', 100) . ' per hour)', $host);
            throw new UserError('Too many logins to this server through this site. Please try again later.', 429);
        }
    }

    public static function loginFailed(string $host, string $user): void
    {
        self::hit('fail:' . strtolower($host) . '|' . $user, self::cfg('login_window', 3600), 1000000);
    }
}

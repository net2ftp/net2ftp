<?php
declare(strict_types=1);

namespace Net2ftp;

/**
 * Writes one row per user action into n2f_action_log (the net2ftp "log access" equivalent).
 * Logging never breaks the user's request: database errors go to the PHP error log.
 */
final class Logger
{
    private static bool $hashColumn = true;

    /** @param array{protocol?:string,server?:string,port?:int,username?:string} $conn */
    public static function log(string $action, array $conn, array $d = []): void
    {
        if (!App::cfg('log_enabled', true)) {
            return;
        }
        $pdo = Db::get();
        if (!$pdo) {
            return;
        }
        $entry = $d['entry'] ?? '';
        if (is_array($entry)) {
            $entry = json_encode(array_values($entry), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO n2f_action_log
                 (created_at, session_hash, remote_addr, remote_port, user_agent, referer, protocol, server, port, username,
                  action, directory, entry, target, bytes, item_count, duration_ms, status, message' . (self::$hashColumn ? ', file_hash' : '') . ')
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?' . (self::$hashColumn ? ',?' : '') . ')'
            );
            $values = [
                (new \DateTimeImmutable())->format('Y-m-d H:i:s.v'),
                session_id() !== '' ? substr(hash('sha256', session_id()), 0, 16) : '',
                App::clientIp(),
                isset($_SERVER['REMOTE_PORT']) ? (int)$_SERVER['REMOTE_PORT'] : null,
                self::cut((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 255),
                self::cut((string)($_SERVER['HTTP_REFERER'] ?? ''), 255),
                self::cut((string)($conn['protocol'] ?? ''), 8),
                self::cut((string)($conn['server'] ?? ''), 255),
                isset($conn['port']) ? (int)$conn['port'] : null,
                self::cut((string)($conn['username'] ?? ''), 255),
                self::cut($action, 32),
                self::cut((string)($d['directory'] ?? ''), 1024),
                self::cut((string)$entry, 65000),
                self::cut((string)($d['target'] ?? ''), 1024),
                max(0, (int)($d['bytes'] ?? 0)),
                max(0, (int)($d['count'] ?? 0)),
                max(0, (int)($d['ms'] ?? 0)),
                ($d['status'] ?? 'ok') === 'error' ? 'error' : 'ok',
                self::cut((string)($d['message'] ?? ''), 1024),
            ];
            if (self::$hashColumn) {
                $values[] = (string)($d['file_hash'] ?? '');
            }
            $stmt->execute($values);
        } catch (\Throwable $e) {
            if (self::$hashColumn && str_contains($e->getMessage(), 'file_hash')) {
                // database from before version 2.3 (sql/upgrade-2.3.sql not run yet): log without the new column
                self::$hashColumn = false;
                self::log($action, $conn, $d);
                return;
            }
            error_log('net2ftp: action log failed: ' . $e->getMessage());
        }
    }

    /** Number of failed logins from this IP inside the configured window. */
    public static function recentLoginFailures(string $ip): int
    {
        $pdo = Db::get();
        if (!$pdo) {
            return 0;
        }
        try {
            $since = (new \DateTimeImmutable('-' . (int)App::cfg('login_failure_window', 900) . ' seconds'))->format('Y-m-d H:i:s');
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM n2f_action_log WHERE remote_addr = ? AND action = 'login' AND status = 'error' AND created_at >= ?");
            $stmt->execute([$ip, $since]);
            return (int)$stmt->fetchColumn();
        } catch (\Throwable) {
            return 0;
        }
    }

    private static function cut(string $s, int $len): string
    {
        return mb_strlen($s) > $len ? mb_substr($s, 0, $len) : $s;
    }
}

<?php
declare(strict_types=1);

namespace Net2ftp;

/** Maintenance mode, switched on in admin.php → Maintenance: users see the message and can't log in. */
final class Maintenance
{
    private static function file(): string
    {
        return N2F_ROOT . '/storage/maintenance.json';
    }

    /** The message, or null when maintenance mode is off. */
    public static function message(): ?string
    {
        if (!is_file(self::file())) {
            return null;
        }
        $m = json_decode((string)@file_get_contents(self::file()), true);
        return is_array($m) ? (string)($m['message'] ?? '') : null;
    }

    public static function on(string $message): void
    {
        @file_put_contents(self::file(), json_encode(['message' => $message, 'since' => time()], JSON_UNESCAPED_UNICODE), LOCK_EX);
    }

    public static function off(): void
    {
        @unlink(self::file());
    }

    /** Throws 503 for everything except the session call, while maintenance mode is on. */
    public static function check(): void
    {
        $m = self::message();
        if ($m !== null) {
            throw new UserError($m !== '' ? $m : 'net2ftp is being maintained. Please try again in a few minutes.', 503);
        }
    }
}

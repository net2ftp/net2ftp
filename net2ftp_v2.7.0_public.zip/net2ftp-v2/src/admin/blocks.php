<?php
/** Admin → Blocks: IP addresses / ranges and servers that may not use net2ftp. */

$now = date('Y-m-d H:i:s');
$active = $q('SELECT * FROM n2f_blocks WHERE expires_at IS NULL OR expires_at > ? ORDER BY created_at DESC', [$now]);
$expired = $q('SELECT * FROM n2f_blocks WHERE expires_at <= ? ORDER BY expires_at DESC LIMIT 30', [$now]);
$banned = (array)\Net2ftp\App::cfg('banned_servers', []);
$table = static function (array $rows, bool $isActive) use ($h, $form): string {
    $o = '<div class="tbl-wrap"><table><thead><tr><th>Type</th><th>Value</th><th>Reason</th><th>Added</th><th>Until</th><th>By</th><th>Hits</th><th>Last hit</th><th></th></tr></thead><tbody>';
    foreach ($rows as $b) {
        $o .= '<tr><td><span class="tag">' . $h($b['kind']) . '</span></td><td class="mono">' . $h($b['value']) . '</td><td class="wrap">' . $h($b['reason']) . '</td>'
            . '<td class="mono">' . $h(substr((string)$b['created_at'], 0, 16)) . '</td><td class="mono">' . ($b['expires_at'] ? $h(substr((string)$b['expires_at'], 0, 16)) : '<b>permanent</b>') . '</td>'
            . '<td>' . $h($b['created_by']) . '</td><td>' . (int)$b['hits'] . '</td><td class="mono">' . $h(substr((string)$b['last_hit'], 0, 16)) . '</td>'
            . '<td>' . $form('block-delete', ['id' => $b['id']], $isActive ? 'Remove' : 'Delete', 'btn btn-ghost danger') . '</td></tr>';
    }
    if (!$rows) {
        $o .= '<tr><td colspan="9" class="muted">' . ($isActive ? 'Nothing is blocked.' : 'No expired blocks.') . '</td></tr>';
    }
    return $o . '</tbody></table></div>';
};
?>
<form class="card filters" method="post">
  <input type="hidden" name="_csrf" value="<?= $h($csrf) ?>"><input type="hidden" name="do" value="block-add">
  <select class="input" name="kind"><option value="ip">IP address / range</option><option value="server">Server</option></select>
  <input class="input" name="value" required placeholder="203.0.113.7 · 198.51.100.0/24 · ftp.example.com · *.example.org">
  <input class="input q" name="reason" maxlength="255" placeholder="Reason (for your records)">
  <select class="input" name="hours"><option value="1">1 hour</option><option value="24" selected>24 hours</option><option value="168">7 days</option><option value="720">30 days</option><option value="0">Permanent</option></select>
  <button class="btn btn-primary">Block</button>
</form>
<p class="muted small">A blocked IP gets "Access from your address is blocked" (with your abuse e-mail address) for everything, including share links. A blocked server can't be logged into, and open sessions to it end at their next action.
  IP ranges use CIDR notation (/8 to /32 for IPv4, /8 to /128 for IPv6). Servers may use * wildcards.</p>
<section class="card"><h2 class="pad-h">Active <small class="muted"><?= count($active) ?></small></h2><?= $table($active, true) ?></section>
<?php if ($banned): ?><p class="muted small">Also blocked in config.php (banned_servers): <?= $h(implode(', ', $banned)) ?></p><?php endif ?>
<section class="card"><h2 class="pad-h">Expired <small class="muted">last 30</small></h2><?= $table($expired, false) ?></section>

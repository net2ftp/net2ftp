<?php
/** Admin → Dashboard. Variables from admin_page.php: $pdo, $q, $h, $human, $dur, $form. */

use Net2ftp\App;
use Net2ftp\Housekeeping;
use Net2ftp\Shares;
use Net2ftp\Usage;

$today = date('Y-m-d');
$t = $q('SELECT COALESCE(SUM(requests),0) requests, COALESCE(SUM(logins),0) logins, COALESCE(SUM(bytes),0) bytes, COALESCE(SUM(ms),0) ms,
         COALESCE(SUM(errors),0) errors, COALESCE(SUM(refused),0) refused FROM n2f_usage_ip WHERE day = ?', [$today])[0];
$ips = (int)$q('SELECT COUNT(*) n FROM n2f_usage_ip WHERE day = ?', [$today])[0]['n'];
$servers = (int)$q('SELECT COUNT(*) n FROM n2f_usage_server WHERE day = ? AND server <> ?', [$today, Usage::SHARES])[0]['n'];
$crit = (int)$q("SELECT COUNT(*) n FROM n2f_security_log WHERE severity = 'critical' AND created_at >= ?", [date('Y-m-d H:i:s', time() - 86400)])[0]['n'];
$openErr = (int)$q("SELECT COUNT(*) n FROM n2f_error_log WHERE status = 'open'")[0]['n'];

// last 30 days: from the per-server table (kept 400 days) and the per-IP table (kept 30 days)
$from = date('Y-m-d', time() - 29 * 86400);
$days = [];
for ($i = 29; $i >= 0; $i--) {
    $days[date('Y-m-d', time() - $i * 86400)] = ['bytes' => 0, 'logins' => 0, 'ips' => 0, 'requests' => 0];
}
foreach ($q('SELECT day, SUM(bytes) bytes, SUM(logins) logins, SUM(requests) requests FROM n2f_usage_ip WHERE day >= ? GROUP BY day', [$from]) as $r) {
    $days[(string)$r['day']] = ['bytes' => (int)$r['bytes'], 'logins' => (int)$r['logins'], 'requests' => (int)$r['requests'], 'ips' => 0] + ($days[(string)$r['day']] ?? []);
}
foreach ($q('SELECT day, COUNT(*) n FROM n2f_usage_ip WHERE day >= ? GROUP BY day', [$from]) as $r) {
    $days[(string)$r['day']]['ips'] = (int)$r['n'];
}

/** Small bar chart (inline SVG, no JavaScript). */
$bars = static function (array $days, string $key, callable $fmt, string $color) use ($h): string {
    $vals = array_column($days, $key);
    $max = max(1, ...$vals);
    $w = 22; $gap = 4; $hgt = 110; $n = count($vals);
    $svg = '<svg class="chart" viewBox="0 0 ' . ($n * ($w + $gap)) . ' ' . ($hgt + 18) . '" role="img" aria-label="' . $h($key) . ' per day">';
    $i = 0;
    foreach ($days as $day => $d) {
        $v = (int)$d[$key];
        $bh = $v > 0 ? max(2, round($v / $max * $hgt)) : 0;
        $x = $i * ($w + $gap);
        $svg .= '<g><title>' . $h(date('D j M', strtotime($day)) . ': ' . $fmt($v)) . '</title>'
            . '<rect x="' . $x . '" y="' . ($hgt - $bh) . '" width="' . $w . '" height="' . $bh . '" rx="3" fill="' . $color . '"/>'
            . (($i % 7 === 2 || $i === $n - 1) ? '<text x="' . ($x + $w / 2) . '" y="' . ($hgt + 14) . '" text-anchor="middle">' . $h(date('j.n.', strtotime($day))) . '</text>' : '')
            . '</g>';
        $i++;
    }
    return $svg . '</svg><p class="chart-max muted small">max ' . $h($fmt($max)) . '</p>';
};
$lim = Usage::limits();
$topIps = $q('SELECT * FROM n2f_usage_ip WHERE day = ? ORDER BY bytes DESC, ms DESC LIMIT 5', [$today]);
$topSrv = $q('SELECT * FROM n2f_usage_server WHERE day = ? ORDER BY bytes DESC, ms DESC LIMIT 5', [$today]);
$events = $q("SELECT * FROM n2f_security_log WHERE severity IN ('warning','critical') ORDER BY id DESC LIMIT 8");
$hk = Housekeeping::status();
$sharesUsed = Shares::problem() === null ? Shares::usedBytes() : 0;
$tmpBytes = 0;
foreach (glob(App::tmpDir() . '/n2f*') ?: [] as $f) {
    $tmpBytes += is_file($f) ? (int)filesize($f) : 0;
}
$free = function_exists('disk_free_space') ? @disk_free_space(App::tmpDir()) : false;
$pct = static fn($v, $max) => $max > 0 ? min(100, (int)round($v / $max * 100)) : 0;
?>
<div class="stats">
  <div class="card stat"><b><?= number_format((int)$t['requests']) ?></b><span>Requests today</span></div>
  <div class="card stat"><b><?= number_format((int)$t['logins']) ?></b><span>Logins today</span></div>
  <div class="card stat"><b><?= number_format($ips) ?></b><span>Visitors (IPs) today</span></div>
  <div class="card stat"><b><?= number_format($servers) ?></b><span>Servers used today</span></div>
  <div class="card stat"><b><?= $h($human($t['bytes'])) ?></b><span>Data transferred today</span></div>
  <div class="card stat"><b><?= $h($dur($t['ms'])) ?></b><span>Server time today</span></div>
  <div class="card stat <?= $t['refused'] ? 'warn-card' : '' ?>"><b><?= number_format((int)$t['refused']) ?></b><span>Requests refused (limits, blocks)</span></div>
  <a class="card stat <?= $openErr ? 'warn-card' : '' ?>" href="?tab=errors"><b><?= $openErr ?></b><span>Open software errors</span></a>
  <a class="card stat <?= $crit ? 'crit-card' : '' ?>" href="?tab=security&amp;severity=critical"><b><?= $crit ?></b><span>Critical security events (24 h)</span></a>
</div>

<div class="grid2">
  <section class="card pad"><h2>Data per day <small class="muted">last 30 days</small></h2><?= $bars($days, 'bytes', $human, 'var(--accent)') ?></section>
  <section class="card pad"><h2>Visitors (IPs) per day</h2><?= $bars($days, 'ips', static fn($v) => number_format($v) . ' IPs', '#12875f') ?></section>
  <section class="card pad"><h2>Logins per day</h2><?= $bars($days, 'logins', static fn($v) => number_format($v) . ' logins', '#7c5cff') ?></section>
  <section class="card pad"><h2>Storage</h2>
    <table class="kv">
      <tr><th>Leftover temporary files</th><td><?= $h($human($tmpBytes)) ?> <span class="muted">(deleted after <?= (int)(((array)App::cfg('housekeeping', []))['tmp_days'] ?? 7) ?> days)</span></td></tr>
      <tr><th>Share links</th><td><?= $h($human($sharesUsed)) ?> of <?= $h($human((int)(((array)App::cfg('shares', []))['total_bytes'] ?? 0))) ?></td></tr>
      <tr><th>Free disk space</th><td><?= $free === false ? '—' : $h($human($free)) ?></td></tr>
      <tr><th>Last cleanup</th><td><?= isset($hk['started']) ? $h(date('Y-m-d H:i', (int)$hk['started'])) . ' (' . $h($hk['mode'] ?? '') . ')' : '<span class="warn">never</span>' ?> · <a href="?tab=maintenance">Maintenance</a></td></tr>
    </table>
  </section>
</div>

<div class="grid2">
  <section class="card"><h2 class="pad-h">Top visitors today <a class="small" href="?tab=usage">all</a></h2>
    <table><thead><tr><th>IP</th><th>Data</th><th>Server time</th><th>Logins</th></tr></thead><tbody>
    <?php foreach ($topIps as $r): ?>
      <tr><td class="mono"><a href="?tab=investigate&amp;ip=<?= $h(rawurlencode($r['ip'])) ?>"><?= $h($r['ip']) ?></a></td>
        <td><?= $h($human($r['bytes'])) ?> <span class="meter"><i style="width:<?= $pct($r['bytes'], $lim['ip_bytes']) ?>%"></i></span></td>
        <td><?= $h($dur($r['ms'])) ?> <span class="meter"><i style="width:<?= $pct($r['ms'], $lim['ip_seconds'] * 1000) ?>%"></i></span></td>
        <td><?= (int)$r['logins'] ?></td></tr>
    <?php endforeach ?>
    <?php if (!$topIps): ?><tr><td colspan="4" class="muted">No activity today.</td></tr><?php endif ?>
    </tbody></table></section>
  <section class="card"><h2 class="pad-h">Top servers today <a class="small" href="?tab=usage">all</a></h2>
    <table><thead><tr><th>Server</th><th>Data</th><th>Server time</th><th>Logins</th></tr></thead><tbody>
    <?php foreach ($topSrv as $r): ?>
      <tr><td><a href="?tab=investigate&amp;server=<?= $h(rawurlencode($r['server'])) ?>"><?= $h($r['server']) ?></a></td>
        <td><?= $h($human($r['bytes'])) ?> <span class="meter"><i style="width:<?= $pct($r['bytes'], $lim['server_bytes']) ?>%"></i></span></td>
        <td><?= $h($dur($r['ms'])) ?> <span class="meter"><i style="width:<?= $pct($r['ms'], $lim['server_seconds'] * 1000) ?>%"></i></span></td>
        <td><?= (int)$r['logins'] ?></td></tr>
    <?php endforeach ?>
    <?php if (!$topSrv): ?><tr><td colspan="4" class="muted">No activity today.</td></tr><?php endif ?>
    </tbody></table></section>
</div>

<section class="card"><h2 class="pad-h">Recent security warnings <a class="small" href="?tab=security">all</a></h2>
  <table><thead><tr><th>Time</th><th>Severity</th><th>Event</th><th>IP</th><th>Server</th><th>Detail</th></tr></thead><tbody>
  <?php foreach ($events as $e): ?>
    <tr><td class="mono"><?= $h($e['created_at']) ?></td><td class="sev-<?= $h($e['severity']) ?>"><?= $h($e['severity']) ?></td><td><span class="tag"><?= $h($e['event']) ?></span></td>
      <td class="mono"><?= $h($e['remote_addr']) ?></td><td><?= $h($e['server']) ?></td><td class="wrap"><?= $h($e['detail']) ?></td></tr>
  <?php endforeach ?>
  <?php if (!$events): ?><tr><td colspan="6" class="muted">No warnings.</td></tr><?php endif ?>
  </tbody></table></section>

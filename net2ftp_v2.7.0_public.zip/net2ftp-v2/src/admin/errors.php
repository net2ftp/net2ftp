<?php
/** Admin → Errors: software errors (PHP and browser), grouped, newest first. */

$status = in_array($_GET['status'] ?? 'open', ['open', 'resolved', 'all'], true) ? ($_GET['status'] ?? 'open') : 'open';
$rows = $status === 'all'
    ? $q('SELECT * FROM n2f_error_log ORDER BY last_seen DESC LIMIT 300')
    : $q('SELECT * FROM n2f_error_log WHERE status = ? ORDER BY last_seen DESC LIMIT 300', [$status]);
$resolved = (int)$q("SELECT COUNT(*) n FROM n2f_error_log WHERE status = 'resolved'")[0]['n'];
?>
<p class="muted">Errors in the software itself — PHP exceptions and crashes, and JavaScript errors in visitors' browsers — grouped: each distinct error is one row with a counter.
  Mark an error resolved after fixing it; it reopens automatically if it happens again. User errors (wrong password, permission denied …) are in the access log.</p>
<div class="filters card">
  <?php foreach (['open' => 'Open', 'resolved' => 'Resolved', 'all' => 'All'] as $k => $l): ?>
    <a class="btn <?= $status === $k ? 'btn-primary' : 'btn-ghost' ?>" href="?tab=errors&amp;status=<?= $k ?>"><?= $l ?></a>
  <?php endforeach ?>
  <span class="grow"></span>
  <?php if ($resolved): ?><?= $form('errors-purge', [], "Delete $resolved resolved", 'btn btn-ghost danger') ?><?php endif ?>
</div>
<section class="card"><div class="tbl-wrap"><table>
  <thead><tr><th>Last seen</th><th>Count</th><th>Source</th><th>Error</th><th>Where</th><th>Version</th><th></th></tr></thead><tbody>
  <?php foreach ($rows as $e): ?>
    <tr class="<?= $e['status'] === 'resolved' ? 'dim' : '' ?>">
      <td class="mono"><?= $h(substr((string)$e['last_seen'], 0, 16)) ?><br><span class="muted small">first <?= $h(substr((string)$e['first_seen'], 0, 10)) ?></span></td>
      <td><b><?= number_format((int)$e['occurrences']) ?></b></td>
      <td><span class="tag"><?= $h($e['source']) ?></span></td>
      <td class="wrap"><b><?= $h($e['level']) ?></b> <?= $h($e['message']) ?>
        <?php if ($e['trace'] || $e['url']): ?><details><summary class="small">details</summary>
          <pre class="trace"><?= $h(trim('URL: ' . $e['url'] . "\nAction: " . $e['action'] . "\nBrowser: " . $e['user_agent'] . "\nLast IP: " . $e['last_ip'] . "\n\n" . $e['trace'])) ?></pre></details><?php endif ?></td>
      <td class="mono wrap"><?= $h($e['file']) ?>:<?= (int)$e['line'] ?></td>
      <td class="mono"><?= $h($e['app_version']) ?><br><span class="muted small">PHP <?= $h($e['php_version']) ?></span></td>
      <td><?= $e['status'] === 'open' ? $form('error-resolve', ['fp' => $e['fingerprint']], 'Mark resolved') : $form('error-reopen', ['fp' => $e['fingerprint']], 'Reopen') ?></td>
    </tr>
  <?php endforeach ?>
  <?php if (!$rows): ?><tr><td colspan="7" class="muted"><?= $status === 'open' ? 'No open errors.' : 'Nothing here.' ?></td></tr><?php endif ?>
  </tbody></table></div></section>

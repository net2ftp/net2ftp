<?php
/** Admin → SSH known hosts (trust on first use). */

$hosts = $q('SELECT * FROM n2f_known_hosts ORDER BY last_seen DESC');
?>
<p class="muted">SSH host keys seen so far. When a server's key changes, logins are refused (possible man-in-the-middle attack).
  Forget a key only when the change is legitimate (e.g. the server was reinstalled): the next login stores the new key.</p>
<div class="card"><div class="tbl-wrap"><table>
  <thead><tr><th>Host</th><th>Port</th><th>Fingerprint</th><th>First seen</th><th>Last seen</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($hosts as $k): ?>
    <tr><td><?= $h($k['host']) ?></td><td><?= (int)$k['port'] ?></td><td class="mono"><?= $h($k['fingerprint']) ?></td>
      <td class="mono"><?= $h($k['first_seen']) ?></td><td class="mono"><?= $h($k['last_seen']) ?></td>
      <td><?= $form('forget-host', ['host' => $k['host'], 'port' => $k['port']], 'Forget key', 'btn btn-ghost danger') ?></td></tr>
  <?php endforeach ?>
  <?php if (!$hosts): ?><tr><td colspan="6" class="muted">No SSH hosts recorded yet.</td></tr><?php endif ?>
  </tbody>
</table></div></div>

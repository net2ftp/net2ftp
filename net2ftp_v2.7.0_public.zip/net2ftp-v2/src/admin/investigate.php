<?php
/**
 * Admin → Investigate: everything done on a server (or by an IP / user) in a time window — the answer to an
 * abuse enquiry ("who changed index.html on ftp.example.com at 10:05?"). Exportable as CSV.
 */

$f = [
    'server' => strtolower(trim((string)($_GET['server'] ?? ''))),
    'ip'     => trim((string)($_GET['ip'] ?? '')),
    'user'   => trim((string)($_GET['user'] ?? '')),
    'from'   => preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $_GET['from'] ?? '') ? $_GET['from'] : date('Y-m-d\TH:i', time() - 7 * 86400),
    'to'     => preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $_GET['to'] ?? '') ? $_GET['to'] : date('Y-m-d\TH:i', time() + 60),
];
$where = ['created_at >= ?', 'created_at <= ?'];
$args = [str_replace('T', ' ', $f['from']) . ':00', str_replace('T', ' ', $f['to']) . ':59'];
if ($f['server'] !== '') { $where[] = 'server = ?'; $args[] = $f['server']; }
if ($f['ip'] !== '') { $where[] = 'remote_addr = ?'; $args[] = $f['ip']; }
if ($f['user'] !== '') { $where[] = 'username = ?'; $args[] = $f['user']; }
$searched = $f['server'] !== '' || $f['ip'] !== '' || $f['user'] !== '';
$w = 'WHERE ' . implode(' AND ', $where);
$cols = 'created_at, remote_addr, user_agent, session_hash, protocol, server, port, username, action, directory, entry, target, bytes, status, message, file_hash';

if (isset($_GET['export'])) {
    // CSV for the reply to the complainant or the police (UTF-8 with BOM, so Excel opens it correctly)
    if (!$searched) {
        http_response_code(400);
        exit('Choose a server, IP or user first.');
    }
    $st = $pdo->prepare("SELECT $cols FROM n2f_action_log $w ORDER BY id LIMIT 100000");
    $st->execute($args);
    \Net2ftp\SecurityLog::event('admin-action', 'info', 'Exported the access log for ' . trim("server {$f['server']} ip {$f['ip']} user {$f['user']}") . " from {$f['from']} to {$f['to']}");
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="net2ftp-' . preg_replace('/[^a-z0-9.\-]+/i', '_', $f['server'] ?: ($f['ip'] ?: $f['user'])) . '-' . date('Ymd-His') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['time (' . date_default_timezone_get() . ')', 'ip', 'browser', 'session', 'protocol', 'server', 'port', 'user', 'action', 'directory', 'entry', 'target', 'bytes', 'status', 'message', 'sha256 of uploaded file']);
    while ($r = $st->fetch()) {
        // a cell starting with = + - @ would be run as a formula by spreadsheet programs
        fputcsv($out, array_map(static fn($v) => is_string($v) && preg_match('/^[=+\-@\t\r]/', $v) ? "'" . $v : $v, array_values($r)));
    }
    fclose($out);
    return;
}

$rows = $searched ? $q("SELECT * FROM n2f_action_log $w ORDER BY id DESC LIMIT 2000", $args) : [];
$byIp = $searched ? $q("SELECT remote_addr, COUNT(*) n, MIN(created_at) first, MAX(created_at) last, SUM(action = 'upload') uploads, SUM(action = 'delete') deletes,
        SUM(action = 'login' AND status = 'error') failed FROM n2f_action_log $w GROUP BY remote_addr ORDER BY n DESC LIMIT 50", $args) : [];
?>
<p class="muted">Everything done on a server, or by an IP address or user, in a time window — to answer abuse enquiries. Times are server time (<?= $h(date_default_timezone_get()) ?>).</p>
<form class="card filters" method="get">
  <input type="hidden" name="tab" value="investigate">
  <label>Server <input class="input" name="server" value="<?= $h($f['server']) ?>" placeholder="ftp.example.com"></label>
  <label>IP <input class="input" name="ip" value="<?= $h($f['ip']) ?>" placeholder="203.0.113.7"></label>
  <label>User <input class="input" name="user" value="<?= $h($f['user']) ?>"></label>
  <label>From <input class="input" type="datetime-local" name="from" value="<?= $h($f['from']) ?>"></label>
  <label>To <input class="input" type="datetime-local" name="to" value="<?= $h($f['to']) ?>"></label>
  <button class="btn btn-primary">Show</button>
  <?php if ($searched): ?><a class="btn btn-ghost" href="<?= $h($qs(['export' => 'csv'])) ?>">Export CSV</a><?php endif ?>
</form>
<?php if (!$searched): ?>
  <p class="muted">Enter a server, an IP address or a user name.</p>
<?php else: ?>
  <section class="card"><h2 class="pad-h">By IP address</h2>
    <table><thead><tr><th>IP</th><th>Actions</th><th>Uploads</th><th>Deletes</th><th>Failed logins</th><th>First</th><th>Last</th><th></th></tr></thead><tbody>
    <?php foreach ($byIp as $r): ?>
      <tr><td class="mono"><?= $h($r['remote_addr']) ?></td><td><?= (int)$r['n'] ?></td><td><?= (int)$r['uploads'] ?></td><td><?= (int)$r['deletes'] ?></td><td><?= (int)$r['failed'] ?></td>
        <td class="mono"><?= $h(substr((string)$r['first'], 0, 19)) ?></td><td class="mono"><?= $h(substr((string)$r['last'], 0, 19)) ?></td>
        <td><?= $form('block-add', ['kind' => 'ip', 'value' => $r['remote_addr'], 'hours' => 24 * 7, 'reason' => 'Abuse on ' . ($f['server'] ?: 'servers')], 'Block 7 days') ?></td></tr>
    <?php endforeach ?>
    <?php if (!$byIp): ?><tr><td colspan="8" class="muted">Nothing found in this time window.</td></tr><?php endif ?>
    </tbody></table></section>
  <section class="card"><h2 class="pad-h">Actions <small class="muted"><?= count($rows) ?><?= count($rows) === 2000 ? '+ (export for all)' : '' ?></small></h2>
    <div class="tbl-wrap"><table>
      <thead><tr><th>Time</th><th>IP</th><th>Action</th><th>Status</th><th>Server</th><th>User</th><th>Directory</th><th>Entry</th><th>Target</th><th>Bytes</th><th>Message</th></tr></thead><tbody>
      <?php foreach ($rows as $r): ?>
        <tr><td class="mono"><?= $h(substr((string)$r['created_at'], 0, 19)) ?></td><td class="mono"><?= $h($r['remote_addr']) ?></td>
          <td><span class="tag"><?= $h($r['action']) ?></span></td><td class="st-<?= $h($r['status']) ?>"><?= $h($r['status']) ?></td>
          <td><?= $h($r['server']) ?></td><td><?= $h($r['username']) ?></td><td class="mono wrap"><?= $h($r['directory']) ?></td>
          <td class="mono wrap"><?= $h(mb_strimwidth((string)$r['entry'], 0, 160, '…')) ?></td><td class="mono wrap"><?= $h($r['target']) ?></td>
          <td><?= $r['bytes'] ? $h($human($r['bytes'])) : '' ?></td><td class="wrap"><?= $h($r['message']) ?></td></tr>
      <?php endforeach ?>
      </tbody></table></div></section>
<?php endif ?>

<?php
/** Admin → Access log (n2f_action_log). */

$f = [
    'action'  => trim((string)($_GET['action'] ?? '')),
    'status'  => in_array($_GET['status'] ?? '', ['ok', 'error'], true) ? $_GET['status'] : '',
    'q'       => trim((string)($_GET['q'] ?? '')),
    'session' => preg_match('/^[0-9a-f]{16}$/', $_GET['session'] ?? '') ? $_GET['session'] : '',
    'from'    => preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['from'] ?? '') ? $_GET['from'] : '',
    'to'      => preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['to'] ?? '') ? $_GET['to'] : '',
];
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 100;
$where = [];
$args = [];
if ($f['action'] !== '') { $where[] = 'action = ?'; $args[] = $f['action']; }
if ($f['status'] !== '') { $where[] = 'status = ?'; $args[] = $f['status']; }
if ($f['session'] !== '') { $where[] = 'session_hash = ?'; $args[] = $f['session']; }
if ($f['from'] !== '') { $where[] = 'created_at >= ?'; $args[] = $f['from'] . ' 00:00:00'; }
if ($f['to'] !== '') { $where[] = 'created_at <= ?'; $args[] = $f['to'] . ' 23:59:59'; }
if ($f['q'] !== '') {
    $where[] = '(remote_addr LIKE ? OR server LIKE ? OR username LIKE ? OR directory LIKE ? OR entry LIKE ? OR target LIKE ? OR message LIKE ?)';
    array_push($args, ...array_fill(0, 7, '%' . $f['q'] . '%'));
}
$w = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$total = (int)$q("SELECT COUNT(*) n FROM n2f_action_log $w", $args)[0]['n'];
$rows = $q("SELECT * FROM n2f_action_log $w ORDER BY id DESC LIMIT $per OFFSET " . (($page - 1) * $per), $args);
$actions = array_column($q('SELECT DISTINCT action FROM n2f_action_log ORDER BY action'), 'action');
?>
<p class="muted">One row per action (login, list, upload, …) with the visitor's IP. Kept <?= (int)\Net2ftp\App::cfg('log_retention_days', 90) ?> days. Click a session to see one visit from start to end.</p>
<div class="card">
  <form class="filters" method="get">
    <input type="hidden" name="tab" value="log">
    <input class="input q" name="q" value="<?= $h($f['q']) ?>" placeholder="Search IP, server, user, path, message…">
    <select class="input" name="action"><option value="">All actions</option>
      <?php foreach ($actions as $a): ?><option <?= $f['action'] === $a ? 'selected' : '' ?>><?= $h($a) ?></option><?php endforeach ?></select>
    <select class="input" name="status"><option value="">Any status</option><option value="ok" <?= $f['status'] === 'ok' ? 'selected' : '' ?>>OK</option><option value="error" <?= $f['status'] === 'error' ? 'selected' : '' ?>>Error</option></select>
    <input class="input" type="date" name="from" value="<?= $h($f['from']) ?>"><input class="input" type="date" name="to" value="<?= $h($f['to']) ?>">
    <?php if ($f['session']): ?><input type="hidden" name="session" value="<?= $h($f['session']) ?>"><span class="tag">session <?= $h($f['session']) ?></span><?php endif ?>
    <button class="btn btn-primary">Filter</button><a class="btn btn-ghost" href="?tab=log">Reset</a>
  </form>
  <div class="tbl-wrap"><table>
    <thead><tr><th>Time</th><th>Status</th><th>Action</th><th>IP</th><th>Session</th><th>Protocol · Server</th><th>User</th><th>Directory</th><th>Entry</th><th>Target</th><th>Bytes</th><th>ms</th><th>Message</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td class="mono"><?= $h(substr((string)$r['created_at'], 0, 19)) ?></td>
        <td class="st-<?= $h($r['status']) ?>"><?= $h($r['status']) ?></td>
        <td><span class="tag"><?= $h($r['action']) ?></span></td>
        <td class="mono"><a href="?tab=investigate&amp;ip=<?= $h(rawurlencode((string)$r['remote_addr'])) ?>"><?= $h($r['remote_addr']) ?></a></td>
        <td class="mono"><?php if ($r['session_hash']): ?><a href="<?= $h($qs(['session' => $r['session_hash'], 'page' => null])) ?>"><?= $h(substr((string)$r['session_hash'], 0, 6)) ?></a><?php endif ?></td>
        <td><?= $h(strtoupper((string)$r['protocol'])) ?> · <a href="?tab=investigate&amp;server=<?= $h(rawurlencode((string)$r['server'])) ?>"><?= $h($r['server']) ?></a><?= $r['port'] ? ':' . (int)$r['port'] : '' ?></td>
        <td><?= $h($r['username']) ?></td>
        <td class="mono wrap"><?= $h($r['directory']) ?></td>
        <td class="mono wrap"><?= $h(mb_strimwidth((string)$r['entry'], 0, 200, '…')) ?></td>
        <td class="mono wrap"><?= $h($r['target']) ?></td>
        <td><?= $r['bytes'] ? $h($human($r['bytes'])) : '' ?></td>
        <td><?= (int)$r['duration_ms'] ?></td>
        <td class="wrap"><?= $h($r['message']) ?></td>
      </tr>
    <?php endforeach ?>
    <?php if (!$rows): ?><tr><td colspan="13" class="muted">No log entries.</td></tr><?php endif ?>
    </tbody>
  </table></div>
  <div class="pager">
    <span><?= number_format($total) ?> entries</span>
    <span>
      <?php if ($page > 1): ?><a class="btn btn-ghost" href="<?= $h($qs(['page' => $page - 1])) ?>">← Newer</a><?php endif ?>
      <?php if ($page * $per < $total): ?><a class="btn btn-ghost" href="<?= $h($qs(['page' => $page + 1])) ?>">Older →</a><?php endif ?>
    </span>
  </div>
</div>

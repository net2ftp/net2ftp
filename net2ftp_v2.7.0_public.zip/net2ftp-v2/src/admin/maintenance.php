<?php
/** Admin → Maintenance: cleanup job and maintenance mode. */

use Net2ftp\App;
use Net2ftp\Housekeeping;
use Net2ftp\Maintenance;

$hk = Housekeeping::status();
$last = $_SESSION['admin_cleanup'] ?? null;
unset($_SESSION['admin_cleanup']);
$cfg = (array)App::cfg('housekeeping', []);
$mm = Maintenance::message();
$retention = [
    ['Access log (n2f_action_log)', App::cfg('log_retention_days', 90) . ' days'],
    ['Consumption per IP (n2f_usage_ip)', ($cfg['usage_ip_days'] ?? 30) . ' days (personal data)'],
    ['Consumption per server (n2f_usage_server)', ($cfg['usage_server_days'] ?? 400) . ' days (statistics)'],
    ['Error log (n2f_error_log)', ($cfg['errors_days'] ?? 90) . ' days after last seen; IP shortened after 30 days'],
    ['Security events (n2f_security_log)', ($cfg['security_days'] ?? 180) . ' days'],
    ['Expired blocks (n2f_blocks)', ($cfg['blocks_days'] ?? 90) . ' days after they ended'],
    ['Leftover temporary files', ($cfg['tmp_days'] ?? 7) . ' days (1 hour when the disk is nearly full)'],
    ['Handled abuse/GDPR requests', ($cfg['requests_days'] ?? 1095) . ' days'],
    ['Copy/move/delete jobs and unfinished uploads (paths, progress; no passwords)', '7 days after the last activity'],
];
$show = $last ?? $hk;
?>
<div class="grid2">
  <section class="card pad">
    <h2>Cleanup job</h2>
    <p class="muted">Mode: <b><?= $h($cfg['mode'] ?? 'auto') ?></b> — <?= ($cfg['mode'] ?? 'auto') === 'cron'
        ? 'run by cron with bin/cleanup.php.'
        : 'runs at most once an hour after a visitor\'s request. A cron job is better: see the README.' ?></p>
    <p>Last run: <b><?= isset($hk['started']) ? $h(date('Y-m-d H:i:s', (int)$hk['started'])) . ' (' . $h($hk['mode'] ?? '') . ', ' . $h($hk['seconds'] ?? '') . ' s)' : 'never' ?></b></p>
    <?= $form('cleanup', [], 'Run cleanup now', 'btn btn-primary') ?>
    <?php if ($show): ?>
      <h3><?= $last ? 'Result' : 'Last result' ?></h3>
      <table class="kv">
      <?php foreach (['tmp' => 'Temporary files', 'shares' => 'Expired shares', 'limits' => 'Limiter files', 'log' => 'Access log rows', 'usage' => 'Consumption rows',
          'errorlog' => 'Error log rows', 'security' => 'Security events', 'blocks' => 'Expired blocks', 'requests' => 'Requests', 'transfers' => 'Old jobs and unfinished uploads'] as $k => $label): if (!isset($show[$k])) continue; $r = $show[$k]; ?>
        <tr><th><?= $h($label) ?></th><td><?= isset($r['skipped']) ? '<span class="muted">' . $h($r['skipped']) . '</span>'
            : $h(implode(', ', array_map(static fn($kk, $vv) => $kk . ': ' . (is_bool($vv) ? ($vv ? 'yes' : 'no') : (is_array($vv) ? json_encode($vv) : $vv)), array_keys($r), $r))) ?></td></tr>
      <?php endforeach ?>
      <?php if (!empty($show['errors']) && is_array($show['errors']) && array_is_list($show['errors'])): ?><tr><th>Errors</th><td class="st-error"><?= $h(implode('; ', $show['errors'])) ?></td></tr><?php endif ?>
      </table>
    <?php endif ?>
  </section>
  <section class="card pad">
    <h2>What is kept, and for how long</h2>
    <table class="kv"><?php foreach ($retention as [$what, $how]): ?><tr><th><?= $h($what) ?></th><td><?= $h($how) ?></td></tr><?php endforeach ?></table>
    <p class="muted small">Change these in config.php (<code>log_retention_days</code>, <code>housekeeping</code>). They are also listed in the privacy policy.</p>
  </section>
</div>
<section class="card pad">
  <h2>Maintenance mode</h2>
  <?php if ($mm !== null): ?>
    <p class="alert">On: users see “<?= $h($mm !== '' ? $mm : 'net2ftp is being maintained. Please try again in a few minutes.') ?>” and can't log in. Share links keep working.</p>
    <?= $form('maintenance-off', [], 'Switch maintenance mode off', 'btn btn-primary') ?>
  <?php else: ?>
    <p class="muted">For upgrades: users see a message on the login page and can't log in; requests of users already logged in are refused. Share links keep working.</p>
    <form method="post" class="filters"><input type="hidden" name="_csrf" value="<?= $h($csrf) ?>"><input type="hidden" name="do" value="maintenance-on">
      <input class="input q" name="message" maxlength="300" placeholder="net2ftp is being maintained. Please try again in a few minutes.">
      <button class="btn btn-ghost danger">Switch maintenance mode on</button></form>
  <?php endif ?>
</section>

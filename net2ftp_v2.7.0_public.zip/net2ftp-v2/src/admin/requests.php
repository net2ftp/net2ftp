<?php
/** Admin → Requests: abuse reports and GDPR requests sent through page.php. */

use Net2ftp\Shares;
use Net2ftp\SiteRequests;

$requests = SiteRequests::all();
?>
<p class="muted">Abuse reports and data protection (GDPR) requests. Stored in <span class="mono"><?= $h(SiteRequests::dir()) ?></span>; handled ones are deleted after
  <?= (int)(((array)\Net2ftp\App::cfg('housekeeping', []))['requests_days'] ?? 1095) ?> days.
  GDPR requests must be answered within 30 days: use <a href="?tab=investigate">Investigate</a> with the person's IP addresses, servers and user names.</p>
<?php if (!$requests): ?><div class="card pad"><span class="muted">No requests yet.</span></div><?php endif ?>
<?php foreach ($requests as $r): $gdpr = $r['kind'] === 'gdpr'; ?>
  <div class="card req <?= $r['status'] === 'done' ? 'req-done' : '' ?>">
    <div class="req-head">
      <span class="tag"><?= $gdpr ? 'GDPR' : 'Abuse' ?></span> <b class="mono"><?= $h($r['ref']) ?></b>
      <span><?= $h($r['type']) ?></span>
      <span class="muted"><?= $h(date('Y-m-d H:i', (int)$r['created'])) ?> · <?= $h($r['ip']) ?> · <?= $h($r['lang']) ?></span>
      <span class="<?= $r['status'] === 'done' ? 'st-ok' : 'warn' ?>"><?= $r['status'] === 'done' ? 'done' : 'open' ?></span>
      <span class="req-actions">
        <?= $form($r['status'] === 'done' ? 'request-open' : 'request-done', ['file' => $r['_file']], $r['status'] === 'done' ? 'Reopen' : 'Mark done') ?>
        <?= $form('request-delete', ['file' => $r['_file']], 'Delete', 'btn btn-ghost danger') ?>
      </span>
    </div>
    <dl class="req-body">
      <dt>From</dt><dd><?= $h($r['name'] ?: '—') ?> &lt;<a href="mailto:<?= $h($r['email']) ?>?subject=<?= $h(rawurlencode('Re: ' . $r['ref'])) ?>"><?= $h($r['email']) ?></a>&gt;</dd>
      <?php foreach (($gdpr ? ['identifiers' => 'How to find the data'] : ['server' => 'Server', 'url' => 'Page / link', 'when' => 'When']) as $k => $label): if (($r[$k] ?? '') === '') continue; ?>
        <dt><?= $h($label) ?></dt><dd class="wrap"><?= nl2br($h($r[$k])) ?></dd>
      <?php endforeach ?>
      <?php if (!$gdpr && !empty($r['server'])): ?>
        <dt>Investigate</dt><dd><a href="?tab=investigate&amp;server=<?= $h(rawurlencode(strtolower(trim((string)$r['server'])))) ?>">All actions on <?= $h($r['server']) ?></a></dd>
      <?php endif ?>
      <?php if (!$gdpr && !empty($r['share'])): $exists = is_dir(Shares::dir() . '/' . $r['share']); ?>
        <dt>Share link</dt><dd><span class="mono"><?= $h($r['share']) ?></span>
          <?= $exists ? $form('delete-share', ['id' => $r['share']], 'Delete this share', 'btn btn-ghost danger') : '<span class="muted">(already deleted or expired)</span>' ?></dd>
      <?php endif ?>
      <?php if ($r['message'] !== ''): ?><dt>Message</dt><dd class="wrap"><?= nl2br($h($r['message'])) ?></dd><?php endif ?>
      <?php if ($gdpr): ?><dt>Log</dt><dd><a href="?tab=investigate&amp;ip=<?= $h(rawurlencode($r['ip'])) ?>">Entries from <?= $h($r['ip']) ?></a> (the request's own IP; search for the others it names)</dd><?php endif ?>
    </dl>
  </div>
<?php endforeach ?>

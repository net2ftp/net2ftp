<?php
/** Admin → Security: limits reached, blocks, private-network attempts, host key changes, mass uploads, admin logins. */

use Net2ftp\SecurityLog;

$f = [
    'event'    => isset(SecurityLog::EVENTS[$_GET['event'] ?? '']) ? $_GET['event'] : '',
    'severity' => in_array($_GET['severity'] ?? '', ['info', 'warning', 'critical'], true) ? $_GET['severity'] : '',
    'ip'       => trim((string)($_GET['ip'] ?? '')),
];
$where = [];
$args = [];
if ($f['event'] !== '') { $where[] = 'event = ?'; $args[] = $f['event']; }
if ($f['severity'] !== '') { $where[] = 'severity = ?'; $args[] = $f['severity']; }
if ($f['ip'] !== '') { $where[] = 'remote_addr = ?'; $args[] = $f['ip']; }
$w = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$rows = $q("SELECT * FROM n2f_security_log $w ORDER BY id DESC LIMIT 500", $args);
$sum = $q('SELECT event, severity, COUNT(*) n FROM n2f_security_log WHERE created_at >= ? GROUP BY event, severity ORDER BY n DESC', [date('Y-m-d H:i:s', time() - 86400)]);
?>
<?php if ($sum): ?>
<div class="chips">
  <span class="muted small">Last 24 h:</span>
  <?php foreach ($sum as $s): ?><a class="chip sev-<?= $h($s['severity']) ?>" href="?tab=security&amp;event=<?= $h($s['event']) ?>"><?= $h($s['event']) ?> <b><?= (int)$s['n'] ?></b></a><?php endforeach ?>
</div>
<?php endif ?>
<form class="filters card" method="get">
  <input type="hidden" name="tab" value="security">
  <select class="input" name="event"><option value="">All events</option>
    <?php foreach (SecurityLog::EVENTS as $k => $label): ?><option value="<?= $h($k) ?>" <?= $f['event'] === $k ? 'selected' : '' ?>><?= $h($k . ' — ' . $label) ?></option><?php endforeach ?></select>
  <select class="input" name="severity"><option value="">Any severity</option>
    <?php foreach (['critical', 'warning', 'info'] as $s): ?><option <?= $f['severity'] === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach ?></select>
  <input class="input" name="ip" value="<?= $h($f['ip']) ?>" placeholder="IP">
  <button class="btn btn-primary">Filter</button><a class="btn btn-ghost" href="?tab=security">Reset</a>
</form>
<section class="card"><div class="tbl-wrap"><table>
  <thead><tr><th>Time</th><th>Severity</th><th>Event</th><th>IP</th><th>Server</th><th>User</th><th>Detail</th><th></th></tr></thead><tbody>
  <?php foreach ($rows as $e): ?>
    <tr><td class="mono"><?= $h($e['created_at']) ?></td><td class="sev-<?= $h($e['severity']) ?>"><?= $h($e['severity']) ?></td>
      <td><span class="tag" title="<?= $h(SecurityLog::EVENTS[$e['event']] ?? '') ?>"><?= $h($e['event']) ?></span></td>
      <td class="mono"><a href="?tab=investigate&amp;ip=<?= $h(rawurlencode((string)$e['remote_addr'])) ?>"><?= $h($e['remote_addr']) ?></a></td>
      <td><?= $h($e['server']) ?></td><td><?= $h($e['username']) ?></td><td class="wrap"><?= $h($e['detail']) ?></td>
      <td class="nowrap"><?= $e['remote_addr'] !== '' && !str_starts_with((string)$e['event'], 'admin') ? $form('block-add', ['kind' => 'ip', 'value' => $e['remote_addr'], 'hours' => 24, 'reason' => $e['event'] . ': ' . mb_substr((string)$e['detail'], 0, 200)], 'Block 24 h') : '' ?></td></tr>
  <?php endforeach ?>
  <?php if (!$rows): ?><tr><td colspan="8" class="muted">No security events.</td></tr><?php endif ?>
  </tbody></table></div></section>

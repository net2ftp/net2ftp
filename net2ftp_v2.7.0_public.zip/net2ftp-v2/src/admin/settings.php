<?php
/**
 * Admin → Settings: the effective configuration, read-only (secrets hidden). Settings are changed in config.php
 * on purpose: an admin panel that can rewrite config.php would let anyone who gets into it take over the server.
 */

use Net2ftp\App;

$config = (array)App::all();
$secret = static fn(string $k): bool => (bool)preg_match('/pass|secret|key|token|hash/i', $k);
$render = static function ($v, string $k) use (&$render, $h, $secret): string {
    if ($secret($k) && $v !== '' && $v !== null && !is_array($v)) {
        return '<span class="muted">••••••• (set)</span>';
    }
    if (is_array($v)) {
        if ($v === []) {
            return '<span class="muted">[]</span>';
        }
        if (array_is_list($v) && !array_filter($v, 'is_array')) {
            return $h(implode(', ', array_map(static fn($x) => is_bool($x) ? ($x ? 'true' : 'false') : (string)$x, $v)));
        }
        $o = '<table class="kv nested">';
        foreach ($v as $kk => $vv) {
            $o .= '<tr><th>' . $h($kk) . '</th><td>' . $render($vv, (string)$kk) . '</td></tr>';
        }
        return $o . '</table>';
    }
    if (is_bool($v)) {
        return $v ? 'true' : 'false';
    }
    if (is_int($v) && $v >= 1 << 20 && preg_match('/bytes/i', $k)) {
        return $h(number_format($v) . ' (' . \Net2ftp\FileOps::human($v) . ')');
    }
    return $v === '' || $v === null ? '<span class="muted">—</span>' : $h((string)$v);
};
?>
<p class="muted">The effective configuration (config.php over the defaults). Read-only on purpose: settings are changed in config.php. Passwords, keys and secrets are hidden.</p>
<div class="card"><table class="kv settings">
  <?php foreach ($config as $k => $v): ?><tr><th class="mono"><?= $h($k) ?></th><td><?= $render($v, (string)$k) ?></td></tr><?php endforeach ?>
</table></div>

<?php
/** Admin → Share links (all of them; the links themselves are only visible to their creators). */

use Net2ftp\FileOps;
use Net2ftp\Shares;

$shares = [];
if (($p = Shares::problem()) === null) {
    Shares::gc(true);
    foreach (Shares::all() as $m) {
        $shares[] = $m;
    }
    usort($shares, static fn($a, $b) => $b['created'] <=> $a['created']);
}
$total = array_sum(array_column($shares, 'bytes'));
$cap = (int)Shares::cfg('total_bytes', 10 << 30);
?>
<?php if ($p): ?><p class="alert"><?= $h($p) ?></p><?php endif ?>
<p class="muted"><?= count($shares) ?> active share links · <?= $h(FileOps::human($total)) ?> of <?= $h(FileOps::human($cap)) ?> used · stored in <span class="mono"><?= $h(Shares::dir()) ?></span>.
  Expired links and their files are deleted by the cleanup job.
  Blocked file types: <span class="mono"><?= $h(implode(' ', Shares::blockedTypes()) ?: 'none') ?></span><?= Shares::cfg('block_programs', true) ? ', and Windows programs under any name' : '' ?>.</p>
<div class="card"><div class="tbl-wrap"><table>
  <thead><tr><th>Created</th><th>Expires</th><th>Shared from</th><th>Created by IP</th><th>Content</th><th>Size</th><th>Downloads</th><th>Password</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($shares as $m): ?>
    <tr><td class="mono"><?= $h(date('Y-m-d H:i', $m['created'])) ?></td><td class="mono"><?= $h(date('Y-m-d H:i', $m['expires'])) ?></td>
      <td><?= $h($m['label'] ?? '') ?></td>
      <td class="mono"><?php if (!empty($m['creatorIp'])): ?><?= $h($m['creatorIp']) ?>
        <?php if ($pdo): ?><?= $form('block-add', ['kind' => 'ip', 'value' => (string)$m['creatorIp'], 'reason' => 'Share link abuse', 'hours' => 0], 'Block IP', 'btn btn-ghost danger') ?><?php endif ?>
        <?php else: ?><span class="muted">—</span><?php endif ?></td><td class="wrap"><?= $h($m['title']) ?> <span class="muted">(<?= (int)$m['count'] ?> files)</span></td>
      <td class="mono"><?= $h(FileOps::human((int)$m['bytes'])) ?></td>
      <td class="mono"><?= (int)$m['downloads'] ?><?= $m['maxDownloads'] ? ' / ' . (int)$m['maxDownloads'] : '' ?></td>
      <td><?= $m['password'] !== null ? 'yes' : 'no' ?></td>
      <td><?= $form('delete-share', ['id' => $m['id']], 'Delete', 'btn btn-ghost danger') ?></td></tr>
  <?php endforeach ?>
  <?php if (!$shares): ?><tr><td colspan="9" class="muted">No active share links.</td></tr><?php endif ?>
  </tbody>
</table></div></div>

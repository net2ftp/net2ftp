<?php
/** Admin → System check. */

use Net2ftp\Requirements;

$system = Requirements::report(true);
// tables of version 2.3 (logs, limits): tell the admin when the database still has to be upgraded
$missing = [];
if ($pdo) {
    foreach (['n2f_usage_ip', 'n2f_usage_server', 'n2f_error_log', 'n2f_security_log', 'n2f_blocks'] as $t) {
        try {
            $pdo->query("SELECT 1 FROM $t LIMIT 1");
        } catch (Throwable) {
            $missing[] = $t;
        }
    }
    try {
        $pdo->query('SELECT file_hash FROM n2f_action_log LIMIT 1');
    } catch (Throwable) {
        $missing[] = 'n2f_action_log.file_hash';
    }
}
?>
<?php if ($system['fatal']): ?><div class="alert"><b>net2ftp cannot work until these are fixed:</b><br><?= implode('<br>', array_map($h, $system['fatal'])) ?></div><?php endif ?>
<?php if ($missing): ?><div class="alert"><b>The database needs an upgrade</b> for the consumption logs, daily limits, error and security logs and blocks
  (missing: <?= $h(implode(', ', $missing)) ?>). Until then these features are switched off. Run:<br>
  <code>mysql -u root -p net2ftp &lt; sql/upgrade-2.3.sql</code> and <code>mysql -u root -p net2ftp &lt; sql/schema.sql</code></div><?php endif ?>
<div class="card"><div class="tbl-wrap"><table>
  <thead><tr><th>Area</th><th>Component</th><th>Status</th><th>Details</th></tr></thead>
  <tbody>
  <?php foreach ($system['checks'] as $c): ?>
    <tr><td><?= $h($c['group']) ?></td><td class="mono"><?= $h($c['name']) ?></td>
      <td class="<?= $c['status'] === 'ok' ? 'st-ok' : ($c['status'] === 'error' ? 'st-error' : 'warn') ?>"><?= $c['status'] === 'ok' ? 'OK' : ($c['status'] === 'error' ? 'Missing' : 'Warning') ?></td>
      <td><?= $h($c['detail']) ?></td></tr>
  <?php endforeach ?>
  </tbody>
</table></div></div>
<p class="muted small">Web server: <?= $h($_SERVER['SERVER_SOFTWARE'] ?? 'unknown') ?> · PHP <?= $h(PHP_VERSION) ?> (<?= $h(PHP_SAPI) ?>) · php.ini: <?= $h(php_ini_loaded_file() ?: 'none') ?> · net2ftp <?= $h(N2F_VERSION) ?></p>

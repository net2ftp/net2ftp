<?php
/** Admin → Consumption: per IP and per server for one day, against the daily limits, with Block buttons. */

use Net2ftp\Usage;

$day = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['day'] ?? '') ? $_GET['day'] : date('Y-m-d');
$lim = Usage::limits();
$ips = $q('SELECT * FROM n2f_usage_ip WHERE day = ? ORDER BY bytes DESC, ms DESC LIMIT 200', [$day]);
$srv = $q('SELECT * FROM n2f_usage_server WHERE day = ? ORDER BY bytes DESC, ms DESC LIMIT 200', [$day]);
$pct = static fn($v, $max) => $max > 0 ? min(100, (int)round($v / $max * 100)) : 0;
$meter = static function ($v, $max, string $text) use ($h, $pct): string {
    $p = $pct($v, $max);
    return $h($text) . ($max > 0 ? ' <span class="meter' . ($p >= 100 ? ' full' : ($p >= 80 ? ' high' : '')) . '" title="' . $p . '% of the daily limit"><i style="width:' . $p . '%"></i></span>' : '');
};
?>
<form class="filters card" method="get">
  <input type="hidden" name="tab" value="usage">
  <label>Day <input class="input" type="date" name="day" value="<?= $h($day) ?>" max="<?= date('Y-m-d') ?>"></label>
  <button class="btn btn-primary">Show</button>
  <span class="muted small">Daily limits: per IP <?= $h($lim['ip_bytes'] ? $human($lim['ip_bytes']) : 'no data limit') ?> and <?= $h($lim['ip_seconds'] ? $dur($lim['ip_seconds'] * 1000) : 'no time limit') ?> ·
    per server <?= $h($lim['server_bytes'] ? $human($lim['server_bytes']) : 'no data limit') ?> and <?= $h($lim['server_seconds'] ? $dur($lim['server_seconds'] * 1000) : 'no time limit') ?> (config.php → daily_limits)</span>
</form>

<section class="card"><h2 class="pad-h">Per IP address <small class="muted"><?= count($ips) ?></small></h2>
  <div class="tbl-wrap"><table>
    <thead><tr><th>IP</th><th>Requests</th><th>Logins</th><th>Data</th><th>Server time</th><th>Errors</th><th>Refused</th><th></th></tr></thead><tbody>
    <?php foreach ($ips as $r): ?>
      <tr><td class="mono"><a href="?tab=investigate&amp;ip=<?= $h(rawurlencode($r['ip'])) ?>&amp;from=<?= $h($day) ?>T00:00&amp;to=<?= $h($day) ?>T23:59"><?= $h($r['ip']) ?></a></td>
        <td><?= number_format((int)$r['requests']) ?></td><td><?= (int)$r['logins'] ?></td>
        <td><?= $meter($r['bytes'], $lim['ip_bytes'], $human($r['bytes'])) ?></td>
        <td><?= $meter($r['ms'], $lim['ip_seconds'] * 1000, $dur($r['ms'])) ?></td>
        <td><?= (int)$r['errors'] ?></td><td class="<?= $r['refused'] ? 'warn' : '' ?>"><?= (int)$r['refused'] ?></td>
        <td class="nowrap"><?= $form('block-add', ['kind' => 'ip', 'value' => $r['ip'], 'hours' => 24, 'reason' => 'Excessive use on ' . $day], 'Block 24 h') ?></td></tr>
    <?php endforeach ?>
    <?php if (!$ips): ?><tr><td colspan="8" class="muted">No data for this day<?= $day < date('Y-m-d', time() - 30 * 86400) ? ' (per-IP data is kept 30 days)' : '' ?>.</td></tr><?php endif ?>
    </tbody></table></div></section>

<section class="card"><h2 class="pad-h">Per server <small class="muted"><?= count($srv) ?></small></h2>
  <div class="tbl-wrap"><table>
    <thead><tr><th>Server</th><th>Requests</th><th>Logins</th><th>Data</th><th>Server time</th><th>Errors</th><th>Refused</th><th></th></tr></thead><tbody>
    <?php foreach ($srv as $r): ?>
      <tr><td><a href="?tab=investigate&amp;server=<?= $h(rawurlencode($r['server'])) ?>&amp;from=<?= $h($day) ?>T00:00&amp;to=<?= $h($day) ?>T23:59"><?= $h($r['server']) ?></a></td>
        <td><?= number_format((int)$r['requests']) ?></td><td><?= (int)$r['logins'] ?></td>
        <td><?= $meter($r['bytes'], $r['server'] === Usage::SHARES ? 0 : $lim['server_bytes'], $human($r['bytes'])) ?></td>
        <td><?= $meter($r['ms'], $r['server'] === Usage::SHARES ? 0 : $lim['server_seconds'] * 1000, $dur($r['ms'])) ?></td>
        <td><?= (int)$r['errors'] ?></td><td class="<?= $r['refused'] ? 'warn' : '' ?>"><?= (int)$r['refused'] ?></td>
        <td class="nowrap"><?= $r['server'] === Usage::SHARES ? '' : $form('block-add', ['kind' => 'server', 'value' => $r['server'], 'hours' => 24, 'reason' => 'Excessive use on ' . $day], 'Block 24 h') ?></td></tr>
    <?php endforeach ?>
    <?php if (!$srv): ?><tr><td colspan="8" class="muted">No data for this day.</td></tr><?php endif ?>
    </tbody></table></div></section>

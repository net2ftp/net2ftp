<?php
declare(strict_types=1);

/**
 * Admin panel (included by public/admin.php after the preflight check).
 *
 * Access control, in this order:
 *  1. admin_allowed_ips: other addresses get a plain "404 Not Found" (the page doesn't reveal it exists);
 *  2. password (admin_password_hash), plus a 6-digit code when admin_totp_secret is set (two-factor login);
 *  3. lockout after admin_lockout failed logins per IP for 15 minutes; every login and failure is a security event;
 *  4. its own session cookie (N2FADMIN, separate from the app's), logged out after admin_session_minutes without
 *     activity and after 8 hours in any case; actions that delete something need a login within the last 30 minutes;
 *  5. every change made here is written to the security log (event "admin-action").
 * An extra Apache password (.htpasswd) or IP rule in front of admin.php is still recommended: see the README.
 */

use Net2ftp\App;
use Net2ftp\Blocks;
use Net2ftp\Db;
use Net2ftp\Housekeeping;
use Net2ftp\Limiter;
use Net2ftp\Maintenance;
use Net2ftp\Requirements;
use Net2ftp\SecurityLog;
use Net2ftp\Session;
use Net2ftp\Shares;
use Net2ftp\SiteRequests;
use Net2ftp\Totp;
use Net2ftp\UserError;

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Cache-Control: no-store');
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'none'; form-action 'self'; frame-ancestors 'none'");
header('X-Robots-Tag: noindex, nofollow');

$h = static fn($s): string => htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

// ---------------------------------------------------------------- 1. IP allowlist
$allowed = (array)App::cfg('admin_allowed_ips', []);
if ($allowed) {
    $ok = false;
    foreach ($allowed as $rule) {
        $ok = $ok || Blocks::ipMatches(App::clientIp(), (string)$rule);
    }
    if (!$ok) {
        SecurityLog::event('admin-denied', 'warning', 'admin.php opened from an address not in admin_allowed_ips');
        http_response_code(404);
        exit('Not Found');
    }
}

$hash = (string)App::cfg('admin_password_hash', '');
if ($hash === '') {
    http_response_code(403);
    exit('The admin page is disabled. Set admin_password_hash in config.php to enable it.');
}
try {
    Session::start('N2FADMIN');
} catch (Throwable $e) {
    n2f_preflight_fail('html', $e->getMessage());
}

$totpSecret = (string)App::cfg('admin_totp_secret', '');
$idle = max(5, (int)App::cfg('admin_session_minutes', 30)) * 60;
$lockMax = max(1, (int)App::cfg('admin_lockout', 5));
$lockKey = 'admin-fail:' . App::clientIp();
$error = '';
$notice = '';

// ---------------------------------------------------------------- 2./3. login, lockout, logout
$do = (string)($_POST['do'] ?? '');
if ($do === 'login') {
    Session::checkCsrf($_POST['_csrf'] ?? null);
    if (Limiter::count($lockKey, 900) >= $lockMax) {
        SecurityLog::event('admin-lockout', 'critical', "Admin login locked after $lockMax failed attempts");
        $error = 'Too many failed attempts. Try again in 15 minutes.';
    } else {
        usleep(random_int(150000, 350000));
        $pwOk = password_verify((string)($_POST['password'] ?? ''), $hash);
        // the code is checked (and used up) only after a correct password: wrong guesses can't burn the user's code
        $codeOk = $pwOk && ($totpSecret === '' || Totp::verify($totpSecret, (string)($_POST['code'] ?? '')));
        if ($pwOk && $codeOk) {
            session_regenerate_id(true);
            $_SESSION['admin'] = ['since' => time(), 'seen' => time(), 'auth' => time()];
            SecurityLog::event('admin-login', 'info', 'Administrator logged in' . ($totpSecret !== '' ? ' (with two-factor code)' : ''));
            $back = (string)($_SESSION['admin_back'] ?? '');
            unset($_SESSION['admin_back']);
            header('Location: admin.php' . (preg_match('/^\?[\w=&%.\-]*$/', $back) ? $back : ''));
            exit;
        }
        Limiter::hit($lockKey, 900, 1000);
        SecurityLog::event('admin-login-failed', 'warning', $pwOk ? 'Wrong two-factor code' : 'Wrong admin password');
        $error = $totpSecret !== '' ? 'Wrong password or code.' : 'Wrong password.';
    }
}
if ($do === 'logout') {
    Session::checkCsrf($_POST['_csrf'] ?? null);
    unset($_SESSION['admin']);
    header('Location: admin.php');
    exit;
}

// ---------------------------------------------------------------- 4. session validity
$adm = $_SESSION['admin'] ?? null;
$isAdmin = is_array($adm) && time() - (int)$adm['seen'] < $idle && time() - (int)$adm['since'] < 8 * 3600;
if (!$isAdmin && $adm) {
    unset($_SESSION['admin']);
    $notice = 'Your admin session ended. Please log in again.';
}
if ($isAdmin) {
    $_SESSION['admin']['seen'] = time();
}
$csrf = Session::csrf();
$recentAuth = $isAdmin && time() - (int)$adm['auth'] < 1800;

// ---------------------------------------------------------------- sections
$sections = [
    'dashboard' => 'Dashboard', 'log' => 'Access log', 'investigate' => 'Investigate', 'usage' => 'Consumption',
    'blocks' => 'Blocks', 'errors' => 'Errors', 'security' => 'Security', 'shares' => 'Share links',
    'requests' => 'Requests', 'hosts' => 'SSH hosts', 'system' => 'System', 'maintenance' => 'Maintenance', 'settings' => 'Settings',
];
$section = (string)($_GET['tab'] ?? 'dashboard');
$section = isset($sections[$section]) ? $section : 'dashboard';
$pdo = $isAdmin ? Db::get() : null;
$flash = (string)($_SESSION['admin_flash'] ?? '');
unset($_SESSION['admin_flash']);

// ---------------------------------------------------------------- 5. actions (POST → redirect)
$destructive = ['forget-host', 'delete-share', 'request-delete', 'errors-purge', 'block-delete'];
if ($isAdmin && $do !== '' && $do !== 'login') {
    Session::checkCsrf($_POST['_csrf'] ?? null);
    $back = 'admin.php?tab=' . $section;
    if (in_array($do, $destructive, true) && !$recentAuth) {
        // deleting needs a fresh login: someone who finds an unlocked admin session can't wipe evidence
        unset($_SESSION['admin']);
        $_SESSION['admin_back'] = '?tab=' . $section;
        $_SESSION['admin_flash'] = 'For actions that delete something, please log in again.';
        header('Location: admin.php');
        exit;
    }
    $msg = '';
    try {
        switch ($do) {
            case 'forget-host':
                $pdo?->prepare('DELETE FROM n2f_known_hosts WHERE host = ? AND port = ?')->execute([(string)$_POST['host'], (int)$_POST['port']]);
                $msg = 'Forgot the SSH key of ' . $_POST['host'] . ':' . (int)$_POST['port'];
                break;
            case 'delete-share':
                $m = Shares::revoke((string)($_POST['id'] ?? ''), null);
                $msg = 'Deleted share link ' . substr($m['id'], 0, 12) . ' (' . $m['title'] . ')';
                break;
            case 'request-done':
            case 'request-open':
            case 'request-delete':
                SiteRequests::update((string)($_POST['file'] ?? ''), substr($do, 8));
                $msg = ucfirst(substr($do, 8)) . ' request ' . preg_replace('/^.*-([AG]-\d+-[0-9A-F]+)\.json$/', '$1', (string)$_POST['file']);
                break;
            case 'block-add':
                Blocks::add((string)$_POST['kind'], (string)$_POST['value'], trim((string)($_POST['reason'] ?? '')), (int)($_POST['hours'] ?? 0), 'admin');
                $msg = 'Blocked ' . $_POST['kind'] . ' ' . $_POST['value'] . ((int)$_POST['hours'] ? ' for ' . (int)$_POST['hours'] . ' h' : ' permanently')
                    . (($_POST['reason'] ?? '') !== '' ? ': ' . $_POST['reason'] : '');
                break;
            case 'block-delete':
                $st = $pdo?->prepare('SELECT kind, value FROM n2f_blocks WHERE id = ?');
                $st?->execute([(int)$_POST['id']]);
                $b = $st?->fetch() ?: ['kind' => '?', 'value' => '?'];
                $pdo?->prepare('DELETE FROM n2f_blocks WHERE id = ?')->execute([(int)$_POST['id']]);
                $msg = 'Removed block of ' . $b['kind'] . ' ' . $b['value'];
                break;
            case 'error-resolve':
            case 'error-reopen':
                $pdo?->prepare('UPDATE n2f_error_log SET status = ? WHERE fingerprint = ?')
                    ->execute([$do === 'error-resolve' ? 'resolved' : 'open', (string)$_POST['fp']]);
                $msg = ($do === 'error-resolve' ? 'Resolved' : 'Reopened') . ' error ' . substr((string)$_POST['fp'], 0, 8);
                break;
            case 'errors-purge':
                $n = $pdo?->exec("DELETE FROM n2f_error_log WHERE status = 'resolved'");
                $msg = "Deleted $n resolved errors";
                break;
            case 'cleanup':
                $r = Housekeeping::run(true);
                $msg = $r['ran'] ? 'Cleanup ran' : 'Cleanup is already running';
                $_SESSION['admin_cleanup'] = $r['report'] ?? null;
                break;
            case 'maintenance-on':
                Maintenance::on(trim((string)($_POST['message'] ?? '')));
                $msg = 'Maintenance mode on';
                break;
            case 'maintenance-off':
                Maintenance::off();
                $msg = 'Maintenance mode off';
                break;
            default:
                throw new UserError('Unknown action.');
        }
        SecurityLog::event('admin-action', in_array($do, $destructive, true) ? 'warning' : 'info', $msg);
        $_SESSION['admin_flash'] = $msg . '.';
    } catch (Throwable $e) {
        $_SESSION['admin_flash'] = 'Error: ' . $e->getMessage();
    }
    $keep = array_intersect_key($_GET, array_flip(['day', 'status', 'event', 'severity']));
    header('Location: ' . $back . ($keep ? '&' . http_build_query($keep) : ''));
    exit;
}
Session::release();

// ---------------------------------------------------------------- helpers for the views
$human = static function ($b): string {
    $b = (float)$b; $u = ['B', 'KB', 'MB', 'GB', 'TB']; $i = 0;
    while ($b >= 1024 && $i < 4) { $b /= 1024; $i++; }
    return ($i ? number_format($b, 1) : (string)(int)$b) . ' ' . $u[$i];
};
$dur = static function ($ms): string {
    $s = (int)round($ms / 1000);
    return $s < 60 ? $s . ' s' : ($s < 3600 ? round($s / 60) . ' min' : round($s / 3600, 1) . ' h');
};
$qs = static fn(array $over): string => '?' . http_build_query(array_filter(array_merge($_GET, $over), static fn($v) => $v !== '' && $v !== null));
$form = static fn(string $do, array $fields = [], string $label = '', string $cls = 'btn btn-ghost') : string =>
    '<form method="post" class="inline"><input type="hidden" name="_csrf" value="' . $h($csrf) . '"><input type="hidden" name="do" value="' . $h($do) . '">'
    . implode('', array_map(static fn($k, $v) => '<input type="hidden" name="' . $h($k) . '" value="' . $h($v) . '">', array_keys($fields), $fields))
    . '<button class="' . $h($cls) . '">' . $h($label) . '</button></form>';
$q = static function (string $sql, array $args = []) use (&$pdo): array {
    $st = $pdo->prepare($sql);
    $st->execute($args);
    return $st->fetchAll();
};
$dbError = '';
if ($isAdmin && !$pdo && !in_array($section, ['shares', 'requests', 'system', 'maintenance', 'settings'], true)) {
    $dbError = (Requirements::databaseProblem(true) ?? 'Database not reachable.') . ' Technical detail: ' . Db::lastError();
}

// CSV export of an investigation (before any HTML)
if ($isAdmin && $pdo && $section === 'investigate' && isset($_GET['export'])) {
    require N2F_ROOT . '/src/admin/investigate.php';
    exit;
}
$openRequests = $isAdmin ? count(array_filter(SiteRequests::all(), static fn($r) => $r['status'] === 'open')) : 0;
$openErrors = 0;
if ($pdo) {
    try {
        $openErrors = (int)$pdo->query("SELECT COUNT(*) FROM n2f_error_log WHERE status = 'open'")->fetchColumn();
    } catch (Throwable) {
    }
}
$badges = ['requests' => $openRequests, 'errors' => $openErrors];
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $h($isAdmin ? $sections[$section] . ' · ' : '') ?>net2ftp admin</title>
<link rel="icon" href="assets/img/favicon.svg">
<link rel="stylesheet" href="assets/css/app.css">
<link rel="stylesheet" href="assets/css/admin.css">
</head>
<body class="adm-body">
<?php if (!$isAdmin): ?>
  <form class="card login-box" method="post" autocomplete="off">
    <a class="brand" href="./"><img src="assets/img/logo.svg" width="28" height="28" alt=""><span>net2ftp admin</span></a>
    <?php if ($flash || $notice): ?><p class="info-note"><?= $h($flash ?: $notice) ?></p><?php endif ?>
    <?php if ($error): ?><p class="alert"><?= $h($error) ?></p><?php endif ?>
    <input type="hidden" name="do" value="login"><input type="hidden" name="_csrf" value="<?= $h($csrf) ?>">
    <label class="field"><span>Password</span><input class="input" type="password" name="password" autofocus required autocomplete="current-password"></label>
    <?php if ($totpSecret !== ''): ?>
      <label class="field"><span>Code from your authenticator app</span><input class="input mono" name="code" inputmode="numeric" pattern="[0-9 ]{6,7}" maxlength="7" required autocomplete="one-time-code"></label>
    <?php endif ?>
    <button class="btn btn-primary btn-block">Log in</button>
    <?php if ($totpSecret === ''): ?><p class="muted small">Tip: enable two-factor login with <code>php bin/admin-2fa.php</code>.</p><?php endif ?>
  </form>
<?php else: ?>
<div class="adm">
  <aside class="adm-nav">
    <a class="brand" href="admin.php"><img src="assets/img/logo.svg" width="26" height="26" alt=""><span>net2ftp admin</span></a>
    <nav>
      <?php foreach ($sections as $k => $label): ?>
        <a href="?tab=<?= $k ?>" class="<?= $section === $k ? 'on' : '' ?>"><?= $h($label) ?><?= !empty($badges[$k]) ? ' <span class="badge-n">' . (int)$badges[$k] . '</span>' : '' ?></a>
      <?php endforeach ?>
    </nav>
    <div class="adm-me">
      <span class="muted small">Logged in <?= $h(date('H:i', (int)$adm['since'])) ?> · <?= $h(App::clientIp()) ?></span>
      <?= $form('logout', [], 'Log out') ?>
    </div>
  </aside>
  <main class="adm-main">
    <h1><?= $h($sections[$section]) ?></h1>
    <?php if (Maintenance::message() !== null): ?><p class="alert">Maintenance mode is on: users can't log in. <a href="?tab=maintenance">Switch it off</a></p><?php endif ?>
    <?php if ($flash): ?><p class="<?= str_starts_with($flash, 'Error') ? 'alert' : 'info-note' ?>"><?= $h($flash) ?></p><?php endif ?>
    <?php if ($dbError): ?><p class="alert"><?= $h($dbError) ?></p><?php else: ?>
      <?php try { require N2F_ROOT . '/src/admin/' . $section . '.php'; } catch (Throwable $e) { ?>
        <p class="alert"><?= $h(str_contains($e->getMessage(), "doesn't exist") || str_contains($e->getMessage(), 'no such table')
            ? 'This section needs the new database tables. Run sql/upgrade-2.3.sql and then sql/schema.sql (see the README). Technical detail: ' . $e->getMessage()
            : 'Error: ' . $e->getMessage()) ?></p>
      <?php } ?>
    <?php endif ?>
  </main>
</div>
<?php endif ?>
</body>
</html>

<?php
declare(strict_types=1);

/**
 * net2ftp v2 bootstrap: config, autoloading, error handling.
 */

define('N2F_ROOT', dirname(__DIR__));
require_once __DIR__ . '/polyfill.php';
define('N2F_VERSION', '2.7.0');

// ---- Autoloader (no Composer needed: phpseclib is vendored in lib/) ----
spl_autoload_register(static function (string $class): void {
    static $map = [
        'Net2ftp\\'                => N2F_ROOT . '/src/',
        'phpseclib3\\'             => N2F_ROOT . '/lib/phpseclib/',
        'ParagonIE\\ConstantTime\\' => N2F_ROOT . '/lib/ParagonIE/ConstantTime/',
    ];
    foreach ($map as $prefix => $dir) {
        if (strncmp($class, $prefix, strlen($prefix)) === 0) {
            $file = $dir . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
            if (is_file($file)) {
                require $file;
            }
            return;
        }
    }
});
// Composer users may also run "composer install"; its autoloader is picked up when present.
if (is_file(N2F_ROOT . '/vendor/autoload.php')) {
    require N2F_ROOT . '/vendor/autoload.php';
}

// ---- Configuration ----
$configFile = getenv('N2F_CONFIG') ?: N2F_ROOT . '/config.php';
if (!is_file($configFile)) {
    $configFile = N2F_ROOT . '/config.sample.php';
}
$config = require $configFile;
Net2ftp\App::init(is_array($config) ? $config : []);

@date_default_timezone_set((string)Net2ftp\App::cfg('timezone', 'UTC'));
mb_internal_encoding('UTF-8');
Net2ftp\App::ini('display_errors', '0');
error_reporting(E_ALL);

// Turn PHP warnings (e.g. from ext-ftp) into exceptions so every failure has a clean message.
set_error_handler(static function (int $severity, string $message, string $file = '', int $line = 0): bool {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    if ($severity === E_DEPRECATED || $severity === E_USER_DEPRECATED) {
        return true;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

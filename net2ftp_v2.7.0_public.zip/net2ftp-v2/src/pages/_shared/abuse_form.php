<?php
/**
 * Shared part of the abuse page: the confirmation after sending, and the form (labels come from the catalog).
 * @var callable $h @var callable $t @var callable $v @var callable $err @var callable $hidden @var array $form @var array $site @var string $app */
$types = [
    'defacement' => 'A website was changed or defaced',
    'access'     => 'Someone accessed my server without permission',
    'malware'    => 'A share link contains malware',
    'phishing'   => 'A share link is used for phishing or fraud',
    'spam'       => 'A share link was sent as spam',
    'copyright'  => 'A share link infringes copyright',
    'other'      => 'Something else',
];
$share = preg_match('/^[0-9a-f]{40}$/', (string)($_GET['share'] ?? '')) ? (string)$_GET['share'] : (string)($form['values']['share'] ?? '');
?>
<?php if ($form['sent']): ?>
  <div class="pg-ok" role="status">
    <h2><?= $h($t('Thank you — your report was received.')) ?></h2>
    <p><?= $h($t('Your reference number is {ref}. Please mention it if you write to us about this report.', ['ref' => $form['sent']])) ?></p>
  </div>
<?php else: ?>
<form method="post" class="pg-form" novalidate>
  <?= $hidden() ?>
  <?php if ($share !== ''): ?><input type="hidden" name="share" value="<?= $h($share) ?>"><p class="pg-note"><?= $h($t('You are reporting a share link.')) ?> <span class="mono"><?= $h(substr($share, 0, 12)) ?>…</span></p><?php endif ?>
  <?= $err('_form') ?>
  <label class="field"><span><?= $h($t('What happened?')) ?> *</span>
    <select class="input" name="type" required>
      <option value=""><?= $h($t('Please choose')) ?></option>
      <?php foreach ($types as $k => $label): ?><option value="<?= $h($k) ?>"<?= ($form['values']['type'] ?? ($share !== '' ? 'malware' : '')) === $k ? ' selected' : '' ?>><?= $h($t($label)) ?></option><?php endforeach ?>
    </select><?= $err('type') ?></label>
  <div class="pg-grid2">
    <label class="field"><span><?= $h($t('Affected server')) ?></span><input class="input" name="server" value="<?= $v('server') ?>" placeholder="ftp.example.com" dir="ltr"><?= $err('server') ?></label>
    <label class="field"><span><?= $h($t('Web page or share link')) ?></span><input class="input" name="url" value="<?= $v('url') ?>" placeholder="https://…" dir="ltr"></label>
  </div>
  <label class="field"><span><?= $h($t('When did it happen? (date, time and time zone)')) ?></span><input class="input" name="when" value="<?= $v('when') ?>" placeholder="2026-11-23 14:05 CET"></label>
  <label class="field"><span><?= $h($t('Description')) ?> *</span>
    <textarea class="input" name="message" rows="6" maxlength="5000" required placeholder="<?= $h($t('What changed or what is wrong, which files, and anything that helps us find it in the log.')) ?>"><?= $v('message') ?></textarea><?= $err('message') ?></label>
  <div class="pg-grid2">
    <label class="field"><span><?= $h($t('Your name')) ?></span><input class="input" name="name" value="<?= $v('name') ?>" autocomplete="name"></label>
    <label class="field"><span><?= $h($t('Your e-mail address')) ?> *</span><input class="input" type="email" name="email" value="<?= $v('email') ?>" required autocomplete="email" dir="ltr"><?= $err('email') ?></label>
  </div>
  <p class="pg-small"><?= $h($t('We use these details only to handle your report. See the privacy policy.')) ?></p>
  <button class="btn btn-primary btn-lg"><?= $h($t('Send report')) ?></button>
</form>
<?php endif ?>

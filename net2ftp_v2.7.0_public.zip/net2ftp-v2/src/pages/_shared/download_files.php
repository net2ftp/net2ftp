<?php
/**
 * Shared part of the Download page: the list of packages in public/downloads/, the checksum hint and the
 * release/source buttons. The language page sets $L (labels) before including this file.
 * Packages' SHA-256 is computed once and cached next to them (<file>.sha256), so visitors can check that the
 * download is complete and unchanged.
 * @var callable $h @var array $site @var array $L
 */
$files = [];
foreach (array_merge(...array_map(static fn($e) => glob(N2F_ROOT . '/public/downloads/*.' . $e) ?: [], ['zip', 'tar.gz', 'tgz'])) as $f) {
    $sumFile = $f . '.sha256';
    $sum = is_file($sumFile) && filemtime($sumFile) >= filemtime($f) ? trim((string)file_get_contents($sumFile)) : '';
    if ($sum === '' && filesize($f) < 200 * 1024 * 1024) {
        $sum = hash_file('sha256', $f);
        @file_put_contents($sumFile, $sum);
    }
    $files[] = ['name' => basename($f), 'size' => filesize($f), 'date' => filemtime($f), 'sha' => $sum];
}
usort($files, static fn($a, $b) => $b['date'] <=> $a['date']);
$mb = static fn(int $b) => number_format($b / 1048576, 1) . ' MB';
?>
<?php if ($files): ?>
  <table class="pg-table">
    <thead><tr><th><?= $h($L['file']) ?></th><th><?= $h($L['size']) ?></th><th><?= $h($L['date']) ?></th><th>SHA-256</th></tr></thead>
    <tbody translate="no">
    <?php foreach ($files as $f): ?>
      <tr><td><a href="downloads/<?= $h(rawurlencode($f['name'])) ?>" download><?= $h($f['name']) ?></a></td>
        <td dir="ltr"><?= $h($mb($f['size'])) ?></td><td dir="ltr"><?= $h(date('Y-m-d', $f['date'])) ?></td>
        <td class="mono pg-sha"><?= $h($f['sha'] ?: '—') ?></td></tr>
    <?php endforeach ?>
    </tbody>
  </table>
  <p class="pg-small"><?= sprintf($L['check'], '<code dir="ltr">sha256sum ' . $h($files[0]['name']) . '</code>', '<code dir="ltr">shasum -a 256</code>', '<code dir="ltr">Get-FileHash</code>') ?></p>
<?php endif ?>
<?php if (!empty($site['download_url']) || !empty($site['source_url'])): ?>
  <p class="pg-buttons">
    <?php if (!empty($site['download_url'])): ?><a class="btn btn-primary" href="<?= $h($site['download_url']) ?>" rel="noopener"><?= $h($L['releases']) ?></a><?php endif ?>
    <?php if (!empty($site['source_url'])): ?><a class="btn btn-ghost" href="<?= $h($site['source_url']) ?>" rel="noopener"><?= $h($L['source']) ?></a><?php endif ?>
  </p>
<?php endif ?>
<?php if (!$files && empty($site['download_url'])): ?>
  <p class="pg-note"><?= $h($L['none']) ?><?= !empty($site['email']) ? ' <a href="mailto:' . $h($site['email']) . '" dir="ltr">' . $h($site['email']) . '</a>' : '' ?></p>
<?php endif ?>

<?php
/**
 * Shared part of the GDPR page: the confirmation after sending, and the form (labels come from the catalog).
 * @var callable $h @var callable $t @var callable $v @var callable $err @var callable $hidden @var callable $url @var array $form @var array $site */
$types = [
    'access'        => 'Access: tell me which data you have about me and give me a copy',
    'rectification' => 'Rectification: correct data about me',
    'erasure'       => 'Erasure: delete data about me',
    'restriction'   => 'Restriction: stop using data about me for now',
    'portability'   => 'Portability: give me my data in a machine-readable format',
    'objection'     => 'Objection: I object to the processing of my data',
    'consent'       => 'Withdraw consent',
];
?>
<?php if ($form['sent']): ?>
  <div class="pg-ok" role="status">
    <h2><?= $h($t('Thank you — your request was received.')) ?></h2>
    <p><?= $h($t('Your reference number is {ref}. We answer within 30 days, by e-mail. We may ask you to confirm your identity first.', ['ref' => $form['sent']])) ?></p>
  </div>
<?php else: ?>
<form method="post" class="pg-form" novalidate>
  <?= $hidden() ?>
  <?= $err('_form') ?>
  <label class="field"><span><?= $h($t('Type of request')) ?> *</span>
    <select class="input" name="type" required>
      <option value=""><?= $h($t('Please choose')) ?></option>
      <?php foreach ($types as $k => $label): ?><option value="<?= $h($k) ?>"<?= ($form['values']['type'] ?? '') === $k ? ' selected' : '' ?>><?= $h($t($label)) ?></option><?php endforeach ?>
    </select><?= $err('type') ?></label>
  <div class="pg-grid2">
    <label class="field"><span><?= $h($t('Your name')) ?> *</span><input class="input" name="name" value="<?= $v('name') ?>" required autocomplete="name"><?= $err('name') ?></label>
    <label class="field"><span><?= $h($t('Your e-mail address')) ?> *</span><input class="input" type="email" name="email" value="<?= $v('email') ?>" required autocomplete="email" dir="ltr"><?= $err('email') ?></label>
  </div>
  <label class="field"><span><?= $h($t('How can we find your data?')) ?> *</span>
    <textarea class="input" name="identifiers" rows="4" maxlength="2000" required placeholder="<?= $h($t('IP addresses you used, servers and user names you logged in to, share links you created, and roughly when.')) ?>"><?= $v('identifiers') ?></textarea><?= $err('identifiers') ?></label>
  <label class="field"><span><?= $h($t('Details')) ?></span><textarea class="input" name="message" rows="4" maxlength="5000"><?= $v('message') ?></textarea></label>
  <label class="check pg-confirm"><input type="checkbox" name="confirm" value="1"<?= !empty($form['values']['confirm']) ? ' checked' : '' ?>>
    <span><?= $h($t('I confirm that this request concerns my own personal data, or that I am authorised to act for the person concerned.')) ?></span></label><?= $err('confirm') ?>
  <button class="btn btn-primary btn-lg"><?= $h($t('Send request')) ?></button>
</form>
<?php endif ?>

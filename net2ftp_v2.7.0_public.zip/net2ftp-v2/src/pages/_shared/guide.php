<?php
/**
 * Shared layout of the guide pages (landing pages, questions and answers, articles, the Guides overview).
 * The language file src/pages/<lang>/<slug>.php only sets $doc and includes this file, so a translation is just text:
 *   'title'    => h1
 *   'lead'     => first paragraph
 *   'sections' => [['h' => heading, 'p' => [paragraphs], 'ul' | 'ol' => [items], 'shot' => [image, description],
 *                   'table' => [[header cells], [cells], …]], …]
 *   'faq'      => [group heading => [[question, answer], …], …]    (also published as schema.org FAQPage)
 *   'hub'      => [[heading, [slugs]], …]                           (the Guides overview: title + description of each)
 *   'cta'      => text of the button that opens the login page
 *   'related'  => [slugs]                                           ("Related guides" at the end)
 *   'article'  => 'YYYY-MM-DD' (date of the text)                   (published as schema.org Article)
 * Texts are trusted (written by the maintainers) and may contain simple HTML. "{app}" becomes the site's name,
 * [[slug|text]] a link to another page in the same language, [[login|text]] a link to the login page.
 *
 * @var callable $h @var callable $url @var callable $t @var callable $abs @var array $doc @var array $pages
 * @var array $seo @var string $slug @var string $lang @var string $app @var array $pageLd
 */
$fmt = static fn(string $s): string => (string)preg_replace_callback('/\[\[([a-z0-9-]+)\|([^\]]+)\]\]/',
    static fn(array $m): string => '<a href="' . $h($m[1] === 'login' ? './' : $url($m[1])) . '">' . $m[2] . '</a>',
    str_replace('{app}', $h($app), $s));
$plain = static fn(string $s): string => trim(html_entity_decode(strip_tags($fmt($s)), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
$label = static fn(string $s): string => $t($pages[$s][0] ?? $s);
?>
<h1><?= $fmt($doc['title']) ?></h1>
<?php if (!empty($doc['lead'])): ?><p class="pg-lead"><?= $fmt($doc['lead']) ?></p><?php endif ?>
<?php foreach ($doc['sections'] ?? [] as $sec): ?>
  <?php if (!empty($sec['h'])): ?><h2><?= $fmt($sec['h']) ?></h2><?php endif ?>
  <?php foreach ($sec['p'] ?? [] as $p): ?><p><?= $fmt($p) ?></p><?php endforeach ?>
  <?php foreach (['ul', 'ol'] as $tag): if (empty($sec[$tag])) continue; ?>
    <<?= $tag ?>><?php foreach ($sec[$tag] as $li): ?><li><?= $fmt($li) ?></li><?php endforeach ?></<?= $tag ?>>
  <?php endforeach ?>
  <?php if (!empty($sec['table'])): $rows = $sec['table']; $head = array_shift($rows); ?>
    <div class="pg-scroll"><table class="pg-table pg-compare">
      <thead><tr><?php foreach ($head as $c): ?><th><?= $fmt($c) ?></th><?php endforeach ?></tr></thead>
      <tbody><?php foreach ($rows as $r): ?><tr><?php foreach ($r as $i => $c): ?><<?= $i === 0 ? 'th' : 'td' ?>><?= $fmt($c) ?></<?= $i === 0 ? 'th' : 'td' ?>><?php endforeach ?></tr><?php endforeach ?></tbody>
    </table></div>
  <?php endif ?>
  <?php if (!empty($sec['shot'])): [$img, $alt] = $sec['shot']; $src = 'assets/img/screenshots/' . $img . '.webp';
      if (is_file(N2F_ROOT . '/public/' . $src)): ?>
    <figure class="pg-shot pg-guide-shot"><a href="<?= $h($src) ?>"><img src="<?= $h($src) ?>" alt="<?= $h($plain($alt)) ?>" loading="lazy" width="720" height="450"></a>
      <figcaption><?= $fmt($alt) ?></figcaption></figure>
  <?php endif; endif ?>
<?php endforeach ?>
<?php if (!empty($doc['faq'])): $qa = []; ?>
  <?php foreach ($doc['faq'] as $group => $items): ?>
    <h2><?= $fmt((string)$group) ?></h2>
    <div class="pg-qa">
    <?php foreach ($items as [$q, $a]): $qa[] = [$q, $a]; ?>
      <h3><?= $fmt($q) ?></h3><p><?= $fmt($a) ?></p>
    <?php endforeach ?>
    </div>
  <?php endforeach ?>
  <?php $pageLd[] = ['@context' => 'https://schema.org', '@type' => 'FAQPage', 'inLanguage' => $lang,
      'mainEntity' => array_map(static fn(array $x): array => ['@type' => 'Question', 'name' => $plain($x[0]),
          'acceptedAnswer' => ['@type' => 'Answer', 'text' => $plain($x[1])]], $qa)]; ?>
<?php endif ?>
<?php foreach ($doc['hub'] ?? [] as [$heading, $slugs]): ?>
  <h2><?= $fmt($heading) ?></h2>
  <div class="pg-tiles">
    <?php foreach ($slugs as $s): if (!isset($pages[$s])) continue; ?>
      <div class="pg-tile"><h3><a href="<?= $h($url($s)) ?>"><?= $h($label($s)) ?></a></h3><p><?= $h($seo[$s][0] ?? '') ?></p></div>
    <?php endforeach ?>
  </div>
<?php endforeach ?>
<?php if (!empty($doc['cta'])): ?>
  <p class="pg-buttons pg-cta"><a class="btn btn-primary btn-lg" href="./"><?= $fmt($doc['cta']) ?> →</a></p>
<?php endif ?>
<?php if (!empty($doc['related'])): ?>
  <h2><?= $h($t('Related guides')) ?></h2>
  <ul class="pg-related">
    <?php foreach ($doc['related'] as $s): if (!isset($pages[$s])) continue; ?>
      <li><a href="<?= $h($url($s)) ?>"><?= $h($label($s)) ?></a></li>
    <?php endforeach ?>
    <li><a href="<?= $h($url('guides')) ?>"><?= $h($t('All guides')) ?></a></li>
  </ul>
<?php endif ?>
<?php
if (!empty($doc['article'])) {
    $base = \Net2ftp\App::baseUrl();
    $pageLd[] = ['@context' => 'https://schema.org', '@type' => 'Article', 'headline' => $plain($doc['title']),
        'description' => $seo[$slug][0] ?? '', 'inLanguage' => $lang, 'datePublished' => $doc['article'],
        'dateModified' => $doc['modified'] ?? $doc['article'],
        'author' => ['@type' => 'Organization', 'name' => $app, 'url' => $base],
        'publisher' => ['@type' => 'Organization', 'name' => $app, 'url' => $base],
        'image' => $base . 'assets/img/og-image.png', 'mainEntityOfPage' => $abs($slug, $lang)];
}

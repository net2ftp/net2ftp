<?php
/**
 * Commands and configuration snippets of the Install page, the same in every language.
 * Each translated install.php prints them with $code['…'].
 */
$code = [
    'apt' => 'sudo apt install apache2 libapache2-mod-php php php-curl php-zip php-mbstring php-mysql php-xml mariadb-server',
    'unpack' => "sudo unzip net2ftp-v2.zip -d /var/www/\ncd /var/www/net2ftp-v2\nsudo chown -R www-data:www-data storage\nsudo chmod 750 storage storage/tmp",
    'db' => "sudo mysql -e \"CREATE DATABASE net2ftp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci\"\n"
        . "sudo mysql -e \"CREATE USER 'net2ftp'@'localhost' IDENTIFIED BY 'choose-a-strong-password';\n"
        . "               GRANT SELECT, INSERT, UPDATE, DELETE ON net2ftp.* TO 'net2ftp'@'localhost'\"\n"
        . "sudo mysql net2ftp < sql/schema.sql",
    'config' => "cp config.sample.php config.php\n"
        . "php -r \"echo base64_encode(random_bytes(32)), PHP_EOL;\"                       # → 'secret_key'\n"
        . "php -r \"echo password_hash('your-admin-password', PASSWORD_DEFAULT), PHP_EOL;\"  # → 'admin_password_hash'\n"
        . "php bin/admin-2fa.php                                                         # → 'admin_totp_secret'\n"
        . "nano config.php",
    'vhost' => "<VirtualHost *:443>\n    ServerName files.example.com\n    DocumentRoot /var/www/net2ftp-v2/public\n"
        . "    <Directory /var/www/net2ftp-v2/public>\n        AllowOverride All\n        Require all granted\n    </Directory>\n"
        . "    SSLEngine on\n    SSLCertificateFile    /etc/letsencrypt/live/files.example.com/fullchain.pem\n"
        . "    SSLCertificateKeyFile /etc/letsencrypt/live/files.example.com/privkey.pem\n</VirtualHost>",
    'certbot' => 'sudo apt install certbot python3-certbot-apache && sudo certbot --apache',
    'cron' => "sudo crontab -u www-data -e\n# add this line:\n17 * * * *  php /var/www/net2ftp-v2/bin/cleanup.php --quiet",
    'cronmode' => "'housekeeping' => ['mode' => 'cron']",
    'upgrade' => "mysql net2ftp < sql/upgrade-2.3.sql   # only when upgrading from 2.2\nmysql net2ftp < sql/schema.sql",
];
/** A command block: left-to-right and never machine-translated, also on Hebrew and Arabic pages. */
$pre = static fn(string $k): string => '<pre class="pg-code" dir="ltr" translate="no">' . htmlspecialchars($code[$k], ENT_QUOTES) . '</pre>';
/** Inline code. */
$c = static fn(string $s): string => '<code dir="ltr" translate="no">' . htmlspecialchars($s, ENT_QUOTES) . '</code>';

<?php
/**
 * Values used by the privacy policy and the disclaimer in every language: the operator's details and the
 * retention periods from config.php, so the policy always matches what the software actually does.
 * @var callable $h @var array $site
 */
use Net2ftp\App;

$op = $h($site['operator'] ?? '');
$isTemplate = in_array($site['operator'] ?? '', ['Example Ltd', ''], true);
$logDays = (int)App::cfg('log_retention_days', 90);
$remDays = (int)App::cfg('remember_days', 30);
$shareDays = (int)(((array)App::cfg('shares', []))['max_days'] ?? 7);
$idle = (int)round((int)App::cfg('session_timeout', 1800) / 60);
$hk = (array)App::cfg('housekeeping', []);
$days = [
    'usage_ip' => (int)($hk['usage_ip_days'] ?? 30),
    'usage_server' => (int)($hk['usage_server_days'] ?? 400),
    'security' => (int)($hk['security_days'] ?? 180),
    'blocks' => (int)($hk['blocks_days'] ?? 90),
    'errors' => (int)($hk['errors_days'] ?? 90),
];
$mail = !empty($site['privacy_email'])
    ? '<a href="mailto:' . $h($site['privacy_email']) . '" dir="ltr">' . $h($site['privacy_email']) . '</a>'
    : $h($site['email'] ?? '');
$jurisdiction = $h($site['jurisdiction'] ?? 'Switzerland');
$updated = (int)@filemtime(N2F_ROOT . '/src/pages/en/privacy.php');
/** The English version is the reference text of the legal pages; translations say so and link to it. */
$enLink = static fn(string $slug, string $label): string =>
    '<a href="page.php?' . $h(http_build_query(['lang' => 'en', 'p' => $slug])) . '" lang="en">' . $h($label) . '</a>';

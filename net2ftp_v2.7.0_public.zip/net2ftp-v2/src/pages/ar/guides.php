<?php
$doc = [
    'title' => 'أدلة',
    'lead' => 'ما يمكنك فعله باستخدام {app} خطوة بخطوة، وإجابات عن أكثر الأسئلة شيوعًا حول FTP وSFTP وAmazon S3.',
    'hub' => [
        ['استخدم {app} من أجل …', ['online-ftp', 'sftp-client', 's3-browser', 'edit-online', 'large-uploads']],
        ['معلومات مفيدة', ['active-passive', 'ftp-ftps-sftp', 'move-website']],
        ['مساعدة', ['faq', 'help']],
    ],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

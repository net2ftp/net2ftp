<?php
/** @var callable $h @var array $form @var array $site @var string $app */
?>
<h1>Missbrauch melden</h1>
<?php if (!$form['sent']): ?>
<p class="pg-lead"><?= $h($app) ?> ist ein Werkzeug, mit dem Menschen <em>ihre eigenen</em> Server verwalten. Wie jedes FTP-Programm kann es von jemandem missbraucht werden, der ein Passwort gestohlen hat.
  Wenn Ihr Server über diese Website verändert wurde oder ein Freigabelink dieser Website für etwas Illegales verwendet wird, melden Sie es hier.</p>
<p>Jede Aktion auf dieser Website wird mit der IP-Adresse des Besuchers, dem Server, dem Benutzernamen und der Uhrzeit protokolliert. So können wir die verantwortliche Person finden, sperren
  und die Angaben an Sie oder die Polizei weitergeben. Wir antworten in der Regel innerhalb von zwei Arbeitstagen. Freigabelinks, die wegen Schadsoftware oder Phishing gemeldet werden, entfernen wir, sobald wir sie geprüft haben.</p>
<p class="pg-small">Bevor Sie melden: Wenn Ihr FTP-Passwort verwendet wurde, <b>ändern Sie es jetzt</b> auf Ihrem Server. Sich von dieser Website abzumelden, hält niemanden auf, der Ihr Passwort kennt.
  <?php if (!empty($site['abuse_email'])): ?>Sie können auch an <a href="mailto:<?= $h($site['abuse_email']) ?>" dir="ltr"><?= $h($site['abuse_email']) ?></a> schreiben.<?php endif ?></p>
<?php endif ?>
<?php require N2F_ROOT . '/src/pages/_shared/abuse_form.php'; ?>

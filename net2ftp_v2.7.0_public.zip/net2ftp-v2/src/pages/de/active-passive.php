<?php
$doc = [
    'title' => 'Aktives und passives FTP: Was ist der Unterschied?',
    'lead' => 'Die Anmeldung klappt, aber die Dateiliste erscheint nie, oder eine Übertragung hängt? Die Ursache ist fast immer die FTP-Datenverbindung, und die Lösung oft ein einziges Häkchen: der passive Modus.',
    'article' => '2026-11-26',
    'sections' => [
        ['h' => 'FTP verwendet zwei Verbindungen',
         'p' => [
             'FTP wurde in den 1970er-Jahren entworfen, lange vor Firewalls. Es verwendet eine Verbindung für Befehle (die <b>Steuerverbindung</b>, meist Port 21) und öffnet für jede Dateiliste und jede Datei eine neue <b>Datenverbindung</b>. Aktiver und passiver Modus unterscheiden sich nur darin, wer diese Datenverbindung öffnet.',
         ]],
        ['h' => 'Passiver Modus: Der Client verbindet sich',
         'p' => [
             'Der Client bittet den Server um einen Port (Befehl <code>PASV</code> oder <code>EPSV</code>). Der Server öffnet einen zufälligen Port, und der Client verbindet sich damit. Das funktioniert gut, wenn der Client hinter einer Firewall oder einem Router steht, deshalb ist der passive Modus Standard in Browsern, in den meisten FTP-Programmen und in {app}. Die Firewall des Servers muss seinen Bereich passiver Ports zulassen.',
         ]],
        ['h' => 'Aktiver Modus: Der Server verbindet sich zurück',
         'p' => [
             'Der Client nennt dem Server eine Adresse und einen Port (Befehl <code>PORT</code> oder <code>EPRT</code>), und der Server verbindet sich dorthin zurück. Das funktioniert, wenn der Server hinter einer Firewall steht, die nur Port 21 durchlässt, aber der Client muss eingehende Verbindungen annehmen. {app} unterstützt beide Modi.',
         ]],
        ['h' => 'Probleme und Lösungen',
         'table' => [
             ['Was Sie sehen', 'Was zu tun ist'],
             ['Die Anmeldung klappt, aber der Ordner lädt nie oder es folgt eine Zeitüberschreitung', 'Wechseln Sie den Modus: Entfernen Sie auf der Anmeldeseite unter <i>Erweiterte Optionen</i> das Häkchen bei <i>Passiver Modus</i>, oder setzen Sie es, falls es fehlte.'],
             ['„… hat auf die Anfrage nach dem passiven Modus nicht geantwortet“', 'Der Server (oder eine Firewall davor) blockiert den passiven Modus. Melden Sie sich mit ausgeschaltetem passivem Modus erneut an.'],
             ['Aktiver Modus funktioniert mit FTP, aber nicht mit FTP über TLS', 'Firewalls können verschlüsselte Befehle nicht lesen und daher den Port für den aktiven Modus nicht öffnen. Verwenden Sie den passiven Modus oder SFTP.'],
             ['Keiner der beiden Modi funktioniert', 'Die Firewall des Servers blockiert die Datenports. Fragen Sie Ihren Hosting-Anbieter, oder verwenden Sie SFTP, das nur einen Port braucht.'],
         ]],
        ['h' => 'Für Serveradministratoren',
         'p' => [
             'Wählen Sie für den passiven Modus einen kleinen Portbereich, öffnen Sie ihn in der Firewall und tragen Sie ihn im FTP-Server ein: <code>pasv_min_port</code> und <code>pasv_max_port</code> in vsftpd, <code>PassivePorts</code> in ProFTPD oder <code>-p</code> in Pure-FTPd. Hinter NAT muss der Server außerdem seine öffentliche Adresse melden. {app} ignoriert die Adresse in der passiven Antwort und verbindet sich mit der eigenen Adresse des Servers, eine falsche Adresse dort hält es also nicht auf.',
         ]],
    ],
    'related' => ['ftp-ftps-sftp', 'faq', 'online-ftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

<?php
/**
 * Übersetzung des Haftungsausschlusses (Vorlage). Maßgeblich ist die englische Fassung.
 * @var callable $h @var callable $url @var array $site @var string $app
 */
require N2F_ROOT . '/src/pages/_shared/privacy_vars.php';
?>
<h1>Haftungsausschluss</h1>
<?php if ($isTemplate): ?>
  <p class="pg-warn"><b>Vorlage.</b> Der Betreiber dieser Website hat seine Angaben noch nicht eingetragen (config.php → <code>site</code>).</p>
<?php endif ?>
<p class="pg-lead">Mit der Nutzung dieser Website akzeptieren Sie die folgenden Bedingungen. Wenn Sie nicht einverstanden sind, nutzen Sie sie bitte nicht.</p>
<p class="pg-small">Diese Übersetzung dient Ihrer Bequemlichkeit; bei Abweichungen ist nur die <?= $enLink('disclaimer', 'englische Fassung') ?> maßgeblich.</p>

<h2>1. Der Dienst</h2>
<p><?= $h($app) ?> wird von <?= $op ?> kostenlos und <b>wie besehen</b> angeboten, ohne jede Gewährleistung: Wir garantieren nicht, dass der Dienst immer verfügbar, fehlerfrei oder für einen bestimmten Zweck geeignet ist.
  Wir können den Dienst jederzeit ändern, einschränken oder einstellen und Grenzen für Dateigrößen, Übertragungen und Nutzung festlegen.</p>

<h2>2. Ihre Verantwortung</h2>
<ul>
  <li>Verbinden Sie sich nur mit Servern, die Sie <b>nutzen dürfen</b>, mit Zugangsdaten, die Ihnen gehören oder die Sie verwenden dürfen.</li>
  <li>Sie sind für alles verantwortlich, was Sie mit dem Dienst tun: die Dateien, die Sie hochladen, ändern, löschen oder teilen, und die Folgen auf Ihrem Server.</li>
  <li><b>Machen Sie Sicherungskopien.</b> Löschen, Überschreiben, Ändern von Berechtigungen und Entpacken von Archiven können nicht rückgängig gemacht werden.</li>
  <li>Nutzen Sie den Dienst für nichts Illegales: unbefugten Zugriff, Verunstalten von Websites, Verbreiten von Schadsoftware, Phishing, Spam oder Dateien, die Rechte anderer verletzen.</li>
  <li>Versuchen Sie nicht, diese Website oder die Server, mit denen sie sich verbindet, zu überlasten, anzugreifen oder ihre Grenzen zu umgehen.</li>
</ul>

<h2>3. Protokollierung und Missbrauch</h2>
<p>Jede Aktion wird protokolliert (siehe <a href="<?= $h($url('privacy')) ?>">Datenschutzerklärung</a>). Bei Missbrauch können wir den Zugang sperren, Freigabelinks löschen und die Protokolleinträge an die Betreiber betroffener Server und an Behörden weitergeben.
  Um Missbrauch zu melden, verwenden Sie das <a href="<?= $h($url('abuse')) ?>">Meldeformular</a>.</p>

<h2>4. Freigabelinks</h2>
<p>Über einen Link geteilte Dateien werden von dem Benutzer veröffentlicht, der den Link erstellt hat, nicht von <?= $op ?>. Wir prüfen sie nicht im Voraus. Als illegal gemeldete Links entfernen wir, sobald wir die Meldung geprüft haben.
  Laden Sie geteilte Dateien nur von Personen herunter, denen Sie vertrauen.</p>

<h2>5. Haftung</h2>
<p>Soweit gesetzlich zulässig, haftet <?= $op ?> nicht für Schäden aus der Nutzung oder der Unmöglichkeit der Nutzung dieser Website – insbesondere nicht für Datenverlust, Schäden an Websites oder Servern, entgangenen Gewinn oder durch andere Benutzer verursachte Schäden.
  Dies beschränkt die Haftung für Vorsatz oder grobe Fahrlässigkeit nicht, wo das Gesetz es nicht erlaubt.</p>

<h2>6. Links zu anderen Websites</h2>
<p>Wir sind nicht für den Inhalt von Websites verantwortlich, auf die wir verlinken.</p>

<h2>7. Die Software</h2>
<p>Die Software hinter dieser Website ist Open Source unter der GNU General Public License, Version 2 oder neuer, und wird ohne Gewährleistung bereitgestellt. Wenn Sie sie selbst installieren, sind Sie der Betreiber Ihrer Installation.</p>

<h2>8. Anwendbares Recht</h2>
<p>Für diese Bedingungen gilt das Recht des folgenden Landes: <?= $jurisdiction ?>. Zuständig sind die Gerichte am Sitz von <?= $op ?>, sofern zwingendes Verbraucherschutzrecht nichts anderes bestimmt.</p>
<p>Kontakt: <span dir="ltr"><?= $h($site['email'] ?? '') ?></span></p>

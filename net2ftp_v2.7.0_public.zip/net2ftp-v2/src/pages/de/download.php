<?php
/** @var callable $h @var callable $url @var array $site @var string $app @var string $version */
$L = [
    'file' => 'Datei', 'size' => 'Größe', 'date' => 'Datum',
    'check' => 'Download prüfen: %1$s (Linux), %2$s (macOS) oder %3$s (Windows PowerShell) muss denselben Wert anzeigen.',
    'releases' => 'Alle Versionen', 'source' => 'Quellcode',
    'none' => 'Auf diesem Server ist noch kein Download veröffentlicht. Fragen Sie den Administrator:',
];
?>
<h1>Download</h1>
<p class="pg-lead">Installieren Sie <?= $h($app) ?> auf Ihrem eigenen Webserver – für Ihr Unternehmen, Ihre Kunden oder sich selbst.
  Es ist kostenlos und Open Source (GPL 2.0 oder neuer). Aktuelle Version: <b dir="ltr"><?= $h($version) ?></b>.</p>
<?php require N2F_ROOT . '/src/pages/_shared/download_files.php'; ?>

<h2>Was Sie brauchen</h2>
<table class="pg-table">
  <tbody>
    <tr><th>Webserver</th><td>Apache 2.4 (mod_php oder PHP-FPM) oder nginx mit PHP-FPM</td></tr>
    <tr><th>PHP</th><td>8.1 oder neuer, mit den Erweiterungen ftp, curl, zip, mbstring, openssl oder sodium (die meisten sind standardmäßig installiert)</td></tr>
    <tr><th>Datenbank</th><td>MySQL 5.7+ oder MariaDB 10.3+ für die Protokolle (optional, aber empfohlen)</td></tr>
    <tr><th>Speicherplatz</th><td>Etwa 5 MB für den Code, plus Platz für temporäre Dateien und Freigabelinks</td></tr>
  </tbody>
</table>
<p>Fehlende Erweiterungen machen die Installation nicht kaputt: <?= $h($app) ?> sagt Ihnen genau, was fehlt, und der Rest funktioniert weiter.
  Siehe <a href="<?= $h($url('install')) ?>">Installation</a>.</p>

<h2>Neu in <span dir="ltr"><?= $h($version) ?></span></h2>
<ul>
  <li>Tägliche Limits für Datenmenge und Serverzeit, pro Besucher und pro FTP-Server, damit der Dienst für alle fair bleibt.</li>
  <li>Automatische Erkennung von Massen-Uploads (dieselbe Datei auf viele Server), mit automatischer Sperre.</li>
  <li>Ein neues Administrationspanel: Übersicht, Untersuchung von Missbrauchsmeldungen, Verbrauch, Sperren, Fehler und Sicherheitsereignisse.</li>
  <li>Zwei-Faktor-Anmeldung und Sperre nach Fehlversuchen für den Administrator.</li>
  <li>Alte Protokolleinträge und übrig gebliebene Dateien werden automatisch gelöscht.</li>
  <li>Die Informationsseiten gibt es in allen elf Sprachen.</li>
</ul>

<?php
$doc = [
    'title' => 'Dateien direkt auf dem Server bearbeiten',
    'lead' => 'Einen Tippfehler auf Ihrer Website korrigieren, eine Einstellung in einer Konfigurationsdatei ändern oder ein PHP-Skript anpassen: direkt auf Ihrem FTP- oder SFTP-Server, in jedem Browser. Ohne Herunterladen, Bearbeiten und erneutes Hochladen.',
    'sections' => [
        ['h' => 'Ein richtiger Code-Editor',
         'ul' => [
             'Syntaxhervorhebung für PHP, HTML, CSS, JavaScript und mehr als 20 weitere Sprachen, mit Zeilennummern.',
             'Suchen und Ersetzen in der Datei (<kbd>Strg</kbd>+<kbd>F</kbd>), Speichern mit <kbd>Strg</kbd>+<kbd>S</kbd>.',
             'Zeichenkodierung und Zeilenenden der Datei bleiben erhalten: Windows- und Unix-Dateien bleiben, wie sie waren.',
             '<b>Keine verlorenen Änderungen</b>: Hat jemand anderes die Datei auf dem Server geändert, nachdem Sie sie geöffnet haben, warnt {app} Sie, bevor sie überschrieben wird.',
         ],
         'shot' => ['edit', 'Der Code-Editor mit Syntaxhervorhebung.']],
        ['h' => 'Finden, was zu ändern ist',
         'p' => [
             '<b>Suchen</b> findet Text in allen Dateien eines Ordners und seiner Unterordner, zum Beispiel eine alte E-Mail-Adresse oder eine Datenbankeinstellung. Sie können die Suche auf bestimmte Dateien beschränken (<code>*.php *.html</code>) oder einen regulären Ausdruck verwenden. Ein Klick auf ein Ergebnis öffnet die Datei an dieser Zeile.',
         ]],
        ['h' => 'Rund um den Editor',
         'ul' => [
             'Neue Dateien und Ordner anlegen, Dateien umbenennen und kopieren, um vor einer Änderung eine Sicherung zu behalten.',
             'Berechtigungen ändern, zum Beispiel <code>644</code> für Dateien und <code>755</code> für Ordner.',
             'Lesezeichen setzen: Jede Datei im Editor hat ihre eigene Adresse, so kommen Sie direkt zu ihr zurück.',
         ]],
    ],
    'cta' => 'Editor öffnen',
    'related' => ['online-ftp', 'move-website', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

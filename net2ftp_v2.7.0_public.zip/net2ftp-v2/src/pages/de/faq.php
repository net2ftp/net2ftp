<?php
$doc = [
    'title' => 'Fragen und Antworten',
    'lead' => 'Die häufigsten Fragen zu {app}. Ihre ist nicht dabei? Lesen Sie die [[help|Anleitung]] oder den [[guides|Ratgeber]].',
    'faq' => [
        'Über {app}' => [
            ['Ist {app} kostenlos?', 'Ja. {app} ist kostenlos und Open Source (GPL). Sie können es auf dieser Website nutzen oder [[download|herunterladen]] und auf Ihrem eigenen Server installieren.'],
            ['Muss ich ein Konto anlegen?', 'Nein. Sie melden sich mit dem Benutzernamen und Passwort Ihres eigenen FTP-, SFTP- oder S3-Servers an. Es gibt nichts zu registrieren.'],
            ['Muss ich etwas installieren?', 'Nein. {app} läuft in jedem aktuellen Browser, unter Windows, Mac, Linux, auf Chromebook, Android und iPhone.'],
            ['Mit welchen Servern funktioniert es?', 'Mit jedem FTP- oder FTPS-Server, jedem SFTP/SSH-Server unter Linux oder Windows, mit Amazon S3 und S3-kompatiblem Speicher wie MinIO, Wasabi, Cloudflare R2, Exoscale oder Infomaniak.'],
        ],
        'Sicherheit und Datenschutz' => [
            ['Ist es sicher, mein FTP-Passwort einzugeben?', 'Ihr Passwort wird nur für die Verbindung mit Ihrem Server verwendet. Es bleibt verschlüsselt, solange Sie angemeldet sind, wird nie im Klartext gespeichert und nie in Links eingefügt. Vor dem Senden können Sie den Fingerabdruck des Servers prüfen.'],
            ['Was ist der Fingerabdruck des Servers?', 'Der Fingerabdruck identifiziert einen Server, wie ein Siegel auf einem Brief. Vergleichen Sie ihn vor der ersten Anmeldung mit dem, den Ihr Hosting-Anbieter Ihnen nennt. Meldet {app} später, dass er sich geändert hat, melden Sie sich erst an, wenn Sie wissen, warum.'],
            ['Bleiben meine Dateien auf Ihrem Server?', 'Nein. Dateien laufen auf dem Weg zwischen Ihrem Computer und Ihrem Server durch diesen Server und werden nicht aufbewahrt. Ausnahmen sind die Kopien für Freigabelinks (bis der Link abläuft) und die Teile unvollständiger Uploads (bis sie ablaufen oder Sie sie abschließen).'],
            ['Was wird protokolliert?', 'Jede Aktion (zum Beispiel: wer welche Datei wann auf welchen Server hochgeladen hat) wird mit der IP-Adresse protokolliert, um Serverbetreiber vor Missbrauch zu schützen. Die [[privacy|Datenschutzerklärung]] sagt, was wie lange aufbewahrt wird.'],
        ],
        'Verbinden' => [
            ['Welchen Port soll ich verwenden?', 'Lassen Sie den Port leer, dann wird der übliche verwendet: 21 für FTP und FTPS, 22 für SFTP. Geben Sie einen anderen Port nur an, wenn Ihr Anbieter es verlangt.'],
            ['Warum erscheint „Verbindung zu … fehlgeschlagen“?', 'Prüfen Sie Servername und Port. Manche Hosting-Anbieter erlauben FTP nur von bestimmten Adressen oder nicht von anderen Servern aus; fragen Sie nach oder versuchen Sie es mit SFTP.'],
            ['Die Anmeldung klappt, aber der Ordner lädt nicht. Was nun?', 'Das liegt fast immer an der FTP-Datenverbindung. Öffnen Sie auf der Anmeldeseite <i>Erweiterte Optionen</i> und entfernen Sie das Häkchen bei <i>Passiver Modus</i> (oder setzen Sie es, falls es fehlte). [[active-passive|Aktives und passives FTP]] erklärt, warum.'],
            ['Soll ich FTP, FTPS oder SFTP verwenden?', 'SFTP oder FTPS, wenn Ihr Server es unterstützt: Beide sind verschlüsselt. Einfaches FTP sendet Ihr Passwort unverschlüsselt. Siehe [[ftp-ftps-sftp|FTP, FTPS oder SFTP?]].'],
        ],
        'Dateien' => [
            ['Kann ich große Dateien übertragen?', 'Ja. Dateien werden in Teilen gesendet und nach einer Unterbrechung fortgesetzt, und Ordner jeder Größe werden ohne Zeitlimit kopiert, verschoben und gezippt. Siehe [[large-uploads|Große Dateien hochladen]].'],
            ['Kann ich Dateien auf dem Server entpacken?', 'Ja. Wählen Sie eine .zip-, .tar-, .tar.gz- oder .tar.bz2-Datei und dann <b>Entpacken</b>: Sie wird direkt auf dem Server entpackt.'],
            ['Wie schicke ich jemandem ohne Zugang zu meinem Server eine Datei?', 'Wählen Sie die Datei aus und klicken Sie auf <b>Teilen</b>. Sie erhalten einen Download-Link, der abläuft, auf Wunsch mit Passwort und einer Höchstzahl an Downloads.'],
            ['Gibt es Limits?', 'Damit der Dienst für alle fair bleibt, kann diese Website begrenzen, wie viel jeder Besucher und jeder Server pro Tag überträgt. Erreichen Sie ein Limit, sagt {app} Ihnen das; die Limits werden um Mitternacht (Serverzeit) zurückgesetzt. Auf Ihrer eigenen Installation legen Sie die Limits selbst fest.'],
        ],
        'Eigene Installation' => [
            ['Kann ich {app} auf meinem eigenen Server installieren?', 'Ja. Sie brauchen einen Webserver mit PHP 8.1 oder neuer; MySQL oder MariaDB ist optional, aber empfohlen. Die [[install|Installationsanleitung]] dauert etwa 15 Minuten.'],
        ],
    ],
    'related' => ['help', 'active-passive', 'ftp-ftps-sftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

<?php
/** @var callable $h @var callable $url @var string $app */
$groups = [
    'Verbinden' => [
        ['FTP und FTPS', 'Passiver und aktiver Modus, FTP over TLS (explizit), Unix- und Windows-Server.'],
        ['SFTP / SSH', 'Passwort oder privater Schlüssel (RSA, ECDSA, Ed25519), mit einem SSH-Terminal zum Ausführen von Befehlen.'],
        ['Amazon S3', 'Jede Region, ein einzelner Bucket oder alle Buckets, temporäre Zugangsdaten und S3-kompatibler Speicher wie MinIO, Wasabi, Cloudflare R2, Exoscale oder Infomaniak.'],
        ['Fingerabdruck des Servers', 'Sehen Sie den SSH-Host-Schlüssel oder das TLS-Zertifikat, bevor Ihr Passwort gesendet wird, und erhalten Sie eine Warnung, wenn er sich ändert.'],
        ['Gespeicherte Server', 'Bis zu 5 Verbindungen pro Browser, mit verschlüsseltem Passwort und dem zuletzt geöffneten Ordner – nur wenn Sie Präferenz-Cookies erlauben.'],
        ['Lesezeichen', 'Jeder Ordner und jede Datei hat eine eigene Adresse, für die Sie ein Lesezeichen setzen können. Passwörter stehen nie in Links.'],
    ],
    'Durchsuchen und übertragen' => [
        ['Schnelle Dateiliste', 'Sortieren, filtern, mit Tastatur oder Maus auswählen und Ordner mit 10.000 Dateien sofort öffnen.'],
        ['Hochladen', 'Dateien oder ganze Ordner per Drag & Drop. Große Dateien werden in Teilen gesendet, zwei gleichzeitig, und ein unterbrochener Upload wird dort fortgesetzt, wo er stehen geblieben ist – auch in einer späteren Sitzung.'],
        ['Herunterladen', 'Einzelne Dateien oder eine beliebige Auswahl von Dateien und Ordnern als eine Zip-Datei. Unterbrochene Downloads kann der Browser fortsetzen.'],
        ['Kopieren, verschieben, umbenennen, löschen', 'Rekursiv für Ordner jeder Größe. Große Aufträge laufen in Schritten, mit Fortschrittsanzeige, Anhalten und Fortsetzen, und laufen nach der nächsten Anmeldung weiter.'],
        ['Suchen', 'Text in Dateien oder Dateien nach Namen in einem ganzen Ordnerbaum finden, mit regulären Ausdrücken und Dateimustern.'],
    ],
    'Auf dem Server arbeiten' => [
        ['Bearbeiten', 'Ein Code-Editor mit Syntaxhervorhebung für PHP, HTML, CSS, JavaScript und 20 weitere Sprachen, Suchen und Ersetzen und Schutz davor, Änderungen anderer zu überschreiben.'],
        ['Berechtigungen', 'chmod und chown für viele Dateien und Ordner auf einmal, rekursiv, in einer Reihenfolge, die Sie nie aussperrt.'],
        ['Entpacken', '.zip-, .tar-, .tar.gz- und .tar.bz2-Archive sicher direkt auf dem Server entpacken.'],
        ['SSH-Terminal', 'Shell-Befehle im aktuellen Ordner eines SFTP-Servers ausführen, auf Linux- und Windows-Servern.'],
        ['Freigabelinks', 'Download-Links mit Ablaufdatum und optionalem Passwort und Download-Limit, wie bei WeTransfer. Empfänger erhalten nie Zugriff auf Ihren Server.'],
    ],
    'Sicherheit und Datenschutz' => [
        ['Verschlüsselte Zugangsdaten', 'Ihr Passwort wird verschlüsselt aufbewahrt, solange Sie angemeldet sind, und nie im Klartext auf die Festplatte geschrieben.'],
        ['Aktionsprotokoll', 'Jede Aktion wird protokolliert, um Serverbetreiber vor Missbrauch zu schützen.'],
        ['Cookie-Auswahl', 'Nur notwendige Cookies, außer Sie erlauben mehr. Keine Werbe- oder Tracking-Cookies.'],
        ['Schutz vor Missbrauch', 'Freigabelinks lehnen Programme und Skripte ab, und Limits pro Besucher schützen die Server, mit denen Sie sich verbinden.'],
        ['Keine Registrierung', 'Anmeldung mit Benutzername und Passwort Ihres eigenen Servers: Es gibt kein Konto zu erstellen.'],
        ['Open Source', 'GPL-lizenziert: Sie können den Code selbst lesen, prüfen und installieren.'],
    ],
    'Überall' => [
        ['11 Sprachen', 'Englisch, Deutsch, Spanisch, Französisch, Niederländisch, Russisch, vereinfachtes und traditionelles Chinesisch, Japanisch, Hebräisch und Arabisch, mit gespiegeltem Layout für Hebräisch und Arabisch.'],
        ['Jedes Gerät', 'Funktioniert in jedem modernen Browser, auf Computer, Tablet und Handy, im hellen und dunklen Modus. Nichts zu installieren.'],
    ],
];
?>
<h1>Funktionen</h1>
<p class="pg-lead"><?= $h($app) ?> ist ein Dateimanager für Ihre FTP-, SFTP- und Amazon-S3-Server, der im Browser läuft.
  Alles Folgende funktioniert, ohne etwas auf Ihrem Computer zu installieren. <a href="<?= $h($url('screenshots')) ?>">Screenshots ansehen</a>.</p>
<?php foreach ($groups as $group => $items): ?>
  <h2><?= $h($group) ?></h2>
  <div class="pg-tiles">
    <?php foreach ($items as [$name, $text]): ?>
      <div class="pg-tile"><h3><?= $h($name) ?></h3><p><?= $h($text) ?></p></div>
    <?php endforeach ?>
  </div>
<?php endforeach ?>

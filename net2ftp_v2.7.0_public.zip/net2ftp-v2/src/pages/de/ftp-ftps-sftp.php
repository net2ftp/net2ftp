<?php
$doc = [
    'title' => 'FTP, FTPS oder SFTP: Was sollten Sie verwenden?',
    'lead' => 'Alle drei übertragen Dateien zwischen Ihrem Computer und einem Server, aber nur zwei schützen Ihr Passwort. So unterscheiden sie sich, und so wählen Sie.',
    'article' => '2026-11-26',
    'sections' => [
        ['h' => 'Die drei in Kürze',
         'ul' => [
             '<b>FTP</b> ist das ursprüngliche File Transfer Protocol. Alles, auch Ihr Passwort, wird unverschlüsselt übertragen.',
             '<b>FTPS</b> (FTP über TLS) ist FTP mit derselben Verschlüsselung wie HTTPS-Websites. Befehle und Dateien sind geschützt.',
             '<b>SFTP</b> hat mit FTP nichts zu tun: Es ist Dateiübertragung über SSH, das Protokoll, mit dem sich Administratoren auf Servern anmelden. Alles ist verschlüsselt.',
         ]],
        ['h' => 'Im Vergleich',
         'table' => [
             ['', 'FTP', 'FTPS', 'SFTP'],
             ['Verschlüsselt', 'Nein', 'Ja', 'Ja'],
             ['Üblicher Port', '21', '21 (explizit)', '22'],
             ['Zusätzliche Ports für Daten', 'Ja', 'Ja', 'Nein'],
             ['Durch Firewalls', 'Manchmal schwierig', 'Manchmal schwierig', 'Einfach'],
             ['Anmeldung mit', 'Passwort', 'Passwort', 'Passwort oder Schlüssel'],
             ['Befehle ausführen', 'Nein', 'Nein', 'Ja (SSH)'],
         ]],
        ['h' => 'Was Sie wählen sollten',
         'ol' => [
             '<b>SFTP</b>, wenn Ihr Server es anbietet: verschlüsselt, ein Port, und Sie können sich mit einem Schlüssel anmelden. Viele Hoster nennen es „SSH-Zugang“.',
             '<b>FTPS</b>, wenn Ihr Hoster nur FTP anbietet: Meist wird TLS auch unterstützt. Setzen Sie in {app} unter <i>Erweiterte Optionen</i> das Häkchen bei <i>FTP over TLS (FTPS)</i>.',
             '<b>Einfaches FTP</b> nur, wenn nichts anderes möglich ist, und nie in einem öffentlichen WLAN.',
         ]],
        ['h' => 'So finden Sie heraus, was Ihr Server unterstützt',
         'p' => [
             'Suchen Sie in der Willkommens-E-Mail oder im Kundenbereich Ihres Hosting-Anbieters nach „SFTP“, „SSH“ oder „FTP über TLS“. Sie können es auch einfach ausprobieren: Wählen Sie auf der [[login|Anmeldeseite]] <b>SFTP / SSH</b> mit Ihrem normalen Benutzernamen und Passwort; klappt das nicht, wählen Sie <b>FTP</b> mit eingeschaltetem <i>FTP over TLS (FTPS)</i>. {app} unterstützt explizites FTPS, die übliche Form auf Port 21.',
         ]],
    ],
    'related' => ['sftp-client', 'active-passive', 'online-ftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

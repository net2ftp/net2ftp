<?php
/** @var callable $h @var callable $url @var array $form @var array $site */
?>
<h1>Anfrage zum Datenschutz</h1>
<?php if (!$form['sent']): ?>
<p class="pg-lead">Nach der Datenschutz-Grundverordnung der EU (DSGVO) und dem Schweizer Bundesgesetz über den Datenschutz (DSG) können Sie fragen, welche personenbezogenen Daten wir über Sie haben,
  und sie berichtigen, löschen, einschränken oder sich herausgeben lassen. Verwenden Sie dieses Formular oder schreiben Sie uns<?php if (!empty($site['privacy_email'])): ?> an <a href="mailto:<?= $h($site['privacy_email']) ?>" dir="ltr"><?= $h($site['privacy_email']) ?></a><?php endif ?>.</p>
<p>Welche Daten wir verarbeiten, steht in der <a href="<?= $h($url('privacy')) ?>">Datenschutzerklärung</a>. Kurz gesagt: das Aktionsprotokoll (IP-Adresse, Server, Benutzername, was wann getan wurde),
  die Verbrauchs- und Sicherheitsprotokolle, Dateien, die Sie über einen Link geteilt haben, und die Cookies auf Ihrem eigenen Gerät. <b>Wir speichern Ihre Serverpasswörter nie</b> – wir können sie Ihnen also weder geben noch löschen.</p>
<p class="pg-small">Cookies und gespeicherte Server befinden sich auf Ihrem eigenen Gerät: Sie können sie jederzeit selbst über <i>Cookie-Einstellungen</i> unten auf der Anmeldeseite oder in Ihrem Browser entfernen.</p>
<?php endif ?>
<?php require N2F_ROOT . '/src/pages/_shared/gdpr_form.php'; ?>

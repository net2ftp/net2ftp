<?php
$doc = [
    'title' => 'Ratgeber',
    'lead' => 'Was Sie mit {app} tun können, Schritt für Schritt, und Antworten auf die häufigsten Fragen zu FTP, SFTP und Amazon S3.',
    'hub' => [
        ['{app} verwenden für …', ['online-ftp', 'sftp-client', 's3-browser', 'edit-online', 'large-uploads']],
        ['Wissen', ['active-passive', 'ftp-ftps-sftp', 'move-website']],
        ['Hilfe', ['faq', 'help']],
    ],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

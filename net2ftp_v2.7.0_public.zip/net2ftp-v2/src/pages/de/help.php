<?php
/** @var callable $h @var callable $url @var array $site @var string $app */
$maxDays = (int)(((array)\Net2ftp\App::cfg('shares', []))['max_days'] ?? 7);
$toc = [
    'login' => 'Anmelden', 'browse' => 'Sich zurechtfinden', 'upload' => 'Hochladen', 'download' => 'Herunterladen',
    'edit' => 'Eine Datei bearbeiten', 'organise' => 'Kopieren, verschieben, umbenennen, löschen', 'search' => 'Suchen',
    'perms' => 'Berechtigungen', 'extract' => 'Archive entpacken', 'share' => 'Freigabelinks', 'bookmarks' => 'Lesezeichen',
    'terminal' => 'SSH-Terminal', 'keys' => 'Tastenkürzel', 'large' => 'Große Dateien und lange Aufträge', 'problems' => 'Wenn etwas nicht klappt',
];
?>
<h1>So benutzen Sie <?= $h($app) ?></h1>
<p class="pg-lead">Alles, was Sie tun können, in der Reihenfolge, in der Sie es brauchen. Neu hier? Lesen Sie die ersten drei Abschnitte; der Rest ist da, wenn Sie ihn brauchen.</p>
<nav class="pg-toc" aria-label="Inhalt"><ol>
  <?php foreach ($toc as $id => $label): ?><li><a href="#<?= $h($id) ?>"><?= $h($label) ?></a></li><?php endforeach ?>
</ol></nav>

<h2 id="login">1. Anmelden</h2>
<ol>
  <li>Wählen Sie den Servertyp: <b>FTP</b> (die meisten Webhosting-Angebote), <b>SFTP / SSH</b> (Server, die Sie auch mit einem SSH-Client erreichen) oder <b>Amazon S3</b> (Cloud-Speicher). Welchen Sie haben, steht meist in der Willkommens-E-Mail Ihres Hosting-Anbieters.</li>
  <li>Geben Sie den <b>Server</b> (z. B. <code dir="ltr">ftp.example.com</code>), Ihren <b>Benutzernamen</b> und Ihr <b>Passwort</b> ein. Lassen Sie den Port leer, um den üblichen zu verwenden (21 für FTP, 22 für SFTP).</li>
  <li>Für Amazon S3 geben Sie stattdessen die <b>Zugriffsschlüssel-ID</b> und den <b>geheimen Zugriffsschlüssel</b> ein, optional einen Bucket und eine Region. Für anderen S3-kompatiblen Speicher öffnen Sie <i>Erweiterte Optionen</i> und geben dessen Endpunkt ein.</li>
  <li>Klicken Sie auf <b>Verbinden</b>.</li>
</ol>
<p><b>Prüfen Sie zuerst den Fingerabdruck</b> eines Servers, den Sie noch nicht verwendet haben: <i>Fingerabdruck des Servers prüfen</i> zeigt die Identität des Servers, bevor Ihr Passwort gesendet wird. Vergleichen Sie ihn mit dem, den Ihr Anbieter Ihnen nennt. Meldet net2ftp später, dass sich der Fingerabdruck <i>geändert</i> hat, melden Sie sich erst an, wenn Sie wissen, warum.</p>
<p><b>Einfaches FTP ist nicht verschlüsselt.</b> Wenn Ihr Server es unterstützt, schalten Sie unter Erweiterte Optionen <i>FTP over TLS (FTPS)</i> ein, oder verwenden Sie SFTP.</p>
<p><b>Diese Verbindung auf diesem Gerät speichern</b> merkt sich die Verbindung (mit verschlüsseltem Passwort) in Ihrem Browser, für bis zu 5 Server. Bei der nächsten Anmeldung über die Liste öffnet sich der Ordner, in dem Sie zuletzt gearbeitet haben. Die Option wird nur angeboten, wenn Sie Präferenz-Cookies erlauben. Verwenden Sie sie nicht auf einem gemeinsam genutzten Computer.</p>

<h2 id="browse">2. Sich zurechtfinden</h2>
<ul>
  <li><b>Öffnen Sie einen Ordner</b> mit einem Klick auf seinen Namen oder mit Enter. <b>Eine Ebene höher</b> geht es mit dem Pfeil oben links oder mit der Rücktaste.</li>
  <li>Der <b>Pfad</b> oben zeigt, wo Sie sind; klicken Sie auf einen Teil, um dorthin zu springen, oder doppelklicken Sie, um einen Pfad einzutippen.</li>
  <li><b>Sortieren</b> Sie mit einem Klick auf eine Spaltenüberschrift. <b>Filtern</b> Sie den aktuellen Ordner, indem Sie in das Filterfeld tippen (oder <kbd>/</kbd> drücken).</li>
  <li><b>Wählen Sie aus</b> mit den Kontrollkästchen, mit Strg-Klick (⌘-Klick auf dem Mac) oder mit Umschalt-Klick für einen Bereich. Die Aktionsleiste zeigt dann, was Sie mit der Auswahl tun können. Ein Rechtsklick zeigt dieselben Aktionen in einem Menü.</li>
  <li>Die Schaltflächen <b>Zurück und Vorwärts</b> des Browsers wechseln zwischen Ordnern.</li>
</ul>

<h2 id="upload">3. Hochladen</h2>
<p>Ziehen Sie Dateien oder ganze Ordner von Ihrem Computer auf die Seite, oder verwenden Sie <b>Hochladen</b>. Ordner behalten ihre Struktur. Dateien werden zu zweit gesendet, jeweils mit Fortschrittsanzeige; Sie können jede abbrechen. Existiert eine Datei bereits, werden Sie gefragt, ob sie ersetzt oder übersprungen werden soll. Wird ein Upload unterbrochen (Netzwerkfehler, Browser geschlossen), laden Sie dieselbe Datei erneut in denselben Ordner hoch: Er wird dort fortgesetzt, wo er stehen geblieben ist. Unvollendete Uploads werden nach der Anmeldung aufgelistet.</p>

<h2 id="download">4. Herunterladen</h2>
<p>Wählen Sie eine Datei aus und klicken Sie auf <b>Herunterladen</b>. Um mehrere Dateien oder einen Ordner herunterzuladen, wählen Sie sie aus und klicken auf <b>Zip</b>: Sie erhalten eine einzige Zip-Datei. Bilder und PDFs können Sie auch direkt mit <b>Anzeigen</b> öffnen. Wird ein großer Download unterbrochen, kann Ihr Browser ihn in seiner Download-Liste fortsetzen.</p>

<h2 id="edit">5. Eine Datei bearbeiten</h2>
<p>Klicken Sie auf eine Textdatei (HTML, PHP, CSS, JavaScript, Konfigurationsdateien …), um sie im Editor zu öffnen. Speichern mit <kbd>Strg</kbd>+<kbd>S</kbd>, Suchen und Ersetzen mit <kbd>Strg</kbd>+<kbd>F</kbd>. Hat jemand anderes die Datei auf dem Server geändert, nachdem Sie sie geöffnet haben, warnt net2ftp Sie, bevor dessen Änderungen überschrieben werden. Zeichenkodierung und Zeilenenden der Datei bleiben erhalten.</p>

<h2 id="organise">6. Kopieren, verschieben, umbenennen, löschen</h2>
<p>Wählen Sie die Elemente aus, dann <b>Kopieren</b> oder <b>Verschieben</b>, und wählen Sie den Zielordner. <b>Umbenennen</b> (F2) gilt für ein Element. <b>Löschen</b> entfernt Ordner mit allem, was darin ist – lesen Sie die Bestätigung also genau: Das kann nicht rückgängig gemacht werden. Große Kopier-, Verschiebe- und Löschvorgänge laufen als Aufträge: Der Bereich <b>Aufträge</b> zeigt ihren Fortschritt, und Sie können sie anhalten, fortsetzen oder abbrechen. Lassen Sie die Seite offen, solange ein Auftrag läuft; wenn Sie sie schließen, läuft er nach der nächsten Anmeldung weiter.</p>

<h2 id="search">7. Suchen</h2>
<p>Klicken Sie auf <b>Suchen</b>, um Text in Dateien oder Dateinamen im aktuellen Ordner und allem darunter zu finden. Sie können die Suche auf bestimmte Dateien beschränken (z. B. <code dir="ltr">*.php *.html</code>), Groß-/Kleinschreibung beachten oder einen regulären Ausdruck verwenden. Ein Klick auf ein Ergebnis öffnet die Datei an dieser Zeile.</p>

<h2 id="perms">8. Berechtigungen</h2>
<p>Wählen Sie Dateien und Ordner aus, dann <b>Berechtigungen</b> (nur FTP und SFTP). Setzen Sie Lesen, Schreiben und Ausführen für Besitzer, Gruppe und Andere, oder geben Sie die Zahl ein (z. B. <b>755</b> für Ordner und <b>644</b> für Dateien, die üblichen Werte für Websites). Haken Sie <i>rekursiv</i> an, um auch alles in den ausgewählten Ordnern zu ändern. Mit SFTP können Sie auch Besitzer und Gruppe ändern. net2ftp wählt die Reihenfolge der Änderungen so, dass Sie sich nicht auf halbem Weg aussperren, und warnt, wenn Sie einen Ordner mit den neuen Berechtigungen nicht mehr öffnen könnten.</p>

<h2 id="extract">9. Archive entpacken</h2>
<p>Wählen Sie eine <code dir="ltr">.zip</code>-, <code dir="ltr">.tar</code>-, <code dir="ltr">.tar.gz</code>- oder <code dir="ltr">.tar.bz2</code>-Datei aus und wählen Sie <b>Entpacken</b>. Sie wird auf dem Server in einen neuen Ordner mit dem Namen des Archivs oder in den aktuellen Ordner entpackt. Wählen Sie, ob vorhandene Dateien ersetzt oder behalten werden. Das ist viel schneller als herunterladen, entpacken und wieder hochladen.</p>

<h2 id="share">10. Freigabelinks</h2>
<p>Wählen Sie Dateien oder Ordner aus und klicken Sie auf <b>Teilen</b>, um einen Download-Link für jemanden ohne Zugriff auf Ihren Server zu erhalten. Wählen Sie, wie lange er gilt (1 Stunde bis <?= $maxDays ?> Tage), und optional ein Passwort, eine maximale Anzahl Downloads und eine Nachricht. Die Dateien werden beim Erstellen des Links kopiert, spätere Änderungen auf dem Server betreffen ihn also nicht. <b>Freigaben</b> oben listet Ihre Links auf; dort können Sie sie kopieren oder löschen. Senden Sie das Passwort getrennt vom Link.</p>

<h2 id="bookmarks">11. Lesezeichen</h2>
<p>Jeder Ordner und jede im Editor geöffnete Datei hat eine eigene Adresse. Setzen Sie ein Lesezeichen (<kbd>Strg</kbd>+<kbd>D</kbd>) oder kopieren Sie sie mit der Link-Schaltfläche, und sie öffnet dieselbe Stelle wieder. Passwörter sind nie Teil der Adresse: Ist der Server nicht gespeichert, werden Sie nach dem Passwort gefragt.</p>

<h2 id="terminal">12. SSH-Terminal</h2>
<p>Auf SFTP-Servern, die es erlauben, führt <b>Terminal</b> Shell-Befehle im aktuellen Ordner aus. <code dir="ltr">cd</code> wechselt auch den Ordner in der Dateiliste. Befehle laufen einzeln nacheinander; interaktive Programme (Editoren, <code dir="ltr">top</code>) funktionieren dort nicht.</p>

<h2 id="keys">13. Tastenkürzel</h2>
<table class="pg-table">
  <tbody>
    <tr><th dir="ltr">↑ ↓ PgUp PgDn Home End</th><td>Bewegen (mit Umschalt: Auswahl erweitern)</td></tr>
    <tr><th dir="ltr">Enter</th><td>Ordner oder Datei öffnen</td></tr>
    <tr><th dir="ltr">Backspace</th><td>Eine Ebene höher</td></tr>
    <tr><th dir="ltr">Space · Ctrl+A · Esc</th><td>Auswählen · alles auswählen · Auswahl aufheben</td></tr>
    <tr><th dir="ltr">F2 · Delete</th><td>Umbenennen · löschen</td></tr>
    <tr><th dir="ltr">/ · Ctrl+L · Ctrl+Shift+F</th><td>Filtern · Pfad eingeben · suchen</td></tr>
    <tr><th>Buchstaben</th><td>Zum ersten Namen springen, der damit beginnt</td></tr>
  </tbody>
</table>

<h2 id="large">14. Große Dateien und lange Aufträge</h2>
<ul>
  <li>Uploads werden in Teilen gesendet. Wird ein Upload unterbrochen, laden Sie dieselbe Datei erneut in denselben Ordner hoch, und er wird dort fortgesetzt, wo er stehen geblieben ist; unvollendete Uploads werden auch nach der Anmeldung aufgelistet.</li>
  <li>Downloads einzelner Dateien kann Ihr Browser fortsetzen. Zip-Downloads beginnen sofort, egal wie groß die Auswahl ist.</li>
  <li>Kopieren, Verschieben und Löschen von Ordnern läuft als Auftrag im Bereich <b>Aufträge</b>, mit Fortschritt, Anhalten und Fortsetzen. Lassen Sie die Seite offen; wenn Sie sie schließen, läuft der Auftrag nach der nächsten Anmeldung weiter.</li>
  <li>Bei Amazon S3 werden Kopien auf der S3-Seite erstellt, auch für Dateien über 5 GB, ohne Umweg über net2ftp.</li>
</ul>

<h2 id="problems">15. Wenn etwas nicht klappt</h2>
<ul>
  <li><b>„Verbindung fehlgeschlagen“</b>: Prüfen Sie Servername und Port. Manche Hosting-Anbieter sperren FTP von anderen Servern aus; fragen Sie dort nach, oder versuchen Sie SFTP.</li>
  <li><b>Angemeldet, aber der Ordner lädt nicht (FTP)</b>: Öffnen Sie die erweiterten Optionen und schalten Sie den <i>passiven Modus</i> aus – oder umgekehrt.</li>
  <li><b>„Zugriff verweigert“</b>: Ihr Konto darf das auf dem Server nicht. Fragen Sie den Administrator des Servers.</li>
  <li><b>„Ihre Sitzung ist abgelaufen“</b>: Sie waren eine Weile inaktiv. Melden Sie sich erneut an; Lesezeichen bringen Sie dorthin zurück, wo Sie waren.</li>
  <li>Etwas anderes? Wenden Sie sich an den Administrator dieser Website<?= !empty($site['email']) ? ' unter <span dir="ltr">' . $h($site['email']) . '</span>' : '' ?>.</li>
</ul>

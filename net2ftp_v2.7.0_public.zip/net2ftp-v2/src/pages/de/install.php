<?php
/** @var callable $h @var callable $url @var string $app */
require N2F_ROOT . '/src/pages/_shared/install_code.php';
?>
<h1><?= $h($app) ?> auf Ihrem Server installieren</h1>
<p class="pg-lead">Etwa 15 Minuten auf einem Linux-Server mit Apache, PHP und MySQL. Sie brauchen Shell-Zugang mit sudo.
  <a href="<?= $h($url('download')) ?>">Laden Sie</a> zuerst das Paket herunter und prüfen Sie dessen SHA-256.</p>

<h2>1. PHP und Erweiterungen installieren</h2>
<p>Unter Debian oder Ubuntu:</p>
<?= $pre('apt') ?>
<p>Die Erweiterungen <?= $c('ftp') ?>, <?= $c('sodium') ?> und <?= $c('openssl') ?> sind dort eingebaut. Auf anderen Systemen aktivieren Sie <?= $c('extension=ftp') ?>, <?= $c('curl') ?>, <?= $c('zip') ?> und <?= $c('sodium') ?> in der <?= $c('php.ini') ?>. <b>Unter Windows</b> fügen Sie außerdem den PHP-Ordner (z. B. <?= $c('C:\PHP') ?>) zum System-PATH hinzu und starten Windows neu, sonst kann Apache curl und sodium nicht laden.</p>

<h2>2. Dateien entpacken</h2>
<?= $pre('unpack') ?>
<p>Nur der Ordner <?= $c('public/') ?> darf aus dem Web erreichbar sein. <?= $c('src/') ?>, <?= $c('config.php') ?> und <?= $c('storage/') ?> müssen außerhalb des Web-Stammverzeichnisses bleiben.</p>

<h2>3. Datenbank anlegen</h2>
<?= $pre('db') ?>

<h2>4. Konfigurieren</h2>
<?= $pre('config') ?>
<p>Setzen Sie mindestens das Datenbankpasswort, <?= $c('secret_key') ?>, <?= $c('admin_password_hash') ?>, <?= $c('admin_totp_secret') ?> (der Zwei-Faktor-Code für die Administration; scannen Sie den Link mit einer Authenticator-App) und Ihre Angaben im Abschnitt <?= $c('site') ?> (sie erscheinen in der Datenschutzerklärung und im Haftungsausschluss).
  Die Standardwerte sind für eine öffentliche Installation gedacht: Verbindungen zu privaten Netzen sind gesperrt, und es gibt tägliche Limits pro Besucher und pro Server. Prüfen Sie sie in <?= $c('config.php') ?>.</p>

<h2>5. Apache auf den Ordner public zeigen lassen</h2>
<?= $pre('vhost') ?>
<p>Verwenden Sie immer <b>HTTPS</b>: Auf dieser Website werden Serverpasswörter eingegeben. Ein kostenloses Zertifikat: <?= $c($code['certbot']) ?>.</p>

<h2>6. Aufräumaufgabe einplanen</h2>
<p><?= $h($app) ?> löscht übrig gebliebene temporäre Dateien, abgelaufene Freigabelinks und alte Protokolleinträge selbst, einmal pro Stunde. Besser ist es, das cron zu überlassen, damit nie ein Besucher darauf warten muss:</p>
<?= $pre('cron') ?>
<p>Setzen Sie dann <?= $c($code['cronmode']) ?> in <?= $c('config.php') ?>.</p>

<h2>7. Prüfen</h2>
<p>Öffnen Sie <?= $c('https://files.example.com/admin.php') ?>, melden Sie sich mit Ihrem Administratorpasswort und Zwei-Faktor-Code an und öffnen Sie <b>System</b>. Alles sollte <i>OK</i> sein; was fehlt, wird dort samt Lösung erklärt. Melden Sie sich danach auf der Startseite bei einem Testserver an.</p>

<h2>Aktualisieren</h2>
<p>Entpacken Sie die neue Version neben der alten, kopieren Sie <?= $c('config.php') ?> und den Ordner <?= $c('storage/') ?> hinüber, aktualisieren Sie die Datenbank und stellen Sie dann das <?= $c('DocumentRoot') ?> um:</p>
<?= $pre('upgrade') ?>
<p>Übernehmen Sie neue Einstellungen aus <?= $c('config.sample.php') ?> in Ihre <?= $c('config.php') ?>. Die README im Paket beschreibt jede Einstellung.</p>

<?php
$doc = [
    'title' => 'Große Dateien im Browser hochladen',
    'lead' => 'Der Upload einer großen Datei über eine Website scheitert meist im ungünstigsten Moment: an einem Zeitlimit, einer Größenbegrenzung oder einer abgebrochenen Verbindung. {app} sendet Dateien in Teilen, damit Uploads jeder Größe dort weitergehen, wo sie unterbrochen wurden.',
    'sections' => [
        ['h' => 'So funktioniert es',
         'ul' => [
             'Dateien werden in Teilen gesendet, zwei Dateien gleichzeitig, mit Fortschritt für jede Datei.',
             'Wird der Upload unterbrochen (Netzwerkfehler, zugeklappter Laptop, geschlossener Browser), laden Sie dieselbe Datei erneut in denselben Ordner hoch: Sie wird dort fortgesetzt, wo sie stehen blieb, auch in einer späteren Sitzung.',
             'Unvollständige Uploads werden nach der Anmeldung angezeigt, damit Sie wissen, was noch fehlt.',
             'Ziehen Sie einen ganzen Ordner auf die Seite: Seine Struktur bleibt auf dem Server erhalten.',
         ],
         'shot' => ['resume', 'Ein unterbrochener Upload wird nach der nächsten Anmeldung wieder angeboten.']],
        ['h' => 'Schritt für Schritt',
         'ol' => [
             '[[login|Melden Sie sich]] bei Ihrem FTP-, SFTP- oder Amazon-S3-Server an.',
             'Öffnen Sie den Ordner, in den die Dateien sollen.',
             'Ziehen Sie die Dateien oder Ordner auf die Seite, oder klicken Sie auf <b>Hochladen</b>.',
             'Lassen Sie die Seite offen, bis der Fortschritt abgeschlossen ist. Geht etwas schief, laden Sie dieselbe Datei einfach noch einmal hoch.',
         ]],
        ['h' => 'Tipps für sehr viele oder sehr große Dateien',
         'ul' => [
             '<b>Viele kleine Dateien</b> (eine Website, eine Fotosammlung): Packen Sie sie auf Ihrem Computer in eine Zip-Datei, laden Sie diese eine Datei hoch und entpacken Sie sie mit <b>Entpacken</b> auf dem Server. Das ist viel schneller als Tausende einzelne Uploads.',
             '<b>Amazon S3</b>: Große Dateien werden in Teilen hochgeladen; Kopien von Dateien über 5 GB entstehen innerhalb von S3.',
             '<b>Downloads</b> großer Dateien kann Ihr Browser fortsetzen. Ordner werden als eine Zip-Datei heruntergeladen, die sofort beginnt, egal wie groß sie ist.',
         ]],
    ],
    'cta' => 'Upload starten',
    'related' => ['move-website', 's3-browser', 'online-ftp', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

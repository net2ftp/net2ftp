<?php
$doc = [
    'title' => 'Eine Website auf einen neuen Server umziehen',
    'lead' => 'Sie wechseln den Hosting-Anbieter? Mit {app} ziehen Sie die Dateien einer Website im Browser vom alten auf den neuen Server um, ohne FTP-Programm und ohne Tausende einzelne Dateien herunterzuladen.',
    'article' => '2026-11-26',
    'sections' => [
        ['h' => 'Bevor Sie beginnen',
         'ul' => [
             'Die FTP- oder SFTP-Zugangsdaten des <b>alten</b> und des <b>neuen</b> Servers.',
             'Verwendet die Website eine Datenbank (WordPress, Joomla, ein Shop …), exportieren Sie sie im Kundenbereich des alten Hosters (zum Beispiel mit phpMyAdmin) und importieren Sie sie beim neuen. {app} zieht Dateien um, keine Datenbanken.',
         ]],
        ['h' => 'Schritt für Schritt',
         'ol' => [
             '<b>Die Website als eine Zip-Datei herunterladen.</b> [[login|Melden Sie sich]] beim alten Server an, öffnen Sie den Ordner der Website (oft <code>public_html</code>, <code>www</code> oder <code>htdocs</code>), wählen Sie alles aus und klicken Sie auf <b>Zip</b>. Sie erhalten eine einzige Zip-Datei, egal wie groß.',
             '<b>Die Zip-Datei auf den neuen Server hochladen.</b> Melden Sie sich beim neuen Server an, öffnen Sie den Zielordner und ziehen Sie die Zip-Datei auf die Seite. Wird der Upload unterbrochen, laden Sie sie erneut hoch: Er geht dort weiter, wo er stehen blieb.',
             '<b>Auf dem Server entpacken.</b> Wählen Sie die Zip-Datei aus und dann <b>Entpacken</b>. Das Entpacken auf dem Server ist viel schneller, als jede Datei einzeln hochzuladen. Löschen Sie danach die Zip-Datei.',
             '<b>Berechtigungen setzen.</b> Meist <code>755</code> für Ordner und <code>644</code> für Dateien: Wählen Sie alles aus, dann <b>Berechtigungen</b>, und setzen Sie das Häkchen bei <i>rekursiv</i>. Ordner, in die die Website schreibt (Uploads, Cache), brauchen eventuell mehr; folgen Sie ihrer Dokumentation.',
             '<b>Die Konfiguration anpassen.</b> Öffnen Sie die Konfigurationsdatei im Editor (zum Beispiel <code>wp-config.php</code>) und tragen Sie den neuen Datenbanknamen, Benutzer und das Passwort ein. Mit <b>Suchen</b> finden Sie die alte Domain oder alte Pfade in allen Dateien.',
             '<b>Testen, dann umschalten.</b> Prüfen Sie die Website unter der vorläufigen Adresse des neuen Hosters (oder mit einem Eintrag in der hosts-Datei Ihres Computers) und lassen Sie erst dann Ihre Domain auf den neuen Server zeigen. Behalten Sie den alten Server noch einige Tage, bis die Änderung überall angekommen ist.',
         ]],
        ['h' => 'Schneller mit SSH',
         'p' => [
             'Bietet der alte Server SFTP mit Terminal, können Sie das Archiv auf dem Server selbst erstellen: Öffnen Sie <b>Terminal</b> im übergeordneten Ordner und führen Sie <code>tar -czf site.tar.gz public_html</code> aus. Laden Sie dann diese eine Datei herunter, auf den neuen Server hoch und entpacken Sie sie dort.',
         ]],
    ],
    'related' => ['large-uploads', 'edit-online', 'sftp-client'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

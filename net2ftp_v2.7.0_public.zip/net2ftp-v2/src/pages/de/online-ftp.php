<?php
$doc = [
    'title' => 'Online-FTP-Client: Ihre Dateien in einem Browser-Tab',
    'lead' => 'Mit {app} arbeiten Sie im Browser auf jedem FTP- oder FTPS-Server: Dateien hochladen, herunterladen, bearbeiten, verschieben und teilen, ohne ein FTP-Programm zu installieren. Kostenlos, Open Source und auf jedem Computer, Tablet und Smartphone.',
    'sections' => [
        ['h' => 'Was Sie tun können',
         'ul' => [
             '<b>Hochladen</b>: Dateien und ganze Ordner einfach auf die Seite ziehen. Große Uploads werden dort fortgesetzt, wo sie unterbrochen wurden.',
             '<b>Herunterladen</b>: einzelne Dateien oder eine beliebige Auswahl von Dateien und Ordnern als eine Zip-Datei.',
             '<b>Bearbeiten</b>: HTML-, PHP-, CSS-, JavaScript- und Konfigurationsdateien in einem Code-Editor mit Syntaxhervorhebung.',
             '<b>Kopieren, verschieben, umbenennen und löschen</b>: Ordner jeder Größe, mit Fortschrittsanzeige, Pause und Fortsetzen.',
             '<b>Suchen</b> Sie Text in einem ganzen Ordnerbaum, ändern Sie <b>Berechtigungen</b> (chmod) und <b>entpacken</b> Sie Zip- und Tar-Archive direkt auf dem Server.',
             '<b>Teilen</b>: Dateien über einen ablaufenden Download-Link weitergeben, auf Wunsch mit Passwort.',
         ],
         'shot' => ['browse', 'Die Dateiliste: sortieren, filtern, auswählen und viele Dateien auf einmal bearbeiten.']],
        ['h' => 'So funktioniert es',
         'ol' => [
             'Öffnen Sie [[login|die Anmeldeseite]] und wählen Sie <b>FTP</b>.',
             'Geben Sie Ihren Server (zum Beispiel <code>ftp.example.com</code>), Benutzernamen und Passwort ein. Sie stehen in der Willkommens-E-Mail Ihres Hosting-Anbieters.',
             'Klicken Sie auf <b>Verbinden</b>. Das ist alles: Es gibt kein Konto anzulegen.',
         ]],
        ['h' => 'Warum FTP im Browser?',
         'ul' => [
             '<b>Nichts zu installieren oder zu aktualisieren</b>: praktisch auf einem Firmencomputer, auf dem Sie keine Software installieren dürfen, auf einem geliehenen Laptop oder auf dem Smartphone.',
             '<b>Funktioniert auch, wo FTP gesperrt ist</b>: Viele Firmen- und Hotelnetze sperren FTP, erlauben aber Websites. {app} spricht für Sie mit Ihrem Server.',
             '<b>Überall gleich</b>: Windows, Mac, Linux, Chromebook, Android und iPhone, in 11 Sprachen, hell und dunkel.',
         ]],
        ['h' => 'Sicher in der Anwendung',
         'p' => [
             'Ihr Passwort wird nur für die Verbindung mit Ihrem Server verwendet. Es bleibt verschlüsselt, solange Sie angemeldet sind, wird nie im Klartext gespeichert und nie in Links eingefügt. Bevor Sie es senden, können Sie den Fingerabdruck des Servers prüfen. Wenn Ihr Server es unterstützt, schalten Sie unter <i>Erweiterte Optionen</i> <b>FTP over TLS (FTPS)</b> ein, damit alles verschlüsselt ist; warum das wichtig ist, lesen Sie in [[ftp-ftps-sftp|FTP, FTPS oder SFTP?]].',
         ]],
    ],
    'cta' => 'FTP-Client öffnen',
    'related' => ['sftp-client', 'large-uploads', 'edit-online', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

<?php
/**
 * Übersetzung der Datenschutzerklärung (Vorlage). Maßgeblich ist die englische Fassung.
 * @var callable $h @var callable $url @var array $site @var string $app
 */
require N2F_ROOT . '/src/pages/_shared/privacy_vars.php';
?>
<h1>Datenschutzerklärung</h1>
<?php if ($isTemplate): ?>
  <p class="pg-warn"><b>Vorlage.</b> Der Betreiber dieser Website hat seine Angaben noch nicht eingetragen (config.php → <code>site</code>). Bis dahin ist diese Erklärung unvollständig.</p>
<?php endif ?>
<p class="pg-lead">Diese Erklärung beschreibt, welche personenbezogenen Daten <?= $op ?> verarbeitet, wenn Sie <?= $h($app) ?> auf dieser Website nutzen, warum, wie lange, und welche Rechte Sie haben.</p>
<p class="pg-small">Zuletzt aktualisiert: <?= $h(date('d.m.Y', $updated)) ?>. Diese Übersetzung dient Ihrer Bequemlichkeit; bei Abweichungen ist nur die <?= $enLink('privacy', 'englische Fassung') ?> maßgeblich.</p>

<h2>1. Verantwortlicher</h2>
<p><?= $op ?>, <?= $h($site['address'] ?? '') ?> ist für Ihre personenbezogenen Daten verantwortlich. Fragen zum Datenschutz: <?= $mail ?>.</p>

<h2>2. Was wir verarbeiten und warum</h2>
<table class="pg-table">
  <thead><tr><th>Daten</th><th>Zweck</th><th>Rechtsgrundlage</th><th>Speicherdauer</th></tr></thead>
  <tbody>
    <tr><td><b>Anmeldedaten für den Server</b>: Server, Port, Benutzername, Passwort oder Schlüssel, Amazon-S3-Schlüssel</td>
      <td>Verbindung zum Server Ihrer Wahl, solange Sie angemeldet sind</td><td>Erbringung des von Ihnen angeforderten Dienstes (Art. <bdi dir="ltr" class="pg-nw">6(1)(b)</bdi> DSGVO)</td>
      <td>Nur solange Sie angemeldet sind, verschlüsselt; gelöscht beim Abmelden oder nach <?= $idle ?> Minuten Inaktivität. <b>Nie im Klartext auf die Festplatte oder in eine Datenbank geschrieben.</b></td></tr>
    <tr><td><b>Fortschritt von Kopier-, Verschiebe- und Löschaufträgen und von unvollendeten Uploads</b>: Server, Benutzername, Ordner- und Dateinamen, Größen, Fortschritt (keine Passwörter)</td>
      <td>Fortsetzen einer Übertragung nach einer Unterbrechung (Verbindung verloren, Browser geschlossen)</td><td>Erbringung des von Ihnen gewünschten Dienstes (DSGVO Art. <bdi dir="ltr" class="pg-nw">6(1)(b)</bdi>)</td>
      <td>7 Tage nach der letzten Aktivität, dann automatisch gelöscht</td></tr>
    <tr><td><b>Aktionsprotokoll</b>: IP-Adresse, Browser (User-Agent), Datum und Uhrzeit, Server, Benutzername, Ordner- und Dateinamen, Aktion, Datenmenge, Ergebnis</td>
      <td>Schutz der Serverbetreiber vor Missbrauch (gestohlene Passwörter, Verunstaltung von Websites), Bearbeitung von Missbrauchsmeldungen, Abwehr von Angriffen auf diese Website</td>
      <td>Berechtigtes Interesse an Sicherheit (Art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi> DSGVO)</td><td><?= $logDays ?> Tage, dann automatisch gelöscht</td></tr>
    <tr><td><b>Verbrauch pro IP-Adresse</b>: Datum, IP-Adresse, Anzahl Anfragen und Anmeldungen, Datenmenge, genutzte Serverzeit</td>
      <td>Durchsetzung der täglichen Limits, die den Dienst für alle verfügbar halten</td><td>Berechtigtes Interesse (Art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td>
      <td><?= $days['usage_ip'] ?> Tage, dann gelöscht. Summen pro Server (ohne IP-Adressen) werden <?= $days['usage_server'] ?> Tage für Statistiken aufbewahrt</td></tr>
    <tr><td><b>Sicherheitsereignisse</b>: IP-Adresse, Server, Benutzername, was geschah (Limit erreicht, gesperrt, fehlgeschlagene Administratoranmeldung …)</td>
      <td>Erkennen und Stoppen von Angriffen und Missbrauch</td><td>Berechtigtes Interesse (Art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td><?= $days['security'] ?> Tage</td></tr>
    <tr><td><b>Sperrliste</b>: nach Missbrauch gesperrte IP-Adressen und Server, mit Grund</td>
      <td>Verhindern weiteren Missbrauchs</td><td>Berechtigtes Interesse (Art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td>Bis die Sperre endet, dann <?= $days['blocks'] ?> Tage</td></tr>
    <tr><td><b>Fehlerberichte</b>: technische Fehlermeldungen der Software, Browsertyp und IP-Adresse des letzten Auftretens</td>
      <td>Fehler finden und beheben</td><td>Berechtigtes Interesse (Art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td><?= $days['errors'] ?> Tage nach dem letzten Auftreten des Fehlers; die IP-Adresse wird nach 30 Tagen entfernt</td></tr>
    <tr><td><b>Dateien, die Sie über einen Link teilen</b>, mit den Einstellungen des Links, Ihrer IP-Adresse (gegen Missbrauch), der Anzahl der Downloads und den IP-Adressen der Herunterladenden (im Aktionsprotokoll)</td>
      <td>Bereitstellung der Dateien für die Personen, denen Sie den Link senden</td><td>Erbringung des Dienstes (Art. <bdi dir="ltr" class="pg-nw">6(1)(b)</bdi>)</td>
      <td>Bis der Link abläuft (höchstens <?= $shareDays ?> Tage) oder Sie ihn löschen; dann sofort gelöscht</td></tr>
    <tr><td><b>Missbrauchsmeldungen und Datenschutzanfragen</b>, die Sie uns senden: Name, E-Mail-Adresse, Inhalt Ihrer Nachricht, IP-Adresse</td>
      <td>Bearbeitung Ihrer Meldung oder Anfrage</td><td>Rechtliche Verpflichtung (Art. <bdi dir="ltr" class="pg-nw">6(1)(c)</bdi>) und berechtigtes Interesse (Art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td>
      <td>So lange wie für die Bearbeitung nötig, höchstens 3 Jahre</td></tr>
    <tr><td><b>Webserver-Protokolle</b> unseres Hosting-Anbieters: IP-Adresse, Seite, Datum und Uhrzeit</td><td>Betrieb und Absicherung der Website</td>
      <td>Berechtigtes Interesse (Art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td>Gemäß den Einstellungen des Hosting-Anbieters</td></tr>
  </tbody>
</table>
<p>Wir sehen uns den Inhalt Ihrer Dateien nicht an, außer Sie teilen sie über einen Link und jemand meldet diesen Link als Missbrauch. Wir verkaufen keine personenbezogenen Daten und nutzen sie nicht für Werbung.</p>

<h2>3. Cookies</h2>
<table class="pg-table">
  <thead><tr><th>Cookie</th><th>Wofür</th><th>Kategorie</th><th>Speicherdauer</th></tr></thead>
  <tbody>
    <tr><td class="mono">N2FSESSID</td><td>Hält Sie angemeldet</td><td>Notwendig</td><td>Bis Sie den Browser schließen</td></tr>
    <tr><td class="mono">n2f_consent</td><td>Speichert Ihre Cookie-Auswahl</td><td>Notwendig</td><td>1 Jahr</td></tr>
    <tr><td class="mono">n2f_dl_*</td><td>Zeigt an, wann ein Download begonnen hat</td><td>Notwendig</td><td>2 Minuten</td></tr>
    <tr><td class="mono">n2f_sp_*</td><td>Merkt sich, dass Sie das Passwort eines Freigabelinks eingegeben haben</td><td>Notwendig</td><td>Bis der Link abläuft</td></tr>
    <tr><td class="mono">n2f_lang</td><td>Ihre Sprache</td><td>Präferenzen (sonst bis Sie den Browser schließen)</td><td>1 Jahr</td></tr>
    <tr><td class="mono">n2f_saved</td><td>Gespeicherte Server, einschließlich Passwort und zuletzt geöffnetem Ordner, verschlüsselt mit unserem Schlüssel und für Skripte unlesbar</td><td>Präferenzen</td><td><?= $remDays ?> Tage</td></tr>
  </tbody>
</table>
<p><?= $h($app) ?> setzt <b>keine Statistik- oder Werbe-Cookies</b>. Sie können Ihre Auswahl jederzeit über <i>Cookie-Einstellungen</i> unten auf der Anmeldeseite ändern; wenn Sie „Präferenzen“ widerrufen, werden die gespeicherten Server sofort gelöscht.</p>

<h2>4. Wer Daten erhält</h2>
<ul>
  <li><b>Die Server, mit denen Sie sich verbinden</b>, erhalten Ihre Anmeldedaten und Ihre Aktionen, wie bei jedem FTP- oder SSH-Programm. Deren Betreiber haben eigene Datenschutzerklärungen.</li>
  <li><b>Unser Hosting-Anbieter</b> speichert die Daten in unserem Auftrag auf Grundlage eines Auftragsverarbeitungsvertrags.</li>
  <li><b>Personen, denen Sie einen Freigabelink senden</b>, können die geteilten Dateien herunterladen.</li>
  <li><b>Serverbetreiber und Behörden</b>: Wird Ihr Konto für Missbrauch genutzt, können wir die betreffenden Protokolleinträge an den Betreiber des betroffenen Servers oder an die Polizei weitergeben, soweit das Gesetz es erlaubt oder verlangt.</li>
</ul>
<p>Land, in dem die Daten gespeichert werden: <?= $jurisdiction ?>. Werden Daten in andere Länder übermittelt, geschieht das nur mit geeigneten Garantien (z. B. EU-Standardvertragsklauseln).</p>

<h2>5. Sicherheit</h2>
<p>Alle Verbindungen zu dieser Website nutzen HTTPS. Anmeldedaten werden in der Sitzung verschlüsselt (XSalsa20-Poly1305 oder AES-256-GCM). Freigabelinks enthalten 192 Zufallsbits, werden nur als Hash gespeichert und können mit einem Passwort geschützt werden. Zugriff auf die Protokolle haben nur Administratoren.</p>

<h2>6. Ihre Rechte</h2>
<p>Sie können Auskunft über Ihre Daten, eine Kopie in einem maschinenlesbaren Format, Berichtigung, Löschung und Einschränkung der Verarbeitung verlangen und der Verarbeitung auf Grundlage berechtigter Interessen widersprechen.
  Verwenden Sie das <a href="<?= $h($url('gdpr')) ?>">Formular für Datenschutzanfragen</a> oder schreiben Sie an <?= $mail ?>. Wir antworten innerhalb von 30 Tagen.
  Bitte beachten Sie, dass das Aktionsprotokoll nach IP-Adresse, Server und Benutzername geordnet ist: Nennen Sie uns die von Ihnen verwendeten, damit wir Ihre Einträge finden.</p>
<p>Sie haben außerdem das Recht, sich bei einer Aufsichtsbehörde zu beschweren: in der Schweiz beim <?= $h($site['authority'] ?? 'EDÖB') ?>, in der EU bei der Behörde Ihres Landes.</p>

<h2>7. Änderungen</h2>
<p>Wir aktualisieren diese Erklärung, wenn sich der Dienst ändert. Das Datum oben zeigt die aktuelle Fassung.</p>

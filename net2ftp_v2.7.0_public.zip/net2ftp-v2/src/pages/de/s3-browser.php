<?php
$doc = [
    'title' => 'Amazon S3 im Browser',
    'lead' => 'Durchsuchen Sie Ihre Amazon-S3-Buckets wie Ordner auf einer Festplatte: Dateien hochladen, herunterladen, kopieren, teilen und bearbeiten, ohne AWS-Konsole und ohne Desktop-Programm. {app} funktioniert auch mit S3-kompatiblem Speicher.',
    'sections' => [
        ['h' => 'Was Sie tun können',
         'ul' => [
             'Alle Ihre Buckets durchsuchen, oder nur einen Bucket, wenn Ihr Schlüssel darauf beschränkt ist.',
             'Dateien und Ordner jeder Größe hochladen: Große Dateien werden in Teilen gesendet und nach einer Unterbrechung fortgesetzt.',
             'Eine Datei herunterladen, oder eine Auswahl von Dateien und „Ordnern“ als eine Zip-Datei.',
             'Dateien kopieren und verschieben, auch über 5 GB: Kopien entstehen innerhalb von S3, ohne über Ihren Computer zu laufen.',
             'Textdateien bearbeiten, Dateien suchen und Dateien über einen ablaufenden Download-Link teilen.',
         ]],
        ['h' => 'Welcher Speicher funktioniert',
         'p' => [
             'Amazon S3 in allen Regionen sowie Speicher, der das S3-Protokoll spricht, etwa MinIO, Wasabi, Cloudflare R2, Exoscale oder Infomaniak. Öffnen Sie dafür <i>Erweiterte Optionen</i> und geben Sie die Endpunkt-Adresse des Anbieters ein.',
         ]],
        ['h' => 'So melden Sie sich an',
         'ol' => [
             'Öffnen Sie [[login|die Anmeldeseite]] und wählen Sie <b>Amazon S3</b>.',
             'Geben Sie einen <b>Access Key</b> und einen <b>Secret Key</b> ein, auf Wunsch auch einen Bucket und eine Region.',
             'Klicken Sie auf <b>Verbinden</b>.',
         ],
         'p' => [
             '<b>Tipp:</b> Verwenden Sie nicht die Schlüssel Ihres AWS-Root-Kontos. Legen Sie einen IAM-Benutzer (oder temporäre Zugangsdaten) mit Zugriff nur auf die benötigten Buckets an. {app} hält den Secret Key verschlüsselt, solange Sie angemeldet sind, und fügt ihn nie in Links ein.',
         ]],
    ],
    'cta' => 'S3-Browser öffnen',
    'related' => ['large-uploads', 'online-ftp', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

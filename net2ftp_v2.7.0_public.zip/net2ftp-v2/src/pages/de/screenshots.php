<?php
/** @var callable $h @var string $app */
$shots = [
    ['login', 'Anmelden', 'Wählen Sie FTP, SFTP oder Amazon S3. Sie können den Fingerabdruck des Servers prüfen, bevor Sie Ihr Passwort senden.'],
    ['browse', 'Durchsuchen', 'Eine schnelle Dateiliste mit Sortieren, Filtern, Mehrfachauswahl und Kontextmenü.'],
    ['edit', 'Bearbeiten', 'Der Code-Editor mit Syntaxhervorhebung, Suchen und Ersetzen und Zeilennummern.'],
    ['search', 'Suchen', 'Text in einem ganzen Ordnerbaum finden; ein Klick auf ein Ergebnis öffnet die Datei an dieser Zeile.'],
    ['upload', 'Hochladen', 'Dateien oder Ordner auf die Seite ziehen; Fortschritt für jede Datei.'],
    ['resume', 'Uploads fortsetzen', 'Ein durch einen geschlossenen Browser unterbrochener Upload wird nach der nächsten Anmeldung wieder angeboten: Datei wählen, um fortzufahren.'],
    ['jobs', 'Kopieraufträge', 'Ordner jeder Größe kopieren, verschieben oder löschen: Fortschritt, Geschwindigkeit und Restzeit, mit Anhalten und Fortsetzen.'],
    ['permissions', 'Berechtigungen', 'Berechtigungen vieler Dateien und Ordner auf einmal ändern, rekursiv.'],
    ['terminal', 'SSH-Terminal', 'Befehle auf einem SFTP-Server im aktuellen Ordner ausführen, direkt neben der Dateiliste.'],
    ['share', 'Freigabelinks', 'Einen Download-Link mit Ablaufdatum, Passwort und Download-Limit erstellen.'],
    ['sharepage', 'Download-Seite', 'Was der Empfänger eines Freigabelinks sieht.'],
    ['arabic', 'In Ihrer Sprache', 'Elf Sprachen, mit gespiegeltem Layout für Arabisch und Hebräisch.'],
    ['mobile', 'Auf dem Handy', 'Dieselben Funktionen auf einem kleinen Bildschirm, hier im dunklen Modus.'],
];
?>
<h1>Screenshots</h1>
<p class="pg-lead">So sieht <?= $h($app) ?> aus. Klicken Sie auf ein Bild, um es in voller Größe zu sehen.</p>
<div class="pg-shots">
  <?php foreach ($shots as [$file, $title, $text]):
      $src = 'assets/img/screenshots/' . $file . '.webp';
      if (!is_file(N2F_ROOT . '/public/' . $src)) continue; ?>
    <figure class="pg-shot">
      <a href="<?= $h($src) ?>"><img src="<?= $h($src) ?>" alt="<?= $h($title . ': ' . $text) ?>" loading="lazy" width="720" height="450"></a>
      <figcaption><b><?= $h($title) ?></b> <?= $h($text) ?></figcaption>
    </figure>
  <?php endforeach ?>
</div>

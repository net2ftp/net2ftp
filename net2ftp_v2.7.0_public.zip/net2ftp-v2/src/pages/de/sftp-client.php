<?php
$doc = [
    'title' => 'Webbasierter SFTP-Client mit SSH-Terminal',
    'lead' => 'Verwalten Sie die Dateien auf Ihrem SFTP-Server im Browser und führen Sie gleich daneben Shell-Befehle aus. {app} unterstützt Passwörter und private Schlüssel, prüft die Identität des Servers und funktioniert mit Linux- und Windows-Servern.',
    'sections' => [
        ['h' => 'SFTP im Browser',
         'p' => [
             'SFTP ist Dateiübertragung über SSH: Die ganze Verbindung ist verschlüsselt und läuft über den einen Port, den Ihr Server ohnehin für SSH verwendet (meist 22). Mit {app} erhalten Sie den Dateimanager eines SFTP-Programms, ohne eines zu installieren: durchsuchen, hoch- und herunterladen (auch ganze Ordner, auch fortsetzbar), Dateien bearbeiten, Berechtigungen und Eigentümer ändern, Archive entpacken und Freigabelinks erstellen.',
         ]],
        ['h' => 'Anmelden mit Passwort oder Schlüssel',
         'ul' => [
             '<b>Passwort</b>: derselbe Benutzername und dasselbe Passwort wie für SSH.',
             '<b>Privater Schlüssel</b>: Fügen Sie einen RSA-, ECDSA- oder Ed25519-Schlüssel ein, mit Passphrase, falls er eine hat. Der Schlüssel dient nur der Anmeldung und bleibt verschlüsselt, solange Sie angemeldet sind.',
             '<b>Fingerabdruck prüfen</b>: Sehen Sie den Host-Schlüssel des Servers vor der Anmeldung und erhalten Sie eine Warnung, falls er sich jemals ändert.',
         ]],
        ['h' => 'Ein SSH-Terminal neben Ihren Dateien',
         'p' => [
             'Auf Servern, die es erlauben, führt <b>Terminal</b> Shell-Befehle in dem Ordner aus, den Sie gerade sehen: ein Archiv mit <code>tar</code> erstellen, den Speicherplatz mit <code>du</code> prüfen, einen Cache leeren, einen Datenbank-Dump oder einen Composer-Befehl ausführen. <code>cd</code> wechselt auch den Ordner in der Dateiliste. Befehle laufen nacheinander; interaktive Programme wie Editoren oder <code>top</code> funktionieren dort nicht.',
         ],
         'shot' => ['terminal', 'Das SSH-Terminal unter der Dateiliste, im aktuellen Ordner.']],
        ['h' => 'Wann SFTP die richtige Wahl ist',
         'p' => [
             'Wenn Ihr Server SFTP anbietet, verwenden Sie es: Es ist verschlüsselt, braucht nur einen Port und kommt leicht durch Firewalls. Viele Webhoster bieten es neben FTP an, manchmal unter dem Namen „SSH-Zugang“. Einen Vergleich finden Sie unter [[ftp-ftps-sftp|FTP, FTPS oder SFTP?]].',
         ]],
    ],
    'cta' => 'SFTP-Client öffnen',
    'related' => ['ftp-ftps-sftp', 'online-ftp', 'move-website', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

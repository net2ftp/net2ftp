<?php
/** @var callable $h @var array $form @var array $site @var string $app */
?>
<h1>Report abuse</h1>
<?php if (!$form['sent']): ?>
<p class="pg-lead"><?= $h($app) ?> is a tool that people use to manage <em>their own</em> servers. Like any FTP program, it can be misused by someone who has stolen a password.
  If your server was changed through this site, or a share link from this site is used for something illegal, tell us here.</p>
<p>Every action on this site is logged with the visitor's IP address, the server, the user name and the time. That lets us find the person responsible, block them,
  and give the information to you or to the police. We usually answer within two working days. Share links reported for malware or phishing are removed as soon as we have checked them.</p>
<p class="pg-small">Before you report: if your FTP password was used, <b>change it now</b> on your server. Logging out of this site doesn't stop someone who has your password.
  <?php if (!empty($site['abuse_email'])): ?>You can also write to <a href="mailto:<?= $h($site['abuse_email']) ?>" dir="ltr"><?= $h($site['abuse_email']) ?></a>.<?php endif ?></p>
<?php endif ?>
<?php require N2F_ROOT . '/src/pages/_shared/abuse_form.php'; ?>

<?php
$doc = [
    'title' => 'Active and passive FTP: what’s the difference?',
    'lead' => 'You can log in, but the file list never appears or a transfer hangs? The cause is almost always the FTP data connection, and the fix is often one checkbox: passive mode.',
    'article' => '2026-11-26',
    'sections' => [
        ['h' => 'FTP uses two connections',
         'p' => [
             'FTP was designed in the 1970s, long before firewalls. It uses one connection for commands (the <b>control connection</b>, usually port 21) and opens a new <b>data connection</b> for every file list and every file. Active and passive mode only differ in who opens that data connection.',
         ]],
        ['h' => 'Passive mode: the client connects',
         'p' => [
             'The client asks the server for a port (the <code>PASV</code> or <code>EPSV</code> command). The server opens a random port and the client connects to it. This works well when the client is behind a firewall or a home router, which is why passive mode is the default in browsers, in most FTP programs and in {app}. The server’s firewall must allow its range of passive ports.',
         ]],
        ['h' => 'Active mode: the server connects back',
         'p' => [
             'The client tells the server an address and a port (the <code>PORT</code> or <code>EPRT</code> command), and the server connects back to it. This works when the server is behind a firewall that only lets port 21 in, but the client must accept incoming connections. {app} supports both modes.',
         ]],
        ['h' => 'Problems and solutions',
         'table' => [
             ['What you see', 'What to do'],
             ['The login works, but the folder never loads or a time-out follows', 'Switch the mode: untick <i>Passive mode</i> under <i>Advanced options</i> on the login page, or tick it if it was off.'],
             ['“… did not answer the request for passive mode”', 'The server (or a firewall in front of it) blocks passive mode. Log in again with passive mode turned off.'],
             ['Active mode works with FTP, but not with FTP over TLS', 'Firewalls can’t read encrypted commands, so they can’t open the port for active mode. Use passive mode, or SFTP.'],
             ['Neither mode works', 'The server’s firewall blocks the data ports. Ask your hosting provider, or use SFTP, which needs only one port.'],
         ]],
        ['h' => 'For server administrators',
         'p' => [
             'For passive mode, choose a small port range, open it in the firewall and set it in the FTP server: <code>pasv_min_port</code> and <code>pasv_max_port</code> in vsftpd, <code>PassivePorts</code> in ProFTPD, or <code>-p</code> in Pure-FTPd. Behind NAT, the server must also announce its public address. {app} ignores the address in the passive reply and connects to the server’s own address, so a wrong address there doesn’t stop it.',
         ]],
    ],
    'related' => ['ftp-ftps-sftp', 'faq', 'online-ftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

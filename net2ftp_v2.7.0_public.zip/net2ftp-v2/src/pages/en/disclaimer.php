<?php
/**
 * TEMPLATE disclaimer — to be checked by a lawyer for the operator's jurisdiction.
 * @var callable $h @var callable $url @var array $site @var string $app
 */
require N2F_ROOT . '/src/pages/_shared/privacy_vars.php';
?>
<h1>Disclaimer</h1>
<?php if ($isTemplate): ?>
  <p class="pg-warn"><b>Template.</b> The operator of this site has not entered their details yet (config.php → <code>site</code>).</p>
<?php endif ?>
<p class="pg-lead">By using this website you accept the terms below. If you don't agree, please don't use it.</p>

<h2>1. The service</h2>
<p><?= $h($app) ?> is offered by <?= $op ?> free of charge and <b>as is</b>, without any warranty: we don't guarantee that it is always available, error-free, or suitable for a particular purpose.
  We may change, limit or stop the service at any time, and set limits on file sizes, transfers and use.</p>

<h2>2. Your responsibility</h2>
<ul>
  <li>Only connect to servers you are <b>authorised</b> to use, with credentials that are yours or that you are allowed to use.</li>
  <li>You are responsible for everything you do with the service: the files you upload, change, delete or share, and the consequences on your server.</li>
  <li><b>Make backups.</b> Deleting, overwriting, changing permissions and extracting archives can't be undone.</li>
  <li>Don't use the service for anything illegal: unauthorised access, defacing websites, distributing malware, phishing, spam, or files that infringe the rights of others.</li>
  <li>Don't try to overload, attack or get around the limits of this site or the servers it connects to.</li>
</ul>

<h2>3. Logging and abuse</h2>
<p>Every action is logged (see the <a href="<?= $h($url('privacy')) ?>">privacy policy</a>). In case of misuse we may block access, delete share links, and give the log entries to the owners of affected servers and to the authorities.
  To report misuse, use the <a href="<?= $h($url('abuse')) ?>">abuse form</a>.</p>

<h2>4. Share links</h2>
<p>Files shared with a link are published by the user who created the link, not by <?= $op ?>. We don't check them in advance. We remove links reported as illegal once we have checked the report.
  Download shared files only from people you trust.</p>

<h2>5. Liability</h2>
<p>To the extent permitted by law, <?= $op ?> is not liable for any damage resulting from the use of, or the inability to use, this website — in particular loss of data, damage to websites or servers, lost profits, or damage caused by other users.
  This doesn't limit liability for intent or gross negligence where the law doesn't allow it.</p>

<h2>6. Links to other websites</h2>
<p>We are not responsible for the content of websites we link to.</p>

<h2>7. The software</h2>
<p>The software behind this site is open source under the GNU General Public License, version 2 or later, and comes with no warranty. If you install it yourself, you are the operator of your installation.</p>

<h2>8. Applicable law</h2>
<p>These terms are governed by the law of <?= $jurisdiction ?>. The courts at the registered office of <?= $op ?> have jurisdiction, unless mandatory consumer protection law says otherwise.</p>
<p>Contact: <span dir="ltr"><?= $h($site['email'] ?? '') ?></span></p>

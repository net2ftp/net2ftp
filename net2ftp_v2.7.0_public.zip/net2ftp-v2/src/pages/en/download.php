<?php
/** @var callable $h @var callable $url @var array $site @var string $app @var string $version */
$L = [
    'file' => 'File', 'size' => 'Size', 'date' => 'Date',
    'check' => 'Check the download: %1$s (Linux), %2$s (macOS) or %3$s (Windows PowerShell) must show the same value.',
    'releases' => 'All releases', 'source' => 'Source code',
    'none' => 'No download is published on this server yet. Ask the administrator:',
];
?>
<h1>Download</h1>
<p class="pg-lead">Install <?= $h($app) ?> on your own web server, for your company, your customers or yourself.
  It is free and open source (GPL 2.0 or later). Current version: <b dir="ltr"><?= $h($version) ?></b>.</p>
<?php require N2F_ROOT . '/src/pages/_shared/download_files.php'; ?>

<h2>What you need</h2>
<table class="pg-table">
  <tbody>
    <tr><th>Web server</th><td>Apache 2.4 (mod_php or PHP-FPM), or nginx with PHP-FPM</td></tr>
    <tr><th>PHP</th><td>8.1 or newer, with the extensions ftp, curl, zip, mbstring, openssl or sodium (most are installed by default)</td></tr>
    <tr><th>Database</th><td>MySQL 5.7+ or MariaDB 10.3+ for the logs (optional, but recommended)</td></tr>
    <tr><th>Disk</th><td>About 5 MB for the code, plus room for temporary files and share links</td></tr>
  </tbody>
</table>
<p>Missing extensions don't break the installation: <?= $h($app) ?> tells you exactly what is missing and keeps the rest working.
  See <a href="<?= $h($url('install')) ?>">how to install</a>.</p>

<h2>What's new in <span dir="ltr"><?= $h($version) ?></span></h2>
<ul>
  <li>Daily limits for data and server time, per visitor and per FTP server, to keep the service fair for everyone.</li>
  <li>Automatic detection of mass uploads (the same file to many servers), with automatic blocking.</li>
  <li>A new administration panel: dashboard, investigation of abuse reports, consumption, blocks, errors and security events.</li>
  <li>Two-factor login and lockout for the administrator.</li>
  <li>Old log entries and leftover files are deleted automatically.</li>
  <li>The information pages are available in all eleven languages.</li>
</ul>

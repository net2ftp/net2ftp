<?php
$doc = [
    'title' => 'Edit files on your server online',
    'lead' => 'Fix a typo on your website, change a setting in a configuration file or update a PHP script directly on your FTP or SFTP server, from any browser. No download, edit and upload round trip.',
    'sections' => [
        ['h' => 'A real code editor',
         'ul' => [
             'Syntax highlighting for PHP, HTML, CSS, JavaScript and more than 20 other languages, with line numbers.',
             'Search and replace in the file (<kbd>Ctrl</kbd>+<kbd>F</kbd>), save with <kbd>Ctrl</kbd>+<kbd>S</kbd>.',
             'The file’s character encoding and line endings are kept, so Windows and Unix files stay as they were.',
             '<b>No lost changes</b>: if someone else changed the file on the server after you opened it, {app} warns you before overwriting it.',
         ],
         'shot' => ['edit', 'The code editor with syntax highlighting.']],
        ['h' => 'Find what to change',
         'p' => [
             '<b>Search</b> looks for text inside all files of a folder and its subfolders, for example an old e-mail address or a database setting. You can limit it to certain files (<code>*.php *.html</code>) or use a regular expression. Click a result to open the file at that line.',
         ]],
        ['h' => 'Around the editor',
         'ul' => [
             'Create new files and folders, rename and copy files to keep a backup before you change them.',
             'Change permissions, for example <code>644</code> for files and <code>755</code> for folders.',
             'Bookmark a file: every file in the editor has its own address, so you can come back to it directly.',
         ]],
    ],
    'cta' => 'Open the editor',
    'related' => ['online-ftp', 'move-website', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

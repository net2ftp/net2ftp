<?php
$doc = [
    'title' => 'Questions and answers',
    'lead' => 'The questions people ask most about {app}. Can’t find yours? Read [[help|How to use]] or the [[guides|guides]].',
    'faq' => [
        'About {app}' => [
            ['Is {app} free?', 'Yes. {app} is free and open source (GPL). You can use it on this site, or [[download|download]] it and install it on your own server.'],
            ['Do I need to create an account?', 'No. You log in with the user name and password of your own FTP, SFTP or S3 server. There is nothing to register.'],
            ['Do I need to install anything?', 'No. {app} runs in any modern browser, on Windows, Mac, Linux, Chromebook, Android and iPhone.'],
            ['Which servers does it work with?', 'Any FTP or FTPS server, any SFTP/SSH server on Linux or Windows, Amazon S3, and S3-compatible storage such as MinIO, Wasabi, Cloudflare R2, Exoscale or Infomaniak.'],
        ],
        'Security and privacy' => [
            ['Is it safe to enter my FTP password?', 'Your password is only used to connect to your server. It is kept encrypted while you are logged in, never written to disk in clear text and never put in links. You can check the server’s fingerprint before sending it.'],
            ['What is the server fingerprint?', 'The fingerprint identifies a server, like a seal on a letter. Compare it with the one your hosting provider gives you before you log in for the first time. If {app} later says that it changed, don’t log in until you know why.'],
            ['Do my files stay on your server?', 'No. Files pass through this server on their way between your computer and your server, and are not kept. The exceptions are the copies you make for share links (until the link expires) and the pieces of unfinished uploads (until they expire or you finish them).'],
            ['What is logged?', 'Every action (for example: who uploaded which file to which server, and when) is logged with the IP address, to protect server owners against abuse. The [[privacy|privacy policy]] says what is kept and for how long.'],
        ],
        'Connecting' => [
            ['Which port should I use?', 'Leave the port empty to use the usual one: 21 for FTP and FTPS, 22 for SFTP. Enter another port only if your provider tells you to.'],
            ['Why do I get “Could not connect”?', 'Check the server name and port. Some hosting providers only allow FTP from certain addresses, or not from other servers; ask them, or try SFTP instead.'],
            ['I can log in, but the folder doesn’t load. What now?', 'This is almost always the FTP data connection. Open <i>Advanced options</i> on the login page and untick <i>Passive mode</i> (or tick it, if it was off). [[active-passive|Active and passive FTP]] explains why.'],
            ['Should I use FTP, FTPS or SFTP?', 'SFTP or FTPS if your server supports it: both are encrypted. Plain FTP sends your password unencrypted. See [[ftp-ftps-sftp|FTP, FTPS or SFTP?]].'],
        ],
        'Files' => [
            ['Can I transfer large files?', 'Yes. Files are sent in pieces and continue where they stopped after an interruption, and folders of any size are copied, moved and zipped without time limits. See [[large-uploads|Upload large files]].'],
            ['Can I unzip files on the server?', 'Yes. Select a .zip, .tar, .tar.gz or .tar.bz2 file and choose <b>Extract</b>: it is unpacked directly on the server.'],
            ['How do I send a file to someone without access to my server?', 'Select it and click <b>Share</b>. You get a download link that expires, optionally with a password and a maximum number of downloads.'],
            ['Are there limits?', 'To keep the service fair for everyone, this site can limit how much each visitor and each server transfer per day. If you reach a limit, {app} says so; limits are reset at midnight (server time). On your own installation, you choose the limits.'],
        ],
        'Your own installation' => [
            ['Can I install {app} on my own server?', 'Yes. You need a web server with PHP 8.1 or newer; MySQL or MariaDB is optional but recommended. The [[install|installation guide]] takes about 15 minutes.'],
        ],
    ],
    'related' => ['help', 'active-passive', 'ftp-ftps-sftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

<?php
/** @var callable $h @var callable $url @var string $app */
$groups = [
    'Connect' => [
        ['FTP and FTPS', 'Passive and active mode, FTP over TLS (explicit), Unix and Windows servers.'],
        ['SFTP / SSH', 'Password or private key (RSA, ECDSA, Ed25519), with an SSH terminal for running commands.'],
        ['Amazon S3', 'Any region, a single bucket or all buckets, temporary credentials, and S3-compatible storage such as MinIO, Wasabi, Cloudflare R2, Exoscale or Infomaniak.'],
        ['Server fingerprint', 'See the SSH host key or the TLS certificate before your password is sent, and get a warning when it changes.'],
        ['Remembered servers', 'Up to 5 connections per browser, password encrypted, only if you allow preference cookies.'],
        ['Bookmarks', 'Every folder and file has its own address, so you can bookmark it. Passwords are never put in links.'],
    ],
    'Browse and transfer' => [
        ['Fast file list', 'Sort, filter, select with the keyboard or mouse, and open folders with 10,000 files instantly.'],
        ['Upload', 'Drag and drop files or whole folders. Large files are sent in pieces, two at a time, and an interrupted upload continues where it stopped, even in a later session.'],
        ['Download', 'Single files, or any selection of files and folders as one zip file. Interrupted downloads can be resumed in the browser.'],
        ['Copy, move, rename, delete', 'Recursive for folders of any size. Large jobs run in steps with progress, pause and resume, and continue after you log in again.'],
        ['Search', 'Find text in files, or files by name, in a whole folder tree, with regular expressions and file patterns.'],
    ],
    'Work on the server' => [
        ['Edit', 'A code editor with syntax highlighting for PHP, HTML, CSS, JavaScript and 20 more languages, search and replace, and protection against overwriting changes made by others.'],
        ['Permissions', 'chmod and chown for many files and folders at once, recursively, in an order that never locks you out.'],
        ['Extract', 'Unzip .zip, .tar, .tar.gz and .tar.bz2 archives directly on the server, safely.'],
        ['SSH terminal', 'Run shell commands in the current folder of an SFTP server, on Linux and Windows servers.'],
        ['Share links', 'Expiring download links with an optional password and download limit, like WeTransfer. Recipients never get access to your server.'],
    ],
    'Security and privacy' => [
        ['Encrypted credentials', 'Your password is kept encrypted while you are logged in, and never written to disk in clear text.'],
        ['Action log', 'Every action is logged, to protect server owners against abuse.'],
        ['Cookie choice', 'Only necessary cookies unless you allow more. No advertising or tracking cookies.'],
        ['Protection against abuse', 'Share links refuse programs and scripts, and limits per visitor protect the servers you connect to.'],
        ['No registration', 'Log in with your server’s own user name and password: there is no account to create.'],
        ['Open source', 'GPL licensed: you can read, check and install the code yourself.'],
    ],
    'Everywhere' => [
        ['11 languages', 'English, German, Spanish, French, Dutch, Russian, Simplified and Traditional Chinese, Japanese, Hebrew and Arabic, with a mirrored layout for Hebrew and Arabic.'],
        ['Any device', 'Works in any modern browser, on desktop, tablet and phone, in light and dark mode. Nothing to install.'],
    ],
];
?>
<h1>Features</h1>
<p class="pg-lead"><?= $h($app) ?> is a file manager for your FTP, SFTP and Amazon S3 servers that runs in the browser.
  Everything below works without installing anything on your computer. <a href="<?= $h($url('screenshots')) ?>">See the screenshots</a>.</p>
<?php foreach ($groups as $group => $items): ?>
  <h2><?= $h($group) ?></h2>
  <div class="pg-tiles">
    <?php foreach ($items as [$name, $text]): ?>
      <div class="pg-tile"><h3><?= $h($name) ?></h3><p><?= $h($text) ?></p></div>
    <?php endforeach ?>
  </div>
<?php endforeach ?>

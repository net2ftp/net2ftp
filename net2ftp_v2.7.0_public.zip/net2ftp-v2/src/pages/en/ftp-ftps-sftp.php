<?php
$doc = [
    'title' => 'FTP, FTPS or SFTP: which one should you use?',
    'lead' => 'All three move files between your computer and a server, but only two of them protect your password. Here is how they differ, and which one to pick.',
    'article' => '2026-11-26',
    'sections' => [
        ['h' => 'The three in short',
         'ul' => [
             '<b>FTP</b> is the original File Transfer Protocol. Everything, including your password, travels unencrypted.',
             '<b>FTPS</b> (FTP over TLS) is FTP with the same encryption as HTTPS websites. Commands and files are protected.',
             '<b>SFTP</b> has nothing to do with FTP: it is file transfer over SSH, the protocol administrators use to log in to servers. Everything is encrypted.',
         ]],
        ['h' => 'Compared',
         'table' => [
             ['', 'FTP', 'FTPS', 'SFTP'],
             ['Encrypted', 'No', 'Yes', 'Yes'],
             ['Usual port', '21', '21 (explicit)', '22'],
             ['Extra ports for data', 'Yes', 'Yes', 'No'],
             ['Through firewalls', 'Sometimes difficult', 'Sometimes difficult', 'Easy'],
             ['Log in with', 'Password', 'Password', 'Password or key'],
             ['Run commands', 'No', 'No', 'Yes (SSH)'],
         ]],
        ['h' => 'Which one to choose',
         'ol' => [
             '<b>SFTP</b>, if your server offers it: encrypted, one port, and you can log in with a key. Many hosts call it “SSH access”.',
             '<b>FTPS</b>, if your host only offers FTP: it usually supports TLS too. In {app}, tick <i>FTP over TLS</i> under <i>Advanced options</i>.',
             '<b>Plain FTP</b> only when nothing else is possible, and never on a public Wi-Fi network.',
         ]],
        ['h' => 'How to find out what your server supports',
         'p' => [
             'Look in your hosting provider’s welcome e-mail or control panel for “SFTP”, “SSH” or “FTP over TLS”. You can also simply try: choose <b>SFTP / SSH</b> on the [[login|login page]] with your normal user name and password; if that doesn’t connect, choose <b>FTP</b> with <i>FTP over TLS</i> switched on. {app} supports explicit FTPS, the common form on port 21.',
         ]],
    ],
    'related' => ['sftp-client', 'active-passive', 'online-ftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

<?php
/** @var callable $h @var callable $url @var array $form @var array $site */
?>
<h1>Data protection request</h1>
<?php if (!$form['sent']): ?>
<p class="pg-lead">Under the EU General Data Protection Regulation (GDPR) and the Swiss Federal Act on Data Protection (FADP), you can ask what personal data we hold about you,
  and have it corrected, deleted, restricted or handed over. Use this form, or write to
  <?php if (!empty($site['privacy_email'])): ?><a href="mailto:<?= $h($site['privacy_email']) ?>" dir="ltr"><?= $h($site['privacy_email']) ?></a><?php else: ?>us<?php endif ?>.</p>
<p>Which data we process is explained in the <a href="<?= $h($url('privacy')) ?>">privacy policy</a>. In short: the action log (IP address, server, user name, what was done and when),
  consumption and security logs, files you shared with a link, and the cookies on your own device. <b>We never store your server passwords</b>, so we can't give them to you or delete them.</p>
<p class="pg-small">Cookies and remembered servers are on your own device: you can remove them yourself at any time with <i>Cookie settings</i> at the bottom of the login page, or in your browser.</p>
<?php endif ?>
<?php require N2F_ROOT . '/src/pages/_shared/gdpr_form.php'; ?>

<?php
$doc = [
    'title' => 'Guides',
    'lead' => 'What you can do with {app}, step by step, and answers to the questions people ask most about FTP, SFTP and Amazon S3.',
    'hub' => [
        ['Use {app} for …', ['online-ftp', 'sftp-client', 's3-browser', 'edit-online', 'large-uploads']],
        ['Learn', ['active-passive', 'ftp-ftps-sftp', 'move-website']],
        ['Help', ['faq', 'help']],
    ],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

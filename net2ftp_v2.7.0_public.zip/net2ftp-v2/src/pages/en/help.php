<?php
/** @var callable $h @var callable $url @var array $site @var string $app */
$maxDays = (int)(((array)\Net2ftp\App::cfg('shares', []))['max_days'] ?? 7);
$toc = [
    'login' => 'Logging in', 'browse' => 'Finding your way around', 'upload' => 'Uploading', 'download' => 'Downloading',
    'edit' => 'Editing a file', 'organise' => 'Copy, move, rename, delete', 'search' => 'Searching',
    'perms' => 'Permissions', 'extract' => 'Extracting archives', 'share' => 'Share links', 'bookmarks' => 'Bookmarks',
    'terminal' => 'SSH terminal', 'keys' => 'Keyboard shortcuts', 'large' => 'Large files and long jobs', 'problems' => 'When something goes wrong',
];
?>
<h1>How to use <?= $h($app) ?></h1>
<p class="pg-lead">Everything you can do, in the order you will need it. New here? Read the first three sections; the rest is there when you need it.</p>
<nav class="pg-toc" aria-label="Contents"><ol>
  <?php foreach ($toc as $id => $label): ?><li><a href="#<?= $h($id) ?>"><?= $h($label) ?></a></li><?php endforeach ?>
</ol></nav>

<h2 id="login">1. Logging in</h2>
<ol>
  <li>Choose the type of server: <b>FTP</b> (most web hosting), <b>SFTP / SSH</b> (servers you can also reach with an SSH client) or <b>Amazon S3</b> (cloud storage). Your hosting provider's welcome e-mail usually says which one you have.</li>
  <li>Enter the <b>server</b> (e.g. <code>ftp.example.com</code>), your <b>username</b> and <b>password</b>. Leave the port empty to use the usual one (21 for FTP, 22 for SFTP).</li>
  <li>For Amazon S3, enter the <b>access key</b> and <b>secret key</b> instead, and optionally a bucket and region. For other S3-compatible storage, open <i>Advanced options</i> and enter its endpoint.</li>
  <li>Click <b>Connect</b>.</li>
</ol>
<p><b>Check the fingerprint first</b> on a server you haven't used before: <i>Check server fingerprint</i> shows the server's identity before your password is sent. Compare it with the one your provider gives you. If net2ftp later says the fingerprint <i>changed</i>, don't log in until you know why.</p>
<p><b>Plain FTP is not encrypted.</b> If your server supports it, switch on <i>FTP over TLS (FTPS)</i> under Advanced options, or use SFTP.</p>
<p><b>Remember this connection on this device</b> keeps the connection (and password, encrypted) in your browser, for up to 5 servers. It is only offered when you allow preference cookies. Don't use it on a shared computer.</p>

<h2 id="browse">2. Finding your way around</h2>
<ul>
  <li><b>Open a folder</b> by clicking its name, or with Enter. <b>Go up</b> with the arrow at the top left or Backspace.</li>
  <li>The <b>path</b> at the top shows where you are; click any part to jump there, or double-click it to type a path.</li>
  <li><b>Sort</b> by clicking a column header. <b>Filter</b> the current folder by typing in the filter box (or press <kbd>/</kbd>).</li>
  <li><b>Select</b> with the checkboxes, Ctrl-click (⌘-click on a Mac) or Shift-click for a range. The action bar then shows what you can do with the selection. Right-click for the same actions in a menu.</li>
  <li>The browser's <b>back and forward</b> buttons move between folders.</li>
</ul>

<h2 id="upload">3. Uploading</h2>
<p>Drag files or whole folders from your computer onto the page, or use <b>Upload</b>. Folders keep their structure. Files are sent two at a time, with progress for each; you can cancel any of them. If a file already exists, you are asked whether to replace it or skip it. If an upload is interrupted (network error, closed browser), upload the same file to the same folder again: it continues where it stopped. Unfinished uploads are listed after you log in.</p>

<h2 id="download">4. Downloading</h2>
<p>Select a file and click <b>Download</b>. To download several files or a folder, select them and click <b>Zip</b>: you get one zip file. Images and PDFs can also be opened directly with <b>View</b>. If a large download is interrupted, your browser can resume it from its list of downloads.</p>

<h2 id="edit">5. Editing a file</h2>
<p>Click a text file (HTML, PHP, CSS, JavaScript, configuration files …) to open it in the editor. Save with <kbd>Ctrl</kbd>+<kbd>S</kbd>, search and replace with <kbd>Ctrl</kbd>+<kbd>F</kbd>. If someone else changed the file on the server after you opened it, net2ftp warns you before overwriting their changes. The file's character encoding and line endings are kept.</p>

<h2 id="organise">6. Copy, move, rename, delete</h2>
<p>Select the items, then choose <b>Copy</b> or <b>Move</b> and pick the target folder. <b>Rename</b> (F2) works on one item. <b>Delete</b> removes folders with everything in them, so check the confirmation carefully: it can't be undone. Large copies, moves and deletions run as jobs: the <b>Jobs</b> panel shows their progress, and you can pause, resume or cancel them. Keep the page open while a job runs; if you close it, the job continues after your next login.</p>

<h2 id="search">7. Searching</h2>
<p>Click <b>Search</b> to look for text inside files, or for file names, in the current folder and everything below it. You can limit the search to certain files (e.g. <code>*.php *.html</code>), make it case-sensitive or use a regular expression. Click a result to open the file at that line.</p>

<h2 id="perms">8. Permissions</h2>
<p>Select files and folders, then <b>Permissions</b> (FTP and SFTP only). Tick read, write and execute for owner, group and others, or type the number (e.g. <b>755</b> for folders and <b>644</b> for files, the usual values for websites). Tick <i>recursive</i> to change everything inside the selected folders too. With SFTP you can also change the owner and group. net2ftp chooses the order of the changes so that you don't lock yourself out halfway; it warns you if your new permissions would stop you from opening a folder.</p>

<h2 id="extract">9. Extracting archives</h2>
<p>Select a <code>.zip</code>, <code>.tar</code>, <code>.tar.gz</code> or <code>.tar.bz2</code> file and choose <b>Extract</b>. It is unpacked on the server into a new folder named after the archive, or into the current folder. Choose whether existing files are replaced or kept. This is much faster than downloading, unpacking and uploading again.</p>

<h2 id="share">10. Share links</h2>
<p>Select files or folders and click <b>Share</b> to get a download link for someone without access to your server. Choose how long it works (1 hour to <?= $maxDays ?> days), and optionally a password, a maximum number of downloads and a message. The files are copied when you create the link, so later changes on the server don't affect it. <b>Shares</b> at the top lists your links, where you can copy or delete them. Send the password separately from the link.</p>

<h2 id="bookmarks">11. Bookmarks</h2>
<p>Every folder and file in the editor has its own address. Bookmark it (<kbd>Ctrl</kbd>+<kbd>D</kbd>) or copy it with the link button, and it opens the same place again. Passwords are never part of the address: if the server isn't remembered, you are asked for the password.</p>

<h2 id="terminal">12. SSH terminal</h2>
<p>For SFTP servers that allow it, <b>Terminal</b> runs shell commands in the current folder. <code>cd</code> also changes the folder shown in the file list. Commands run one at a time; interactive programs (editors, <code>top</code>) don't work there.</p>

<h2 id="keys">13. Keyboard shortcuts</h2>
<table class="pg-table">
  <tbody>
    <tr><th>↑ ↓ PgUp PgDn Home End</th><td>Move (with Shift: extend the selection)</td></tr>
    <tr><th>Enter</th><td>Open folder or file</td></tr>
    <tr><th>Backspace</th><td>Up one folder</td></tr>
    <tr><th>Space · Ctrl+A · Esc</th><td>Select · select all · clear selection</td></tr>
    <tr><th>F2 · Delete</th><td>Rename · delete</td></tr>
    <tr><th>/ · Ctrl+L · Ctrl+Shift+F</th><td>Filter · type a path · search</td></tr>
    <tr><th>Letters</th><td>Jump to the first name starting with them</td></tr>
  </tbody>
</table>

<h2 id="large">14. Large files and long jobs</h2>
<ul>
  <li>Uploads are sent in pieces. If an upload is interrupted, upload the same file to the same folder again and it continues where it stopped; unfinished uploads are also listed after you log in.</li>
  <li>Downloads of single files can be resumed by your browser. Zip downloads start at once, whatever the size of the selection.</li>
  <li>Copying, moving and deleting folders runs as a job in the <b>Jobs</b> panel, with progress, pause and resume. Keep the page open; if you close it, the job continues at your next login.</li>
  <li>On Amazon S3, copies are made on the S3 side, also for files over 5 GB, without passing through net2ftp.</li>
</ul>

<h2 id="problems">15. When something goes wrong</h2>
<ul>
  <li><b>"Could not connect"</b>: check the server name and port. Some hosting providers block FTP from other servers; ask them, or try SFTP.</li>
  <li><b>Logged in, but the folder doesn't load (FTP)</b>: open Advanced options and untick <i>Passive mode</i>, or the other way round.</li>
  <li><b>"Permission denied"</b>: your account isn't allowed to do that on the server. Ask the server's administrator.</li>
  <li><b>"Your session timed out"</b>: you were inactive for a while. Log in again; bookmarks bring you back to where you were.</li>
  <li>Something else? Contact the administrator of this site<?= !empty($site['email']) ? ' at ' . $h($site['email']) : '' ?>.</li>
</ul>

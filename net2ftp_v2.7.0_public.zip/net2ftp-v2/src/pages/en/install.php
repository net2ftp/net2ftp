<?php
/** @var callable $h @var callable $url @var string $app */
require N2F_ROOT . '/src/pages/_shared/install_code.php';
?>
<h1>Install <?= $h($app) ?> on your server</h1>
<p class="pg-lead">About 15 minutes on a Linux server with Apache, PHP and MySQL. You need shell access with sudo.
  First <a href="<?= $h($url('download')) ?>">download</a> the package and check its SHA-256.</p>

<h2>1. Install PHP and its extensions</h2>
<p>On Debian or Ubuntu:</p>
<?= $pre('apt') ?>
<p>The <?= $c('ftp') ?>, <?= $c('sodium') ?> and <?= $c('openssl') ?> extensions are built in there. On other systems, enable <?= $c('extension=ftp') ?>, <?= $c('curl') ?>, <?= $c('zip') ?> and <?= $c('sodium') ?> in <?= $c('php.ini') ?>. <b>On Windows</b>, also add the PHP folder (e.g. <?= $c('C:\PHP') ?>) to the system PATH and restart Windows, otherwise Apache can't load curl and sodium.</p>

<h2>2. Unpack the files</h2>
<?= $pre('unpack') ?>
<p>Only the <?= $c('public/') ?> folder may be reachable from the web. <?= $c('src/') ?>, <?= $c('config.php') ?> and <?= $c('storage/') ?> must stay outside the web root.</p>

<h2>3. Create the database</h2>
<?= $pre('db') ?>

<h2>4. Configure</h2>
<?= $pre('config') ?>
<p>Set at least the database password, <?= $c('secret_key') ?>, <?= $c('admin_password_hash') ?>, <?= $c('admin_totp_secret') ?> (the two-factor code for the administration, scan the link with an authenticator app) and your details in the <?= $c('site') ?> section (they appear in the privacy policy and disclaimer).
  The defaults are made for a public installation: connections to private networks are blocked, and there are daily limits per visitor and per server. Review them in <?= $c('config.php') ?>.</p>

<h2>5. Point Apache to the public folder</h2>
<?= $pre('vhost') ?>
<p>Always use <b>HTTPS</b>: people type server passwords into this site. A free certificate: <?= $c($code['certbot']) ?>.</p>

<h2>6. Schedule the cleanup job</h2>
<p><?= $h($app) ?> deletes leftover temporary files, expired share links and old log entries by itself, once an hour. It is better to let cron do it, so that no visitor ever waits for it:</p>
<?= $pre('cron') ?>
<p>Then set <?= $c($code['cronmode']) ?> in <?= $c('config.php') ?>.</p>

<h2>7. Check</h2>
<p>Open <?= $c('https://files.example.com/admin.php') ?>, log in with your admin password and two-factor code, and open <b>System</b>. Everything should be <i>OK</i>; anything missing is explained there, with the fix. Then log in to a test server on the home page.</p>

<h2>Upgrading</h2>
<p>Unpack the new version next to the old one, copy <?= $c('config.php') ?> and the <?= $c('storage/') ?> folder across, update the database, then switch the <?= $c('DocumentRoot') ?>:</p>
<?= $pre('upgrade') ?>
<p>Add any new settings from <?= $c('config.sample.php') ?> to your <?= $c('config.php') ?>. The README in the package lists every setting.</p>

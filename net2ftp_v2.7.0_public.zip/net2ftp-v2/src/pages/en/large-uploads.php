<?php
$doc = [
    'title' => 'Upload large files from your browser',
    'lead' => 'Uploading a large file through a website usually fails at the worst moment: a time limit, a size limit or a dropped connection. {app} sends files in pieces, so uploads of any size continue where they stopped.',
    'sections' => [
        ['h' => 'How it works',
         'ul' => [
             'Files are sent in pieces, two files at a time, with progress for each file.',
             'If the upload is interrupted (network error, closed laptop, closed browser), upload the same file to the same folder again: it continues where it stopped, also in a later session.',
             'Unfinished uploads are listed after you log in, so you know what is left.',
             'Drag a whole folder onto the page: its structure is kept on the server.',
         ],
         'shot' => ['resume', 'An interrupted upload is offered again after the next login.']],
        ['h' => 'Step by step',
         'ol' => [
             '[[login|Log in]] to your FTP, SFTP or Amazon S3 server.',
             'Open the folder where the files should go.',
             'Drag the files or folders onto the page, or click <b>Upload</b>.',
             'Keep the page open until the progress is complete. If something goes wrong, simply upload the same file again.',
         ]],
        ['h' => 'Tips for very many or very large files',
         'ul' => [
             '<b>Many small files</b> (a website, a photo collection): zip them on your computer, upload the one zip file, and use <b>Extract</b> to unpack it on the server. That is much faster than thousands of single uploads.',
             '<b>Amazon S3</b>: large files are uploaded in parts; copies of files over 5 GB are made inside S3.',
             '<b>Downloads</b> of large files can be resumed by your browser. Folders are downloaded as one zip file that starts at once, whatever the size.',
         ]],
    ],
    'cta' => 'Start uploading',
    'related' => ['move-website', 's3-browser', 'online-ftp', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

<?php
$doc = [
    'title' => 'Move a website to a new server',
    'lead' => 'Changing hosting provider? With {app} you can move the files of a website from the old server to the new one in your browser, without an FTP program and without downloading thousands of single files.',
    'article' => '2026-11-26',
    'sections' => [
        ['h' => 'Before you start',
         'ul' => [
             'The FTP or SFTP login details of the <b>old</b> and the <b>new</b> server.',
             'If the site uses a database (WordPress, Joomla, a shop …): export it in the old host’s control panel (for example with phpMyAdmin) and import it at the new host. {app} moves files, not databases.',
         ]],
        ['h' => 'Step by step',
         'ol' => [
             '<b>Download the site as one zip.</b> [[login|Log in]] to the old server, open the folder of the website (often <code>public_html</code>, <code>www</code> or <code>htdocs</code>), select everything and click <b>Zip</b>. You get one zip file, whatever the size.',
             '<b>Upload the zip to the new server.</b> Log in to the new server, open the target folder and drag the zip file onto the page. If the upload is interrupted, upload it again: it continues where it stopped.',
             '<b>Extract it on the server.</b> Select the zip file and choose <b>Extract</b>. Unpacking on the server is much faster than uploading every file separately. Then delete the zip file.',
             '<b>Set the permissions.</b> Usually <code>755</code> for folders and <code>644</code> for files: select everything, choose <b>Permissions</b> and tick <i>recursive</i>. Folders the website writes to (uploads, cache) may need more; follow its documentation.',
             '<b>Update the configuration.</b> Open the configuration file in the editor (for example <code>wp-config.php</code>) and enter the new database name, user and password. Use <b>Search</b> to find the old domain or old paths in all files.',
             '<b>Test, then switch.</b> Check the site at the new host’s temporary address (or with an entry in your computer’s hosts file), and only then point your domain to the new server. Keep the old server for a few days until the change has reached everyone.',
         ]],
        ['h' => 'Faster with SSH',
         'p' => [
             'If the old server offers SFTP with a terminal, you can create the archive on the server itself: open <b>Terminal</b> in the parent folder and run <code>tar -czf site.tar.gz public_html</code>. Then download that one file, upload it to the new server and extract it there.',
         ]],
    ],
    'related' => ['large-uploads', 'edit-online', 'sftp-client'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

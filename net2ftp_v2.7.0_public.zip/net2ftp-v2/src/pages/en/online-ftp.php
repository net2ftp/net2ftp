<?php
$doc = [
    'title' => 'Online FTP client: your files in a browser tab',
    'lead' => '{app} lets you work on any FTP or FTPS server from your browser: upload, download, edit, move and share files without installing an FTP program. It is free, open source and works on any computer, tablet or phone.',
    'sections' => [
        ['h' => 'What you can do',
         'ul' => [
             '<b>Upload</b> files and whole folders by dragging them onto the page. Large uploads continue where they stopped.',
             '<b>Download</b> single files, or any selection of files and folders as one zip file.',
             '<b>Edit</b> HTML, PHP, CSS, JavaScript and configuration files in a code editor with syntax highlighting.',
             '<b>Copy, move, rename and delete</b> folders of any size, with progress, pause and resume.',
             '<b>Search</b> for text in a whole folder tree, change <b>permissions</b> (chmod) and <b>extract</b> zip and tar archives on the server.',
             '<b>Share</b> files with an expiring download link, with an optional password.',
         ],
         'shot' => ['browse', 'The file list: sort, filter, select and act on many files at once.']],
        ['h' => 'How it works',
         'ol' => [
             'Open [[login|the login page]] and choose <b>FTP</b>.',
             'Enter your server (for example <code>ftp.example.com</code>), user name and password. Your hosting provider’s welcome e-mail has them.',
             'Click <b>Connect</b>. That’s all: there is no account to create.',
         ]],
        ['h' => 'Why use FTP in the browser?',
         'ul' => [
             '<b>Nothing to install or update</b>: handy on a work computer where you can’t install software, on a borrowed laptop or on a phone.',
             '<b>Works where FTP is blocked</b>: many company and hotel networks block FTP but allow websites. {app} talks to your server for you.',
             '<b>The same everywhere</b>: Windows, Mac, Linux, Chromebook, Android and iPhone, in 11 languages, in light and dark mode.',
         ]],
        ['h' => 'Safe to use',
         'p' => [
             'Your password is only used to connect to your server. It is kept encrypted while you are logged in, never written to disk in clear text and never put in links. Before you send it, you can check the server’s fingerprint. If your server supports it, switch on <b>FTP over TLS</b> under <i>Advanced options</i> so that everything is encrypted; read [[ftp-ftps-sftp|FTP, FTPS or SFTP?]] to see why that matters.',
         ]],
    ],
    'cta' => 'Open the FTP client',
    'related' => ['sftp-client', 'large-uploads', 'edit-online', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

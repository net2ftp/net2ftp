<?php
/**
 * TEMPLATE privacy policy. It describes what this software actually does with personal data, with the
 * values from config.php. The operator must complete the 'site' details and have it checked by a lawyer:
 * hosting provider, other processors and the legal situation differ per installation.
 * @var callable $h @var callable $url @var array $site @var string $app
 */
require N2F_ROOT . '/src/pages/_shared/privacy_vars.php';
?>
<h1>Privacy policy</h1>
<?php if ($isTemplate): ?>
  <p class="pg-warn"><b>Template.</b> The operator of this site has not entered their details yet (config.php → <code>site</code>). Until then, this policy is incomplete.</p>
<?php endif ?>
<p class="pg-lead">This policy explains which personal data <?= $op ?> processes when you use <?= $h($app) ?> on this website, why, for how long, and what your rights are.</p>
<p class="pg-small">Last updated: <?= $h(date('j F Y', $updated)) ?></p>

<h2>1. Who is responsible</h2>
<p><?= $op ?>, <?= $h($site['address'] ?? '') ?> is the controller of your personal data. Questions about data protection: <?= $mail ?>.</p>

<h2>2. What we process, and why</h2>
<table class="pg-table">
  <thead><tr><th>Data</th><th>Purpose</th><th>Legal basis</th><th>Kept for</th></tr></thead>
  <tbody>
    <tr><td><b>Server login details</b>: server, port, user name, password or key, Amazon S3 keys</td>
      <td>Connecting to the server you choose, for as long as you are logged in</td><td>Performance of the service you request (GDPR art. <bdi dir="ltr" class="pg-nw">6(1)(b)</bdi>)</td>
      <td>Only while you are logged in, encrypted; deleted when you log out or after <?= $idle ?> minutes of inactivity. <b>Never written to disk or a database in clear text.</b></td></tr>
    <tr><td><b>Progress of copy, move and delete jobs and of unfinished uploads</b>: server, user name, folder and file names, sizes, progress (no passwords)</td>
      <td>Continuing a transfer after an interruption (lost connection, closed browser)</td><td>Performance of the service you request (GDPR art. <bdi dir="ltr" class="pg-nw">6(1)(b)</bdi>)</td>
      <td>7 days after the last activity, then deleted automatically</td></tr>
    <tr><td><b>Action log</b>: IP address, browser (user agent), date and time, server, user name, folder and file names, action, amount of data, result</td>
      <td>Protecting server owners against misuse (stolen passwords, defacement), investigating abuse reports, preventing attacks on this site</td>
      <td>Legitimate interest in security (GDPR art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td><?= $logDays ?> days, then deleted automatically</td></tr>
    <tr><td><b>Consumption per IP address</b>: date, IP address, number of requests and logins, amount of data, server time used</td>
      <td>Enforcing the daily limits that keep the service available for everyone</td><td>Legitimate interest (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td>
      <td><?= $days['usage_ip'] ?> days, then deleted. Totals per server (without IP addresses) are kept <?= $days['usage_server'] ?> days for statistics</td></tr>
    <tr><td><b>Security events</b>: IP address, server, user name, what happened (limit reached, blocked, failed administrator login …)</td>
      <td>Detecting and stopping attacks and misuse</td><td>Legitimate interest (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td><?= $days['security'] ?> days</td></tr>
    <tr><td><b>Block list</b>: IP addresses and servers blocked after misuse, with the reason</td>
      <td>Preventing further misuse</td><td>Legitimate interest (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td>Until the block ends, then <?= $days['blocks'] ?> days</td></tr>
    <tr><td><b>Error reports</b>: technical error messages of the software, the browser type, and the IP address of the last occurrence</td>
      <td>Finding and fixing bugs</td><td>Legitimate interest (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td><?= $days['errors'] ?> days after the error last happened; the IP address is removed after 30 days</td></tr>
    <tr><td><b>Files you share with a link</b>, with the link's settings, your IP address (to stop abuse), the number of downloads and the downloaders' IP addresses in the action log</td>
      <td>Making the files available to the people you send the link to</td><td>Performance of the service (art. <bdi dir="ltr" class="pg-nw">6(1)(b)</bdi>)</td>
      <td>Until the link expires (at most <?= $shareDays ?> days) or you delete it; then deleted at once</td></tr>
    <tr><td><b>Abuse reports and data protection requests</b> you send us: name, e-mail address, the content of your message, IP address</td>
      <td>Handling your report or request</td><td>Legal obligation (art. <bdi dir="ltr" class="pg-nw">6(1)(c)</bdi>) and legitimate interest (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td>
      <td>As long as needed to handle it, at most 3 years</td></tr>
    <tr><td><b>Web server logs</b> of our hosting provider: IP address, page, date and time</td><td>Operating and securing the website</td>
      <td>Legitimate interest (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td>According to the hosting provider's settings</td></tr>
  </tbody>
</table>
<p>We don't look at the content of your files unless you share them with a link and someone reports that link as abuse. We don't sell personal data and don't use it for advertising.</p>

<h2>3. Cookies</h2>
<table class="pg-table">
  <thead><tr><th>Cookie</th><th>What for</th><th>Category</th><th>Kept for</th></tr></thead>
  <tbody>
    <tr><td class="mono">N2FSESSID</td><td>Keeps you logged in</td><td>Necessary</td><td>Until you close the browser</td></tr>
    <tr><td class="mono">n2f_consent</td><td>Remembers your cookie choice</td><td>Necessary</td><td>1 year</td></tr>
    <tr><td class="mono">n2f_dl_*</td><td>Shows when a download has started</td><td>Necessary</td><td>2 minutes</td></tr>
    <tr><td class="mono">n2f_sp_*</td><td>Remembers that you entered the password of a share link</td><td>Necessary</td><td>Until the link expires</td></tr>
    <tr><td class="mono">n2f_lang</td><td>Your language</td><td>Preferences (otherwise until you close the browser)</td><td>1 year</td></tr>
    <tr><td class="mono">n2f_saved</td><td>Remembered servers, including the password and the last folder you opened, encrypted with our key and unreadable for scripts</td><td>Preferences</td><td><?= $remDays ?> days</td></tr>
  </tbody>
</table>
<p><?= $h($app) ?> sets <b>no statistics or advertising cookies</b>. You can change your choice at any time with <i>Cookie settings</i> at the bottom of the login page; withdrawing "Preferences" deletes the remembered servers at once.</p>

<h2>4. Who receives data</h2>
<ul>
  <li><b>The servers you connect to</b> receive your login details and your actions, like with any FTP or SSH program. Their owners have their own privacy policies.</li>
  <li><b>Our hosting provider</b> stores the data on our behalf, under a data processing agreement.</li>
  <li><b>People you send a share link to</b> can download the shared files.</li>
  <li><b>Server owners and authorities</b>: if your account is used for abuse, we may give the relevant log entries to the owner of the affected server or to the police, where the law allows or requires it.</li>
</ul>
<p>Data is stored in <?= $jurisdiction ?>. Where data is transferred to other countries, this happens only with appropriate safeguards (e.g. EU standard contractual clauses).</p>

<h2>5. Security</h2>
<p>All connections to this site use HTTPS. Login details are encrypted in the session (XSalsa20-Poly1305 or AES-256-GCM). Share links contain 192 random bits, are stored only as a hash, and can be protected with a password. Access to the logs is limited to administrators.</p>

<h2>6. Your rights</h2>
<p>You can ask for access to your data, a copy in a machine-readable format, correction, deletion, restriction of processing, and object to processing based on legitimate interest.
  Use the <a href="<?= $h($url('gdpr')) ?>">data protection request form</a> or write to <?= $mail ?>. We answer within 30 days.
  Please note that the action log is organised by IP address, server and user name: tell us which ones you used so that we can find your entries.</p>
<p>You also have the right to complain to a supervisory authority, in Switzerland <?= $h($site['authority'] ?? 'the FDPIC') ?>, or in the EU the authority of your country.</p>

<h2>7. Changes</h2>
<p>We update this policy when the service changes. The date at the top shows the current version.</p>

<?php
$doc = [
    'title' => 'Amazon S3 in the browser',
    'lead' => 'Browse your Amazon S3 buckets like folders on a disk: upload, download, copy, share and edit files, without the AWS console or a desktop program. {app} also works with S3-compatible storage.',
    'sections' => [
        ['h' => 'What you can do',
         'ul' => [
             'Browse all your buckets, or a single bucket if your key is limited to it.',
             'Upload files and folders of any size: large files are sent in parts and continue after an interruption.',
             'Download a file, or a selection of files and “folders” as one zip file.',
             'Copy and move files, also over 5 GB: copies are made inside S3, without passing through your computer.',
             'Edit text files, search for files, and share files with an expiring download link.',
         ]],
        ['h' => 'Which storage works',
         'p' => [
             'Amazon S3 in every region, and storage that speaks the S3 protocol, such as MinIO, Wasabi, Cloudflare R2, Exoscale or Infomaniak. For those, open <i>Advanced options</i> and enter the provider’s endpoint address.',
         ]],
        ['h' => 'How to log in',
         'ol' => [
             'Open [[login|the login page]] and choose <b>Amazon S3</b>.',
             'Enter an <b>access key</b> and a <b>secret key</b>. Optionally enter a bucket and a region.',
             'Click <b>Connect</b>.',
         ],
         'p' => [
             '<b>Tip:</b> don’t use the keys of your AWS root account. Create an IAM user (or temporary credentials) with access to just the buckets you need. {app} keeps the secret key encrypted while you are logged in and never puts it in links.',
         ]],
    ],
    'cta' => 'Open the S3 browser',
    'related' => ['large-uploads', 'online-ftp', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

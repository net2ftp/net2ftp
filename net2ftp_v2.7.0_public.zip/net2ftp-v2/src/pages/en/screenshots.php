<?php
/** @var callable $h @var string $app */
$shots = [
    ['login', 'Log in', 'Choose FTP, SFTP or Amazon S3. You can check the server fingerprint before sending your password.'],
    ['browse', 'Browse', 'A fast file list with sorting, filtering, multi-select and a context menu.'],
    ['edit', 'Edit', 'The code editor with syntax highlighting, search and replace, and line numbers.'],
    ['search', 'Search', 'Find text in a whole folder tree; click a result to open the file at that line.'],
    ['upload', 'Upload', 'Drag files or folders onto the page; progress for every file.'],
    ['resume', 'Resume uploads', 'An upload interrupted by a closed browser is offered again after the next login: choose the file to continue.'],
    ['jobs', 'Copy jobs', 'Copy, move or delete folders of any size: progress, speed and time left, with pause and resume.'],
    ['permissions', 'Permissions', 'Change permissions of many files and folders at once, recursively.'],
    ['terminal', 'SSH terminal', 'Run commands on an SFTP server in the current folder, next to the file list.'],
    ['share', 'Share links', 'Create an expiring download link with a password and a download limit.'],
    ['sharepage', 'Download page', 'What the recipient of a share link sees.'],
    ['arabic', 'In your language', 'Eleven languages, with a mirrored layout for Arabic and Hebrew.'],
    ['mobile', 'On your phone', 'The same features on a small screen, here in dark mode.'],
];
?>
<h1>Screenshots</h1>
<p class="pg-lead">This is what <?= $h($app) ?> looks like. Click a picture to see it full size.</p>
<div class="pg-shots">
  <?php foreach ($shots as [$file, $title, $text]):
      $src = 'assets/img/screenshots/' . $file . '.webp';
      if (!is_file(N2F_ROOT . '/public/' . $src)) continue; ?>
    <figure class="pg-shot">
      <a href="<?= $h($src) ?>"><img src="<?= $h($src) ?>" alt="<?= $h($title . ': ' . $text) ?>" loading="lazy" width="720" height="450"></a>
      <figcaption><b><?= $h($title) ?></b> <?= $h($text) ?></figcaption>
    </figure>
  <?php endforeach ?>
</div>

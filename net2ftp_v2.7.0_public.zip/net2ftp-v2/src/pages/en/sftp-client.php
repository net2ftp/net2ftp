<?php
$doc = [
    'title' => 'Web-based SFTP client with SSH terminal',
    'lead' => 'Manage the files on your SFTP server from your browser, and run shell commands next to them. {app} supports passwords and private keys, checks the server’s identity, and works with Linux and Windows servers.',
    'sections' => [
        ['h' => 'SFTP in your browser',
         'p' => [
             'SFTP is file transfer over SSH: the whole connection is encrypted, through the one port your server already uses for SSH (usually 22). With {app} you get the file manager of a desktop SFTP program without installing one: browse, upload and download (also whole folders, also resumable), edit files, change permissions and owners, extract archives and create share links.',
         ]],
        ['h' => 'Log in with a password or a key',
         'ul' => [
             '<b>Password</b>: the same user name and password you use for SSH.',
             '<b>Private key</b>: paste an RSA, ECDSA or Ed25519 key, with its passphrase if it has one. The key is only used to log in and is kept encrypted while you are logged in.',
             '<b>Fingerprint check</b>: see the server’s host key before you log in, and get a warning if it ever changes.',
         ]],
        ['h' => 'An SSH terminal next to your files',
         'p' => [
             'On servers that allow it, <b>Terminal</b> runs shell commands in the folder you are looking at: create an archive with <code>tar</code>, check disk usage with <code>du</code>, clear a cache, run a database dump or a Composer command. <code>cd</code> also changes the folder in the file list. Commands run one at a time; interactive programs such as editors or <code>top</code> don’t work there.',
         ],
         'shot' => ['terminal', 'The SSH terminal under the file list, in the current folder.']],
        ['h' => 'When to choose SFTP',
         'p' => [
             'If your server offers SFTP, use it: it is encrypted, needs only one port and is easy to get through firewalls. Many web hosts offer it alongside FTP, sometimes under the name “SSH access”. See [[ftp-ftps-sftp|FTP, FTPS or SFTP?]] for a comparison.',
         ]],
    ],
    'cta' => 'Open the SFTP client',
    'related' => ['ftp-ftps-sftp', 'online-ftp', 'move-website', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

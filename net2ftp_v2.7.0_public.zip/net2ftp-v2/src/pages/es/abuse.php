<?php
/** @var callable $h @var array $form @var array $site @var string $app */
?>
<h1>Denunciar un abuso</h1>
<?php if (!$form['sent']): ?>
<p class="pg-lead"><?= $h($app) ?> es una herramienta con la que la gente gestiona <em>sus propios</em> servidores. Como cualquier programa FTP, puede usarla de forma indebida alguien que haya robado una contraseña.
  Si su servidor fue modificado a través de este sitio, o un enlace compartido de este sitio se usa para algo ilegal, díganoslo aquí.</p>
<p>Cada acción en este sitio se registra con la dirección IP del visitante, el servidor, el nombre de usuario y la hora. Eso nos permite encontrar al responsable, bloquearlo
  y facilitarle la información a usted o a la policía. Normalmente respondemos en dos días laborables. Los enlaces compartidos denunciados por malware o phishing se eliminan en cuanto los hemos comprobado.</p>
<p class="pg-small">Antes de denunciar: si se usó su contraseña de FTP, <b>cámbiela ahora</b> en su servidor. Cerrar sesión en este sitio no detiene a quien conozca su contraseña.
  <?php if (!empty($site['abuse_email'])): ?>También puede escribir a <a href="mailto:<?= $h($site['abuse_email']) ?>" dir="ltr"><?= $h($site['abuse_email']) ?></a>.<?php endif ?></p>
<?php endif ?>
<?php require N2F_ROOT . '/src/pages/_shared/abuse_form.php'; ?>

<?php
$doc = [
    'title' => 'FTP activo y pasivo: ¿cuál es la diferencia?',
    'lead' => '¿Puede iniciar sesión pero la lista de archivos nunca aparece, o una transferencia se queda colgada? La causa es casi siempre la conexión de datos de FTP, y la solución suele ser una sola casilla: el modo pasivo.',
    'article' => '2026-11-26',
    'sections' => [
        ['h' => 'FTP usa dos conexiones',
         'p' => [
             'FTP se diseñó en los años setenta, mucho antes de los cortafuegos. Usa una conexión para los comandos (la <b>conexión de control</b>, normalmente el puerto 21) y abre una nueva <b>conexión de datos</b> para cada listado y cada archivo. Los modos activo y pasivo solo se diferencian en quién abre esa conexión de datos.',
         ]],
        ['h' => 'Modo pasivo: el cliente se conecta',
         'p' => [
             'El cliente pide un puerto al servidor (comando <code>PASV</code> o <code>EPSV</code>). El servidor abre un puerto aleatorio y el cliente se conecta a él. Funciona bien cuando el cliente está detrás de un cortafuegos o de un router doméstico, por eso el modo pasivo es el predeterminado en los navegadores, en la mayoría de programas FTP y en {app}. El cortafuegos del servidor debe permitir su rango de puertos pasivos.',
         ]],
        ['h' => 'Modo activo: el servidor se conecta de vuelta',
         'p' => [
             'El cliente indica al servidor una dirección y un puerto (comando <code>PORT</code> o <code>EPRT</code>), y el servidor se conecta de vuelta a ellos. Funciona cuando el servidor está detrás de un cortafuegos que solo deja pasar el puerto 21, pero el cliente debe aceptar conexiones entrantes. {app} admite ambos modos.',
         ]],
        ['h' => 'Problemas y soluciones',
         'table' => [
             ['Lo que ve', 'Qué hacer'],
             ['El inicio de sesión funciona, pero la carpeta nunca carga o se agota el tiempo', 'Cambie de modo: desmarque <i>Modo pasivo</i> en <i>Opciones avanzadas</i> de la página de inicio de sesión, o márquelo si estaba desmarcado.'],
             ['«… no respondió a la solicitud de modo pasivo»', 'El servidor (o un cortafuegos delante de él) bloquea el modo pasivo. Vuelva a iniciar sesión con el modo pasivo desactivado.'],
             ['El modo activo funciona con FTP, pero no con FTP sobre TLS', 'Los cortafuegos no pueden leer comandos cifrados, así que no pueden abrir el puerto del modo activo. Use el modo pasivo o SFTP.'],
             ['No funciona ningún modo', 'El cortafuegos del servidor bloquea los puertos de datos. Pregunte a su proveedor de alojamiento, o use SFTP, que solo necesita un puerto.'],
         ]],
        ['h' => 'Para administradores de servidores',
         'p' => [
             'Para el modo pasivo, elija un rango de puertos pequeño, ábralo en el cortafuegos y configúrelo en el servidor FTP: <code>pasv_min_port</code> y <code>pasv_max_port</code> en vsftpd, <code>PassivePorts</code> en ProFTPD o <code>-p</code> en Pure-FTPd. Detrás de NAT, el servidor también debe anunciar su dirección pública. {app} ignora la dirección de la respuesta pasiva y se conecta a la dirección propia del servidor, así que una dirección errónea ahí no lo detiene.',
         ]],
    ],
    'related' => ['ftp-ftps-sftp', 'faq', 'online-ftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

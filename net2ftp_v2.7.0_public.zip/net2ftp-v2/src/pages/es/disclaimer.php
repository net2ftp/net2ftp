<?php
/**
 * Traducción del aviso legal (plantilla). La versión inglesa es la que da fe.
 * @var callable $h @var callable $url @var array $site @var string $app
 */
require N2F_ROOT . '/src/pages/_shared/privacy_vars.php';
?>
<h1>Aviso legal</h1>
<?php if ($isTemplate): ?>
  <p class="pg-warn"><b>Plantilla.</b> El operador de este sitio todavía no ha introducido sus datos (config.php → <code>site</code>).</p>
<?php endif ?>
<p class="pg-lead">Al usar este sitio web acepta las condiciones siguientes. Si no está de acuerdo, no lo utilice.</p>
<p class="pg-small">Esta traducción se ofrece para su comodidad; en caso de discrepancia, solo da fe la <?= $enLink('disclaimer', 'versión en inglés') ?>.</p>

<h2>1. El servicio</h2>
<p><?= $op ?> ofrece <?= $h($app) ?> de forma gratuita y <b>tal cual</b>, sin ninguna garantía: no garantizamos que esté siempre disponible, libre de errores ni que sirva para un fin concreto.
  Podemos cambiar, limitar o interrumpir el servicio en cualquier momento, y fijar límites al tamaño de los archivos, a las transferencias y al uso.</p>

<h2>2. Su responsabilidad</h2>
<ul>
  <li>Conéctese solo a servidores que esté <b>autorizado</b> a usar, con credenciales que sean suyas o que tenga permiso para usar.</li>
  <li>Usted es responsable de todo lo que hace con el servicio: los archivos que sube, modifica, elimina o comparte, y sus consecuencias en su servidor.</li>
  <li><b>Haga copias de seguridad.</b> Eliminar, sobrescribir, cambiar permisos y extraer archivos comprimidos no se puede deshacer.</li>
  <li>No use el servicio para nada ilegal: acceso no autorizado, desfiguración de sitios web, distribución de malware, phishing, spam o archivos que infrinjan derechos de terceros.</li>
  <li>No intente sobrecargar, atacar ni eludir los límites de este sitio o de los servidores a los que se conecta.</li>
</ul>

<h2>3. Registros y abusos</h2>
<p>Cada acción se registra (consulte la <a href="<?= $h($url('privacy')) ?>">política de privacidad</a>). En caso de abuso, podemos bloquear el acceso, eliminar enlaces compartidos y facilitar las entradas de registro a los propietarios de los servidores afectados y a las autoridades.
  Para denunciar un abuso, use el <a href="<?= $h($url('abuse')) ?>">formulario de denuncia</a>.</p>

<h2>4. Enlaces compartidos</h2>
<p>Los archivos compartidos con un enlace los publica el usuario que creó el enlace, no <?= $op ?>. No los revisamos de antemano. Eliminamos los enlaces denunciados como ilegales una vez comprobada la denuncia.
  Descargue archivos compartidos solo de personas de su confianza.</p>

<h2>5. Responsabilidad</h2>
<p>En la medida en que lo permita la ley, <?= $op ?> no se hace responsable de ningún daño derivado del uso o de la imposibilidad de usar este sitio web, en particular la pérdida de datos, los daños a sitios web o servidores, el lucro cesante o los daños causados por otros usuarios.
  Esto no limita la responsabilidad por dolo o negligencia grave cuando la ley no lo permite.</p>

<h2>6. Enlaces a otros sitios web</h2>
<p>No somos responsables del contenido de los sitios web a los que enlazamos.</p>

<h2>7. El software</h2>
<p>El software de este sitio es de código abierto bajo la Licencia Pública General de GNU, versión 2 o posterior, y se ofrece sin garantía. Si lo instala usted mismo, usted es el operador de su instalación.</p>

<h2>8. Legislación aplicable</h2>
<p>Estas condiciones se rigen por la ley del siguiente país: <?= $jurisdiction ?>. Son competentes los tribunales del domicilio social de <?= $op ?>, salvo que la legislación imperativa de protección de los consumidores disponga otra cosa.</p>
<p>Contacto: <span dir="ltr"><?= $h($site['email'] ?? '') ?></span></p>

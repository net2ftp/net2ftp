<?php
/** @var callable $h @var callable $url @var array $site @var string $app @var string $version */
$L = [
    'file' => 'Archivo', 'size' => 'Tamaño', 'date' => 'Fecha',
    'check' => 'Compruebe la descarga: %1$s (Linux), %2$s (macOS) o %3$s (Windows PowerShell) deben mostrar el mismo valor.',
    'releases' => 'Todas las versiones', 'source' => 'Código fuente',
    'none' => 'Todavía no hay ninguna descarga publicada en este servidor. Pregunte al administrador:',
];
?>
<h1>Descargar</h1>
<p class="pg-lead">Instale <?= $h($app) ?> en su propio servidor web, para su empresa, sus clientes o usted mismo.
  Es gratuito y de código abierto (GPL 2.0 o posterior). Versión actual: <b dir="ltr"><?= $h($version) ?></b>.</p>
<?php require N2F_ROOT . '/src/pages/_shared/download_files.php'; ?>

<h2>Qué necesita</h2>
<table class="pg-table">
  <tbody>
    <tr><th>Servidor web</th><td>Apache 2.4 (mod_php o PHP-FPM), o nginx con PHP-FPM</td></tr>
    <tr><th>PHP</th><td>8.1 o posterior, con las extensiones ftp, curl, zip, mbstring, openssl o sodium (la mayoría vienen instaladas de serie)</td></tr>
    <tr><th>Base de datos</th><td>MySQL 5.7+ o MariaDB 10.3+ para los registros (opcional, pero recomendado)</td></tr>
    <tr><th>Disco</th><td>Unos 5 MB para el código, más espacio para archivos temporales y enlaces compartidos</td></tr>
  </tbody>
</table>
<p>Las extensiones que falten no estropean la instalación: <?= $h($app) ?> le indica exactamente qué falta y el resto sigue funcionando.
  Consulte <a href="<?= $h($url('install')) ?>">cómo instalarlo</a>.</p>

<h2>Novedades de la versión <span dir="ltr"><?= $h($version) ?></span></h2>
<ul>
  <li>Límites diarios de datos y tiempo de servidor, por visitante y por servidor FTP, para que el servicio siga siendo justo para todos.</li>
  <li>Detección automática de subidas masivas (el mismo archivo a muchos servidores), con bloqueo automático.</li>
  <li>Un nuevo panel de administración: resumen, investigación de denuncias de abuso, consumo, bloqueos, errores y eventos de seguridad.</li>
  <li>Inicio de sesión en dos pasos y bloqueo tras intentos fallidos para el administrador.</li>
  <li>Las entradas antiguas de los registros y los archivos sobrantes se eliminan automáticamente.</li>
  <li>Las páginas informativas están disponibles en los once idiomas.</li>
</ul>

<?php
$doc = [
    'title' => 'Editar archivos en su servidor en línea',
    'lead' => 'Corrija una errata de su sitio web, cambie un ajuste en un archivo de configuración o actualice un script PHP directamente en su servidor FTP o SFTP, desde cualquier navegador. Sin descargar, editar y volver a subir.',
    'sections' => [
        ['h' => 'Un editor de código de verdad',
         'ul' => [
             'Resaltado de sintaxis para PHP, HTML, CSS, JavaScript y más de 20 lenguajes más, con números de línea.',
             'Buscar y reemplazar en el archivo (<kbd>Ctrl</kbd>+<kbd>F</kbd>), guardar con <kbd>Ctrl</kbd>+<kbd>S</kbd>.',
             'Se conservan la codificación de caracteres y los finales de línea del archivo: los archivos de Windows y de Unix quedan como estaban.',
             '<b>Sin cambios perdidos</b>: si otra persona modificó el archivo en el servidor después de que usted lo abriera, {app} le avisa antes de sobrescribirlo.',
         ],
         'shot' => ['edit', 'El editor de código con resaltado de sintaxis.']],
        ['h' => 'Encuentre lo que hay que cambiar',
         'p' => [
             '<b>Buscar</b> encuentra texto en todos los archivos de una carpeta y sus subcarpetas, por ejemplo una dirección de correo antigua o un ajuste de la base de datos. Puede limitar la búsqueda a ciertos archivos (<code>*.php *.html</code>) o usar una expresión regular. Haga clic en un resultado para abrir el archivo en esa línea.',
         ]],
        ['h' => 'Alrededor del editor',
         'ul' => [
             'Crear archivos y carpetas nuevos, y cambiar el nombre o copiar archivos para guardar una copia antes de modificarlos.',
             'Cambiar permisos, por ejemplo <code>644</code> para archivos y <code>755</code> para carpetas.',
             'Guardar un marcador: cada archivo del editor tiene su propia dirección, así puede volver a él directamente.',
         ]],
    ],
    'cta' => 'Abrir el editor',
    'related' => ['online-ftp', 'move-website', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

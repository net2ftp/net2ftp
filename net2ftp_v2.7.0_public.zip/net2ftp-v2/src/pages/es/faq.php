<?php
$doc = [
    'title' => 'Preguntas y respuestas',
    'lead' => 'Las preguntas más frecuentes sobre {app}. ¿No encuentra la suya? Lea [[help|Cómo usar]] o las [[guides|guías]].',
    'faq' => [
        'Sobre {app}' => [
            ['¿{app} es gratuito?', 'Sí. {app} es gratuito y de código abierto (GPL). Puede usarlo en este sitio, o [[download|descargarlo]] e instalarlo en su propio servidor.'],
            ['¿Tengo que crear una cuenta?', 'No. Inicia sesión con el nombre de usuario y la contraseña de su propio servidor FTP, SFTP o S3. No hay nada que registrar.'],
            ['¿Tengo que instalar algo?', 'No. {app} funciona en cualquier navegador moderno, en Windows, Mac, Linux, Chromebook, Android e iPhone.'],
            ['¿Con qué servidores funciona?', 'Con cualquier servidor FTP o FTPS, cualquier servidor SFTP/SSH en Linux o Windows, Amazon S3 y almacenamiento compatible con S3 como MinIO, Wasabi, Cloudflare R2, Exoscale o Infomaniak.'],
        ],
        'Seguridad y privacidad' => [
            ['¿Es seguro introducir mi contraseña FTP?', 'Su contraseña solo se usa para conectarse a su servidor. Se guarda cifrada mientras tiene la sesión iniciada, nunca se escribe en el disco en texto claro y nunca se incluye en enlaces. Puede comprobar la huella del servidor antes de enviarla.'],
            ['¿Qué es la huella del servidor?', 'La huella identifica a un servidor, como un sello en una carta. Compárela con la que le da su proveedor de alojamiento antes de iniciar sesión por primera vez. Si más adelante {app} indica que ha cambiado, no inicie sesión hasta saber por qué.'],
            ['¿Mis archivos se quedan en su servidor?', 'No. Los archivos pasan por este servidor en su camino entre su ordenador y su servidor, y no se guardan. Las excepciones son las copias que hace para los enlaces compartidos (hasta que caduca el enlace) y las partes de subidas sin terminar (hasta que caducan o las termina).'],
            ['¿Qué se registra?', 'Cada acción (por ejemplo: quién subió qué archivo a qué servidor, y cuándo) se registra con la dirección IP, para proteger a los propietarios de servidores contra abusos. La [[privacy|política de privacidad]] indica qué se guarda y durante cuánto tiempo.'],
        ],
        'Conexión' => [
            ['¿Qué puerto debo usar?', 'Deje el puerto vacío para usar el habitual: 21 para FTP y FTPS, 22 para SFTP. Indique otro puerto solo si su proveedor se lo pide.'],
            ['¿Por qué aparece «No se pudo conectar a …»?', 'Compruebe el nombre del servidor y el puerto. Algunos proveedores solo permiten FTP desde ciertas direcciones, o no desde otros servidores; pregúnteles o pruebe con SFTP.'],
            ['Puedo iniciar sesión, pero la carpeta no carga. ¿Qué hago?', 'Casi siempre se debe a la conexión de datos de FTP. Abra <i>Opciones avanzadas</i> en la página de inicio de sesión y desmarque <i>Modo pasivo</i> (o márquelo, si estaba desmarcado). [[active-passive|FTP activo y pasivo]] explica por qué.'],
            ['¿Debo usar FTP, FTPS o SFTP?', 'SFTP o FTPS si su servidor lo admite: ambos van cifrados. El FTP simple envía su contraseña sin cifrar. Vea [[ftp-ftps-sftp|¿FTP, FTPS o SFTP?]].'],
        ],
        'Archivos' => [
            ['¿Puedo transferir archivos grandes?', 'Sí. Los archivos se envían por partes y continúan donde se quedaron tras una interrupción, y las carpetas de cualquier tamaño se copian, mueven y comprimen sin límite de tiempo. Vea [[large-uploads|Subir archivos grandes]].'],
            ['¿Puedo descomprimir archivos en el servidor?', 'Sí. Seleccione un archivo .zip, .tar, .tar.gz o .tar.bz2 y elija <b>Extraer</b>: se descomprime directamente en el servidor.'],
            ['¿Cómo envío un archivo a alguien sin acceso a mi servidor?', 'Selecciónelo y haga clic en <b>Compartir</b>. Obtiene un enlace de descarga que caduca, con contraseña y número máximo de descargas opcionales.'],
            ['¿Hay límites?', 'Para que el servicio sea justo para todos, este sitio puede limitar cuánto transfiere al día cada visitante y cada servidor. Si llega a un límite, {app} se lo indica; los límites se reinician a medianoche (hora del servidor). En su propia instalación, usted decide los límites.'],
        ],
        'Su propia instalación' => [
            ['¿Puedo instalar {app} en mi propio servidor?', 'Sí. Necesita un servidor web con PHP 8.1 o posterior; MySQL o MariaDB es opcional pero recomendable. La [[install|guía de instalación]] lleva unos 15 minutos.'],
        ],
    ],
    'related' => ['help', 'active-passive', 'ftp-ftps-sftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

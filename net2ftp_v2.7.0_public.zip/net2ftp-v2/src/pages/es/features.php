<?php
/** @var callable $h @var callable $url @var string $app */
$groups = [
    'Conectar' => [
        ['FTP y FTPS', 'Modo pasivo y activo, FTP over TLS (explícito), servidores Unix y Windows.'],
        ['SFTP / SSH', 'Contraseña o clave privada (RSA, ECDSA, Ed25519), con un terminal SSH para ejecutar comandos.'],
        ['Amazon S3', 'Cualquier región, un solo bucket o todos, credenciales temporales y almacenamiento compatible con S3 como MinIO, Wasabi, Cloudflare R2, Exoscale o Infomaniak.'],
        ['Huella del servidor', 'Vea la clave de host SSH o el certificado TLS antes de enviar su contraseña, y reciba un aviso si cambia.'],
        ['Servidores recordados', 'Hasta 5 conexiones por navegador, con la contraseña cifrada y la última carpeta abierta, solo si permite las cookies de preferencias.'],
        ['Marcadores', 'Cada carpeta y cada archivo tiene su propia dirección, que puede guardar en marcadores. Las contraseñas nunca aparecen en los enlaces.'],
    ],
    'Explorar y transferir' => [
        ['Lista de archivos rápida', 'Ordene, filtre, seleccione con el teclado o el ratón y abra al instante carpetas con 10 000 archivos.'],
        ['Subir', 'Arrastre y suelte archivos o carpetas completas. Los archivos grandes se envían por partes, dos a la vez, y una subida interrumpida continúa donde se detuvo, incluso en una sesión posterior.'],
        ['Descargar', 'Archivos sueltos, o cualquier selección de archivos y carpetas como un único archivo zip. El navegador puede reanudar las descargas interrumpidas.'],
        ['Copiar, mover, cambiar nombre, eliminar', 'De forma recursiva para carpetas de cualquier tamaño. Las tareas grandes avanzan por pasos, con progreso, pausa y reanudación, y continúan cuando vuelve a iniciar sesión.'],
        ['Buscar', 'Busque texto dentro de archivos, o archivos por nombre, en todo un árbol de carpetas, con expresiones regulares y patrones de nombre.'],
    ],
    'Trabajar en el servidor' => [
        ['Editar', 'Un editor de código con resaltado de sintaxis para PHP, HTML, CSS, JavaScript y 20 lenguajes más, buscar y reemplazar, y protección para no sobrescribir los cambios de otros.'],
        ['Permisos', 'chmod y chown para muchos archivos y carpetas a la vez, de forma recursiva, en un orden que nunca le deja sin acceso.'],
        ['Extraer', 'Descomprima archivos .zip, .tar, .tar.gz y .tar.bz2 directamente en el servidor, de forma segura.'],
        ['Terminal SSH', 'Ejecute comandos de shell en la carpeta actual de un servidor SFTP, en servidores Linux y Windows.'],
        ['Enlaces compartidos', 'Enlaces de descarga con caducidad, contraseña opcional y límite de descargas, como WeTransfer. Los destinatarios nunca obtienen acceso a su servidor.'],
    ],
    'Seguridad y privacidad' => [
        ['Credenciales cifradas', 'Su contraseña se guarda cifrada mientras tiene la sesión iniciada y nunca se escribe en disco en texto plano.'],
        ['Registro de acciones', 'Cada acción queda registrada para proteger a los propietarios de servidores contra abusos.'],
        ['Elección de cookies', 'Solo cookies necesarias, salvo que permita más. Sin cookies publicitarias ni de seguimiento.'],
        ['Protección contra el abuso', 'Los enlaces para compartir rechazan programas y scripts, y los límites por visitante protegen los servidores a los que se conecta.'],
        ['Sin registro', 'Inicie sesión con el usuario y la contraseña de su propio servidor: no hay ninguna cuenta que crear.'],
        ['Código abierto', 'Licencia GPL: puede leer, revisar e instalar el código usted mismo.'],
    ],
    'En todas partes' => [
        ['11 idiomas', 'Inglés, alemán, español, francés, neerlandés, ruso, chino simplificado y tradicional, japonés, hebreo y árabe, con un diseño en espejo para el hebreo y el árabe.'],
        ['Cualquier dispositivo', 'Funciona en cualquier navegador moderno, en ordenador, tableta y móvil, en modo claro y oscuro. Nada que instalar.'],
    ],
];
?>
<h1>Funciones</h1>
<p class="pg-lead"><?= $h($app) ?> es un gestor de archivos para sus servidores FTP, SFTP y Amazon S3 que funciona en el navegador.
  Todo lo que sigue funciona sin instalar nada en su ordenador. <a href="<?= $h($url('screenshots')) ?>">Ver las capturas de pantalla</a>.</p>
<?php foreach ($groups as $group => $items): ?>
  <h2><?= $h($group) ?></h2>
  <div class="pg-tiles">
    <?php foreach ($items as [$name, $text]): ?>
      <div class="pg-tile"><h3><?= $h($name) ?></h3><p><?= $h($text) ?></p></div>
    <?php endforeach ?>
  </div>
<?php endforeach ?>

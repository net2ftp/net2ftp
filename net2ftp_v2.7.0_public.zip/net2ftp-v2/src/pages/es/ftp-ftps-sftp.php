<?php
$doc = [
    'title' => '¿FTP, FTPS o SFTP? Cuál conviene usar',
    'lead' => 'Los tres transfieren archivos entre su ordenador y un servidor, pero solo dos protegen su contraseña. Así se diferencian y así se elige.',
    'article' => '2026-11-26',
    'sections' => [
        ['h' => 'Los tres en resumen',
         'ul' => [
             '<b>FTP</b> es el File Transfer Protocol original. Todo, incluida su contraseña, viaja sin cifrar.',
             '<b>FTPS</b> (FTP sobre TLS) es FTP con el mismo cifrado que los sitios web HTTPS. Los comandos y los archivos van protegidos.',
             '<b>SFTP</b> no tiene nada que ver con FTP: es transferencia de archivos por SSH, el protocolo con el que los administradores entran en los servidores. Todo va cifrado.',
         ]],
        ['h' => 'Comparación',
         'table' => [
             ['', 'FTP', 'FTPS', 'SFTP'],
             ['Cifrado', 'No', 'Sí', 'Sí'],
             ['Puerto habitual', '21', '21 (explícito)', '22'],
             ['Puertos adicionales para datos', 'Sí', 'Sí', 'No'],
             ['A través de cortafuegos', 'A veces difícil', 'A veces difícil', 'Fácil'],
             ['Inicio de sesión con', 'Contraseña', 'Contraseña', 'Contraseña o clave'],
             ['Ejecutar comandos', 'No', 'No', 'Sí (SSH)'],
         ]],
        ['h' => 'Cuál elegir',
         'ol' => [
             '<b>SFTP</b>, si su servidor lo ofrece: cifrado, un solo puerto, y puede iniciar sesión con una clave. Muchos proveedores lo llaman «acceso SSH».',
             '<b>FTPS</b>, si su proveedor solo ofrece FTP: normalmente admite también TLS. En {app}, marque <i>FTP over TLS (FTPS)</i> en <i>Opciones avanzadas</i>.',
             '<b>FTP simple</b> solo cuando no haya otra opción, y nunca en una red wifi pública.',
         ]],
        ['h' => 'Cómo saber qué admite su servidor',
         'p' => [
             'Busque «SFTP», «SSH» o «FTP sobre TLS» en el correo de bienvenida o en el panel de control de su proveedor. También puede simplemente probar: elija <b>SFTP / SSH</b> en la [[login|página de inicio de sesión]] con su usuario y contraseña habituales; si no conecta, elija <b>FTP</b> con <i>FTP over TLS (FTPS)</i> activado. {app} admite FTPS explícito, la forma habitual en el puerto 21.',
         ]],
    ],
    'related' => ['sftp-client', 'active-passive', 'online-ftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

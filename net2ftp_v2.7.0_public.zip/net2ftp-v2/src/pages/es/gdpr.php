<?php
/** @var callable $h @var callable $url @var array $form @var array $site */
?>
<h1>Solicitud sobre protección de datos</h1>
<?php if (!$form['sent']): ?>
<p class="pg-lead">Según el Reglamento General de Protección de Datos de la UE (RGPD) y la Ley Federal suiza de Protección de Datos (LPD), puede preguntar qué datos personales tenemos sobre usted,
  y pedir que se rectifiquen, supriman, limiten o se le entreguen. Use este formulario o escríbanos<?php if (!empty($site['privacy_email'])): ?> a <a href="mailto:<?= $h($site['privacy_email']) ?>" dir="ltr"><?= $h($site['privacy_email']) ?></a><?php endif ?>.</p>
<p>Los datos que tratamos se explican en la <a href="<?= $h($url('privacy')) ?>">política de privacidad</a>. En resumen: el registro de acciones (dirección IP, servidor, nombre de usuario, qué se hizo y cuándo),
  los registros de consumo y de seguridad, los archivos que compartió con un enlace y las cookies de su propio dispositivo. <b>Nunca guardamos las contraseñas de sus servidores</b>, así que no podemos entregárselas ni eliminarlas.</p>
<p class="pg-small">Las cookies y los servidores recordados están en su propio dispositivo: puede eliminarlos usted mismo en cualquier momento con <i>Configuración de cookies</i> al pie de la página de inicio de sesión, o en su navegador.</p>
<?php endif ?>
<?php require N2F_ROOT . '/src/pages/_shared/gdpr_form.php'; ?>

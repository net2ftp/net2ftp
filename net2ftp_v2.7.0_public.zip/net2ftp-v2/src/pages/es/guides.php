<?php
$doc = [
    'title' => 'Guías',
    'lead' => 'Lo que puede hacer con {app}, paso a paso, y respuestas a las preguntas más frecuentes sobre FTP, SFTP y Amazon S3.',
    'hub' => [
        ['Usar {app} para …', ['online-ftp', 'sftp-client', 's3-browser', 'edit-online', 'large-uploads']],
        ['Aprender', ['active-passive', 'ftp-ftps-sftp', 'move-website']],
        ['Ayuda', ['faq', 'help']],
    ],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

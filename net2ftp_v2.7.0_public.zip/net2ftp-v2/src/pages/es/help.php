<?php
/** @var callable $h @var callable $url @var array $site @var string $app */
$maxDays = (int)(((array)\Net2ftp\App::cfg('shares', []))['max_days'] ?? 7);
$toc = [
    'login' => 'Iniciar sesión', 'browse' => 'Orientarse', 'upload' => 'Subir archivos', 'download' => 'Descargar',
    'edit' => 'Editar un archivo', 'organise' => 'Copiar, mover, cambiar nombre, eliminar', 'search' => 'Buscar',
    'perms' => 'Permisos', 'extract' => 'Extraer archivos comprimidos', 'share' => 'Enlaces compartidos', 'bookmarks' => 'Marcadores',
    'terminal' => 'Terminal SSH', 'keys' => 'Atajos de teclado', 'large' => 'Archivos grandes y tareas largas', 'problems' => 'Si algo falla',
];
?>
<h1>Cómo usar <?= $h($app) ?></h1>
<p class="pg-lead">Todo lo que puede hacer, en el orden en que lo necesitará. ¿Es nuevo aquí? Lea las tres primeras secciones; el resto está aquí para cuando lo necesite.</p>
<nav class="pg-toc" aria-label="Contenido"><ol>
  <?php foreach ($toc as $id => $label): ?><li><a href="#<?= $h($id) ?>"><?= $h($label) ?></a></li><?php endforeach ?>
</ol></nav>

<h2 id="login">1. Iniciar sesión</h2>
<ol>
  <li>Elija el tipo de servidor: <b>FTP</b> (la mayoría de los alojamientos web), <b>SFTP / SSH</b> (servidores a los que también puede acceder con un cliente SSH) o <b>Amazon S3</b> (almacenamiento en la nube). El correo de bienvenida de su proveedor de alojamiento suele indicar cuál tiene.</li>
  <li>Introduzca el <b>servidor</b> (p. ej. <code dir="ltr">ftp.example.com</code>), su <b>nombre de usuario</b> y su <b>contraseña</b>. Deje el puerto vacío para usar el habitual (21 para FTP, 22 para SFTP).</li>
  <li>Para Amazon S3, introduzca en su lugar el <b>ID de clave de acceso</b> y la <b>clave de acceso secreta</b>, y si quiere un bucket y una región. Para otro almacenamiento compatible con S3, abra <i>Opciones avanzadas</i> e introduzca su endpoint.</li>
  <li>Haga clic en <b>Conectar</b>.</li>
</ol>
<p><b>Compruebe primero la huella</b> de un servidor que no haya usado antes: <i>Comprobar la huella del servidor</i> muestra la identidad del servidor antes de enviar su contraseña. Compárela con la que le da su proveedor. Si más adelante net2ftp indica que la huella <i>ha cambiado</i>, no inicie sesión hasta saber por qué.</p>
<p><b>El FTP simple no está cifrado.</b> Si su servidor lo admite, active <i>FTP over TLS (FTPS)</i> en Opciones avanzadas, o use SFTP.</p>
<p><b>Recordar esta conexión en este dispositivo</b> guarda la conexión (y la contraseña, cifrada) en su navegador, hasta 5 servidores. Al volver a iniciar sesión desde la lista se abre la carpeta en la que trabajó por última vez. Solo se ofrece si permite las cookies de preferencias. No la use en un ordenador compartido.</p>

<h2 id="browse">2. Orientarse</h2>
<ul>
  <li><b>Abra una carpeta</b> haciendo clic en su nombre o con Intro. <b>Suba un nivel</b> con la flecha de arriba a la izquierda o con Retroceso.</li>
  <li>La <b>ruta</b> de arriba muestra dónde está; haga clic en cualquier parte para ir allí, o doble clic para escribir una ruta.</li>
  <li><b>Ordene</b> haciendo clic en el encabezado de una columna. <b>Filtre</b> la carpeta actual escribiendo en el cuadro de filtro (o pulse <kbd>/</kbd>).</li>
  <li><b>Seleccione</b> con las casillas, con Ctrl+clic (⌘+clic en Mac) o con Mayús+clic para un intervalo. La barra de acciones muestra entonces lo que puede hacer con la selección. El clic derecho ofrece las mismas acciones en un menú.</li>
  <li>Los botones <b>Atrás y Adelante</b> del navegador pasan de una carpeta a otra.</li>
</ul>

<h2 id="upload">3. Subir archivos</h2>
<p>Arrastre archivos o carpetas completas de su ordenador a la página, o use <b>Subir</b>. Las carpetas conservan su estructura. Los archivos se envían de dos en dos, con el progreso de cada uno; puede cancelar cualquiera. Si un archivo ya existe, se le pregunta si quiere reemplazarlo u omitirlo. Si una subida se interrumpe (error de red, navegador cerrado), vuelva a subir el mismo archivo a la misma carpeta: continúa donde se detuvo. Las subidas sin terminar se muestran al iniciar sesión.</p>

<h2 id="download">4. Descargar</h2>
<p>Seleccione un archivo y haga clic en <b>Descargar</b>. Para descargar varios archivos o una carpeta, selecciónelos y haga clic en <b>Zip</b>: obtendrá un único archivo zip. Las imágenes y los PDF también se pueden abrir directamente con <b>Ver</b>. Si una descarga grande se interrumpe, su navegador puede reanudarla desde su lista de descargas.</p>

<h2 id="edit">5. Editar un archivo</h2>
<p>Haga clic en un archivo de texto (HTML, PHP, CSS, JavaScript, archivos de configuración…) para abrirlo en el editor. Guarde con <kbd>Ctrl</kbd>+<kbd>S</kbd>, busque y reemplace con <kbd>Ctrl</kbd>+<kbd>F</kbd>. Si otra persona modificó el archivo en el servidor después de que usted lo abriera, net2ftp le avisa antes de sobrescribir sus cambios. Se conservan la codificación de caracteres y los finales de línea del archivo.</p>

<h2 id="organise">6. Copiar, mover, cambiar nombre, eliminar</h2>
<p>Seleccione los elementos, elija <b>Copiar</b> o <b>Mover</b> y la carpeta de destino. <b>Cambiar nombre</b> (F2) funciona con un elemento. <b>Eliminar</b> borra las carpetas con todo su contenido, así que lea con atención la confirmación: no se puede deshacer. Las copias, los traslados y las eliminaciones grandes se ejecutan como tareas: el panel <b>Tareas</b> muestra su progreso y permite pausarlas, reanudarlas o cancelarlas. Mantenga la página abierta mientras se ejecuta una tarea; si la cierra, la tarea continúa al volver a iniciar sesión.</p>

<h2 id="search">7. Buscar</h2>
<p>Haga clic en <b>Buscar</b> para buscar texto dentro de los archivos, o nombres de archivo, en la carpeta actual y todo lo que contiene. Puede limitar la búsqueda a ciertos archivos (p. ej. <code dir="ltr">*.php *.html</code>), distinguir mayúsculas y minúsculas o usar una expresión regular. Haga clic en un resultado para abrir el archivo en esa línea.</p>

<h2 id="perms">8. Permisos</h2>
<p>Seleccione archivos y carpetas y elija <b>Permisos</b> (solo FTP y SFTP). Marque lectura, escritura y ejecución para el propietario, el grupo y los demás, o escriba el número (p. ej. <b>755</b> para carpetas y <b>644</b> para archivos, los valores habituales en sitios web). Marque <i>recursivo</i> para cambiar también todo el contenido de las carpetas seleccionadas. Con SFTP también puede cambiar el propietario y el grupo. net2ftp elige el orden de los cambios para que no se quede sin acceso a mitad de camino, y le avisa si los nuevos permisos le impedirían abrir una carpeta.</p>

<h2 id="extract">9. Extraer archivos comprimidos</h2>
<p>Seleccione un archivo <code dir="ltr">.zip</code>, <code dir="ltr">.tar</code>, <code dir="ltr">.tar.gz</code> o <code dir="ltr">.tar.bz2</code> y elija <b>Extraer</b>. Se descomprime en el servidor, en una carpeta nueva con el nombre del archivo o en la carpeta actual. Elija si los archivos existentes se reemplazan o se conservan. Es mucho más rápido que descargar, descomprimir y volver a subir.</p>

<h2 id="share">10. Enlaces compartidos</h2>
<p>Seleccione archivos o carpetas y haga clic en <b>Compartir</b> para obtener un enlace de descarga para alguien sin acceso a su servidor. Elija cuánto tiempo funciona (de 1 hora a <?= $maxDays ?> días) y, si quiere, una contraseña, un número máximo de descargas y un mensaje. Los archivos se copian al crear el enlace, así que los cambios posteriores en el servidor no le afectan. <b>Compartidos</b>, arriba, muestra sus enlaces, donde puede copiarlos o eliminarlos. Envíe la contraseña por separado del enlace.</p>

<h2 id="bookmarks">11. Marcadores</h2>
<p>Cada carpeta, y cada archivo abierto en el editor, tiene su propia dirección. Guárdela en marcadores (<kbd>Ctrl</kbd>+<kbd>D</kbd>) o cópiela con el botón de enlace, y volverá a abrir el mismo sitio. Las contraseñas nunca forman parte de la dirección: si el servidor no está recordado, se le pedirá la contraseña.</p>

<h2 id="terminal">12. Terminal SSH</h2>
<p>En los servidores SFTP que lo permiten, <b>Terminal</b> ejecuta comandos de shell en la carpeta actual. <code dir="ltr">cd</code> también cambia la carpeta que se muestra en la lista. Los comandos se ejecutan de uno en uno; los programas interactivos (editores, <code dir="ltr">top</code>) no funcionan ahí.</p>

<h2 id="keys">13. Atajos de teclado</h2>
<table class="pg-table">
  <tbody>
    <tr><th dir="ltr">↑ ↓ PgUp PgDn Home End</th><td>Moverse (con Mayús: ampliar la selección)</td></tr>
    <tr><th dir="ltr">Enter</th><td>Abrir la carpeta o el archivo</td></tr>
    <tr><th dir="ltr">Backspace</th><td>Subir una carpeta</td></tr>
    <tr><th dir="ltr">Space · Ctrl+A · Esc</th><td>Seleccionar · seleccionar todo · quitar la selección</td></tr>
    <tr><th dir="ltr">F2 · Delete</th><td>Cambiar nombre · eliminar</td></tr>
    <tr><th dir="ltr">/ · Ctrl+L · Ctrl+Shift+F</th><td>Filtrar · escribir una ruta · buscar</td></tr>
    <tr><th>Letras</th><td>Ir al primer nombre que empieza por ellas</td></tr>
  </tbody>
</table>

<h2 id="large">14. Archivos grandes y tareas largas</h2>
<ul>
  <li>Las subidas se envían por partes. Si una subida se interrumpe, vuelva a subir el mismo archivo a la misma carpeta y continúa donde se detuvo; las subidas sin terminar también se muestran al iniciar sesión.</li>
  <li>Su navegador puede reanudar las descargas de archivos sueltos. Las descargas en zip empiezan de inmediato, sea cual sea el tamaño de la selección.</li>
  <li>Copiar, mover y eliminar carpetas se ejecuta como una tarea en el panel <b>Tareas</b>, con progreso, pausa y reanudación. Mantenga la página abierta; si la cierra, la tarea continúa al volver a iniciar sesión.</li>
  <li>En Amazon S3, las copias se hacen en el lado de S3, también para archivos de más de 5 GB, sin pasar por net2ftp.</li>
</ul>

<h2 id="problems">15. Si algo falla</h2>
<ul>
  <li><b>«No se pudo conectar»</b>: compruebe el nombre del servidor y el puerto. Algunos proveedores de alojamiento bloquean el FTP desde otros servidores; consúlteles, o pruebe SFTP.</li>
  <li><b>Sesión iniciada, pero la carpeta no carga (FTP)</b>: abra Opciones avanzadas y desmarque <i>Modo pasivo</i>, o al revés.</li>
  <li><b>«Permiso denegado»</b>: su cuenta no tiene permiso para hacer eso en el servidor. Consulte al administrador del servidor.</li>
  <li><b>«Se agotó el tiempo de su sesión»</b>: estuvo inactivo un rato. Vuelva a iniciar sesión; los marcadores le llevan de vuelta a donde estaba.</li>
  <li>¿Otra cosa? Póngase en contacto con el administrador de este sitio<?= !empty($site['email']) ? ' en <span dir="ltr">' . $h($site['email']) . '</span>' : '' ?>.</li>
</ul>

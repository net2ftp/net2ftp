<?php
/** @var callable $h @var callable $url @var string $app */
require N2F_ROOT . '/src/pages/_shared/install_code.php';
?>
<h1>Instalar <?= $h($app) ?> en su servidor</h1>
<p class="pg-lead">Unos 15 minutos en un servidor Linux con Apache, PHP y MySQL. Necesita acceso a la línea de comandos con sudo.
  Primero <a href="<?= $h($url('download')) ?>">descargue</a> el paquete y compruebe su SHA-256.</p>

<h2>1. Instalar PHP y sus extensiones</h2>
<p>En Debian o Ubuntu:</p>
<?= $pre('apt') ?>
<p>Las extensiones <?= $c('ftp') ?>, <?= $c('sodium') ?> y <?= $c('openssl') ?> vienen integradas allí. En otros sistemas, active <?= $c('extension=ftp') ?>, <?= $c('curl') ?>, <?= $c('zip') ?> y <?= $c('sodium') ?> en <?= $c('php.ini') ?>. <b>En Windows</b>, añada además la carpeta de PHP (p. ej. <?= $c('C:\PHP') ?>) al PATH del sistema y reinicie Windows; si no, Apache no podrá cargar curl ni sodium.</p>

<h2>2. Descomprimir los archivos</h2>
<?= $pre('unpack') ?>
<p>Solo la carpeta <?= $c('public/') ?> puede ser accesible desde la web. <?= $c('src/') ?>, <?= $c('config.php') ?> y <?= $c('storage/') ?> deben quedar fuera de la raíz web.</p>

<h2>3. Crear la base de datos</h2>
<?= $pre('db') ?>

<h2>4. Configurar</h2>
<?= $pre('config') ?>
<p>Defina como mínimo la contraseña de la base de datos, <?= $c('secret_key') ?>, <?= $c('admin_password_hash') ?>, <?= $c('admin_totp_secret') ?> (el código en dos pasos de la administración; escanee el enlace con una aplicación de autenticación) y sus datos en la sección <?= $c('site') ?> (aparecen en la política de privacidad y en el aviso legal).
  Los valores predeterminados están pensados para una instalación pública: las conexiones a redes privadas están bloqueadas y hay límites diarios por visitante y por servidor. Revíselos en <?= $c('config.php') ?>.</p>

<h2>5. Apuntar Apache a la carpeta public</h2>
<?= $pre('vhost') ?>
<p>Use siempre <b>HTTPS</b>: en este sitio se escriben contraseñas de servidores. Un certificado gratuito: <?= $c($code['certbot']) ?>.</p>

<h2>6. Programar la tarea de limpieza</h2>
<p><?= $h($app) ?> elimina por sí mismo, una vez por hora, los archivos temporales sobrantes, los enlaces compartidos caducados y las entradas antiguas de los registros. Es mejor dejarlo a cron, para que ningún visitante tenga que esperar:</p>
<?= $pre('cron') ?>
<p>Después, defina <?= $c($code['cronmode']) ?> en <?= $c('config.php') ?>.</p>

<h2>7. Comprobar</h2>
<p>Abra <?= $c('https://files.example.com/admin.php') ?>, inicie sesión con su contraseña de administrador y su código en dos pasos, y abra <b>System</b>. Todo debería estar en <i>OK</i>; lo que falte se explica allí, con la solución. Después, inicie sesión en un servidor de prueba desde la página principal.</p>

<h2>Actualizar</h2>
<p>Descomprima la nueva versión junto a la antigua, copie <?= $c('config.php') ?> y la carpeta <?= $c('storage/') ?>, actualice la base de datos y cambie después el <?= $c('DocumentRoot') ?>:</p>
<?= $pre('upgrade') ?>
<p>Añada a su <?= $c('config.php') ?> los ajustes nuevos de <?= $c('config.sample.php') ?>. El README del paquete describe cada ajuste.</p>

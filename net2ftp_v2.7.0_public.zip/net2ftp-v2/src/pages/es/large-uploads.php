<?php
$doc = [
    'title' => 'Subir archivos grandes desde el navegador',
    'lead' => 'Subir un archivo grande a través de un sitio web suele fallar en el peor momento: un límite de tiempo, un límite de tamaño o una conexión que se corta. {app} envía los archivos por partes, así que las subidas de cualquier tamaño continúan donde se interrumpieron.',
    'sections' => [
        ['h' => 'Cómo funciona',
         'ul' => [
             'Los archivos se envían por partes, dos archivos a la vez, con el progreso de cada uno.',
             'Si la subida se interrumpe (error de red, portátil cerrado, navegador cerrado), vuelva a subir el mismo archivo a la misma carpeta: continúa donde se quedó, también en una sesión posterior.',
             'Las subidas sin terminar aparecen tras iniciar sesión, para que sepa qué falta.',
             'Arrastre una carpeta entera a la página: su estructura se conserva en el servidor.',
         ],
         'shot' => ['resume', 'Una subida interrumpida se vuelve a ofrecer tras el siguiente inicio de sesión.']],
        ['h' => 'Paso a paso',
         'ol' => [
             '[[login|Inicie sesión]] en su servidor FTP, SFTP o Amazon S3.',
             'Abra la carpeta donde deben ir los archivos.',
             'Arrastre los archivos o carpetas a la página, o haga clic en <b>Subir</b>.',
             'Deje la página abierta hasta que termine el progreso. Si algo sale mal, simplemente vuelva a subir el mismo archivo.',
         ]],
        ['h' => 'Consejos para muchísimos archivos o archivos muy grandes',
         'ul' => [
             '<b>Muchos archivos pequeños</b> (un sitio web, una colección de fotos): comprímalos en un zip en su ordenador, suba ese único archivo y use <b>Extraer</b> para descomprimirlo en el servidor. Es mucho más rápido que miles de subidas sueltas.',
             '<b>Amazon S3</b>: los archivos grandes se suben por partes; las copias de archivos de más de 5 GB se hacen dentro de S3.',
             'Las <b>descargas</b> de archivos grandes las puede reanudar su navegador. Las carpetas se descargan como un solo archivo zip que empieza enseguida, sea cual sea su tamaño.',
         ]],
    ],
    'cta' => 'Empezar a subir',
    'related' => ['move-website', 's3-browser', 'online-ftp', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

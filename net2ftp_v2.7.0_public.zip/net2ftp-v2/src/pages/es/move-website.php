<?php
$doc = [
    'title' => 'Trasladar un sitio web a un servidor nuevo',
    'lead' => '¿Cambia de proveedor de alojamiento? Con {app} puede trasladar los archivos de un sitio web del servidor antiguo al nuevo desde el navegador, sin programa FTP y sin descargar miles de archivos sueltos.',
    'article' => '2026-11-26',
    'sections' => [
        ['h' => 'Antes de empezar',
         'ul' => [
             'Los datos de acceso FTP o SFTP del servidor <b>antiguo</b> y del <b>nuevo</b>.',
             'Si el sitio usa una base de datos (WordPress, Joomla, una tienda …): expórtela en el panel del proveedor antiguo (por ejemplo con phpMyAdmin) e impórtela en el nuevo. {app} traslada archivos, no bases de datos.',
         ]],
        ['h' => 'Paso a paso',
         'ol' => [
             '<b>Descargue el sitio como un solo zip.</b> [[login|Inicie sesión]] en el servidor antiguo, abra la carpeta del sitio web (a menudo <code>public_html</code>, <code>www</code> o <code>htdocs</code>), seleccione todo y haga clic en <b>Zip</b>. Obtiene un único archivo zip, sea cual sea el tamaño.',
             '<b>Suba el zip al servidor nuevo.</b> Inicie sesión en el servidor nuevo, abra la carpeta de destino y arrastre el archivo zip a la página. Si la subida se interrumpe, vuelva a subirlo: continúa donde se quedó.',
             '<b>Extráigalo en el servidor.</b> Seleccione el archivo zip y elija <b>Extraer</b>. Descomprimir en el servidor es mucho más rápido que subir cada archivo por separado. Después elimine el zip.',
             '<b>Ajuste los permisos.</b> Normalmente <code>755</code> para carpetas y <code>644</code> para archivos: seleccione todo, elija <b>Permisos</b> y marque <i>recursivo</i>. Las carpetas en las que escribe el sitio (subidas, caché) pueden necesitar más; siga su documentación.',
             '<b>Actualice la configuración.</b> Abra el archivo de configuración en el editor (por ejemplo <code>wp-config.php</code>) e introduzca el nuevo nombre de la base de datos, el usuario y la contraseña. Use <b>Buscar</b> para encontrar el dominio o las rutas antiguas en todos los archivos.',
             '<b>Pruebe y después cambie.</b> Revise el sitio en la dirección provisional del nuevo proveedor (o con una entrada en el archivo hosts de su ordenador), y solo entonces apunte su dominio al servidor nuevo. Conserve el servidor antiguo unos días, hasta que el cambio haya llegado a todo el mundo.',
         ]],
        ['h' => 'Más rápido con SSH',
         'p' => [
             'Si el servidor antiguo ofrece SFTP con terminal, puede crear el archivo comprimido en el propio servidor: abra <b>Terminal</b> en la carpeta superior y ejecute <code>tar -czf site.tar.gz public_html</code>. Después descargue ese único archivo, súbalo al servidor nuevo y extráigalo allí.',
         ]],
    ],
    'related' => ['large-uploads', 'edit-online', 'sftp-client'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

<?php
$doc = [
    'title' => 'Cliente FTP en línea: sus archivos en una pestaña del navegador',
    'lead' => 'Con {app} trabaja en cualquier servidor FTP o FTPS desde el navegador: suba, descargue, edite, mueva y comparta archivos sin instalar un programa FTP. Es gratuito, de código abierto y funciona en cualquier ordenador, tableta o teléfono.',
    'sections' => [
        ['h' => 'Lo que puede hacer',
         'ul' => [
             '<b>Subir</b> archivos y carpetas enteras arrastrándolos a la página. Las subidas grandes continúan donde se interrumpieron.',
             '<b>Descargar</b> archivos sueltos, o cualquier selección de archivos y carpetas como un solo archivo zip.',
             '<b>Editar</b> archivos HTML, PHP, CSS, JavaScript y de configuración en un editor de código con resaltado de sintaxis.',
             '<b>Copiar, mover, cambiar el nombre y eliminar</b> carpetas de cualquier tamaño, con progreso, pausa y reanudación.',
             '<b>Buscar</b> texto en todo un árbol de carpetas, cambiar <b>permisos</b> (chmod) y <b>extraer</b> archivos zip y tar directamente en el servidor.',
             '<b>Compartir</b> archivos con un enlace de descarga que caduca, con contraseña opcional.',
         ],
         'shot' => ['browse', 'La lista de archivos: ordene, filtre, seleccione y actúe sobre muchos archivos a la vez.']],
        ['h' => 'Cómo funciona',
         'ol' => [
             'Abra [[login|la página de inicio de sesión]] y elija <b>FTP</b>.',
             'Introduzca su servidor (por ejemplo <code>ftp.example.com</code>), su nombre de usuario y su contraseña. Los encontrará en el correo de bienvenida de su proveedor de alojamiento.',
             'Haga clic en <b>Conectar</b>. Eso es todo: no hay que crear ninguna cuenta.',
         ]],
        ['h' => '¿Por qué usar FTP en el navegador?',
         'ul' => [
             '<b>Nada que instalar ni actualizar</b>: práctico en un ordenador del trabajo donde no puede instalar software, en un portátil prestado o en el teléfono.',
             '<b>Funciona donde FTP está bloqueado</b>: muchas redes de empresas y hoteles bloquean FTP pero permiten sitios web. {app} habla con su servidor por usted.',
             '<b>Igual en todas partes</b>: Windows, Mac, Linux, Chromebook, Android e iPhone, en 11 idiomas, en modo claro y oscuro.',
         ]],
        ['h' => 'Seguro',
         'p' => [
             'Su contraseña solo se usa para conectarse a su servidor. Se guarda cifrada mientras tiene la sesión iniciada, nunca se escribe en el disco en texto claro y nunca se incluye en enlaces. Antes de enviarla, puede comprobar la huella del servidor. Si su servidor lo admite, active <b>FTP over TLS (FTPS)</b> en <i>Opciones avanzadas</i> para que todo vaya cifrado; lea [[ftp-ftps-sftp|¿FTP, FTPS o SFTP?]] para saber por qué es importante.',
         ]],
    ],
    'cta' => 'Abrir el cliente FTP',
    'related' => ['sftp-client', 'large-uploads', 'edit-online', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

<?php
/**
 * Traducción de la política de privacidad (plantilla). La versión inglesa es la que da fe.
 * @var callable $h @var callable $url @var array $site @var string $app
 */
require N2F_ROOT . '/src/pages/_shared/privacy_vars.php';
?>
<h1>Política de privacidad</h1>
<?php if ($isTemplate): ?>
  <p class="pg-warn"><b>Plantilla.</b> El operador de este sitio todavía no ha introducido sus datos (config.php → <code>site</code>). Hasta entonces, esta política está incompleta.</p>
<?php endif ?>
<p class="pg-lead">Esta política explica qué datos personales trata <?= $op ?> cuando usa <?= $h($app) ?> en este sitio web, por qué, durante cuánto tiempo y cuáles son sus derechos.</p>
<p class="pg-small">Última actualización: <?= $h(date('d/m/Y', $updated)) ?>. Esta traducción se ofrece para su comodidad; en caso de discrepancia, solo da fe la <?= $enLink('privacy', 'versión en inglés') ?>.</p>

<h2>1. Responsable</h2>
<p><?= $op ?>, <?= $h($site['address'] ?? '') ?> es el responsable del tratamiento de sus datos personales. Preguntas sobre protección de datos: <?= $mail ?>.</p>

<h2>2. Qué tratamos y por qué</h2>
<table class="pg-table">
  <thead><tr><th>Datos</th><th>Finalidad</th><th>Base jurídica</th><th>Plazo de conservación</th></tr></thead>
  <tbody>
    <tr><td><b>Datos de acceso al servidor</b>: servidor, puerto, nombre de usuario, contraseña o clave, claves de Amazon S3</td>
      <td>Conectarse al servidor que elija, mientras tenga la sesión iniciada</td><td>Prestación del servicio que solicita (art. <bdi dir="ltr" class="pg-nw">6(1)(b)</bdi> RGPD)</td>
      <td>Solo mientras tiene la sesión iniciada, cifrados; se eliminan al cerrar sesión o tras <?= $idle ?> minutos de inactividad. <b>Nunca se escriben en disco ni en una base de datos en texto plano.</b></td></tr>
    <tr><td><b>Progreso de las tareas de copiar, mover y eliminar y de las subidas sin terminar</b>: servidor, nombre de usuario, nombres de carpetas y archivos, tamaños, progreso (sin contraseñas)</td>
      <td>Continuar una transferencia tras una interrupción (conexión perdida, navegador cerrado)</td><td>Prestación del servicio que usted solicita (RGPD art. <bdi dir="ltr" class="pg-nw">6(1)(b)</bdi>)</td>
      <td>7 días después de la última actividad; después se elimina automáticamente</td></tr>
    <tr><td><b>Registro de acciones</b>: dirección IP, navegador (user agent), fecha y hora, servidor, nombre de usuario, nombres de carpetas y archivos, acción, cantidad de datos, resultado</td>
      <td>Proteger a los propietarios de servidores contra abusos (contraseñas robadas, desfiguración de sitios), investigar denuncias de abuso, prevenir ataques contra este sitio</td>
      <td>Interés legítimo en la seguridad (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi> RGPD)</td><td><?= $logDays ?> días; después se elimina automáticamente</td></tr>
    <tr><td><b>Consumo por dirección IP</b>: fecha, dirección IP, número de solicitudes e inicios de sesión, cantidad de datos, tiempo de servidor usado</td>
      <td>Aplicar los límites diarios que mantienen el servicio disponible para todos</td><td>Interés legítimo (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td>
      <td><?= $days['usage_ip'] ?> días; después se elimina. Los totales por servidor (sin direcciones IP) se conservan <?= $days['usage_server'] ?> días con fines estadísticos</td></tr>
    <tr><td><b>Eventos de seguridad</b>: dirección IP, servidor, nombre de usuario, qué ocurrió (límite alcanzado, bloqueo, inicio de sesión de administrador fallido…)</td>
      <td>Detectar y detener ataques y abusos</td><td>Interés legítimo (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td><?= $days['security'] ?> días</td></tr>
    <tr><td><b>Lista de bloqueos</b>: direcciones IP y servidores bloqueados tras un abuso, con el motivo</td>
      <td>Evitar nuevos abusos</td><td>Interés legítimo (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td>Hasta que termina el bloqueo; después, <?= $days['blocks'] ?> días</td></tr>
    <tr><td><b>Informes de errores</b>: mensajes de error técnicos del software, tipo de navegador y dirección IP de la última vez que ocurrió</td>
      <td>Encontrar y corregir errores</td><td>Interés legítimo (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td><?= $days['errors'] ?> días después de la última vez que ocurrió el error; la dirección IP se elimina a los 30 días</td></tr>
    <tr><td><b>Archivos que comparte con un enlace</b>, con los ajustes del enlace, su dirección IP (contra el abuso), el número de descargas y las direcciones IP de quienes descargan (en el registro de acciones)</td>
      <td>Poner los archivos a disposición de las personas a las que envía el enlace</td><td>Prestación del servicio (art. <bdi dir="ltr" class="pg-nw">6(1)(b)</bdi>)</td>
      <td>Hasta que caduca el enlace (como máximo <?= $shareDays ?> días) o usted lo elimina; después se eliminan de inmediato</td></tr>
    <tr><td><b>Denuncias de abuso y solicitudes sobre protección de datos</b> que nos envía: nombre, dirección de correo electrónico, contenido de su mensaje, dirección IP</td>
      <td>Tramitar su denuncia o solicitud</td><td>Obligación legal (art. <bdi dir="ltr" class="pg-nw">6(1)(c)</bdi>) e interés legítimo (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td>
      <td>El tiempo necesario para tramitarla, como máximo 3 años</td></tr>
    <tr><td><b>Registros del servidor web</b> de nuestro proveedor de alojamiento: dirección IP, página, fecha y hora</td><td>Funcionamiento y seguridad del sitio web</td>
      <td>Interés legítimo (art. <bdi dir="ltr" class="pg-nw">6(1)(f)</bdi>)</td><td>Según la configuración del proveedor de alojamiento</td></tr>
  </tbody>
</table>
<p>No miramos el contenido de sus archivos, salvo que los comparta con un enlace y alguien denuncie ese enlace como abuso. No vendemos datos personales ni los usamos para publicidad.</p>

<h2>3. Cookies</h2>
<table class="pg-table">
  <thead><tr><th>Cookie</th><th>Para qué</th><th>Categoría</th><th>Plazo de conservación</th></tr></thead>
  <tbody>
    <tr><td class="mono">N2FSESSID</td><td>Mantiene su sesión iniciada</td><td>Necesarias</td><td>Hasta que cierre el navegador</td></tr>
    <tr><td class="mono">n2f_consent</td><td>Recuerda su elección sobre las cookies</td><td>Necesarias</td><td>1 año</td></tr>
    <tr><td class="mono">n2f_dl_*</td><td>Indica cuándo ha empezado una descarga</td><td>Necesarias</td><td>2 minutos</td></tr>
    <tr><td class="mono">n2f_sp_*</td><td>Recuerda que introdujo la contraseña de un enlace compartido</td><td>Necesarias</td><td>Hasta que caduque el enlace</td></tr>
    <tr><td class="mono">n2f_lang</td><td>Su idioma</td><td>Preferencias (si no, hasta que cierre el navegador)</td><td>1 año</td></tr>
    <tr><td class="mono">n2f_saved</td><td>Servidores recordados, incluida la contraseña y la última carpeta abierta, cifrados con nuestra clave e ilegibles para los scripts</td><td>Preferencias</td><td><?= $remDays ?> días</td></tr>
  </tbody>
</table>
<p><?= $h($app) ?> <b>no usa cookies estadísticas ni publicitarias</b>. Puede cambiar su elección en cualquier momento con <i>Configuración de cookies</i> al pie de la página de inicio de sesión; retirar «Preferencias» elimina de inmediato los servidores recordados.</p>

<h2>4. Quién recibe los datos</h2>
<ul>
  <li><b>Los servidores a los que se conecta</b> reciben sus datos de acceso y sus acciones, como con cualquier programa FTP o SSH. Sus propietarios tienen sus propias políticas de privacidad.</li>
  <li><b>Nuestro proveedor de alojamiento</b> almacena los datos por cuenta nuestra, en virtud de un contrato de encargo del tratamiento.</li>
  <li><b>Las personas a las que envía un enlace compartido</b> pueden descargar los archivos compartidos.</li>
  <li><b>Propietarios de servidores y autoridades</b>: si su cuenta se usa para cometer abusos, podemos facilitar las entradas de registro correspondientes al propietario del servidor afectado o a la policía, cuando la ley lo permita o lo exija.</li>
</ul>
<p>País donde se almacenan los datos: <?= $jurisdiction ?>. Cuando se transfieren datos a otros países, solo se hace con garantías adecuadas (p. ej. las cláusulas contractuales tipo de la UE).</p>

<h2>5. Seguridad</h2>
<p>Todas las conexiones a este sitio usan HTTPS. Los datos de acceso se cifran en la sesión (XSalsa20-Poly1305 o AES-256-GCM). Los enlaces compartidos contienen 192 bits aleatorios, solo se guardan como hash y pueden protegerse con contraseña. El acceso a los registros está limitado a los administradores.</p>

<h2>6. Sus derechos</h2>
<p>Puede solicitar el acceso a sus datos, una copia en un formato legible por máquina, su rectificación, supresión y la limitación del tratamiento, así como oponerse al tratamiento basado en el interés legítimo.
  Use el <a href="<?= $h($url('gdpr')) ?>">formulario de solicitud sobre protección de datos</a> o escriba a <?= $mail ?>. Respondemos en un plazo de 30 días.
  Tenga en cuenta que el registro de acciones está organizado por dirección IP, servidor y nombre de usuario: díganos cuáles usó para que podamos encontrar sus entradas.</p>
<p>También tiene derecho a presentar una reclamación ante una autoridad de control: en Suiza, <?= $h($site['authority'] ?? 'el FDPIC') ?>; en la UE, la autoridad de su país.</p>

<h2>7. Cambios</h2>
<p>Actualizamos esta política cuando cambia el servicio. La fecha de arriba indica la versión vigente.</p>

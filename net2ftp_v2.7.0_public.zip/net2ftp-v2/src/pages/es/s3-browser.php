<?php
$doc = [
    'title' => 'Amazon S3 en el navegador',
    'lead' => 'Explore sus buckets de Amazon S3 como carpetas de un disco: suba, descargue, copie, comparta y edite archivos sin la consola de AWS ni un programa de escritorio. {app} también funciona con almacenamiento compatible con S3.',
    'sections' => [
        ['h' => 'Lo que puede hacer',
         'ul' => [
             'Explorar todos sus buckets, o uno solo si su clave está limitada a él.',
             'Subir archivos y carpetas de cualquier tamaño: los archivos grandes se envían por partes y continúan tras una interrupción.',
             'Descargar un archivo, o una selección de archivos y «carpetas» como un solo archivo zip.',
             'Copiar y mover archivos, también de más de 5 GB: las copias se hacen dentro de S3, sin pasar por su ordenador.',
             'Editar archivos de texto, buscar archivos y compartirlos con un enlace de descarga que caduca.',
         ]],
        ['h' => 'Qué almacenamiento funciona',
         'p' => [
             'Amazon S3 en todas las regiones, y el almacenamiento que usa el protocolo S3, como MinIO, Wasabi, Cloudflare R2, Exoscale o Infomaniak. Para estos, abra <i>Opciones avanzadas</i> e introduzca la dirección del endpoint del proveedor.',
         ]],
        ['h' => 'Cómo iniciar sesión',
         'ol' => [
             'Abra [[login|la página de inicio de sesión]] y elija <b>Amazon S3</b>.',
             'Introduzca una <b>clave de acceso</b> y una <b>clave secreta</b>. Si quiere, indique también un bucket y una región.',
             'Haga clic en <b>Conectar</b>.',
         ],
         'p' => [
             '<b>Consejo:</b> no use las claves de la cuenta raíz de AWS. Cree un usuario de IAM (o credenciales temporales) con acceso solo a los buckets que necesita. {app} guarda la clave secreta cifrada mientras la sesión está abierta y nunca la incluye en enlaces.',
         ]],
    ],
    'cta' => 'Abrir el navegador de S3',
    'related' => ['large-uploads', 'online-ftp', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

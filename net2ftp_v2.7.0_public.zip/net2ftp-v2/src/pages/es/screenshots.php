<?php
/** @var callable $h @var string $app */
$shots = [
    ['login', 'Iniciar sesión', 'Elija FTP, SFTP o Amazon S3. Puede comprobar la huella del servidor antes de enviar su contraseña.'],
    ['browse', 'Explorar', 'Una lista de archivos rápida con ordenación, filtro, selección múltiple y menú contextual.'],
    ['edit', 'Editar', 'El editor de código con resaltado de sintaxis, buscar y reemplazar, y números de línea.'],
    ['search', 'Buscar', 'Busque texto en todo un árbol de carpetas; haga clic en un resultado para abrir el archivo en esa línea.'],
    ['upload', 'Subir', 'Arrastre archivos o carpetas a la página; progreso de cada archivo.'],
    ['resume', 'Reanudar subidas', 'Una subida interrumpida al cerrar el navegador se ofrece de nuevo al iniciar sesión: elija el archivo para continuar.'],
    ['jobs', 'Tareas de copia', 'Copie, mueva o elimine carpetas de cualquier tamaño: progreso, velocidad y tiempo restante, con pausa y reanudación.'],
    ['permissions', 'Permisos', 'Cambie los permisos de muchos archivos y carpetas a la vez, de forma recursiva.'],
    ['terminal', 'Terminal SSH', 'Ejecute comandos en un servidor SFTP en la carpeta actual, junto a la lista de archivos.'],
    ['share', 'Enlaces compartidos', 'Cree un enlace de descarga con caducidad, contraseña y límite de descargas.'],
    ['sharepage', 'Página de descarga', 'Lo que ve el destinatario de un enlace compartido.'],
    ['arabic', 'En su idioma', 'Once idiomas, con un diseño en espejo para el árabe y el hebreo.'],
    ['mobile', 'En su móvil', 'Las mismas funciones en una pantalla pequeña, aquí en modo oscuro.'],
];
?>
<h1>Capturas de pantalla</h1>
<p class="pg-lead">Así es <?= $h($app) ?>. Haga clic en una imagen para verla a tamaño completo.</p>
<div class="pg-shots">
  <?php foreach ($shots as [$file, $title, $text]):
      $src = 'assets/img/screenshots/' . $file . '.webp';
      if (!is_file(N2F_ROOT . '/public/' . $src)) continue; ?>
    <figure class="pg-shot">
      <a href="<?= $h($src) ?>"><img src="<?= $h($src) ?>" alt="<?= $h($title . ': ' . $text) ?>" loading="lazy" width="720" height="450"></a>
      <figcaption><b><?= $h($title) ?></b> <?= $h($text) ?></figcaption>
    </figure>
  <?php endforeach ?>
</div>

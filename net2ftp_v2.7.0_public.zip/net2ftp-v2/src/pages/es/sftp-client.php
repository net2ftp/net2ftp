<?php
$doc = [
    'title' => 'Cliente SFTP web con terminal SSH',
    'lead' => 'Gestione los archivos de su servidor SFTP desde el navegador y ejecute comandos de shell junto a ellos. {app} admite contraseñas y claves privadas, comprueba la identidad del servidor y funciona con servidores Linux y Windows.',
    'sections' => [
        ['h' => 'SFTP en su navegador',
         'p' => [
             'SFTP es transferencia de archivos por SSH: toda la conexión va cifrada, a través del único puerto que su servidor ya usa para SSH (normalmente el 22). Con {app} tiene el gestor de archivos de un programa SFTP de escritorio sin instalar ninguno: navegar, subir y descargar (también carpetas enteras, también con reanudación), editar archivos, cambiar permisos y propietarios, extraer archivos comprimidos y crear enlaces para compartir.',
         ]],
        ['h' => 'Inicie sesión con contraseña o con clave',
         'ul' => [
             '<b>Contraseña</b>: el mismo nombre de usuario y contraseña que usa para SSH.',
             '<b>Clave privada</b>: pegue una clave RSA, ECDSA o Ed25519, con su frase de contraseña si la tiene. La clave solo se usa para iniciar sesión y se guarda cifrada mientras la sesión está abierta.',
             '<b>Comprobación de la huella</b>: vea la clave del servidor antes de iniciar sesión y reciba un aviso si alguna vez cambia.',
         ]],
        ['h' => 'Un terminal SSH junto a sus archivos',
         'p' => [
             'En los servidores que lo permiten, <b>Terminal</b> ejecuta comandos de shell en la carpeta que está viendo: crear un archivo con <code>tar</code>, consultar el espacio con <code>du</code>, vaciar una caché, hacer un volcado de la base de datos o ejecutar un comando de Composer. <code>cd</code> cambia también la carpeta de la lista de archivos. Los comandos se ejecutan de uno en uno; los programas interactivos como los editores o <code>top</code> no funcionan ahí.',
         ],
         'shot' => ['terminal', 'El terminal SSH bajo la lista de archivos, en la carpeta actual.']],
        ['h' => 'Cuándo elegir SFTP',
         'p' => [
             'Si su servidor ofrece SFTP, úselo: va cifrado, necesita un solo puerto y atraviesa fácilmente los cortafuegos. Muchos proveedores lo ofrecen junto a FTP, a veces con el nombre de «acceso SSH». Encontrará una comparación en [[ftp-ftps-sftp|¿FTP, FTPS o SFTP?]].',
         ]],
    ],
    'cta' => 'Abrir el cliente SFTP',
    'related' => ['ftp-ftps-sftp', 'online-ftp', 'move-website', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

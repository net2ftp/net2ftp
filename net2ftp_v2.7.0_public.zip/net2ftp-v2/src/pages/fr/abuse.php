<?php
/** @var callable $h @var array $form @var array $site @var string $app */
?>
<h1>Signaler un abus</h1>
<?php if (!$form['sent']): ?>
<p class="pg-lead"><?= $h($app) ?> est un outil qui sert à gérer <em>ses propres</em> serveurs. Comme tout programme FTP, il peut être détourné par quelqu'un qui a volé un mot de passe.
  Si votre serveur a été modifié via ce site, ou si un lien de partage de ce site est utilisé à des fins illégales, signalez-le ici.</p>
<p>Chaque action sur ce site est journalisée avec l'adresse IP du visiteur, le serveur, le nom d'utilisateur et l'heure. Cela nous permet de retrouver le responsable, de le bloquer
  et de transmettre ces informations à vous-même ou à la police. Nous répondons généralement sous deux jours ouvrables. Les liens de partage signalés pour logiciel malveillant ou hameçonnage sont supprimés dès que nous les avons vérifiés.</p>
<p class="pg-small">Avant de signaler : si votre mot de passe FTP a été utilisé, <b>changez-le maintenant</b> sur votre serveur. Se déconnecter de ce site n'arrête pas quelqu'un qui connaît votre mot de passe.
  <?php if (!empty($site['abuse_email'])): ?>Vous pouvez aussi écrire à <a href="mailto:<?= $h($site['abuse_email']) ?>" dir="ltr"><?= $h($site['abuse_email']) ?></a>.<?php endif ?></p>
<?php endif ?>
<?php require N2F_ROOT . '/src/pages/_shared/abuse_form.php'; ?>

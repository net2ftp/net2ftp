<?php
$doc = [
    'title' => 'FTP actif et passif : quelle différence ?',
    'lead' => 'La connexion fonctionne, mais la liste des fichiers n’apparaît jamais ou un transfert se bloque ? La cause est presque toujours la connexion de données FTP, et la solution tient souvent en une case à cocher : le mode passif.',
    'article' => '2026-11-26',
    'sections' => [
        ['h' => 'FTP utilise deux connexions',
         'p' => [
             'FTP a été conçu dans les années 1970, bien avant les pare-feu. Il utilise une connexion pour les commandes (la <b>connexion de contrôle</b>, en général le port 21) et ouvre une nouvelle <b>connexion de données</b> pour chaque liste et chaque fichier. Les modes actif et passif ne diffèrent que par celui qui ouvre cette connexion de données.',
         ]],
        ['h' => 'Mode passif : le client se connecte',
         'p' => [
             'Le client demande un port au serveur (commande <code>PASV</code> ou <code>EPSV</code>). Le serveur ouvre un port aléatoire et le client s’y connecte. Cela fonctionne bien quand le client est derrière un pare-feu ou une box, c’est pourquoi le mode passif est le réglage par défaut des navigateurs, de la plupart des logiciels FTP et de {app}. Le pare-feu du serveur doit autoriser sa plage de ports passifs.',
         ]],
        ['h' => 'Mode actif : le serveur se reconnecte',
         'p' => [
             'Le client indique au serveur une adresse et un port (commande <code>PORT</code> ou <code>EPRT</code>), et le serveur s’y connecte en retour. Cela fonctionne quand le serveur est derrière un pare-feu qui ne laisse entrer que le port 21, mais le client doit accepter les connexions entrantes. {app} prend en charge les deux modes.',
         ]],
        ['h' => 'Problèmes et solutions',
         'table' => [
             ['Ce que vous voyez', 'Que faire'],
             ['La connexion fonctionne, mais le dossier ne se charge jamais ou le délai expire', 'Changez de mode : décochez <i>Mode passif</i> dans les <i>Options avancées</i> de la page de connexion, ou cochez-le s’il était décoché.'],
             ['« … n’a pas répondu à la demande de mode passif »', 'Le serveur (ou un pare-feu devant lui) bloque le mode passif. Reconnectez-vous avec le mode passif désactivé.'],
             ['Le mode actif fonctionne en FTP, mais pas en FTP sur TLS', 'Les pare-feu ne peuvent pas lire les commandes chiffrées, ils ne peuvent donc pas ouvrir le port du mode actif. Utilisez le mode passif, ou SFTP.'],
             ['Aucun des deux modes ne fonctionne', 'Le pare-feu du serveur bloque les ports de données. Demandez à votre hébergeur, ou utilisez SFTP, qui n’a besoin que d’un port.'],
         ]],
        ['h' => 'Pour les administrateurs de serveurs',
         'p' => [
             'Pour le mode passif, choisissez une petite plage de ports, ouvrez-la dans le pare-feu et configurez-la dans le serveur FTP : <code>pasv_min_port</code> et <code>pasv_max_port</code> dans vsftpd, <code>PassivePorts</code> dans ProFTPD, ou <code>-p</code> dans Pure-FTPd. Derrière un NAT, le serveur doit aussi annoncer son adresse publique. {app} ignore l’adresse de la réponse passive et se connecte à l’adresse propre du serveur : une mauvaise adresse à cet endroit ne le bloque donc pas.',
         ]],
    ],
    'related' => ['ftp-ftps-sftp', 'faq', 'online-ftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

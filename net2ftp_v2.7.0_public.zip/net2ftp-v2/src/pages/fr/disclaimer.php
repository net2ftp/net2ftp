<?php
/**
 * Traduction de l'avertissement (modèle). La version anglaise fait foi.
 * @var callable $h @var callable $url @var array $site @var string $app
 */
require N2F_ROOT . '/src/pages/_shared/privacy_vars.php';
?>
<h1>Avertissement</h1>
<?php if ($isTemplate): ?>
  <p class="pg-warn"><b>Modèle.</b> L'exploitant de ce site n'a pas encore saisi ses coordonnées (config.php → <code>site</code>).</p>
<?php endif ?>
<p class="pg-lead">En utilisant ce site, vous acceptez les conditions ci-dessous. Si vous ne les acceptez pas, veuillez ne pas l'utiliser.</p>
<p class="pg-small">Cette traduction est fournie pour vous faciliter la lecture ; en cas de divergence, seule la <?= $enLink('disclaimer', 'version anglaise') ?> fait foi.</p>

<h2>1. Le service</h2>
<p><?= $h($app) ?> est proposé par <?= $op ?> gratuitement et <b>en l'état</b>, sans aucune garantie : nous ne garantissons pas qu'il soit toujours disponible, exempt d'erreurs ou adapté à un usage particulier.
  Nous pouvons modifier, limiter ou arrêter le service à tout moment, et fixer des limites à la taille des fichiers, aux transferts et à l'utilisation.</p>

<h2>2. Votre responsabilité</h2>
<ul>
  <li>Connectez-vous uniquement à des serveurs que vous êtes <b>autorisé</b> à utiliser, avec des identifiants qui vous appartiennent ou que vous avez le droit d'utiliser.</li>
  <li>Vous êtes responsable de tout ce que vous faites avec le service : les fichiers que vous envoyez, modifiez, supprimez ou partagez, et leurs conséquences sur votre serveur.</li>
  <li><b>Faites des sauvegardes.</b> Supprimer, écraser, modifier les permissions et extraire des archives sont des opérations irréversibles.</li>
  <li>N'utilisez pas le service à des fins illégales : accès non autorisé, défiguration de sites web, diffusion de logiciels malveillants, hameçonnage, spam, ou fichiers portant atteinte aux droits d'autrui.</li>
  <li>N'essayez pas de surcharger, d'attaquer ou de contourner les limites de ce site ou des serveurs auxquels il se connecte.</li>
</ul>

<h2>3. Journalisation et abus</h2>
<p>Chaque action est journalisée (voir la <a href="<?= $h($url('privacy')) ?>">politique de confidentialité</a>). En cas d'abus, nous pouvons bloquer l'accès, supprimer des liens de partage et transmettre les entrées de journal aux propriétaires des serveurs touchés et aux autorités.
  Pour signaler un abus, utilisez le <a href="<?= $h($url('abuse')) ?>">formulaire de signalement</a>.</p>

<h2>4. Liens de partage</h2>
<p>Les fichiers partagés par lien sont publiés par l'utilisateur qui a créé le lien, et non par <?= $op ?>. Nous ne les vérifions pas à l'avance. Nous supprimons les liens signalés comme illégaux après avoir vérifié le signalement.
  Ne téléchargez des fichiers partagés que de personnes en qui vous avez confiance.</p>

<h2>5. Responsabilité</h2>
<p>Dans les limites autorisées par la loi, <?= $op ?> décline toute responsabilité pour les dommages résultant de l'utilisation ou de l'impossibilité d'utiliser ce site — en particulier la perte de données, les dommages causés à des sites web ou à des serveurs, le manque à gagner, ou les dommages causés par d'autres utilisateurs.
  Cela ne limite pas la responsabilité pour faute intentionnelle ou négligence grave lorsque la loi ne le permet pas.</p>

<h2>6. Liens vers d'autres sites</h2>
<p>Nous ne sommes pas responsables du contenu des sites vers lesquels nous renvoyons.</p>

<h2>7. Le logiciel</h2>
<p>Le logiciel de ce site est open source, sous licence publique générale GNU, version 2 ou ultérieure, et est fourni sans garantie. Si vous l'installez vous-même, vous êtes l'exploitant de votre installation.</p>

<h2>8. Droit applicable</h2>
<p>Les présentes conditions sont régies par le droit de : <?= $jurisdiction ?>. Les tribunaux du siège de <?= $op ?> sont compétents, sauf disposition impérative contraire du droit de la consommation.</p>
<p>Contact : <span dir="ltr"><?= $h($site['email'] ?? '') ?></span></p>

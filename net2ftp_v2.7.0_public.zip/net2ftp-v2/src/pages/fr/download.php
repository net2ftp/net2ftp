<?php
/** @var callable $h @var callable $url @var array $site @var string $app @var string $version */
$L = [
    'file' => 'Fichier', 'size' => 'Taille', 'date' => 'Date',
    'check' => 'Vérifiez le téléchargement : %1$s (Linux), %2$s (macOS) ou %3$s (Windows PowerShell) doit afficher la même valeur.',
    'releases' => 'Toutes les versions', 'source' => 'Code source',
    'none' => 'Aucun téléchargement n\'est encore publié sur ce serveur. Demandez à l\'administrateur :',
];
?>
<h1>Téléchargement</h1>
<p class="pg-lead">Installez <?= $h($app) ?> sur votre propre serveur web, pour votre entreprise, vos clients ou vous-même.
  Il est gratuit et open source (GPL 2.0 ou ultérieure). Version actuelle : <b dir="ltr"><?= $h($version) ?></b>.</p>
<?php require N2F_ROOT . '/src/pages/_shared/download_files.php'; ?>

<h2>Ce qu'il vous faut</h2>
<table class="pg-table">
  <tbody>
    <tr><th>Serveur web</th><td>Apache 2.4 (mod_php ou PHP-FPM), ou nginx avec PHP-FPM</td></tr>
    <tr><th>PHP</th><td>8.1 ou plus récent, avec les extensions ftp, curl, zip, mbstring, openssl ou sodium (la plupart sont installées par défaut)</td></tr>
    <tr><th>Base de données</th><td>MySQL 5.7+ ou MariaDB 10.3+ pour les journaux (facultatif, mais recommandé)</td></tr>
    <tr><th>Disque</th><td>Environ 5 Mo pour le code, plus de la place pour les fichiers temporaires et les liens de partage</td></tr>
  </tbody>
</table>
<p>Une extension manquante ne bloque pas l'installation : <?= $h($app) ?> vous indique exactement ce qui manque et le reste continue de fonctionner.
  Voir <a href="<?= $h($url('install')) ?>">comment l'installer</a>.</p>

<h2>Nouveautés de la version <span dir="ltr"><?= $h($version) ?></span></h2>
<ul>
  <li>Limites quotidiennes de données et de temps serveur, par visiteur et par serveur FTP, pour un service équitable pour tous.</li>
  <li>Détection automatique des envois en masse (le même fichier vers de nombreux serveurs), avec blocage automatique.</li>
  <li>Un nouveau panneau d'administration : tableau de bord, examen des signalements d'abus, consommation, blocages, erreurs et événements de sécurité.</li>
  <li>Connexion à deux facteurs et verrouillage pour l'administrateur.</li>
  <li>Les anciennes entrées des journaux et les fichiers restants sont supprimés automatiquement.</li>
  <li>Les pages d'information sont disponibles dans les onze langues.</li>
</ul>

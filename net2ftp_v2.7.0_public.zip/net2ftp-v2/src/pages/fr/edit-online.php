<?php
$doc = [
    'title' => 'Modifier des fichiers sur votre serveur en ligne',
    'lead' => 'Corriger une faute sur votre site, changer un réglage dans un fichier de configuration ou mettre à jour un script PHP directement sur votre serveur FTP ou SFTP, depuis n’importe quel navigateur. Sans télécharger, modifier puis renvoyer.',
    'sections' => [
        ['h' => 'Un vrai éditeur de code',
         'ul' => [
             'Coloration syntaxique pour PHP, HTML, CSS, JavaScript et plus de 20 autres langages, avec numéros de ligne.',
             'Rechercher et remplacer dans le fichier (<kbd>Ctrl</kbd>+<kbd>F</kbd>), enregistrer avec <kbd>Ctrl</kbd>+<kbd>S</kbd>.',
             'L’encodage des caractères et les fins de ligne du fichier sont conservés : les fichiers Windows et Unix restent tels quels.',
             '<b>Aucune modification perdue</b> : si quelqu’un d’autre a modifié le fichier sur le serveur après que vous l’avez ouvert, {app} vous prévient avant de l’écraser.',
         ],
         'shot' => ['edit', 'L’éditeur de code avec coloration syntaxique.']],
        ['h' => 'Trouver ce qu’il faut changer',
         'p' => [
             '<b>Rechercher</b> trouve du texte dans tous les fichiers d’un dossier et de ses sous-dossiers, par exemple une ancienne adresse e-mail ou un réglage de base de données. Vous pouvez limiter la recherche à certains fichiers (<code>*.php *.html</code>) ou utiliser une expression régulière. Cliquez sur un résultat pour ouvrir le fichier à cette ligne.',
         ]],
        ['h' => 'Autour de l’éditeur',
         'ul' => [
             'Créer des fichiers et des dossiers, renommer et copier des fichiers pour garder une sauvegarde avant de les modifier.',
             'Modifier les permissions, par exemple <code>644</code> pour les fichiers et <code>755</code> pour les dossiers.',
             'Ajouter un favori : chaque fichier de l’éditeur a sa propre adresse, pour y revenir directement.',
         ]],
    ],
    'cta' => 'Ouvrir l’éditeur',
    'related' => ['online-ftp', 'move-website', 'faq'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

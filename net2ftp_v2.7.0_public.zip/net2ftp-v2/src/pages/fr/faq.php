<?php
$doc = [
    'title' => 'Questions et réponses',
    'lead' => 'Les questions les plus fréquentes sur {app}. Vous ne trouvez pas la vôtre ? Lisez le [[help|mode d’emploi]] ou les [[guides|guides]].',
    'faq' => [
        'À propos de {app}' => [
            ['{app} est-il gratuit ?', 'Oui. {app} est gratuit et open source (GPL). Vous pouvez l’utiliser sur ce site, ou le [[download|télécharger]] et l’installer sur votre propre serveur.'],
            ['Faut-il créer un compte ?', 'Non. Vous vous connectez avec le nom d’utilisateur et le mot de passe de votre propre serveur FTP, SFTP ou S3. Il n’y a rien à enregistrer.'],
            ['Faut-il installer quelque chose ?', 'Non. {app} fonctionne dans tout navigateur récent, sous Windows, Mac, Linux, Chromebook, Android et iPhone.'],
            ['Avec quels serveurs fonctionne-t-il ?', 'Avec tout serveur FTP ou FTPS, tout serveur SFTP/SSH sous Linux ou Windows, Amazon S3 et les stockages compatibles S3 comme MinIO, Wasabi, Cloudflare R2, Exoscale ou Infomaniak.'],
        ],
        'Sécurité et confidentialité' => [
            ['Est-il sûr de saisir mon mot de passe FTP ?', 'Votre mot de passe sert uniquement à vous connecter à votre serveur. Il reste chiffré pendant votre session, n’est jamais écrit en clair sur le disque et n’apparaît jamais dans les liens. Vous pouvez vérifier l’empreinte du serveur avant de l’envoyer.'],
            ['Qu’est-ce que l’empreinte du serveur ?', 'L’empreinte identifie un serveur, comme un sceau sur une lettre. Comparez-la avec celle que vous donne votre hébergeur avant votre première connexion. Si {app} indique plus tard qu’elle a changé, ne vous connectez pas avant de savoir pourquoi.'],
            ['Mes fichiers restent-ils sur votre serveur ?', 'Non. Les fichiers transitent par ce serveur entre votre ordinateur et votre serveur, et ne sont pas conservés. Exceptions : les copies faites pour les liens de partage (jusqu’à l’expiration du lien) et les morceaux d’envois inachevés (jusqu’à leur expiration ou leur achèvement).'],
            ['Qu’est-ce qui est journalisé ?', 'Chaque action (par exemple : qui a envoyé quel fichier sur quel serveur, et quand) est journalisée avec l’adresse IP, pour protéger les propriétaires de serveurs contre les abus. La [[privacy|politique de confidentialité]] indique ce qui est conservé et combien de temps.'],
        ],
        'Connexion' => [
            ['Quel port utiliser ?', 'Laissez le port vide pour utiliser le port habituel : 21 pour FTP et FTPS, 22 pour SFTP. N’indiquez un autre port que si votre hébergeur vous le demande.'],
            ['Pourquoi « Impossible de se connecter à … » ?', 'Vérifiez le nom du serveur et le port. Certains hébergeurs n’autorisent FTP que depuis certaines adresses, ou pas depuis d’autres serveurs ; demandez-leur, ou essayez SFTP.'],
            ['La connexion fonctionne, mais le dossier ne se charge pas. Que faire ?', 'C’est presque toujours la connexion de données FTP. Ouvrez les <i>Options avancées</i> sur la page de connexion et décochez <i>Mode passif</i> (ou cochez-le s’il était décoché). [[active-passive|FTP actif et passif]] explique pourquoi.'],
            ['Faut-il utiliser FTP, FTPS ou SFTP ?', 'SFTP ou FTPS si votre serveur les prend en charge : les deux sont chiffrés. Le FTP simple envoie votre mot de passe en clair. Voir [[ftp-ftps-sftp|FTP, FTPS ou SFTP ?]].'],
        ],
        'Fichiers' => [
            ['Puis-je transférer de gros fichiers ?', 'Oui. Les fichiers sont envoyés par morceaux et reprennent après une interruption, et les dossiers de toute taille sont copiés, déplacés et compressés sans limite de temps. Voir [[large-uploads|Envoyer de gros fichiers]].'],
            ['Puis-je décompresser des fichiers sur le serveur ?', 'Oui. Sélectionnez un fichier .zip, .tar, .tar.gz ou .tar.bz2 et choisissez <b>Extraire</b> : il est décompressé directement sur le serveur.'],
            ['Comment envoyer un fichier à quelqu’un qui n’a pas accès à mon serveur ?', 'Sélectionnez-le et cliquez sur <b>Partager</b>. Vous obtenez un lien de téléchargement qui expire, avec si vous le souhaitez un mot de passe et un nombre maximal de téléchargements.'],
            ['Y a-t-il des limites ?', 'Pour que le service reste équitable, ce site peut limiter ce que chaque visiteur et chaque serveur transfèrent par jour. Si vous atteignez une limite, {app} vous le dit ; les limites sont remises à zéro à minuit (heure du serveur). Sur votre propre installation, c’est vous qui fixez les limites.'],
        ],
        'Votre propre installation' => [
            ['Puis-je installer {app} sur mon propre serveur ?', 'Oui. Il vous faut un serveur web avec PHP 8.1 ou plus récent ; MySQL ou MariaDB est facultatif mais recommandé. Le [[install|guide d’installation]] prend environ 15 minutes.'],
        ],
    ],
    'related' => ['help', 'active-passive', 'ftp-ftps-sftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';

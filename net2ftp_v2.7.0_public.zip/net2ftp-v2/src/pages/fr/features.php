<?php
/** @var callable $h @var callable $url @var string $app */
$groups = [
    'Se connecter' => [
        ['FTP et FTPS', 'Mode passif et actif, FTP over TLS (explicite), serveurs Unix et Windows.'],
        ['SFTP / SSH', 'Mot de passe ou clé privée (RSA, ECDSA, Ed25519), avec un terminal SSH pour exécuter des commandes.'],
        ['Amazon S3', 'Toutes les régions, un seul bucket ou tous les buckets, identifiants temporaires, et stockages compatibles S3 comme MinIO, Wasabi, Cloudflare R2, Exoscale ou Infomaniak.'],
        ['Empreinte du serveur', 'Voyez la clé d\'hôte SSH ou le certificat TLS avant l\'envoi de votre mot de passe, et soyez averti s\'ils changent.'],
        ['Serveurs mémorisés', 'Jusqu\'à 5 connexions par navigateur, mot de passe chiffré, uniquement si vous autorisez les cookies de préférences.'],
        ['Favoris', 'Chaque dossier et chaque fichier a sa propre adresse, que vous pouvez mettre en favori. Les mots de passe ne figurent jamais dans les liens.'],
    ],
    'Parcourir et transférer' => [
        ['Liste de fichiers rapide', 'Triez, filtrez, sélectionnez au clavier ou à la souris, et ouvrez instantanément des dossiers de 10 000 fichiers.'],
        ['Envoi', 'Glissez-déposez des fichiers ou des dossiers entiers. Les gros fichiers sont envoyés par morceaux, deux à la fois, et un envoi interrompu reprend là où il s’était arrêté, même lors d’une session ultérieure.'],
        ['Téléchargement', 'Un fichier seul, ou n’importe quelle sélection de fichiers et de dossiers en un seul fichier zip. Le navigateur peut reprendre les téléchargements interrompus.'],
        ['Copier, déplacer, renommer, supprimer', 'Récursif pour les dossiers de toute taille. Les grosses tâches avancent par étapes, avec progression, pause et reprise, et continuent après votre prochaine connexion.'],
        ['Recherche', 'Trouvez du texte dans les fichiers, ou des fichiers par leur nom, dans toute une arborescence, avec expressions régulières et filtres de noms.'],
    ],
    'Travailler sur le serveur' => [
        ['Édition', 'Un éditeur de code avec coloration syntaxique pour PHP, HTML, CSS, JavaScript et 20 autres langages, rechercher-remplacer, et une protection contre l\'écrasement des modifications d\'autres personnes.'],
        ['Permissions', 'chmod et chown sur de nombreux fichiers et dossiers à la fois, récursivement, dans un ordre qui ne vous bloque jamais l\'accès.'],
        ['Extraction', 'Décompressez les archives .zip, .tar, .tar.gz et .tar.bz2 directement sur le serveur, en toute sécurité.'],
        ['Terminal SSH', 'Exécutez des commandes shell dans le dossier courant d’un serveur SFTP, sur les serveurs Linux et Windows.'],
        ['Liens de partage', 'Des liens de téléchargement à durée limitée, avec mot de passe et nombre de téléchargements facultatifs, comme WeTransfer. Les destinataires n\'ont jamais accès à votre serveur.'],
    ],
    'Sécurité et confidentialité' => [
        ['Identifiants chiffrés', 'Votre mot de passe est conservé chiffré pendant que vous êtes connecté, et n\'est jamais écrit en clair sur le disque.'],
        ['Journal des actions', 'Chaque action est journalisée, pour protéger les propriétaires de serveurs contre les abus.'],
        ['Choix des cookies', 'Uniquement les cookies nécessaires, sauf si vous en autorisez davantage. Aucun cookie publicitaire ni de suivi.'],
        ['Protection contre les abus', 'Les liens de partage refusent les programmes et les scripts, et des limites par visiteur protègent les serveurs auxquels vous vous connectez.'],
        ['Sans inscription', 'Connectez-vous avec le nom d’utilisateur et le mot de passe de votre serveur : aucun compte à créer.'],
        ['Open source', 'Sous licence GPL : vous pouvez lire, vérifier et installer le code vous-même.'],
    ],
    'Partout' => [
        ['11 langues', 'Anglais, allemand, espagnol, français, néerlandais, russe, chinois simplifié et traditionnel, japonais, hébreu et arabe, avec une mise en page inversée pour l\'hébreu et l\'arabe.'],
        ['Tous les appareils', 'Fonctionne dans tout navigateur récent, sur ordinateur, tablette et téléphone, en mode clair et sombre. Rien à installer.'],
    ],
];
?>
<h1>Fonctionnalités</h1>
<p class="pg-lead"><?= $h($app) ?> est un gestionnaire de fichiers pour vos serveurs FTP, SFTP et Amazon S3, qui fonctionne dans le navigateur.
  Tout ce qui suit fonctionne sans rien installer sur votre ordinateur. <a href="<?= $h($url('screenshots')) ?>">Voir les captures d'écran</a>.</p>
<?php foreach ($groups as $group => $items): ?>
  <h2><?= $h($group) ?></h2>
  <div class="pg-tiles">
    <?php foreach ($items as [$name, $text]): ?>
      <div class="pg-tile"><h3><?= $h($name) ?></h3><p><?= $h($text) ?></p></div>
    <?php endforeach ?>
  </div>
<?php endforeach ?>

<?php
$doc = [
    'title' => 'FTP, FTPS ou SFTP : lequel utiliser ?',
    'lead' => 'Tous les trois transfèrent des fichiers entre votre ordinateur et un serveur, mais deux seulement protègent votre mot de passe. Voici ce qui les distingue, et lequel choisir.',
    'article' => '2026-11-26',
    'sections' => [
        ['h' => 'Les trois en bref',
         'ul' => [
             '<b>FTP</b> est le File Transfer Protocol d’origine. Tout, y compris votre mot de passe, circule en clair.',
             '<b>FTPS</b> (FTP sur TLS) est du FTP avec le même chiffrement que les sites HTTPS. Les commandes et les fichiers sont protégés.',
             '<b>SFTP</b> n’a rien à voir avec FTP : c’est le transfert de fichiers par SSH, le protocole qu’utilisent les administrateurs pour se connecter aux serveurs. Tout est chiffré.',
         ]],
        ['h' => 'Comparaison',
         'table' => [
             ['', 'FTP', 'FTPS', 'SFTP'],
             ['Chiffré', 'Non', 'Oui', 'Oui'],
             ['Port habituel', '21', '21 (explicite)', '22'],
             ['Ports supplémentaires pour les données', 'Oui', 'Oui', 'Non'],
             ['Passage des pare-feu', 'Parfois difficile', 'Parfois difficile', 'Facile'],
             ['Connexion avec', 'Mot de passe', 'Mot de passe', 'Mot de passe ou clé'],
             ['Exécuter des commandes', 'Non', 'Non', 'Oui (SSH)'],
         ]],
        ['h' => 'Lequel choisir',
         'ol' => [
             '<b>SFTP</b>, si votre serveur le propose : chiffré, un seul port, et connexion possible par clé. Beaucoup d’hébergeurs l’appellent « accès SSH ».',
             '<b>FTPS</b>, si votre hébergeur ne propose que FTP : il prend généralement aussi en charge TLS. Dans {app}, cochez <i>FTP over TLS (FTPS)</i> dans les <i>Options avancées</i>.',
             '<b>FTP simple</b> seulement quand rien d’autre n’est possible, et jamais sur un Wi-Fi public.',
         ]],
        ['h' => 'Savoir ce que votre serveur prend en charge',
         'p' => [
             'Cherchez « SFTP », « SSH » ou « FTP sur TLS » dans l’e-mail de bienvenue ou le panneau de contrôle de votre hébergeur. Vous pouvez aussi simplement essayer : choisissez <b>SFTP / SSH</b> sur la [[login|page de connexion]] avec vos nom d’utilisateur et mot de passe habituels ; si cela ne se connecte pas, choisissez <b>FTP</b> avec <i>FTP over TLS (FTPS)</i> activé. {app} prend en charge le FTPS explicite, la forme courante sur le port 21.',
         ]],
    ],
    'related' => ['sftp-client', 'active-passive', 'online-ftp'],
];
require N2F_ROOT . '/src/pages/_shared/guide.php';
